from __future__ import print_function
import os

var=os.environ['MYVAR']
print(var)