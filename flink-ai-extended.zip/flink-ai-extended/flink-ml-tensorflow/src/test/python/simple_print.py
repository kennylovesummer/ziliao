from __future__ import print_function
import sys


def map_func(context):
    for i in range(2):
        print("hello world!")
        sys.stdout.flush()


if __name__ == "__main__":
    pass
