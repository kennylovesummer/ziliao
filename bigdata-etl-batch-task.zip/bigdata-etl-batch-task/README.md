spark-submit \
--master yarn \
--deploy-mode client \
--class com.intellif.dataplatform.batch.task.PersonEventBatchEtlTask \
--num-executors 16 \
--executor-cores 2 \
--executor-memory 4G \
--files PersonEventEtlTask.properties \
etl-batch-task.jar --partitions 64