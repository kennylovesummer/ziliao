```scala
  /**
    * 构建归档数据集合，聚档数据集合
    *
    * @param iterator 迭代器
    * @return
    */
  protected def buildFaceEventList(iterator: Iterator[FaceEvent]): (ArrayBuffer[FaceEvent], ArrayBuffer[FaceEvent], ArrayBuffer[FaceEvent], ArrayBuffer[FaceEvent]) = {
    // 可聚档
    val clusterFaceEvents = new ArrayBuffer[FaceEvent]()
    // 可归档不可聚档
    val classFaceEvents = new ArrayBuffer[FaceEvent]()
    // 不可归档不可聚档
    val unlessFaceEvents = new ArrayBuffer[FaceEvent]()
    // 小孩
    val childFaceEvents = new ArrayBuffer[FaceEvent]()

    while (iterator.hasNext) {
      val faceEvent = iterator.next()
      // 年龄过滤
      val ageFilter = {
        try {
          case class AgeInfo(value: Int, confidence: Float)
          JSON.parseObject(faceEvent.age_info, classOf[AgeInfo]).value > config.realAgeThreshold
        } catch {
          case e: Throwable =>
            println(s"======> parse json to AgeInfo POJO failure! Exception is $e")
            false
        }
      }

      // 聚档特征值质量过滤
      val clusterFeatureFilter = faceEvent.feature_quality.compareTo(Predef.float2Float(0.0f)) > 0

      // 归档特征值质量过滤
      val classFeatureFilter = faceEvent.feature_quality.compareTo(Predef.float2Float(-1.0f)) >= 0

      // featureQuality 大于 0 表示可聚档
      if (ageFilter) {
        if (clusterFeatureFilter) {
          clusterFaceEvents.append(faceEvent)
        } else if (classFeatureFilter) {
          classFaceEvents.append(faceEvent)
        } else {
          unlessFaceEvents.append(faceEvent)
        }
      } else {
        childFaceEvents.append(faceEvent)
      }
    }
    (clusterFaceEvents, classFaceEvents, unlessFaceEvents, childFaceEvents)
  }


/**
  * 预处理后的 FaceEvent
  *
  * @param sys_code           源系统 code
  * @param thumbnail_id       小图唯一标识
  * @param thumbnail_url      小图 url
  * @param image_id           人脸小图对应大图唯一标识
  * @param image_url          大图 url
  * @param feature_info       特征值
  * @param algo_version       算法版本
  * @param gender_info        性别信息
  * @param age_info           年龄信息
  * @param hairstyle_info     发型信息
  * @param hat_info           帽子信息
  * @param glasses_info       眼镜信息
  * @param race_info          族别信息
  * @param mask_info          口罩信息
  * @param skin_info          皮肤信息
  * @param pose_info          角度信息
  * @param quality_info       质量信息
  * @param taraget_rect       人脸框位置信息
  * @param taraget_rect_float 人脸框位置信息
  * @param land_mark_info     一些脸部轮廓信息
  * @param source_id          采集源id
  * @param source_type        采集源类型
  * @param site               地点
  * @param time               抓拍时间
  * @param create_time        数据存入时间
  * @param feature_quality    根据角度、质量分值等计算出的质量指标
  * @param column1            扩展字段备用
  * @param column2            扩展字段备用
  * @param column3            扩展字段备用
  */
case class FaceEvent(sys_code: String, thumbnail_id: String, thumbnail_url: String, image_id: String, image_url: String,
                     feature_info: Array[Byte], algo_version: Int, gender_info: String, age_info: String,
                     hairstyle_info: String, hat_info: String, glasses_info: String, race_info: String,
                     mask_info: String, skin_info: String, pose_info: String, quality_info: Float,
                     taraget_rect: String, taraget_rect_float: String, land_mark_info: String, source_id: Long,
                     source_type: Int, site: String, time: Timestamp, create_time: Timestamp,
                     feature_quality: Float, column1: String, column2: String, column3: String)
                     
                     
  def partitionFunc(iterator: Iterator[FaceEvent]): Unit = {

    if (iterator.isEmpty) {
      return
    }

    val tuple = buildFaceEventList(iterator)
    println(s"======> partition ${TaskContext.getPartitionId()} has " +
      s"${tuple._1.length} cluster data, " +
      s"${tuple._2.length} class data, " +
      s"${tuple._3.length} unless data, " +
      s"${tuple._4.length} children data")

    var conn: Connection = null
    try {
      conn = ConnectionUtils.getConnection(config.dbUrl, config.dbUser, config.dbPasswd)
      conn.setAutoCommit(false)
      batchInsertFunc(tuple._1, conn, config.processedTable)
/*      batchInsertFunc(tuple._2, conn, config.classTable)
      batchInsertFunc(tuple._3, conn, config.uselessTable)
      batchInsertFunc(tuple._4, conn, config.childrenTable)*/
      conn.commit()
    } catch {
      case e: Exception =>
        println("======> insert data failure", e)
        if (conn != null) {
          try {
            conn.rollback()
          } catch {
            case e: Exception => println("======> rollback failure", e)
          }
        }
        throw e
    } finally {
      ConnectionUtils.closeConnection(conn)
    }
  }

  private def batchInsertFunc(faceEvents: ArrayBuffer[FaceEvent], conn: Connection, table: String): Unit = {
    if (faceEvents.isEmpty) {
      return
    }
    var pstmt: PreparedStatement = null
    try {
      val sql = s"insert into $table(sys_code, thumbnail_id, thumbnail_url, image_id, image_url, feature_info, " +
        s"algo_version, gender_info, age_info, hairstyle_info, hat_info, glasses_info, race_info, mask_info, " +
        s"skin_info, pose_info, quality_info, taraget_rect, taraget_rect_float, land_mark_info, source_id, " +
        s"source_type, site, time, create_time, column1, column2, column3) " +
        s"values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      var sum = 0
      var i = 0
      pstmt = conn.prepareStatement(sql)
      for (index <- faceEvents.indices) {
        i += 1
        sum += 1
        if (i > config.dbBatchsize) {
          i = 0
          pstmt.executeBatch()
          pstmt.clearBatch()
        }
        val faceEvent = faceEvents(index)
        pstmt.setString(1, faceEvent.sys_code)
        pstmt.setString(2, faceEvent.thumbnail_id)
        pstmt.setString(3, faceEvent.thumbnail_url)
        pstmt.setString(4, faceEvent.image_id)
        pstmt.setString(5, faceEvent.image_url)
        pstmt.setBytes(6, faceEvent.feature_info)
        pstmt.setInt(7, faceEvent.algo_version)
        pstmt.setString(8, faceEvent.gender_info)
        pstmt.setString(9, faceEvent.age_info)
        pstmt.setString(10, faceEvent.hairstyle_info)
        pstmt.setString(11, faceEvent.hat_info)
        pstmt.setString(12, faceEvent.glasses_info)
        pstmt.setString(13, faceEvent.race_info)
        pstmt.setString(14, faceEvent.mask_info)
        pstmt.setString(15, faceEvent.skin_info)
        pstmt.setString(16, faceEvent.pose_info)
        pstmt.setFloat(17, faceEvent.quality_info)
        pstmt.setString(18, faceEvent.taraget_rect)
        pstmt.setString(19, faceEvent.taraget_rect_float)
        pstmt.setString(20, faceEvent.land_mark_info)
        pstmt.setLong(21, faceEvent.source_id)
        pstmt.setInt(22, faceEvent.source_type)
        pstmt.setString(23, faceEvent.site)
        pstmt.setTimestamp(24, faceEvent.time)
        pstmt.setTimestamp(25, faceEvent.create_time)
        pstmt.setString(26, faceEvent.column1)
        pstmt.setString(27, faceEvent.column2)
        pstmt.setString(28, faceEvent.column3)
        pstmt.addBatch()
      }
      pstmt.executeBatch()
    } finally {
      ConnectionUtils.closeStatement(pstmt)
    }
  }


object AgeUtils {

  /**
    * age占用两个字节，分别表示年龄的区间和实际的年龄值，先左移8位（该8位用于表示年龄段），得到高八位，转换为十进制，用于表示真实年龄
    *
    * @param ageInfo 年龄信息
    * @return 是否是真实年龄 true，返回真实年龄， false，返回年龄段
    */
  def parseRealAge(ageInfo: Int): (Boolean, Int) =
    if (ageInfo > 255) {
      (true, Integer.valueOf(Integer.toBinaryString(ageInfo >> 8), 2))
    } else {
      (false, ageInfo)
    }
}
```