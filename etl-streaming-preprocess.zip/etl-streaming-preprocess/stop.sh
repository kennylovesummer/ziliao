 #!/bin/bash

    curl http://127.0.0.1:19999/close/

  echo "stop finish"