package com.intellif.dataplatform.streaming.preprocess.job

import java.sql.{Connection, PreparedStatement, Timestamp}
import java.time.LocalDateTime

import cn.hutool.crypto.SecureUtil
import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializeFilter
import com.intellif.dataplatform.common.domain.EventFace
import com.intellif.dataplatform.streaming.preprocess.ability.CalculateFeatureQuality
import com.intellif.dataplatform.streaming.preprocess.config.{CommandLineArgs, ConfigArgs}
import com.intellif.dataplatform.streaming.preprocess.http.CloseHttpServer
import com.intellif.dataplatform.streaming.preprocess.util.{ConnectionPool, KafkaSender, ZkKafkaOffset}
import org.apache.commons.lang3.StringUtils
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.{StringDeserializer, StringSerializer}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, HasOffsetRanges, KafkaUtils, LocationStrategies}
import org.apache.spark.streaming.{Durations, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext, TaskContext}

import scala.collection.JavaConversions
import scala.collection.mutable.ArrayBuffer

/**
  * @author w1992wishes 2019/4/25 19:59
  */
object StreamingPreProcessJob extends Serializable with CalculateFeatureQuality {

  val config: ConfigArgs = ConfigArgs()

  def main(args: Array[String]): Unit = {

    val command: CommandLineArgs = new CommandLineArgs(args)

    // consumer
    val groupId = config.kafkaGroupId
    val kfkServers = config.kafkaServers
    val topicStr = config.kafkaOdlTopic
    val topics = topicStr.split(",")
    val receiveBufferBytes = config.properties.getProperty("kafka.receive.buffer.bytes").toInt
    val maxPartitionFetchBytes = config.properties.getProperty("kafka.max.partition.fetch.bytes").toInt
    val autoOffsetReset = config.properties.getProperty("kafka.auto.offset.reset")
    val kafkaConf = Map[String, Object](
      "bootstrap.servers" -> kfkServers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> groupId,
      "receive.buffer.bytes" -> (receiveBufferBytes: java.lang.Integer),
      "max.partition.fetch.bytes" -> (maxPartitionFetchBytes: java.lang.Integer),
      "auto.offset.reset" -> autoOffsetReset,
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
    // sparkstreaming conf
    val conf = new SparkConf().setAppName(config.streamingAppName).setIfMissing("spark.master", "local[2]")
    conf.set("kafka.zk.hosts", config.zookeeperServers)
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")
    val ssc = new StreamingContext(sc, Durations.seconds(command.batchDuration))

    // 构建 stream
    val offsetId = SecureUtil.md5(groupId + topics.mkString(","))
    val kafkaOffset = ZkKafkaOffset(ssc.sparkContext.getConf, offsetId)
    kafkaOffset.initOffset()
    val customOffset: Map[TopicPartition, Long] = kafkaOffset.getOffset
    var stream: InputDStream[ConsumerRecord[String, String]] = null
    if (customOffset.isEmpty) {
      stream = KafkaUtils.createDirectStream[String, String](ssc,
        LocationStrategies.PreferConsistent,
        ConsumerStrategies.Subscribe[String, String](topics, kafkaConf))
    } else {
      stream = KafkaUtils.createDirectStream[String, String](ssc,
        LocationStrategies.PreferConsistent,
        ConsumerStrategies.Assign[String, String](customOffset.keySet, kafkaConf, customOffset))
    }

    // kafka producer
    val kafkaSender: Broadcast[KafkaSender[String, String]] = {
      val kafkaProducerConf = Map[String, Object](
        "bootstrap.servers" -> kfkServers,
        "key.serializer" -> classOf[StringSerializer],
        "value.serializer" -> classOf[StringSerializer],
        "client.id" -> "dwd_event_face_output",
        "acks" -> config.properties.getProperty("kafka.acks"),
        "retries" -> config.properties.getProperty("kafka.retries"),
        "batch.size" -> config.properties.getProperty("kafka.batch.size"),
        "linger.ms" -> config.properties.getProperty("kafka.linger.ms"),
        "buffer.memory" -> config.properties.getProperty("kafka.buffer.memory")
      )
      println("****** kafka producer init done! ******")
      ssc.sparkContext.broadcast(KafkaSender[String, String](kafkaProducerConf))
    }

    // 消费数据
    stream
      .foreachRDD(kafkaRdd => {
        val offsetRanges = kafkaRdd.asInstanceOf[HasOffsetRanges].offsetRanges
        kafkaOffset.updateOffset(offsetRanges)

        println("****** Start processing RDD data ******")
        val eventFaceRdd = kafkaRdd.map(json => JSON.parseObject(json.value(), classOf[EventFace]))
        doAction(eventFaceRdd.repartition(command.partitions), kafkaSender)

        kafkaOffset.commitOffset(offsetRanges)
      })

    CloseHttpServer.daemonHttpServer(config.streamingClosePort, ssc)
    ssc.start()
    ssc.awaitTermination()
  }

  private def doAction(eventFaceRdd: RDD[EventFace],
                       kafkaSender: Broadcast[KafkaSender[String, String]]): Unit = {
    eventFaceRdd
      .map(eventFace => {
        eventFace.setFeatureQuality(
          calculateFeatureQuality(config)(eventFace.getFeatureInfo, eventFace.getPoseInfo, eventFace.getQualityInfo))
        eventFace.setSaveTime(Timestamp.valueOf(LocalDateTime.now().withNano(0)))
        eventFace
      }).foreachPartition(iter => partitionFunc(iter, kafkaSender))
  }

  private def writeSql(): String = {
    val holders = StringUtils.join(JavaConversions.seqAsJavaList((1 to 30).map(_ => "?")), ",")
    s"insert into ${config.dwdTable} (sys_code, thumbnail_id, thumbnail_url, image_id, image_url, " +
      "feature_info, algo_version, gender_info, age_info, hairstyle_info, " +
      "hat_info, glasses_info, race_info, mask_info, skin_info, " +
      "pose_info, quality_info, target_rect, target_rect_float, land_mark_info, " +
      "source_id, source_type, site, time, create_time, " +
      "feature_quality, save_time, column1, column2, column3) " + s"VALUES($holders)"
  }

  private def partitionFunc(iter: Iterator[EventFace], kafkaSender: Broadcast[KafkaSender[String, String]]): Unit = {
    if (!iter.hasNext) {
      return
    }

    val eventFaces: ArrayBuffer[EventFace] = new ArrayBuffer[EventFace]()
    while (iter.hasNext) {
      eventFaces += iter.next()
    }

    println("****** Start send kafka message ******")
    val sendKafkaRdd: ArrayBuffer[EventFace] = eventFaces.filter(_.getFeatureQuality.compareTo(-1.0f) >= 0)
    sendKafkaRdd.foreach(eventFace =>
      kafkaSender.value.send(config.kafkaDwdTopic, JSON.toJSONString(eventFace, new Array[SerializeFilter](0))))
    println(s"****** End send kafka message, ${sendKafkaRdd.size} totally ******")

    if (config.saveDbEnable) {
      println("****** Start save db ******")
      saveToDB(eventFaces)
      println("****** End save db ******")
    }
    println(s"****** Partition_${TaskContext.get.partitionId} preProcess ${eventFaces.length} data totally ******")
  }

  private def fillPreparedStatement(ps: PreparedStatement, eventFace: EventFace): Unit = {
    ps.setString(1, eventFace.getSysCode)
    ps.setString(2, eventFace.getThumbnailId)
    ps.setString(3, eventFace.getThumbnailUrl)
    ps.setString(4, eventFace.getImageId)
    ps.setString(5, eventFace.getImageUrl)
    ps.setBytes(6, eventFace.getFeatureInfo)
    ps.setInt(7, eventFace.getAlgoVersion)
    ps.setString(8, eventFace.getGenderInfo)
    ps.setString(9, eventFace.getAgeInfo)
    ps.setString(10, eventFace.getHairstyleInfo)
    ps.setString(11, eventFace.getHatInfo)
    ps.setString(12, eventFace.getGlassesInfo)
    ps.setString(13, eventFace.getRaceInfo)
    ps.setString(14, eventFace.getMaskInfo)
    ps.setString(15, eventFace.getSkinInfo)
    ps.setString(16, eventFace.getPoseInfo)
    ps.setFloat(17, if (eventFace.getQualityInfo == null) 0f else eventFace.getQualityInfo)
    ps.setString(18, eventFace.getTargetRect)
    ps.setString(19, eventFace.getTargetRectFloat)
    ps.setString(20, eventFace.getLandMarkInfo)
    ps.setLong(21, eventFace.getSourceId)
    ps.setInt(22, eventFace.getSourceType)
    ps.setString(23, eventFace.getSite)
    ps.setTimestamp(24, eventFace.getTime)
    ps.setTimestamp(25, Timestamp.valueOf(eventFace.getCreateTime.toLocalDateTime.withNano(0)))
    ps.setFloat(26, eventFace.getFeatureQuality)
    ps.setTimestamp(27, eventFace.getSaveTime)
    ps.setString(28, eventFace.getColumn1)
    ps.setString(29, eventFace.getColumn2)
    ps.setString(30, eventFace.getColumn3)
  }

  private def saveToDB(eventFaces: ArrayBuffer[EventFace]): Unit = {
    var conn: Connection = null
    var ps: PreparedStatement = null
    try {
      conn = ConnectionPool(config.dbcpProperties)
      conn.setAutoCommit(false)
      ps = conn.prepareStatement(writeSql())
      var amount = 0
      var i = 0
      for (eventFace <- eventFaces) {
        if (i >= config.dwdBatchSize) {
          i = 0
          ps.executeBatch()
          conn.commit()
        }
        i += 1
        amount += 1
        fillPreparedStatement(ps, eventFace)
        ps.addBatch()
      }
      ps.executeBatch()
      conn.commit()
    } finally {
      ConnectionPool.closeResource(conn, ps, rs = null)
    }
  }
}
