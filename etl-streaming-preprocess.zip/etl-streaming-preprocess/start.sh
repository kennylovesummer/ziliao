#!/bin/bash

MASTER="spark://127.0.0.1:50002"
DEPLOY_MODE="client"
APP_MAINCLASS="com.intellif.dataplatform.streaming.preprocess.job.StreamingPreProcessJob"
EXECUTOR_MEMORY="4G"
TOTAL_EXECUTOR_CORES=8
EXECUTOR_CORES=2
CONF_FILE="config.properties"
APP_JAR="etl-streaming-preprocess.jar"
APP_ARG="--partitions 24"

nohup spark-submit \
--master $MASTER \
--deploy-mode $DEPLOY_MODE \
--class $APP_MAINCLASS \
--executor-memory $EXECUTOR_MEMORY \
--total-executor-cores $TOTAL_EXECUTOR_CORES \
--executor-cores $EXECUTOR_CORES \
--files $CONF_FILE \
$APP_JAR $APP_ARG \
> etl_streaming_preprocess.log 2>&1 &