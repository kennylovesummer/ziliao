package com.atguigu.gmall1205.publisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gmall1205PublisherApplication {

    public static void main(String[] args) {
        SpringApplication.run(Gmall1205PublisherApplication.class, args);
    }

}
