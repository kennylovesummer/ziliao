package com.atguigu.gmall1205.logger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gmall1205LoggerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Gmall1205LoggerApplication.class, args);
    }

}
