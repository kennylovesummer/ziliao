package com.atguigu.gmall1205.common.constant;

public class GmallConstant {


    public static final String KAFKA_TOPIC_STARTUP="GMALL_STARTUP";
    public static final String KAFKA_TOPIC_EVENT="GMALL_EVENT";
    public static final String KAFKA_TOPIC_ORDER="GMALL_ORDER";

    public static final String ES_INDEX_DAU="gmall1205_dau";
    public static final String ES_INDEX_ORDER="gmall1205_order";
    public static final String ES_INDEX_SALE="gmall1205_sale_detail";
}
