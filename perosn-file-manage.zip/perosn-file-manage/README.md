# 天图

## 项目介绍

### 概述
此项目是基于天图数据层，为天图数据展示提供业务接口；其目前主要功能模块包括：档案展示、事件展示、关系展示、数据分析以及数据统计

### 涉及技术
* 基础框架：spring cloud + mybatis - 其中spring boot 1.5.8
* 中间件：kafka 1.1.0
* 搜索引擎： solr
* 日志：log4j2
* API文档管理：Swagger2

### rel_1.3.0版本
* 将person-file-job,person-file-manage,person-file-datastatistics三个项目合并为perosn-file-manage 一个项目，其中数据库也由三个变为一个，即删除person_file_job,person_file_datastatistics两个数据库，合并为一个数据库即person_file_manage
* 实行档案和事件分表；分表规则：档案按档案ID取模分为十个表；事件按抓拍日期和数量分表，即初次按照抓拍日期分表，当达到一定量再拉出拓展表
* 定时任务由原来的quartz2换为spring schedule
* 实行MySQL主从复制，一主一从模式
* 新增昼伏夜出、活动规律以及徘徊分析
* 新增用户管理、登录模块
* 修改档案推荐逻辑，由原来的从solr查询相似档推荐改为从底层数据层拉取相似档推荐
* 去除刷solr（将档案导入solr）功能
* 事件统计由原来按创建时间每天统计改为按抓拍时间统计
* 新增关系图谱去除相似档机制

### 主要功能说明
#### 档案
* 数据来源：基础数据层往kafka推送档案数据 -> 服务从kafka拉取档案数据并存入Mysql，以此同时也会将带有特征值的档案(档案ID和特征值)刷入solr
* 数据统计：定时统计前两天每天的新增档案数、新增实名档案数、实名档案总数以及档案总数
* 以图搜档：通过档案头像或者用户上传的图片去结构化引擎获取特征值，然后带着特征值通过solr api相应接口去solr里查询相似档案，注意：最多返回100条相似数据（可配）
* 档案合并：当两个档案相似时，可以通过合并功能将它们合并为一个档案。此时合并的档案信息会得到更新，如果被合并的档案是实名的，且被合并的档案会被删除其事件会被放入回收站
* 标签地图：将搜索得到的带有对应标签的档案以地图热力图的形式展现其出现的位置
* 年龄统计：目前是定时统计每个年龄段的人数，年龄段定义在后台已约定无法动态修改
* 档案推荐：调用数据层接口获取相似档，最多返回100个相似档（可配）
#### 事件
* 数据来源：基础数据层往kafka推送事件数据 -> 服务从kafka拉取事件数据并存入Mysql
* 事件统计：定时统计每天事件总数，统计所有事件表
* 事件流：根据时间降序排序展现单个档案每天的事件信息
* 活动规律分析：该人在某地点出现次数大于3次就是落脚点 否则是异常行为
#### 回收站
* 数据来源：删除档案以及合并档案时会把被删除或者被合并档案的事件放入回收站
* 业务功能：定时将回收站数据推送至kafka进行重新归档
#### 关系图谱
* 数据来源：通过调用底层数据接口获取相应关系数据
* 相关默认参数设置：通过高级管理中的关系图谱设置设置默认的搜索参数
#### 数据分析
* 数据来源：用户创建分析任务 -> 此服务通过调用底层数据服务创建分析job -> 此服务自旋调用底层服务获取任务状态直至成功或者失败 -> 若成功则从基础数据层拉取任务结果并保存至 person_file_manage 数据库
* 数据导出：用户创建导出任务 -> 此服务开启对应线程进行下载，并将数据下载至服务器、打包；用户点击下载 -> 此服务根据相应的文件目录将压缩包返回
#### 项目目录结构
```
src
 ├─main
 │  ├─java
 │  │  └─com
 │  │      └─intellif
 │  │          └─cloud
 │  │              └─personfile
 │  │                  └─manage
 │  │                      ├─annotation
 │  │                      ├─aspect
 │  │                      ├─config
 │  │                      ├─contants
 │  │                      ├─controllers
 │  │                      │  ├─api
 │  │                      │  └─sso
 │  │                      ├─entity
 │  │                      ├─enums
 │  │                      ├─exceptions
 │  │                      ├─feignclient
 │  │                      │  └─fallback
 │  │                      ├─handler
 │  │                      │  └─analysis
 │  │                      │      ├─createTask
 │  │                      │      └─syncResult
 │  │                      ├─kafka
 │  │                      │  ├─consumer
 │  │                      │  └─producer
 │  │                      ├─model
 │  │                      │  ├─dto
 │  │                      │  │  ├─account
 │  │                      │  │  ├─analysis
 │  │                      │  │  │  ├─offLine
 │  │                      │  │  │  │  ├─in
 │  │                      │  │  │  │  │  └─base
 │  │                      │  │  │  │  └─out
 │  │                      │  │  │  │      └─base
 │  │                      │  │  │  └─online
 │  │                      │  │  ├─camera
 │  │                      │  │  ├─cluster
 │  │                      │  │  ├─label
 │  │                      │  │  ├─personfile
 │  │                      │  │  ├─relationship
 │  │                      │  │  ├─req
 │  │                      │  │  ├─snap
 │  │                      │  │  └─xdata
 │  │                      │  └─vo
 │  │                      │      ├─activityRoutine
 │  │                      │      ├─analysis
 │  │                      │      ├─crash
 │  │                      │      ├─label
 │  │                      │      ├─peer
 │  │                      │      ├─personfile
 │  │                      │      ├─relationship
 │  │                      │      ├─snap
 │  │                      │      ├─statistic
 │  │                      │      ├─thrift
 │  │                      │      └─xdata
 │  │                      ├─plugin
 │  │                      ├─schedule
 │  │                      │  ├─age
 │  │                      │  ├─archive
 │  │                      │  ├─camera
 │  │                      │  ├─event
 │  │                      │  └─rubbish
 │  │                      ├─services
 │  │                      │  ├─account
 │  │                      │  │  └─impl
 │  │                      │  ├─analysis
 │  │                      │  │  └─impl
 │  │                      │  ├─base
 │  │                      │  ├─datastistic
 │  │                      │  │  └─impl
 │  │                      │  ├─general
 │  │                      │  │  └─impl
 │  │                      │  └─sub
 │  │                      │      └─impl
 │  │                      ├─task
 │  │                      │  └─monitor
 │  │                      ├─thrift
 │  │                      │  ├─ifaas
 │  │                      │  └─thrift
 │  │                      └─utils
 │  └─resources
 │      ├─db
 │      │  ├─migration
 │      │  └─sub
 │      ├─META-INF
 │      └─mybatis
 │          └─mappings
 │              └─mysql
 │                  ├─extend
 │                  │  └─manage
 │                  └─table
 │                      └─manage
 └─test
     └─java
         └─com
             └─intellif
                 └─cloud
                     └─personfile
                         └─manage
                             ├─feignclient
                             ├─kafka
                             │  ├─consumer
                             │  └─producer
                             ├─services
                             │  ├─analysis
                             │  │  └─impl
                             │  ├─general
                             │  │  └─impl
                             │  └─sub
                             └─solr