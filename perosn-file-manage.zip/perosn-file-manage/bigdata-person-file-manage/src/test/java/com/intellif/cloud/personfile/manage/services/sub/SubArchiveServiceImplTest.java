package com.intellif.cloud.personfile.manage.services.sub;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.text.ParseException;
import java.util.*;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class SubArchiveServiceImplTest {
    
    @Autowired
    private SubArchiveServiceImpl subArchiveService;
    
    @Autowired
    private SubEventServiceImpl subEventService;
    
    @Before
    public void initTableCache() {
        subArchiveService.getAllTableFromDB(true,true);
    }
    
    @Test
    public void findBaseInfoByPersonFileId() {
        PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8");
    }
    
    @Test
    public void findBaseInfoByLabels() {
        List<Integer> labels = Lists.newArrayList();
        labels.add(1);
        List<String> person = subArchiveService.findBaseInfoByLabels(labels);
    }
    
    @Test
    public void findBaseInfoVOByPersonFileId() {
        PersonfileBasicsVO personfileBasicsVO = subArchiveService.findBaseInfoVOByPersonFileId("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8");
    }
    
    @Test
    public void insertPersonfileBasicsLabel() {
    }
    
    @Test
    public void deletePersonfileBasicsLabel() {
        subArchiveService.deletePersonfileBasicsLabel("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8", 1);
    }
    
    @Test
    public void updatePersonfileBasics() {
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8");
        personfileBasics.setCid("11111");
        subArchiveService.updatePersonfileBasics(personfileBasics);
    }
    
    @Test
    public void deleteByPersonfileIdPersonfileBasics() {
        subArchiveService.deleteByPersonfileIdPersonfileBasics("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8");
    }
    
    @Test
    public void batchInsertPersonfileBasics() {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        List<PersonfileSnap> personfileSnapList = Lists.newLinkedList();
        for (int i = 1; i < 5; i++) {
            String aid = UUID.randomUUID().toString().replaceAll("-", "y" + i);
            
            PersonfileBasics personfileBasics = new PersonfileBasics();
            personfileBasics.setName("cccc" + i);
            personfileBasics.setCid("1");
            personfileBasics.setPersonFilesId(aid);
            personfileBasics.setPersonFileCreateTime(DateUtils.addDays(new Date(), i));
            personfileBasicsList.add(personfileBasics);
            
            PersonfileSnap personfileSnap = new PersonfileSnap();
//            personfileSnap.setAlgoVersion(5029);
            personfileSnap.setFaceId("123");
            personfileSnap.setFaceUrl("123333");
            personfileSnap.setImageUrl("321");
            personfileSnap.setImageId("321");
            personfileSnap.setSysCode("333");
            personfileSnap.setSourceId("333");
//            personfileSnap.setSourceType(1);
            personfileSnap.setSnapTime(DateUtils.addDays(new Date(), i));
            personfileSnap.setPersonFilesId(aid);
            personfileSnapList.add(personfileSnap);
        }
        subArchiveService.batchInsertPersonfileBasics(personfileBasicsList);
        subEventService.batchInsert(personfileSnapList);
    }
    
    @Test
    public void batchUpdatePersonfileBasics() {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId("18cd82d0y34c0ay3412ay3a0acy36167e6f366ce");
        personfileBasics.setBirthDate(new Date());
        personfileBasicsList.add(personfileBasics);
        
        PersonfileBasics personfileBasics1 = new PersonfileBasics();
        personfileBasics1.setPersonFilesId("2ad1988by78b3y4116ya306y6ea4f2e96b53");
        personfileBasics1.setBirthDate(new Date());
        personfileBasics1.setPersonFileCreateTime(new Date());
        personfileBasicsList.add(personfileBasics1);
        
        subArchiveService.batchUpdatePersonfileBasics(personfileBasicsList);
    }
    
    @Test
    public void findAutoByParam() {
        Map<String, Object> params = new HashMap<>();
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        params.put("personFilesIds", aids);
        List<PersonfileBasics> personfileBasicsList = subArchiveService.findAutoByParam(params);
    }
    
    @Test
    public void statisticNewPersonfile() {
        Integer total = subArchiveService.statisticNewPersonfile("2019-08-31 00:00:00", "2019-08-31 23:59:59", false);
    }
    
    @Test
    public void personfileHandle() {
    }
    
    @Test
    public void findByPersonfileIds() {
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        List<Map<String, Object>> result = subArchiveService.findByPersonfileIds(aids);
    }
    
    @Test
    public void findByFilterParams() {
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        listFilterDTO.setPersonFileIds(aids);
        BasePageRespDTO basePageRespDTO = subArchiveService.findByFilterParams(listFilterDTO);
    }
    
    @Test
    public void findByParams() {
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        listFilterDTO.setPersonFileIds(aids);
        List<PersonfileVO> result = subArchiveService.findByParams(listFilterDTO);
    }
    
    @Test
    public void findPersonfilePageTotal() {
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        listFilterDTO.setPersonFileIds(aids);
        Long total = subArchiveService.findPersonfilePageTotal(listFilterDTO);
    }
    
    @Test
    public void findByPage() {
        List<PersonfileClusterFinishDTO> result = subArchiveService.findByPage(0, 1);
    }
    
    @Test
    public void findDeletedPersonfilesId() {
        List<String> aids = Lists.newArrayList();
        aids.add("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        aids.add("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        subArchiveService.findDeletedPersonfilesId(aids);
    }
    
    @Test
    public void updateImageCount() {
        subArchiveService.updateImageCount(1, "d405a0e2y222b7y244fay2b70ey28e64dc2d13b7");
    }
    
    @Test
    public void statisticAge() {
//        List<Map<String, Object>> result = subArchiveService.statisticAge(0,10);
    }
    
    @Test
    public void statisticImageCountAndGetRecentSnapTime() throws ParseException {
        subArchiveService.statisticImageCountAndGetRecentSnapTime();
    }
    
    @Test
    public void findCount() {
//        String tableName = subArchiveService.initTableCount("t_bigdata_archive_20190910");
    }
    
}