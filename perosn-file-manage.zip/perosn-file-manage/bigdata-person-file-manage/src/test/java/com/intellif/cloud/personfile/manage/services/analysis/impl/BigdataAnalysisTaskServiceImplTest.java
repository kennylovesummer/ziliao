package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskListDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.HashMap;
import java.util.Map;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisTaskServiceImplTest {
    
    @Autowired
    private BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    @Test
    public void findBigdataCrashTaskById() {
        bigdataAnalysisTaskService.findBigdataAnalysisTaskById(29l);
    }
    
    @Test
    public void insertBigdataCrashTask() {
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setName("test");
        
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
    }
    
    @Test
    public void updateBigdataCrashTask() {
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setId(29l);
        bigdataAnalysisTask.setName("test");
        
        bigdataAnalysisTaskService.updateBigdataAnalysisTask(bigdataAnalysisTask);
    }
    
    @Test
    public void findBigdataCrashTaskByParams() {
        AnalysisTaskListDTO crashListDTO = new AnalysisTaskListDTO();
        crashListDTO.setPageNo(1);
        crashListDTO.setPageSize(15);
        
        bigdataAnalysisTaskService.findBigdataAnalysisTaskByParams(crashListDTO);
    }
    
    @Test
    public void updateStatusByOldStatus() {
        
    
    }
}