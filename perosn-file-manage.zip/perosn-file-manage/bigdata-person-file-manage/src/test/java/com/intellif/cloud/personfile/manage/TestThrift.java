package com.intellif.cloud.personfile.manage;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.vo.thrift.Attributes;
import com.intellif.cloud.personfile.manage.model.vo.thrift.FaceAttrInfo;
import com.intellif.cloud.personfile.manage.model.vo.thrift.Headpose;
import com.intellif.cloud.personfile.manage.model.vo.thrift.Pose;
import com.intellif.cloud.personfile.manage.thrift.ifaas.E_FACE_ATTRIBUTE_LIST;
import com.intellif.cloud.personfile.manage.thrift.ifaas.IFaaServiceThriftClient;
import com.intellif.cloud.personfile.manage.thrift.ifaas.T_AttrDetectRstItem_v2;
import com.intellif.cloud.personfile.manage.thrift.ifaas.T_MulAttrDetectRstRsp_v2;
import org.apache.thrift.TException;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description :
 * @Author dyl
 * @Date 17:14 2018/12/26
 */
public class TestThrift {

    public static void main(String[] args) throws TException {

        String server_ip = "192.168.11.26";
        int server_port = 13456;


        IFaaServiceThriftClient iFaaServiceThriftClient = IFaaServiceThriftClient.getInstance(server_ip, server_port);

//        String pic_url = "http://192.168.11.100/eng1store1_11100_0/FaceWareHouse/src_0_3/20181113/20181113T130843_149920_199169.jpg";

        String pic_url = "http://192.168.11.26/17w/362101197611071930_111154.jpg";
        List<Integer> attrList = new ArrayList<Integer>();
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_AGE.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_DRESS.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue());


        String s = Integer.toBinaryString(7);
        String format = String.format("%04d", Long.parseLong(s));

        BigInteger bi = new BigInteger(format + format, 2);
        System.out.println(bi);

        T_MulAttrDetectRstRsp_v2 t = iFaaServiceThriftClient.if_image_detect_extract_url_v2(pic_url, attrList, 1, 5029);
        List<T_AttrDetectRstItem_v2> t_attrDetectRstItem_v2List = t.getFaceAttrList();
        for (T_AttrDetectRstItem_v2 t_attrDetectRstItem_v2 : t_attrDetectRstItem_v2List) {
            String faceAttrInfoStr = t_attrDetectRstItem_v2.getFaceAttrInfo();
            System.out.println(JSONObject.parseObject(faceAttrInfoStr).getJSONArray("face_rect").get(0).toString());
            byte[] feature = t_attrDetectRstItem_v2.getFeature();
            System.out.println(faceAttrInfoStr);
            FaceAttrInfo faceAttrInfo = JSON.parseObject(faceAttrInfoStr, FaceAttrInfo.class);
            List<Attributes> attributesList = JSONArray.parseArray(faceAttrInfo.getAttributes(), Attributes.class);

            System.out.println(attributesList.get(0).getQuality());

            List<Headpose> headposeList = JSONArray.parseArray(attributesList.get(0).getHeadpose(), Headpose.class);

            if (null != headposeList && !headposeList.isEmpty()) {

                Headpose hp = headposeList.get(0);
                Pose p = new Pose(hp.getPitch_angle(), hp.getRoll_angle(), hp.getYaw_angle());
                System.out.println(JSON.toJSONString(p));


            }


            System.out.println(headposeList);
        }
        System.out.println(t.toString());
    }

}
