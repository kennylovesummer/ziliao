package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class PersonfileCameraServiceImplTest {

    @Autowired
    IPersonfileCameraService personfileCameraService;

    @Test
    public void insertPersonfileCamera() {
        PersonfileCamera personfileCamera = new PersonfileCamera();
        personfileCamera.setDevId("22");
        personfileCamera.setOpType(2L);
        personfileCamera.setIp("2dklsfjlsdjf");
        personfileCamera.setPort(122);
        personfileCamera.setStatus(1);
        personfileCamera.setAreaId(322);
        personfileCamera.setDeviceType("22");
        personfileCamera.setGeoString("dddd");
        personfileCamera.setName("sdfdsf");
        personfileCamera.setDeleteStatus(0);

        personfileCameraService.insertPersonfileCamera(personfileCamera);
    }

}