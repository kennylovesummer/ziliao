package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrashArea;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisCrashAreaServiceImplTest {
    
    @Autowired
    private BigdataAnalysisCrashAreaService bigdataAnalysisCrashAreaService;
    
    @Test
    public void findAnalysisCrashAreaById() {
        bigdataAnalysisCrashAreaService.findAnalysisCrashAreaById(41l);
    }
    
    @Test
    public void findAnalysisCrashAreaByTaskId() {
        bigdataAnalysisCrashAreaService.findAnalysisCrashAreaByTaskId(1l);
    }
    
    @Test
    public void findAnalysisCrashAreaByTaskIds() {
        List<Long> taskIds = Lists.newArrayList();
        taskIds.add(1L);
        bigdataAnalysisCrashAreaService.findAnalysisCrashAreaByTaskIds(taskIds);
    }
    
    
    @Test
    public void insertAnalysisCrashArea() {
        BigdataAnalysisCrashArea bigdataAnalysisCrashArea = new BigdataAnalysisCrashArea();
        bigdataAnalysisCrashArea.setTaskId(1L);
        bigdataAnalysisCrashArea.setCode(ICommonConstant.Letter.A);
        
        bigdataAnalysisCrashAreaService.insertAnalysisCrashArea(bigdataAnalysisCrashArea);
    }
    
    @Test
    public void updateAnalysisCrashArea() {
        BigdataAnalysisCrashArea bigdataAnalysisCrashArea = new BigdataAnalysisCrashArea();
        bigdataAnalysisCrashArea.setId(41L);
        bigdataAnalysisCrashArea.setFirstDevId("2");
        
        bigdataAnalysisCrashAreaService.updateAnalysisCrashArea(bigdataAnalysisCrashArea);
    }
    
    @Test
    public void deleteByTaskId() {
        bigdataAnalysisCrashAreaService.deleteByTaskId(1L);
    }
}