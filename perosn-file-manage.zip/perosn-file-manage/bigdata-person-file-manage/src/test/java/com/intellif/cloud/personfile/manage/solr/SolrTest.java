package com.intellif.cloud.personfile.manage.solr;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import org.apache.solr.client.solrj.SolrServerException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.io.IOException;
import java.util.*;

/**
 * solr测试
 *
 * @author liuzhijian
 * @date 2019-03-13
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class SolrTest {

    @Autowired
    private PersonfileSolrService personfileSolrService;

    @Test
    public void deleteByPersonfileId(){
        try {
            personfileSolrService.deleteByPersonfileId("4615763562667706926");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SolrServerException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void batchInsert(){
        PersonfileClusterFinishDTO personfileClusterFinishDTO = new PersonfileClusterFinishDTO();
        personfileClusterFinishDTO.setPersonFilesId("2323434234234");
        byte[] featureInfo = {1,1,2,2,3,4,3};
        personfileClusterFinishDTO.setFeatureInfo(featureInfo);
        personfileClusterFinishDTO.setPersonFileCreateTime(new Date());
//        personfileClusterFinishDTO.setAlgoVersion(5029);

        PersonfileClusterFinishDTO personfileClusterFinishDTO2 = new PersonfileClusterFinishDTO();
        personfileClusterFinishDTO2.setPersonFilesId("2323434234234");
        byte[] featureInfo2 = {1,3,2,2,4,4,3};
        personfileClusterFinishDTO2.setFeatureInfo(featureInfo2);
        personfileClusterFinishDTO2.setPersonFileCreateTime(new Date());
//        personfileClusterFinishDTO2.setAlgoVersion(5029);

        List<PersonfileClusterFinishDTO> personfileClusterFinishDTOS = Lists.newArrayList();
        personfileClusterFinishDTOS.add(personfileClusterFinishDTO);
        personfileClusterFinishDTOS.add(personfileClusterFinishDTO2);
        personfileSolrService.insert(personfileClusterFinishDTOS);
    }

}
