package com.intellif.cloud.personfile.manage.kafka.producer;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.PersonfilesManageApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class MqProducerTest {

    @Autowired
    MqProducer mqProducer;

    @Test
    public void test1() {
        // 发送事件流kafka
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("aid","ddd");
//        jsonObject.put("createTime","dddd");
//        mqProducer.send(jsonObject.toJSONString(),"archive-event-snap");
        byte[] featureInfo = {1,1,2,2,3,4,3};
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("algoVersion","5029");
        jsonObject.put("avatarUrl","http://192.168.11.26/company/011张兆丰222.JPG");
        jsonObject.put("createTime",1550746807953l);
        jsonObject.put("deleteFlag",0);
        jsonObject.put("sysCode","deepEye");
        jsonObject.put("time",new Date());
        jsonObject.put("createTime",new Date());
        jsonObject.put("genderInfo","{dfdsfs}");
        jsonObject.put("ageInfo","{dfdsfs}");
        jsonObject.put("hairstyleInfo","{dfdsfs}");
        jsonObject.put("hatInfo","{dfdsfs}");
        jsonObject.put("glassesInfo","{dfdsfs}");
        jsonObject.put("poseInfo","{dfdsfs}");
        jsonObject.put("qualityInfo",1.0);
        jsonObject.put("identityNo","51050419950914134X");
        jsonObject.put("featureInfo",featureInfo);
        jsonObject.put("identityType",0);
        jsonObject.put("imageId",0);
        jsonObject.put("imageUrl","http://192.168.11.26/company/011张兆丰33.JPG");
        jsonObject.put("personName","999");
        jsonObject.put("sourceType",0);
        jsonObject.put("sourceId",0);
        jsonObject.put("thumbnailUrl","http://192.168.11.26/company/011张兆丰22.JPG");
        jsonObject.put("thumbnailId","555");
        jsonObject.put("targetRect","{future: [12,12,12,12]}");
        String id;
        String iamgeUrl;
        Set<String> aids = new HashSet<>();
        for (int j= 1; j <= 1000000; j++) {
            id = UUID.randomUUID().toString().replaceAll("-", "y");
            iamgeUrl = UUID.randomUUID().toString().replaceAll("-", "h");
            jsonObject.put("aid",id);
            jsonObject.put("thumbnailId",iamgeUrl);
            mqProducer.send(jsonObject.toJSONString(),"bigdata-output-face-event");
            aids.add(id);
        }
    }
}
