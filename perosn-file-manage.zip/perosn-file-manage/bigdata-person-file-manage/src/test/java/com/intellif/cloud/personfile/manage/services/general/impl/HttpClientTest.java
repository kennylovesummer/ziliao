package com.intellif.cloud.personfile.manage.services.general.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.entity.SysDict;
import com.intellif.cloud.personfile.manage.utils.PersonHttpClientUtil;
import org.junit.Test;

import java.util.*;
import java.util.stream.Stream;

import static com.google.common.primitives.Ints.asList;
import static java.util.stream.Collectors.toList;


public class HttpClientTest {

    @Test
    public void test01() {

        // String url, JSONObject jsonParam, Map<String, String> tokenMap
        JSONObject jsonObject = new JSONObject();
        //{"faceSize":20,"nodeType":"district","nodeId":"3","cameraIds":[],"forceSearch":0,"displayType":"time","placeTypeId":0,"deviceTypeId":0,"type":1,"dataType":"1","faceId":"563159834333644","ids":"","mergeType":1,"scoreThreshold":0.92,"starttime":"2018-08-17 00:00:00","endtime":"2018-11-15 23:59:59","dayStartTime":"00:00:00","dayEndTime":"23:59:59","weekDay":"0","quality":"0","gender":"","race":"","age":"","hat":"","glasses":"","genderConfidence":5,"raceConfidence":5,"hatConfidence":5,"glassesConfidence":5}
        jsonObject.put("faceSize", 20);
        jsonObject.put("nodeType", "district");
        jsonObject.put("nodeId", 3);
        jsonObject.put("cameraIds", new JSONArray(0));
        jsonObject.put("forceSearch", 0);
        jsonObject.put("displayType", "time");
        jsonObject.put("placeTypeId", 0);
        jsonObject.put("deviceTypeId", 0);
        jsonObject.put("type", 1);
        jsonObject.put("dataType", "1");
        jsonObject.put("faceId", "563159834333644");
        jsonObject.put("ids", "");
        jsonObject.put("mergeType", 1);
        jsonObject.put("scoreThreshold", 0.92);
        jsonObject.put("starttime", "2018-08-17 00:00:00");
        jsonObject.put("endtime", "2018-11-15 23:59:59");
        jsonObject.put("dayStartTime", "00:00:00");
        jsonObject.put("dayEndTime", "23:59:59");
        jsonObject.put("weekDay", "0");
        jsonObject.put("quality", "0");
        jsonObject.put("gender", "");
        jsonObject.put("race", "");
        jsonObject.put("age", "");
        jsonObject.put("hat", "");
        jsonObject.put("glasses", "");
        jsonObject.put("genderConfidence", 5);
        jsonObject.put("raceConfidence", 5);
        jsonObject.put("hatConfidence", 5);
        jsonObject.put("glassesConfidence", 5);
        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("Authorization", "Bearer 2690449d-64c9-48dd-84ab-8d554e5628d5");
        String json = PersonHttpClientUtil.httpPost("http://192.168.11.37:8083/api/intellif/share/face/search/face/page/1/pagesize/100", jsonObject, tokenMap);
        JSONArray array = JSONArray.parseArray(JSON.parseObject(json).getString("data"));
        for (int i = 0, len = array.size(); i < len; i++) {
            System.out.println("http://192.168.11.37" + array.getJSONObject(i).getString("file"));
        }
    }

    @Test
    public void testStream() {
        List<SysDict> list = new ArrayList<>();
        SysDict sysDict = new SysDict();

        for (int i = 0; i <= 100; i++) {
            sysDict.setId(Long.valueOf(i));
            list.add(sysDict);
            sysDict = new SysDict();
        }
        long count = list.stream().filter(dict -> dict.getId() > 18).count();
        System.out.println(count);
        System.out.println("*************");
        list.forEach(item -> System.out.println(item.getId()));
    }

    /**
     * collect(toList())
     */
    @Test
    public void testCollect() {
        // Stream.of("a", "b", "c")首先由列表生成一个Stream对象，然后collect(Collectors.toList())生成List对象。
        List<String> collect = Stream.of("a", "b", "c").collect(toList());
        collect.forEach(item -> {
            System.out.println(item);
        });
    }

    /**
     * map
     * map可以将一种类型的值转换成另一种类型。
     */
    @Test
    public void testMap() {
        List<String> streamMap = Stream.of("a", "b", "c").map(String -> String.toUpperCase()).collect(toList());
        streamMap.forEach(item -> System.out.println(item));
    }

    /**
     * filter过滤器
     * 遍历并检查其中的元素时，可用filter
     */
    @Test
    public void testFilter() {
        List<String> collect1 = Stream.of("a", "ab", "abc")
                .filter(value -> value.contains("b"))
                .collect(toList());
        collect1.forEach(item -> System.out.println(item));
    }

    /**
     * 如果有一个包含了多个集合的对象希望得到所有数字的集合,可以用flatMap
     * Stream.of(asList(1, 2), asList(3, 4))将每个集合转换成Stream对象，然后.flatMap处理成新的Stream对象。
     */
    @Test
    public void testFlatMap() {
        List<Integer> collect2 = Stream.of(asList(1, 2), asList(3, 4))
                .flatMap(Collection::stream)
                .collect(toList());
        collect2.forEach(item -> System.out.println(item));
    }

    /**
     * 求最大值和最小值
     */
    @Test
    public void testMaxMin() {
        // java8提供了一个Comparator静态方法，可以借助它实现一个方便的比较器
        // 其中Comparator.comparing(student -> student.getAge()可以换成Comparator.comparing(Student::getAge)成为更纯粹的lambda。max同理
        List<SysDict> list = new ArrayList<>();
        SysDict sysDict = new SysDict();

        for (int i = 0; i <= 100; i++) {
            sysDict.setId(Long.valueOf(i));
            list.add(sysDict);
            sysDict = new SysDict();
        }
        sysDict = list.stream()
                .min(Comparator.comparing(dict -> dict.getId()))
                .get();
        System.out.println("min:" + sysDict.getId());

        SysDict sysDictMax = list.stream()
                .max(Comparator.comparing(dict -> dict.getId()))
                .get();
        System.out.println("max:" + sysDictMax.getId());
    }

    /**
     * reduce操作可以实现从一组值中生成一个值，在上述例子中用到的count、min、max方法事实上都是reduce操作。
     */
    @Test
    public void testReduce() {
        // 使用reduce求和，0表示起点，acc表示累加器，保存着当前累加结果（每一步都将stream中的元素累加至acc），element是当前元素
        Integer reduce = Stream.of(1, 2, 3).reduce(0, (acc, element) -> acc + element);
        System.out.println(reduce);
    }
}