package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class BigdataCommonServiceImplTest {

    @Autowired
    BigdataCommonService bigdataCommonService;

    @Test
    public void insertBigdataCommon() {
        BigdataCommon bigdataCommon = new BigdataCommon();
        bigdataCommon.setContent("測試");
        bigdataCommon.setContentType(this.bigdataCommonService.getClass().getName());
        bigdataCommon.setRemark("測試--");
        bigdataCommonService.insertBigdataCommon(bigdataCommon);
    }

    @Test
    public void updateBigdataCommon() {
        BigdataCommon bigdataCommon = new BigdataCommon();
        bigdataCommon.setId(1);
        bigdataCommon.setContent("測試22");
        bigdataCommonService.updateBigdataCommon(bigdataCommon);
    }

    @Test
    public void findBigdataCommonByContentType() {
        List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType("BigdataCommonServiceImpl$$EnhancerBySpringCGLIB$$67afd638");
    }
}