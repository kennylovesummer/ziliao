package com.intellif.cloud.personfile.manage.kafka.consumer;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.cloud.personfile.manage.kafka.producer.MqProducer;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;


@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class MqListenerTest {

    @Autowired
    MqMessageHandle mqMessageHandle;

    @Autowired
    MqProducer mqProducer;

    @Test
    public void clusterStatistic() {
        PersonfileClusterFinishDTO personfileClusterFinishDTO = new PersonfileClusterFinishDTO();
        personfileClusterFinishDTO.setRecentSnapTime(new Date());
        personfileClusterFinishDTO.setImageCount(2);
//        personfileClusterFinishDTO.setAlgoVersion(5029);
        personfileClusterFinishDTO.setBigImageUrl("http://localhost/dd");
        personfileClusterFinishDTO.setHeadImageUrl("http://localhost/dd");
        personfileClusterFinishDTO.setPersonFileCreateTime(new Date());
        personfileClusterFinishDTO.setSmallImageUrl("http://localhost/dd");
        personfileClusterFinishDTO.setPersonFilesId("4444");
        try {
//            mqListener.clusterStatistic(JSONObject.parseObject(JSONObject.toJSONString(personfileClusterFinishDTO)));
                } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void clusterStatisticFinish(){
        // 发送事件流kafka
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("aid","ddd");
        jsonObject.put("createTime","dddd");
        mqProducer.send(jsonObject.toJSONString(),"archive-event-snap");
    }

}