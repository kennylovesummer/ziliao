package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.annotation.Resource;

/**
 * 深目的接口实现类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月15日
 * @see DeepEyeServiceTest
 * @since JDK1.8
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class DeepEyeServiceTest {
    @Resource
    private DeepEyeService deepEyeService;

    /**
     * 获取所有摄像头
     *
     * @return
     */
    @Test
    public void getCameraList() {
        System.out.println(deepEyeService.getCameraList().toString());
    }

    /**
     * 图片上传 获取特征值
     *
     * @return
     */
    @Test
    public void imageUploadUrl() {
        // url 图片地址
        String url = "http://192.168.11.152/eng1store1_5/ImgWareHouse/src_0_9/20181114/20181114T175813_0_9.jpg";
        System.out.println(deepEyeService.imageUploadUrl(url, true).toString());
    }

    /**
     * 根据小图查询大图
     *
     * @return
     */
    @Test
    public void getBigImage() {
        // 小图id
        String id = "281546136531642";
        System.out.println(deepEyeService.getBigImage(id).toString());
    }

    /**
     * 根据大图查询小图
     */
    @Test
    public void getSmallImage() {
        //大图id
        String id = "281546136520669";
        System.out.println(deepEyeService.getSmallImage(id).toString());
    }
}
