package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabel;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

/**
 * @program ifaas-person-file-manage
 * @Author liuYu
 * @create 2018-11-12 10:39
 * @Version 1.0
 * @desc
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
@Rollback
@Transactional
public class PersonfileLabelServiceImplTest {
    
    @Autowired
    private PersonfileLabelServiceImpl personFileLabelService;
    
    @Test
    public void insertPersonfileLabel() throws ParseException, BusinessException {
        PersonfileLabel personfileLabel;
        for (int i = 1; i < 3; i++) {
            personfileLabel = new PersonfileLabel();
            personfileLabel.setLabelName("测试人员" + i);
            personfileLabel.setCreateTime(new Date());
            personfileLabel.setModifiedTime(new Date());
            int result = personFileLabelService.insertPersonfileLabel(personfileLabel);
            System.out.println(personfileLabel);
            assertEquals(1, result);
        }
    }
    
    @Test
    public void updatePersonfileLabel() throws BusinessException {
        List<PersonfileLabel> personfileLabels = personFileLabelService.findAllPersonfileLabel();
        personfileLabels.stream().forEach(personfileLabel -> {
            personfileLabel.setLabelName("标签测试修改" + UUID.randomUUID().toString().substring(0, 1));
            try {
                personFileLabelService.updatePersonfileLabel(personfileLabel);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        System.out.println(personfileLabels);
    }
    
    @Test
    public void deletePersonfileLabel() throws BusinessException {
        List<PersonfileLabel> personfileLabels = personFileLabelService.findAllPersonfileLabel();
        personFileLabelService.deletePersonfileLabel(personfileLabels.get(0).getId());
        List<PersonfileLabel> personfileLabelList = personFileLabelService.findAllPersonfileLabel();
        assertEquals(personfileLabels.size() - 1, personfileLabelList.size());
    }
    
    @Test
    public void findPersonfileLabelRecordByPersonfileIds() throws BusinessException {
        List<String> ids = Lists.newArrayList();
        ids.add("111");
        List<PersonfileLabelVO> personfileLabelVOS = personFileLabelService.findPersonfileLabelRecordByPersonfileIds(ids);
    }
}
