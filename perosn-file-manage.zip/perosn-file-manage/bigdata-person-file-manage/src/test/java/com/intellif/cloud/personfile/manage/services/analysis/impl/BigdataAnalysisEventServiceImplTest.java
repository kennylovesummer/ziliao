package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisEventServiceImplTest {
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    @Test
    public void findAnalysisEventById() {
        bigdataAnalysisEventService.findAnalysisEventById(97l);
    }
    
    @Test
    public void deleteAnalysisEvent() {
        BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
        bigdataAnalysisEvent.setId(97l);
        bigdataAnalysisEventService.deleteAnalysisEvent(bigdataAnalysisEvent);
    }
    
    @Test
    public void insertAnalysisEvent() {
        BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
        bigdataAnalysisEvent.setAid("ddd");
        bigdataAnalysisEvent.setCameraId("dd");
        bigdataAnalysisEvent.setDate(2423l);
        bigdataAnalysisEvent.setTime(444l);
        bigdataAnalysisEvent.setImageId("ddd");
        bigdataAnalysisEvent.setImageUrl("fslfjsl");
        bigdataAnalysisEvent.setTaskId(9L);
        bigdataAnalysisEventService.insertAnalysisEvent(bigdataAnalysisEvent);
    }
    
    @Test
    public void updateAnalysisEvent() {
        BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
        bigdataAnalysisEvent.setAid("ccc");
        bigdataAnalysisEvent.setId(97l);
        bigdataAnalysisEventService.updateAnalysisEvent(bigdataAnalysisEvent);
    }
    
    @Test
    public void findAnalysisEventByParams() {
        EventDTO eventDTO = new EventDTO();
        eventDTO.setPage(1);
        eventDTO.setPerpage(29);
//        eventDTO.setAid("4618381743324411931");
        eventDTO.setIsPeer(true);
        Page<BigdataAnalysisEvent> page = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
    }
}