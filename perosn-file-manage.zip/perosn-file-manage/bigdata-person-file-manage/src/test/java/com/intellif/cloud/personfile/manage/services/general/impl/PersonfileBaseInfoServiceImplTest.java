package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * 基础信息单元测试
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月26日
 * @see PersonfileBaseInfoServiceImplTest
 * @since JDK1.8
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class PersonfileBaseInfoServiceImplTest {
    
    @Autowired
    PersonfileBaseInfoServiceImpl personfileBaseInfoService;
    
    @Autowired
    MqMessageHandle mqMessageHandle;
    
    @Test
    public void findBaseInfoByLabels() {
        List<Integer> lableIdList = Lists.newArrayList();
        lableIdList.add(1);
        personfileBaseInfoService.findBaseInfoByLabels(lableIdList);
    }
    
    @Test
    public void findAutoByParam() {
//        Map<String, Object> params = new HashMap<>(1);
//        params.put("labelIds", StringUtils.split("43,2", ICommonConstant.Symbol.COMMA));
//        List<PersonfileBasics> personfileBasicsList = personfileBaseInfoService.findAutoByParam(params);
//        List<PersonfileBasics> personfileBasicsList1 = personfileBasicsList.stream().limit(20).collect(Collectors.toList());
        
        Map<String, Object> params = Maps.newHashMap();
        params.put("cid", "370503198610012012");
        List<PersonfileBasics> personfileBasics = personfileBaseInfoService.findAutoByParam(params);
    }
    
    @Test
    public void findBaseInfoVOByPersonFileId() {
        PersonfileBasicsVO personfileBasicsVO = personfileBaseInfoService.findBaseInfoVOByPersonFileId("bdf87ceby3cb45y34b05y3858ey3c71dc4507cb8");
    }
    
    @Test
    public void updatePersonfileBasics() throws BusinessException {
        PersonfileBasicsVO personfileBasicsVO = personfileBaseInfoService.findBaseInfoVOByPersonFileId("4719f1e2y125a4y14ef8y18ca7y18b95fa0bb312");
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId(personfileBasicsVO.getPersonFilesId());
        personfileBasics.setAge(66);
        personfileBasics.setBirthDate(new Date());
        personfileBasics.setCid("");
        personfileBasics.setSex(1);
        personfileBasics.setDomicilePlace("深圳");
        personfileBasics.setTransportation("rocket");
        personfileBasics.setLabelId(88);
        personfileBasics.setPhoneNumber("13875963685");
        personfileBasics.setUpdateFlag(true);
        personfileBaseInfoService.updatePersonfileBasics(personfileBasics);
        System.out.println(personfileBasics);
    }
    
    @Test
    public void updatePersonfileBasicsLabel() throws BusinessException {
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId("DNA2018101600060");
        personfileBasics.setLabelId(80);
        personfileBaseInfoService.insertPersonfileBasicsLabel(personfileBasics.getPersonFilesId(), personfileBasics.getLabelId());
        assertEquals(80, personfileBasics.getLabelId().longValue());
        System.out.println(personfileBasics);
    }
    
    @Test
    public void findByPersonfileIds() {
        List<String> personFileIds = new ArrayList<>();
        personFileIds.add("4613045349806768157");
        List<Map<String, Object>> rr = personfileBaseInfoService.findByPersonfileIds(personFileIds);
    }
    
    @Test
    public void findFirstSnapTimeByPersonFileId() {
//        Date date = personfileBaseInfoService.findFirstSnapTimeByPersonFileId("4613489415333871618");
        personfileBaseInfoService.updateImageCount(-1, "4612375777290223616");
    }
    
    @Test
    public void insertPersonfileBasics() {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        for (int i = 1; i < 5; i++) {
            PersonfileBasics personfileBasics = new PersonfileBasics();
            personfileBasics.setCreater(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            personfileBasics.setModifier(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            personfileBasics.setCreateTime(new Date());
            personfileBasics.setModifiedTime(new Date());
            personfileBasics.setName("cccc" + i);
            personfileBasics.setCid("1");
            personfileBasics.setPersonFilesId(UUID.randomUUID().toString().replaceAll("-", "y" + i));
            personfileBasicsList.add(personfileBasics);
//            if (personfileBasicsList.size() == 1000) {
//                personfileBaseInfoService.batchInsertPersonfileBasics(personfileBasicsList);
//                personfileBasicsList.clear();
//            }
        }

//        PersonfileBasics personfileBasics = new PersonfileBasics();
//        personfileBasics.setCreater(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
//        personfileBasics.setModifier(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
//        personfileBasics.setCreateTime(new Date());
//        personfileBasics.setModifiedTime(new Date());
//        personfileBasics.setName("dd");
//        personfileBasics.setPersonFilesId(UUID.randomUUID().toString().replaceAll("-", "y"));
//        personfileBasicsList.add(personfileBasics);
//
        personfileBaseInfoService.batchInsertPersonfileBasics(personfileBasicsList);
    }
    
    @Test
    public void statisticAge() {
//        Object map = personfileBaseInfoService.statisticAge();
    }
    
    @Test
    public void subInsertPersonfile() {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        
        for (int i = 1; i < 5; i++) {
            PersonfileBasics personfileBasics = new PersonfileBasics();
            personfileBasics.setCreater(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            personfileBasics.setModifier(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            personfileBasics.setCreateTime(new Date());
            personfileBasics.setModifiedTime(new Date());
            personfileBasics.setName("dd" + i);
            personfileBasics.setPersonFilesId(UUID.randomUUID().toString().replaceAll("-", "y" + i));
            personfileBasicsList.add(personfileBasics);
        }
        
        personfileBaseInfoService.batchInsertPersonfileBasics(personfileBasicsList);
    }
    
    @Test
    public void findBaseInfoByPersonFileId() {
        Long startTime = System.currentTimeMillis();
        PersonfileBasics personfileBasics = personfileBaseInfoService.findBaseInfoByPersonFileId("b2261cddy321d0y34dcby38ebfy3c56b7cd00716");
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }
    
    @Test
    public void batchUpdatePersonfileBasics() {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId("9c70d37dy27193y24f94y2be49y2833b13c4a9e9");
        personfileBasics.setRecentSnapTime(new Date());
        personfileBasics.setImageCount(1000);
        personfileBasics.setPersonFileCreateTime(new Date());
        personfileBasics.setBirthDate(new Date());
        personfileBasicsList.add(personfileBasics);
        
        PersonfileBasics personfileBasics1 = new PersonfileBasics();
        personfileBasics1.setPersonFilesId("fb363aaay3cea7y3492dy3a828y348fb691292ca");
        personfileBasics1.setRecentSnapTime(new Date());
        personfileBasics1.setImageCount(200);
        personfileBasics.setBirthDate(new Date());
        personfileBasics1.setPersonFileCreateTime(new Date());
        personfileBasicsList.add(personfileBasics1);
        
        personfileBaseInfoService.batchUpdatePersonfileBasics(personfileBasicsList);
    }
}