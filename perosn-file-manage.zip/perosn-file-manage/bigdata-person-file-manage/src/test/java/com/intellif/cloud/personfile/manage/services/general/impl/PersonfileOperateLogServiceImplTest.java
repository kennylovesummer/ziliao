package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileOperateLog;
import com.intellif.cloud.personfile.manage.services.general.PersonfileOperateLogService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class PersonfileOperateLogServiceImplTest {

    @Autowired
    PersonfileOperateLogService personfileOperateLogService;

    @Test
    public void insert() {
        PersonfileOperateLog personfileOperateLog = new PersonfileOperateLog();
        personfileOperateLog.setCreateTime(new Date());
        personfileOperateLog.setModifiedTime(new Date());
        personfileOperateLog.setOperateName("删除档案");
        personfileOperateLog.setOperateTime(new Date());
        personfileOperateLog.setOperateUserName("2333");
        personfileOperateLog.setOperateUserIp("127.0.0.1");
        personfileOperateLogService.insert(personfileOperateLog);
    }
}