package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisPeer;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisPeerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisPeerServiceImplTest {
    
    @Autowired
    private BigdataAnalysisPeerService bigdataAnalysisPeerService;
    
    @Test
    public void findAnalysisPeerById() {
        bigdataAnalysisPeerService.findAnalysisPeerById(97l);
    }
    
    @Test
    public void deleteAnalysisPeer() {
        BigdataAnalysisPeer bigdataAnalysisPeer = new BigdataAnalysisPeer();
        bigdataAnalysisPeer.setId(97l);
        bigdataAnalysisPeerService.deleteAnalysisPeer(bigdataAnalysisPeer);
    }
    
    @Test
    public void insertAnalysisPeer() {
        BigdataAnalysisPeer bigdataAnalysisPeer = new BigdataAnalysisPeer();
        bigdataAnalysisPeer.setAid("ddd");
        bigdataAnalysisPeer.setTaskId(2l);
        bigdataAnalysisPeer.setCameraId("22");
        bigdataAnalysisPeerService.insertAnalysisPeer(bigdataAnalysisPeer);
    }
    
    @Test
    public void updateAnalysisPeer() {
        BigdataAnalysisPeer bigdataAnalysisPeer = new BigdataAnalysisPeer();
        bigdataAnalysisPeer.setAid("ccc");
        bigdataAnalysisPeer.setTaskId(2l);
        bigdataAnalysisPeer.setId(97l);
        bigdataAnalysisPeerService.updateAnalysisPeer(bigdataAnalysisPeer);
    }
    
    @Test
    public void findAnalysisPeerByParams() {
        //TODO
    }
}