package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisExportTaskServiceImplTest {
    
    @Autowired
    private BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;
    
    @Test
    public void selectAnalysisExportTaskById() {
    }
    
    @Test
    public void deleteAnalysisExportTaskById() {
        bigdataAnalysisExportTaskService.deleteAnalysisExportTaskById(1l);
    }
    
    @Test
    public void insertAnalysisExportTask() {
        BigdataAnalysisExportTask bigdataAnalysisExportTask = new BigdataAnalysisExportTask();
        bigdataAnalysisExportTask.setTaskId(1l);
        bigdataAnalysisExportTask.setTaskName("dddd");
        
        bigdataAnalysisExportTaskService.insertAnalysisExportTask(bigdataAnalysisExportTask);
    }
    
    @Test
    public void updateAnalysisExportTask() {
        BigdataAnalysisExportTask bigdataAnalysisExportTask = bigdataAnalysisExportTaskService.selectAnalysisExportTaskById(1l);
        bigdataAnalysisExportTask.setTaskType("peer");
        bigdataAnalysisExportTaskService.updateAnalysisExportTask(bigdataAnalysisExportTask);
    }
    
    @Test
    public void findAnalysisExportTaskByParams() {
        AnalysisTaskDTO analysisTaskDTO = new AnalysisTaskDTO();
        analysisTaskDTO.setPage(1);
        analysisTaskDTO.setPerpage(10);
        Page<BigdataAnalysisExportTask> page = bigdataAnalysisExportTaskService.findAnalysisExportTaskByParams(analysisTaskDTO);
    }
    
    @Test
    public void deleteDiedAnalysisExportTask() {
        bigdataAnalysisExportTaskService.deleteDiedAnalysisExportTask();
    }
    
}