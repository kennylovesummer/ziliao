package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileHeadPicture;
import com.intellif.cloud.personfile.manage.services.general.PersonfileHeadPictureService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class personfileHeadPictureServiceImplTest {

    @Autowired
    private PersonfileHeadPictureService personfileHeadPictureService;

    @Test
    public void batchInsert() {
        PersonfileHeadPicture PersonfileHeadPicture = new PersonfileHeadPicture();
        PersonfileHeadPicture.setCreater("test");
        PersonfileHeadPicture.setCreateTime(new Date());
        PersonfileHeadPicture.setModifiedTime(new Date());
        PersonfileHeadPicture.setModifier("test");
        PersonfileHeadPicture.setPersonFilesId("12322");
        List<PersonfileHeadPicture> personfileTimes = new ArrayList<>();
        personfileTimes.add(PersonfileHeadPicture);

    }

    @Test
    public void insert(){
        PersonfileHeadPicture personfileHeadPicture = new PersonfileHeadPicture();
        personfileHeadPicture.setCreater("test");
        personfileHeadPicture.setCreateTime(new Date());
        personfileHeadPicture.setModifiedTime(new Date());
        personfileHeadPicture.setModifier("test");
        personfileHeadPicture.setPersonFilesId("12322");

        List<PersonfileHeadPicture> personfileHeadPictures = Lists.newLinkedList();
        personfileHeadPictures.add(personfileHeadPicture);

        personfileHeadPictureService.batchInsert(personfileHeadPictures);
    }

    @Test
    public void findByPersonfileId(){
        PersonfileHeadPicture PersonfileHeadPicture = personfileHeadPictureService.findByPersonfileId("4613045349806768157");
        System.out.println(Base64.getEncoder().encodeToString(PersonfileHeadPicture.getFeatureInfo()));
    }

    @Test
    public void update(){
        PersonfileHeadPicture PersonfileHeadPicture = personfileHeadPictureService.findByPersonfileId("12322");
        PersonfileHeadPicture.setModifier("test1");
        personfileHeadPictureService.update(PersonfileHeadPicture);
    }

}