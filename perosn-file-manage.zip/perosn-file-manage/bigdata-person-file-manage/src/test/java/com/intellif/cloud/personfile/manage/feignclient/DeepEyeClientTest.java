package com.intellif.cloud.personfile.manage.feignclient;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

/**
 * 深目的feignClient的测试
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class DeepEyeClientTest {

    @Autowired
    private DeepEyeClient deepEyeClient;

    @Autowired
    private PersonPropertiest personPropertiest;

    /**
     * 深目的登录
     */
    @Test
    public void login() {
        System.out.println(deepEyeClient.login(personPropertiest.getDeepEyeLoginUserName(), personPropertiest.getDeepEyeLoginPassword(), PersonPropertiest.DEEP_EYE_LOGIN_GRAN_TTYPE));
    }
}