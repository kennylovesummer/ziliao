package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTrace;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.TraceDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTraceService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisTraceServiceImplTest {
    
    @Autowired
    private BigdataAnalysisTraceService bigdataAnalysisTraceService;
    
    @Test
    public void findAnalysisTraceById() {
        bigdataAnalysisTraceService.findAnalysisTraceById(97l);
    }
    
    @Test
    public void deleteAnalysisTrace() {
        BigdataAnalysisTrace bigdataAnalysisTrace = new BigdataAnalysisTrace();
        bigdataAnalysisTrace.setId(97l);
        bigdataAnalysisTraceService.deleteAnalysisTrace(bigdataAnalysisTrace);
    }
    
    @Test
    public void insertAnalysisTrace() {
        BigdataAnalysisTrace bigdataAnalysisTrace = new BigdataAnalysisTrace();
        bigdataAnalysisTrace.setDate(222l);
        bigdataAnalysisTrace.setCameraId("dddd");
        bigdataAnalysisTraceService.insertAnalysisTrace(bigdataAnalysisTrace);
    }
    
    @Test
    public void updateAnalysisTrace() {
        BigdataAnalysisTrace bigdataAnalysisTrace = new BigdataAnalysisTrace();
        bigdataAnalysisTrace.setDate(222l);
        bigdataAnalysisTrace.setCameraId("ccc");
        bigdataAnalysisTrace.setId(97l);
        bigdataAnalysisTraceService.updateAnalysisTrace(bigdataAnalysisTrace);
    }
    
    @Test
    public void findAnalysisTraceByParams() {
        TraceDTO traceDTO = new TraceDTO();
        traceDTO.setTaskId(2l);
        traceDTO.setPage(1);
        traceDTO.setPerpage(29);
        Page<BigdataAnalysisTrace> page = bigdataAnalysisTraceService.findAnalysisTraceByParams(traceDTO);
    }
}