package com.intellif.cloud.personfile.manage.services.sub;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapQueryDTO;
import com.intellif.cloud.personfile.manage.model.vo.activityRoutine.PersonfileActivityRoutinesVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl;
import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class SubEventServiceImplTest {
    
    @Autowired
    private SubEventServiceImpl subEventService;
    
    @Before
    public void initTableCache(){
        subEventService.getAllTableFromDB(true,true);
    }
    
    @Test
    public void getPersonfileSnap() {
        SnapQueryDTO snapQueryDTO = new SnapQueryDTO();
        snapQueryDTO.setPersonFileId("1ec3c5a0y794ey4400ya324y69266ddd2dfb");
        snapQueryDTO.setStartTime("2019-08-21");
        snapQueryDTO.setEndTime("2019-010-22");
        Page<EventSnapDetailVO> page = subEventService.getPersonfileSnap(snapQueryDTO);
    }
    
    @Test
    public void getPersonfileSnapDetail() throws ParseException {
//        Page<EventSnapDetailVO> page = subEventService.getPersonfileSnapDetail("1ec3c5a0y794ey4400ya324y69266ddd2dfb","2019-09-10",0,10);
    }
    
    @Test
    public void querySnapMapByPersonFilesId() {
//        SnapQueryDTO snapQueryDTO = new SnapQueryDTO();
//        snapQueryDTO.setPersonFileId("4617498345592594911");
//        snapQueryDTO.setStartTime("2019-08-21");
//        snapQueryDTO.setEndTime("2019-08-22");
//        subEventService.querySnapMapByPersonFilesId(snapQueryDTO);
    }
    
    @Test
    public void getSnapMapByPersonFilesId() {
        SnapMapDTO snapQueryDTO = new SnapMapDTO();
        snapQueryDTO.setPersonFileId("4617498345592594911");
        snapQueryDTO.setStartTime("2019-08-21");
        snapQueryDTO.setEndTime("2019-08-22");
        Page<SnapMapVO> result = subEventService.getSnapMapByPersonFilesId(snapQueryDTO);
    }
    
    @Test
    public void querySnapMapDetail() {
        SnapQueryDTO snapQueryDTO = new SnapQueryDTO();
        snapQueryDTO.setPersonFileId("4617498345592594911");
        snapQueryDTO.setStartTime("2019-08-21");
        snapQueryDTO.setEndTime("2019-08-22");
        Page<SnapMapVO> result = subEventService.querySnapMapDetail(snapQueryDTO);
    }
    
    @Test
    public void getByPersonfileId() {
//        List<PersonfileRubbish> snaps = subEventService.getByPersonfileId(215974L,"4617498345592594911");
    }
    
    @Test
    public void deletePersonfileSnap() {
        PersonfileSnap personfileSnap = new PersonfileSnap();
        
//        subEventService.deletePersonfileSnap();
    }
    
    @Test
    public void deleteEventSnapImg() {
//        subEventService.deleteEventSnapImg();
    }
    
    @Test
    public void batchInsert() {
        List<PersonfileSnap> personfileSnapList = Lists.newLinkedList();
        for (int i = 0; i <= 10; i++) {
            PersonfileSnap personfileSnap = new PersonfileSnap();
//            personfileSnap.setAlgoVersion(5029);
            personfileSnap.setFaceId("123");
            personfileSnap.setFaceUrl("123333");
            personfileSnap.setImageUrl("321");
            personfileSnap.setImageId("321");
            personfileSnap.setSysCode("333");
            personfileSnap.setSourceId("333");
//            personfileSnap.setSourceType(1);
            personfileSnap.setSnapTime(DateUtils.addDays(new Date(),i));
            personfileSnap.setPersonFilesId(UUID.randomUUID() + "d");
            personfileSnapList.add(personfileSnap);
        }
        subEventService.batchInsert(personfileSnapList);
    }
    
    @Test
    public void getSnapActivity() {
        Page<PersonfileActivityRoutinesVO> dd = subEventService.getSnapActivity("4617498345592594911","2019-08-01","2019-10-01",1,0,10);
    }
    
    @Test
    public void getSnap() {
        Integer num = subEventService.getSnap("2019-09-01","2019-09-15");
    }
    
    @Test
    public void findByImageUrl() {
//        Integer num = subEventService.findByImageUrl("321");
    }
    
    @Test
    public void statisticSnapByDate() {
//        Integer num = subEventService.statisticSnapByDate("2019-09-01","2019-09-15");
    }
    
    @Test
    public void findSnapUrlsByPersonfileId() {
        List<String> dd = subEventService.findSnapUrlsByPersonfileId("289cc5e6y4652fy4474fy4b069y424bc2d8d4ac6");
    }
    
    @Test
    public void findFirstSnapTimeByPersonFileId() {
        Date d = subEventService.findFirstSnapTimeByPersonFileId("289cc5e6y4652fy4474fy4b069y424bc2d8d4ac6");
    }
    
    @Test
    public void findSnapTimeAndImageCount() {
//        subEventService.findSnapTimeAndImageCount()
    }
    
    @Test
    public void findSnapTimeAndImageCountByPersonfileId() {
    }
    
    @Test
    public void updateSnapAid(){
        List params = Lists.newArrayList();
        Map<String,Object> map = Maps.newHashMap();
        map.put("targetAid","111");
        
        List<String> fromAids = Lists.newArrayList();
        fromAids.add("693c691fy2469y4070yaacaye7fc9bf70168");
        map.put("fromAids",fromAids);
        params.add(map);
        subEventService.updateSnapAid(params);
    }
}