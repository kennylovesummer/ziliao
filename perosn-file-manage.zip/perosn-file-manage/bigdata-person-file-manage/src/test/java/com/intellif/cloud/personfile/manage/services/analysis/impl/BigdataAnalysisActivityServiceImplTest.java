package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisActivity;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisActivityService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisActivityServiceImplTest {
    
    @Autowired
    private BigdataAnalysisActivityService bigdataAnalysisActivityService;
    
    @Test
    public void findAnalysisActivityByTaskId() {
        BigdataAnalysisActivity bigdataAnalysisActivity = bigdataAnalysisActivityService.findAnalysisActivityByTaskId(1L);
    }
    
    @Test
    public void deleteAnalysisActivityByTaskId() {
        bigdataAnalysisActivityService.deleteAnalysisActivityByTaskId(1L);
    }
    
    @Test
    public void insertAnalysisActivity() {
        BigdataAnalysisActivity bigdataAnalysisActivity = new BigdataAnalysisActivity();
        
        bigdataAnalysisActivity.setTaskId(1L);
        bigdataAnalysisActivity.setImageCount(23L);
        bigdataAnalysisActivity.setPeriods("ddd");
        bigdataAnalysisActivity.setSite("shenzhen");
        bigdataAnalysisActivity.setSourceId("123");
        
        bigdataAnalysisActivityService.insertAnalysisActivity(bigdataAnalysisActivity);
    }
    
    @Test
    public void batchInsertAnalysisActivity() {
    
        BigdataAnalysisActivity bigdataAnalysisActivity = new BigdataAnalysisActivity();
    
        bigdataAnalysisActivity.setTaskId(2L);
        bigdataAnalysisActivity.setImageCount(23L);
        bigdataAnalysisActivity.setPeriods("ddd");
        bigdataAnalysisActivity.setSite("shenzhen");
        bigdataAnalysisActivity.setSourceId("123");
        
        List<BigdataAnalysisActivity> bigdataAnalysisActivityList = Lists.newArrayList();
        bigdataAnalysisActivityList.add(bigdataAnalysisActivity);
    
        bigdataAnalysisActivityService.batchInsertAnalysisActivity(bigdataAnalysisActivityList);
    }
    
    @Test
    public void updateAnalysisActivity() {
        BigdataAnalysisActivity bigdataAnalysisActivity = new BigdataAnalysisActivity();
    
        bigdataAnalysisActivity.setId(1L);
        bigdataAnalysisActivity.setImageCount(23L);
        bigdataAnalysisActivity.setPeriods("ccc");
    
        bigdataAnalysisActivityService.updateAnalysisActivity(bigdataAnalysisActivity);
    }
    
    @Test
    public void findAnalysisActivityByParams() {
        AnalysisDTO analysisDTO = new AnalysisDTO();
        analysisDTO.setTaskId(1L);
        Page page = bigdataAnalysisActivityService.findAnalysisActivityByParams(analysisDTO);
    }
}