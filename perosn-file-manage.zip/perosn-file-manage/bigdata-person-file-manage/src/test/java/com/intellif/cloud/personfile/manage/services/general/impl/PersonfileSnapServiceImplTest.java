package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSnapService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;
import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class PersonfileSnapServiceImplTest {

    @Autowired
    private PersonfileSnapService personfileSnapService;

    @Test
    public void findByImageUrl() {
//        Integer dd = personfileSnapService.findByImageUrl("9/ifsrc/engine1/eng1store1_0/ImgWareHouse/src_0_3511/20181126/20181126T195911_3033_3511.jpg");
//        System.out.println(dd);
    }

    @Test
    public void batchInsert() {
        PersonfileSnap personfileSnap = new PersonfileSnap();
        personfileSnap.setImageId("22");
        personfileSnap.setImageUrl("22");
        personfileSnap.setFaceUrl("33");
        personfileSnap.setFaceId("33");
        personfileSnap.setCreateTime(new Date());
        personfileSnap.setSnapTime(new Date());
        personfileSnap.setQualityInfo(3.0F);
//        personfileSnap.setAlgoVersion(33);
//        personfileSnap.setSourceType(1);
        personfileSnap.setSourceId("2");
        personfileSnap.setSysCode("DeepEye.t_face_4");
        personfileSnap.setPersonFilesId("4617498345592594911");

        List<PersonfileSnap> personfileSnapList = Lists.newLinkedList();
        personfileSnapList.add(personfileSnap);
        Integer dd = personfileSnapService.batchInsert(personfileSnapList);
    }

    @Test
    public void statisticSnapByDate(){
//        Integer num = personfileSnapService.statisticSnapByDate("2018-02-12 00:00:00","2019-12-12 00:00:00");
    }
}