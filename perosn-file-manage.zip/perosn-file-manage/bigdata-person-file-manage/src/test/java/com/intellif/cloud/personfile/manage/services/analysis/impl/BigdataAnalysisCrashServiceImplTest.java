package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrash;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisCrashServiceImplTest {
    
    @Autowired
    private BigdataAnalysisCrashService bigdataAnalysisCrashService;
    
    @Test
    public void findAnalysisCrashById() {
        bigdataAnalysisCrashService.findAnalysisCrashById(97l);
    }
    
    @Test
    public void deleteAnalysisCrash() {
        BigdataAnalysisCrash bigdataAnalysisCrash = new BigdataAnalysisCrash();
        bigdataAnalysisCrash.setId(97l);
        bigdataAnalysisCrashService.deleteAnalysisCrash(bigdataAnalysisCrash);
    }
    
    @Test
    public void insertAnalysisCrash() {
        BigdataAnalysisCrash bigdataAnalysisCrash = new BigdataAnalysisCrash();
        bigdataAnalysisCrash.setCameraId("ee");
        bigdataAnalysisCrash.setAreaCode(ICommonConstant.Letter.A);
        bigdataAnalysisCrashService.insertAnalysisCrash(bigdataAnalysisCrash);
    }
    
    @Test
    public void updateAnalysisCrash() {
        BigdataAnalysisCrash bigdataAnalysisCrash = new BigdataAnalysisCrash();
        bigdataAnalysisCrash.setCameraId("aa");
        bigdataAnalysisCrash.setAreaCode(ICommonConstant.Letter.B);
        bigdataAnalysisCrash.setId(97l);
        bigdataAnalysisCrashService.updateAnalysisCrash(bigdataAnalysisCrash);
    }
    
    @Test
    public void findAnalysisCrashByParams() {
        CrashDTO crashDTO = new CrashDTO();
        crashDTO.setTaskId(2l);
        crashDTO.setPage(1);
        crashDTO.setPerpage(29);
        Page<BigdataAnalysisCrash> page = bigdataAnalysisCrashService.findAnalysisCrashByParams(crashDTO);
    }
}