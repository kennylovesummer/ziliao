package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.services.account.BigdataAccountService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAccountServiceImplTest {
    
    @Autowired
    private BigdataAccountService bigdataAccountService;
    
    @Test
    public void findBigdataAccountById() {
        bigdataAccountService.findBigdataAccountById(1L);
    }
    
    @Test
    public void insertBigdataAccount() {
        BigdataAccount bigdataAccount = new BigdataAccount();
        bigdataAccount.setAccount("test");
        bigdataAccount.setName("Tom");
        bigdataAccount.setPassword("123");
        bigdataAccountService.insertBigdataAccount(bigdataAccount);
    }
    
    @Test
    public void deleteBigdataAccountById() {
        bigdataAccountService.deleteBigdataAccountById(1L);
    }
    
    @Test
    public void updateBigdataAccount() {
        BigdataAccount bigdataAccount = new BigdataAccount();
        bigdataAccount.setId(1L);
        bigdataAccount.setName("Bob");
        bigdataAccount.setPassword("1234");
        bigdataAccountService.updateBigdataAccount(bigdataAccount);
    }
}