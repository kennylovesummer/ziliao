package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.services.general.PersonfileConcernService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.text.ParseException;
import java.util.Date;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class PersonfileConcernServiceTest {
    
    @Autowired
    PersonfileConcernService personfileConcernService;
    
    @Test
    public void insertPersonfileConcern() {
        PersonfileConcern personfileConcern = new PersonfileConcern();
        personfileConcern.setConcerner("superuser1");
        personfileConcern.setPersonFilesId("DNAdkfj33r34");
        personfileConcern.setCreateTime(new Date());
        personfileConcern.setModifiedTime(new Date());
        personfileConcern.setCreater("superuser");
        personfileConcern.setModifier("superuser");
        try {
            personfileConcernService.insertPersonfileConcern(personfileConcern);
        } catch (BusinessException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void deleteByIdPersonfileConcern() {
        try {
            personfileConcernService.deleteByIdPersonfileConcern("DNAdkfj33r34");
        } catch (BusinessException e) {
            e.printStackTrace();
        }
    }
}