package com.intellif.cloud.personfile.manage.services.sub;

import com.google.common.collect.Lists;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.PersonfileHeadPicture;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveAvatorServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;
import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes= PersonfilesManageApplication.class)
public class SubArchiveAvatorServiceImplTest {
    
    @Autowired
    private SubArchiveAvatorServiceImpl subArchiveAvatorService;
    
    @Before
    public void initTableCache(){
        subArchiveAvatorService.getAllTableFromDB(true,true);
    }
    
    @Test
    public void batchInsert() {
        PersonfileHeadPicture personfileHeadPicture = new PersonfileHeadPicture();
        personfileHeadPicture.setPersonFilesId("11");
        personfileHeadPicture.setPersonFileCreateTime(new Date());
        List<PersonfileHeadPicture> personfileHeadPictureList = Lists.newArrayList();
        personfileHeadPictureList.add(personfileHeadPicture);
        subArchiveAvatorService.batchInsert(personfileHeadPictureList);
    }
    
    @Test
    public void findByPersonfileId() {
        PersonfileHeadPicture personfileHeadPicture = subArchiveAvatorService.findByPersonfileId("11");
    }
}