package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileConcernService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class IPersonfileConcernServiceTest {
    
    @Autowired
    IPersonfileConcernService iPersonfileConcernService;
    
    @Test
    public void findByConcerner() {
        List<PersonfileConcern> personfileConcernList = iPersonfileConcernService.findByConcerner(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
    }
    
    @Test
    public void findByPersonfileId() {
        PersonfileConcern personfileConcern = iPersonfileConcernService.findByPersonfileId("DNA2018101600143");
        System.out.println(personfileConcern.toString());
    }
    
    @Test
    public void updatePersonfileConcern() {
        PersonfileConcern personfileConcern = iPersonfileConcernService.findByPersonfileId("DNA2018101600143");
        personfileConcern.setConcerner("superman");
        iPersonfileConcernService.updatePersonfileConcern(personfileConcern);
    }
}