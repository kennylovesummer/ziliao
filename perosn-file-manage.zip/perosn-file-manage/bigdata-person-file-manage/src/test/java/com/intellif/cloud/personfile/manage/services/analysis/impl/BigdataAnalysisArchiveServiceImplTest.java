package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.intellif.cloud.PersonfilesManageApplication;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PersonfilesManageApplication.class)
public class BigdataAnalysisArchiveServiceImplTest {
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    @Test
    public void findAnalysisArchiveById() {
        bigdataAnalysisArchiveService.findAnalysisArchiveById(97l);
    }
    
    @Test
    public void deleteAnalysisArchive() {
        BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
        bigdataAnalysisArchive.setId(97l);
        bigdataAnalysisArchiveService.deleteAnalysisArchive(bigdataAnalysisArchive);
    }
    
    @Test
    public void insertAnalysisArchive() {
        BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
        bigdataAnalysisArchive.setAid("dsf");
        bigdataAnalysisArchive.setTaskId(1l);
        bigdataAnalysisArchiveService.insertAnalysisArchive(bigdataAnalysisArchive);
    }
    
    @Test
    public void updateAnalysisArchive() {
        BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
        bigdataAnalysisArchive.setAid("555");
        bigdataAnalysisArchive.setId(97l);
        bigdataAnalysisArchiveService.updateAnalysisArchive(bigdataAnalysisArchive);
    }
    
    @Test
    public void findAnalysisArchiveByParams() {
        AnalysisDTO analysisDTO = new AnalysisDTO();
        analysisDTO.setTaskId(16l);
        analysisDTO.setPage(1);
        analysisDTO.setPerpage(12);
        Page<BigdataAnalysisArchive> page = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(analysisDTO);
        List<BigdataAnalysisArchive> analysisArchiveList = page.getResult();
    }
    
    @Test
    public void deleteBigdataAnalysisArchiveByTaskId(){
        bigdataAnalysisArchiveService.deleteBigdataAnalysisArchiveByTaskId(1L);
    }
}