package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.handler.analysis.createTask.AnalysisCreateHandler;
import com.intellif.cloud.personfile.manage.handler.analysis.syncResult.AnalysisResultHandler;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskListDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.crash.CrashVO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.task.AnalysisSyncWork;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @see BigdataAnalysisTaskService
 */
@Service
public class BigdataAnalysisTaskServiceImpl extends BaseServiceImpl implements BigdataAnalysisTaskService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisCrashAreaService bigdataAnalysisCrashAreaService;
    
    @Autowired
    private BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    @Autowired
    private AnalysisFeignClient analysisFeignClient;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Override
    public BigdataAnalysisTask findBigdataAnalysisTaskById(Long id) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("id", id);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBigdataAnalysisTaskById");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (BigdataAnalysisTask) object;
    }
    
    @Override
    public BigdataAnalysisTask findBigdataAnalysisTaskByExecId(String execId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("execId", execId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBigdataAnalysisTaskByExecId");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (BigdataAnalysisTask) object;
    }
    
    @Override
    public void insertBigdataAnalysisTask(BigdataAnalysisTask bigdataAnalysisTask) {
        this.baseDao.insert(bigdataAnalysisTask);
    }
    
    @Override
    public void updateBigdataAnalysisTask(BigdataAnalysisTask bigdataAnalysisTask) {
        this.baseDao.update(bigdataAnalysisTask);
    }
    
    @Override
    public Page<CrashVO> findBigdataAnalysisTaskByParams(AnalysisTaskListDTO crashListDTO) {
        QueryEvent<AnalysisTaskListDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(crashListDTO);
        queryEvent.setStatement("findBigdataAnalysisTaskByParams");
        
        Page<CrashVO> page = PageHelper.startPage(crashListDTO.getPageNo(), crashListDTO.getPageSize(), true);
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public BigdataAnalysisTask findBigdataAnalysisTaskByTaskName(String name) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("name", name);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBigdataAnalysisTaskByTaskName");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (BigdataAnalysisTask) object;
    }
    
    @Override
    public Integer updateStatusByOldStatus(Long taskId, Integer newStatus, Integer oldStatus) {
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        parameters.put("newStatus", newStatus);
        parameters.put("oldStatus", oldStatus);
        return this.baseDao.updateStatement("updateStatusByOldStatus",parameters);
    }
    
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteTask(Long taskId) {
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setId(taskId);
//        bigdataAnalysisTask.setIsDeleted(1);
//        updateBigdataAnalysisTask(bigdataAnalysisTask);
        this.baseDao.delete(bigdataAnalysisTask);
        
        bigdataAnalysisCrashAreaService.deleteByTaskId(taskId);
    }
    
    @Override
    public List<BigdataAnalysisTask> findBigdataAnalysisTaskByStatus(Integer status) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("status", status);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBigdataAnalysisTaskByStatus");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object == null ? null : (List<BigdataAnalysisTask>) object;
    }
    
    @Override
    public BaseDataRespDTO createTask(JSONObject params) {
        try {
            if (!params.containsKey("taskType") || Strings.isBlank(params.getString("taskType"))) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "任务新建失败", "任务类型未知");
            }
            
            String execId = AnalysisCreateHandler.getHandlerChain().createTask(params.getString("taskType"), params);
            
            return new BaseDataRespDTO(execId, IResultCode.SUCCESS, "任务新建成功");
        } catch (BusinessException e) {
            String msg = e.getExceptionMsg();
            boolean isNameRepeat = msg.contains("for key 'name'");
            return new BaseDataRespDTO(null, IResultCode.ERROR, isNameRepeat ? "任务名字重复" : "任务创建失败", isNameRepeat ? "任务名字重复" : msg);
        } catch (Exception e) {
            String msg = e.getMessage();
            boolean isNameRepeat = msg.contains("for key 'name'");
            return new BaseDataRespDTO(null, IResultCode.ERROR, isNameRepeat ? "任务名字重复" : "任务创建失败", isNameRepeat ? "任务名字重复" : msg);
        }
    }
    
    @Override
    public void updateTaskStatus() throws InterruptedException {
        while (true) {
            List<BigdataAnalysisTask> bigdataAnalysisTaskList = findBigdataAnalysisTaskByStatus(2);
            if (CollectionUtils.isNotEmpty(bigdataAnalysisTaskList)) {
                for (BigdataAnalysisTask bigdataAnalysisTask : bigdataAnalysisTaskList) {
                    if (Strings.isBlank(bigdataAnalysisTask.getExecId())) {
                        continue;
                    }
                    if (updateStatusByOldStatus(bigdataAnalysisTask.getId(),3,2) == 1)
                        ThreadPoolService.threadPool.submit(new AnalysisSyncWork(this, bigdataAnalysisTask.getExecId()));
                }
            }
            Thread.sleep(6000);
        }
    }
    
    @Override
    public boolean analysisTaskStatusHandler(String execId) {
        BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(execId);
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        offLineTaskDTO.setOpCode("GetTask");
        offLineTaskDTO.setTaskId(execId);
        offLineTaskDTO.setTaskType(bigdataAnalysisTask.getType());
        try {
            boolean isFinish = false;
            String nowStatus = "0";
            while (!isFinish) {
                long endTime = System.currentTimeMillis();
                if ((endTime - bigdataAnalysisTask.getCreateTime().getTime()) > personPropertiest.getDateAnalysisTaskTimeOutMillis()) {
                    updateTaskToStatus(0, endTime - bigdataAnalysisTask.getCreateTime().getTime(), "已超时，超时时间" + personPropertiest.getDateAnalysisTaskTimeOutMillis() + "ms", bigdataAnalysisTask);
                    isFinish = true;
                }
                JSONObject result = JSONObject.parseObject(analysisFeignClient.getTaskStatus(offLineTaskDTO));
                if (SuccessRespUtil.isSuccess(result)) {
                    
                    String status = result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("status");
                    Long costTime = result.getJSONObject(ICommonConstant.ResultDataFormat.data).getLong("useTime");
                    String remark = result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("reMark");
                    
                    // 成功
                    if ("000".equals(status)) {
                        if (bigdataAnalysisTask != null) {
                            AnalysisTaskResultDTO analysisTaskResultDTO = new AnalysisTaskResultDTO();
                            analysisTaskResultDTO.setType(bigdataAnalysisTask.getType());
                            analysisTaskResultDTO.setTaskId(execId);
                            analysisTaskResultDTO.setTaskId2(bigdataAnalysisTask.getId());
                            analysisTaskResultDTO.setCostTime(costTime);
                            DataStisticTypeEnum typeEnum = DataStisticTypeEnum.getByName(bigdataAnalysisTask.getType());
                            if (typeEnum != null) {
                                AnalysisResultHandler.getHandlerChain().syncResult(typeEnum.getResultName(), analysisTaskResultDTO);
                            }
                        }
                        isFinish = true;
                    }
                    
                    // 排队中
                    if ("100".equals(status)) {
                        if (!nowStatus.equals(status)) {
                            nowStatus = status;
                            updateTaskToStatus(3, costTime, remark, bigdataAnalysisTask);
                        }
                    }
                    
                    // 失败
                    if ("400".equals(status) || "300".equals(status) || "500".equals(status)) {
                        if (Strings.isBlank(remark)) {
                            remark = "任务失败或者被异常终止！";
                        }
                        updateTaskToStatus(0, costTime, remark, bigdataAnalysisTask);
                        isFinish = true;
                    }
                    
                } else {
                    String remark = result.getString(ICommonConstant.ResultDataFormat.respRemark);
                    logger.error("任务：" + execId + " 获取任务状态失败;数据平台异常：" + (remark != null ? remark : "未知"));
                    updateTaskToStatus(0, null, "获取任务状态失败;数据平台异常：" + (remark != null ? remark : "未知"), bigdataAnalysisTask);
                    return true;
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("任务：" + execId + ";数据导入失败：" + e.getMessage());
            updateTaskToStatus(0, null, "数据导入失败：" + e.getMessage(), bigdataAnalysisTask);
            return true;
        }
    }
    
    /**
     * 将任务置为失败
     *
     * @param status              状态（0：失败；1：成功；2：正在执行；3：排队中；4：准备中）
     * @param costTime            耗时
     * @param remark              失败原因
     * @param bigdataAnalysisTask 任务
     */
    private void updateTaskToStatus(Integer status, Long costTime, String remark, BigdataAnalysisTask bigdataAnalysisTask) {
        if (bigdataAnalysisTask != null) {
            bigdataAnalysisTask.setStatus(status);
            bigdataAnalysisTask.setCostTime(costTime);
            bigdataAnalysisTask.setRemark(remark);
            bigdataAnalysisTaskService.updateBigdataAnalysisTask(bigdataAnalysisTask);
        }
    }
    
}
