package com.intellif.cloud.personfile.manage.model.vo.activityRoutine;

import com.alibaba.fastjson.JSON;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName PersonfileActivityRoutinesVO
 * @Author liuYu
 * @create 2018-10-25 14:18
 * @Version 1.0
 * @desc 活动
 */
@Data
public class PersonfileActivityRoutinesVO implements Serializable {

    private static final long serialVersionUID = -4570738701531394951L;

    private Integer number;

    private String devId;

    private String devName;

    private String startTime;

    private String endTime;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
