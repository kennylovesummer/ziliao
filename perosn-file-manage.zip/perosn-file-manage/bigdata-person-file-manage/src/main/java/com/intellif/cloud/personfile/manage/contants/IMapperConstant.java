/**
 * 文件名：IMapperConstant.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：wangyi
 * 创建时间：2018年10月16日
 * 修改理由：
 * 修改内容：
 */
package com.intellif.cloud.personfile.manage.contants;

/**
 * 数据操作常量
 * <功能详细描述>
 *
 * @author wangyi
 * @version [版本号, 2012-11-26]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public interface IMapperConstant {
    String COMMON_INSERT = "insert";

    String COMMON_INSERT_BATCH = "batchInsert";

    String COMMON_UPDATE = "update";

    String COMMON_UPDATE_BATCH = "batchUpdate";

    String COMMON_DELETE = "delete";

    String COMMON_DELETE_BATCH = "batchDelete";

    String COMMON_FINDBYID = "findById";

    String COMMON_FINDALL = "findAll";

}
