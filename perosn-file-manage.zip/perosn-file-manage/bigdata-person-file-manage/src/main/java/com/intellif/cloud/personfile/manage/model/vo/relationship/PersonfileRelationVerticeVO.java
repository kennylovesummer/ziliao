package com.intellif.cloud.personfile.manage.model.vo.relationship;

import com.alibaba.fastjson.JSONObject;
import org.apache.logging.log4j.util.Strings;

import java.io.Serializable;
import java.util.Date;

/**
 * 关系图谱-点
 *
 * @author liuzj
 * @date 2019-04-13
 */
public class PersonfileRelationVerticeVO  implements Serializable {

    private String aid;

    private String name;

    private String identityNo;

    private String label;

    private String labelName;

    private String labelManage;

    private Object props;

    private String createTime;

    private String modifyTime;

    private Date appearTime;

    private Integer imageCount;

    public Integer getImageCount() {
        return imageCount;
    }

    public void setImageCount(Integer imageCount) {
        this.imageCount = imageCount;
    }

    public Date getAppearTime() {
        return appearTime;
    }

    public void setAppearTime(Date appearTime) {
        this.appearTime = appearTime;
    }

    public String getLabelManage() {
        return labelManage;
    }

    public void setLabelManage(String labelManage) {
        this.labelManage = labelManage;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getIdentityNo() {
        return identityNo;
    }

    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo;
    }

    public Object getProps() {
        return props;
    }

    public void setProps(String props) {
        if (Strings.isNotBlank(props)) {
            this.props = JSONObject.parse(props);
        }
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelName() {
        return labelName;
    }

    public void setLabelName(String labelName) {
        this.labelName = labelName;
    }

    public static void main(String[] args) {
        String dd = "{\"peerNum\":1}";
        Object J = JSONObject.parse(dd);
    }
}
