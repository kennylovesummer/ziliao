/*
 * 文 件 名:  BaseDao.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2014-11-26
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.intellif.cloud.personfile.manage.services.base;

import com.intellif.cloud.personfile.manage.utils.IMapperConstant;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.cloud.personfile.manage.utils.MySqlHelper;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;


/**
 * 数据操作实现类
 *
 * @param <T> T
 * @param <E> E
 * @author wangyi
 * @version [版本号, 2014-11-26]
 */
public class BaseDaoImpl<T, E> implements IBaseDao<T, E> {
    /**
     * 注入sqlSessionTemplate
     */
    @Autowired
    private transient SqlSession sqlSession;
    
    /**
     * 注入sessionFactory
     */
    @Autowired
    private transient SqlSessionFactory sessionFactory;
    
    public SqlSessionFactory getSessionFactory() {
        return sessionFactory;
    }
    
    /**
     * sessionFactory
     * <功能详细描述>
     *
     * @param sessionFactorys
     * @see [类、类#方法、类#成员]
     */
    public void setSessionFactory(SqlSessionFactory sessionFactorys) {
        this.sessionFactory = sessionFactorys;
    }
    
    public void setSqlSessionTemplate(final SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }
    
    public SqlSession getSqlSessionTemplate() {
        return sqlSession;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int insert(final T obj) {
        return getSqlSessionTemplate().insert(MySqlHelper.getSQLName(IMapperConstant.COMMON_INSERT, obj), obj);
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int update(final T obj) {
        
        return getSqlSessionTemplate().update(MySqlHelper.getSQLName(IMapperConstant.COMMON_UPDATE, obj), obj);
    }
    
    
    @Override
    public int updateStatement(String statementName, Object paramValue) {
        
        return getSqlSessionTemplate().update(statementName, paramValue);
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public T findById(final T obj) {
        return getSqlSessionTemplate().selectOne(MySqlHelper.getSQLName(IMapperConstant.COMMON_FINDBYID, obj), obj);
    }
    
    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public List<E> findAllIsPageByCustom(final QueryEvent event) {
        event.initParameter();
        List<E> object;
        if (null == event.getStatement() || "".equals(event.getStatement())) {
            object = getSqlSessionTemplate().selectList(
                    MySqlHelper.getSQLName(IMapperConstant.COMMON_FINDALL, event.getObj()), event.getParameter());
        } else {
            object = getSqlSessionTemplate().selectList(event.getStatement(), event.getParameter());
        }
        return object;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int batchInsert(final T obj, String statement, List<E> list) {
        //如果没有自己定义的标签，就使用传的对象构造标签
        if (null == statement || "".equals(statement)) {
            //如果这个对象也为空，找不到标签，无法进行操作
            if (null == obj) {
                return 0;
            }
            statement = MySqlHelper.getSQLName(IMapperConstant.COMMON_INSERT, obj);
        }
        SqlSession sqlSession = null;
        try {
            sqlSession = sessionFactory.openSession(ExecutorType.BATCH, false);
            for (E e : list) {
                sqlSession.insert(statement, e);
            }
            sqlSession.commit();
        } catch (Exception e) {
            throw e;
        } finally {
            if (null != sqlSession) {
                sqlSession.close();
            }
        }
        //返回成功
        return 1;
    }
    
    @Override
    public int batchInsert(String statement,List<Map<String, Object>> params) {
        if (null == statement || "".equals(statement)) {
            return 0;
        }
        SqlSession sqlSession = null;
        try {
            sqlSession = sessionFactory.openSession(ExecutorType.BATCH, false);
            sqlSession.insert(statement, params);
            sqlSession.commit();
        } catch (Exception e) {
            throw e;
        } finally {
            if (null != sqlSession) {
                sqlSession.close();
            }
        }
        return 1;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int batchDelete(final T obj, final Map<String, List<E>> map) {
        return getSqlSessionTemplate().delete(MySqlHelper.getSQLName(IMapperConstant.COMMON_DELETE_BATCH, obj), map);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int batchUpdate(final T obj, final Map<String, List<E>> map) {
        return getSqlSessionTemplate().update(MySqlHelper.getSQLName(IMapperConstant.COMMON_UPDATE_BATCH, obj), map);
    }
    
    @Override
    public int batchUpdate(String statement,List<T> params) {
        if (null == statement || "".equals(statement)) {
            return 0;
        }
        SqlSession sqlSession = null;
        try {
            sqlSession = sessionFactory.openSession(ExecutorType.BATCH, false);
            sqlSession.update(statement, params);
            sqlSession.commit();
        } catch (Exception e) {
            throw e;
        } finally {
            if (null != sqlSession) {
                sqlSession.close();
            }
        }
        return 1;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> executeProcedure(final String statement, final Map<String, Object> map) {
        getSqlSessionTemplate().selectOne(statement, map);
        return map;
    }
    
    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Object findOneByCustom(QueryEvent event) {
        event.initParameter();
        Object object = getSqlSessionTemplate().selectOne(event.getStatement(), event.getParameter());
        return object;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public Object count(QueryEvent<T> event) {
        event.initParameter();
        return getSqlSessionTemplate().selectOne(event.getStatement(), event.getParameter());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<E> findAll(T obj) {
        return getSqlSessionTemplate().selectList(MySqlHelper.getSQLName(IMapperConstant.COMMON_FINDALL, obj));
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int delete(T obj) {
        return getSqlSessionTemplate().delete(MySqlHelper.getSQLName(IMapperConstant.COMMON_DELETE, obj), obj);
    }
}
