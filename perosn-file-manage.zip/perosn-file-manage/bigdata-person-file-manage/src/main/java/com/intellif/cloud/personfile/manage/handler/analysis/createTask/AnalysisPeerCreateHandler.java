package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.PeerTaskCreateDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.util.Arrays;

/**
 * 同行分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisPeerCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    AnalysisPeerCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        PeerTaskCreateDTO peerTaskCreateDTO = JSONObject.parseObject(params.toJSONString(), PeerTaskCreateDTO.class);
        
        // 参数校验
        if (CollectionUtils.isEmpty(peerTaskCreateDTO.getAids())
                || Strings.isBlank(peerTaskCreateDTO.getStartTime())
                || Strings.isBlank(peerTaskCreateDTO.getEndTime())) {
            throw new BusinessException(IResultCode.ERROR,"参数异常");
        }
    
        // 人员是否存在校验
        PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(peerTaskCreateDTO.getAids().get(0));
        if (personfileBasics == null) {
            throw new BusinessException(IResultCode.ERROR,"分析档案不存在");
        }
    
        String rulesConfig = personPropertiest.getDataAnalysisPeerRules();
        if (Strings.isNotBlank(rulesConfig)) {
            String[] ruleArray = rulesConfig.split(ICommonConstant.Symbol.AND);
            if (ruleArray.length == 3) {
                if (CollectionUtils.isEmpty(peerTaskCreateDTO.getPeriods())) {
                    peerTaskCreateDTO.setPeriods(Arrays.asList(ruleArray[0].split(ICommonConstant.Symbol.COMMA)));
                }
                if (peerTaskCreateDTO.getInterval() == null) {
                    peerTaskCreateDTO.setInterval(Long.valueOf(ruleArray[1].trim()));
                }
                
                if (peerTaskCreateDTO.getFilterTimes() == null) {
                    peerTaskCreateDTO.setFilterTimes(Long.valueOf(ruleArray[2].trim()));
                }
            }
        }
    
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setTaskType(DataStisticTypeEnum.PEER.getName());
        peerTaskCreateDTO.setAid(peerTaskCreateDTO.getAids().get(0));
        offLineTaskDTO.setParams(peerTaskCreateDTO.toString());
        offLineTaskDTO.setTaskName(peerTaskCreateDTO.getTaskName());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
    
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setType(DataStisticTypeEnum.PEER.getName());
        bigdataAnalysisTask.setName(peerTaskCreateDTO.getTaskName());
        bigdataAnalysisTask.setAid(peerTaskCreateDTO.getAids().get(0));
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        
        return execId;
    }
}
