package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.util.Date;

/**
 * 用户
 */
@Data
public class BigdataAccount {
    private Long id;

    private String name;

    private String account;

    private String password;
    
    private String ip;

    private Date loginTime;

    private Integer isDeleted;

    private String createBy;

    private Date createTime;

    private String modifyBy;

    private Date modifyTime;
}