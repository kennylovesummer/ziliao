/*
 * 文 件 名:  BaseService.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2015/7/14
 */
package com.intellif.cloud.personfile.manage.services.base;

/**
 * service基类
 * @author wangyi
 * @version [版本号, 2015/7/14]
 */
public interface IBaseService
{

}
