package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;

import java.text.ParseException;

/**
 * @ClassName PersonfileConcernService
 * @Author liuYu
 * @create 2018-10-19 18:06
 * @Version 1.0
 * @desc
 */
public interface PersonfileConcernService {

    /**
     * 保存关注人员的信息
     * @return
     * @throws BusinessException
     * @see
     */

    int insertPersonfileConcern(PersonfileConcern personfileConcern) throws BusinessException, ParseException;

    /**
     * 通过档案id删除关注人员
     * @return
     * @throws BusinessException
     * @see
     */

    int deleteByIdPersonfileConcern(String personFilesId) throws BusinessException;
}
