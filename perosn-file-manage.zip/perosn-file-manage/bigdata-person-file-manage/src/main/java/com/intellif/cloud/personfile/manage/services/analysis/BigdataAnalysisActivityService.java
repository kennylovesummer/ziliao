package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisActivity;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;

import java.util.List;

/**
 * 数据分析-活动规律
 *
 * @author liuzj
 * @date 2019-10-22
 */
public interface BigdataAnalysisActivityService {
    
    /**
     * 根据任务ID查找
     *
     * @param taskId 任务ID
     * @return entity
     */
    BigdataAnalysisActivity findAnalysisActivityByTaskId(Long taskId);
    
    /**
     * 根据ID删除对象
     *
     * @param taskId 任务ID
     */
    void deleteAnalysisActivityByTaskId(Long taskId);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisActivity 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisActivity(BigdataAnalysisActivity bigdataAnalysisActivity);
    
    /**
     * 批量插入
     *
     * @param analysisActivities 数据集
     */
    void batchInsertAnalysisActivity(List<BigdataAnalysisActivity> analysisActivities);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisActivity 待更新的对象
     */
    void updateAnalysisActivity(BigdataAnalysisActivity bigdataAnalysisActivity);
    
    /**
     * 分页查找
     *
     * @param analysisDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisActivity> findAnalysisActivityByParams(AnalysisDTO analysisDTO);
    
}
