package com.intellif.cloud.personfile.manage.services.sub;

import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileHeadPicture;

import java.util.List;

/**
 * 档案最近抓拍时间和活动更新时间
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月26日
 * @see SubArchiveAvatorService
 * @since JDK1.8
 */
public interface SubArchiveAvatorService {

    /**
     * 保存
     *
     * @param PersonfileHeadPicture 待保存实体类
     * @return int
     */
    int batchInsert(List<PersonfileHeadPicture> PersonfileHeadPicture);

    /**
     * 根据ID查找
     *
     * @param personfilesId 档案ID
     * @return PersonfileHeadPicture
     */
    PersonfileHeadPicture findByPersonfileId(String personfilesId);
    
    void archiveImageSync(List<PersonfileHeadPicture> personfileBasics);

}
