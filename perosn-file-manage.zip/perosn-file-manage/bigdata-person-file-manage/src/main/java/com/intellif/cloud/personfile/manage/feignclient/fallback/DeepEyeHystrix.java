package com.intellif.cloud.personfile.manage.feignclient.fallback;

import com.intellif.cloud.personfile.manage.feignclient.DeepEyeClient;
import org.springframework.stereotype.Component;


/**
 * @author liuzhijian
 * @version 1.2.0
 * @date 2019年05月29日
 * @see DeepEyeClient
 * @since JDK1.8
 */
@Component
public class DeepEyeHystrix implements DeepEyeClient {
    
    @Override
    public String login(String username, String password, String grant_type) {
        return null;
    }
}
