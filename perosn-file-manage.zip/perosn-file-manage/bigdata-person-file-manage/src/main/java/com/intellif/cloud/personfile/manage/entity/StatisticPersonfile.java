package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName StatisticPersonfile
 * @Author liuzhijian
 * @create 2018-10-20
 * @Version 1.0
 * @desc 档案各类型数量统计（实名 & 未实名）
 */
public class StatisticPersonfile implements Serializable {

    private static final long serialVersionUID = -2021573907786511183L;

    private Long id;

    private Date createTime;

    private Date modifiedTime;

    private Date statisticDate;

    private int statisticWeek;

    private int statisticTotal;

    private int statisticRealNameTotal;

    private int statisticNewNum;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Date getStatisticDate() {
        return statisticDate;
    }

    public void setStatisticDate(Date statisticDate) {
        this.statisticDate = statisticDate;
    }

    public int getStatisticWeek() {
        return statisticWeek;
    }

    public void setStatisticWeek(int statisticWeek) {
        this.statisticWeek = statisticWeek;
    }

    public int getStatisticTotal() {
        return statisticTotal;
    }

    public void setStatisticTotal(int statisticTotal) {
        this.statisticTotal = statisticTotal;
    }

    public int getStatisticRealNameTotal() {
        return statisticRealNameTotal;
    }

    public void setStatisticRealNameTotal(int statisticRealNameTotal) {
        this.statisticRealNameTotal = statisticRealNameTotal;
    }

    public int getStatisticNewNum() {
        return statisticNewNum;
    }

    public void setStatisticNewNum(int statisticNewNum) {
        this.statisticNewNum = statisticNewNum;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}