package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.kafka.MqInit;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import com.intellif.cloud.personfile.manage.services.general.IDevSynchronizeService;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveAvatorServiceImpl;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl;
import com.intellif.log.LoggerUtilI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;

/**
 * 启动初始化
 *
 * @Author liuYu
 * @create 2018-10-18 9:42
 * @Version 1.0
 */

@Component
public class InitializingController implements CommandLineRunner {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final IDevSynchronizeService devSynchronizeService;
    
    private final BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;
    
    private final BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    private final MqInit mqInit;
    
    private final SubArchiveServiceImpl subArchiveService;
    
    private final SubArchiveAvatorServiceImpl subArchiveAvatorService;
    
    private final PersonPropertiest personPropertiest;
    
    @Autowired
    public InitializingController(IDevSynchronizeService devSynchronizeService,
                                  BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService,
                                  BigdataAnalysisTaskService bigdataAnalysisTaskService,
                                  MqInit mqInit,
                                  SubArchiveServiceImpl subArchiveService,
                                  PersonPropertiest personPropertiest,
                                  SubArchiveAvatorServiceImpl subArchiveAvatorService) {
        this.devSynchronizeService = devSynchronizeService;
        this.bigdataAnalysisExportTaskService = bigdataAnalysisExportTaskService;
        this.bigdataAnalysisTaskService = bigdataAnalysisTaskService;
        this.mqInit = mqInit;
        this.subArchiveService = subArchiveService;
        this.personPropertiest = personPropertiest;
        this.subArchiveAvatorService = subArchiveAvatorService;
    }
    
    @Override
    public void run(String... strings) {
    
        logger.info("初始化同步设备列表...");
        devSynchronizeService.devSynchDeepEye();

        logger.info("清除被终止的下载任务...");
        bigdataAnalysisExportTaskService.deleteDiedAnalysisExportTask();

        logger.info("kafka启动...");
        mqInit.archiveConsumer();
        mqInit.eventConsumer();
        mqInit.archiveToSolrConsumer();
        mqInit.mergeArchiveConsumer();
    
        logger.info("分表初始化...");
        subArchiveService.initSubTable(personPropertiest.getArchiveTableMaxTables());
        subArchiveAvatorService.initSubTable(personPropertiest.getArchiveTableMaxTables());
        subArchiveService.getAllTableFromDB(true,true);
        
        logger.info("数据分析更新任务状态线程启动...");
        try {
            bigdataAnalysisTaskService.updateStatusByOldStatus(null,2,3);
            bigdataAnalysisTaskService.updateTaskStatus();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
