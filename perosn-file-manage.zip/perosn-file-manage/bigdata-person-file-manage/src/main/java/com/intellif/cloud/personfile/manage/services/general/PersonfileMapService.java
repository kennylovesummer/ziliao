package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;

import java.util.List;

/**
 * @program ifaas-person-file-manage
 * @Author liuYu
 * @create 2018-10-29 10:56
 * @Version 1.0
 * @desc
 */
public interface PersonfileMapService {

    List<SnapMapVO> get(List<String> lableIds) throws BusinessException;

}
