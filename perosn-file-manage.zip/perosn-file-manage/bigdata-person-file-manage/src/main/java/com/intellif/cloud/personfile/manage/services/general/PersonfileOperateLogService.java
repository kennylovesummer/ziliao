package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.entity.PersonfileOperateLog;

/**
 * 操作日志
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年11月14日
 * @see PersonfileOperateLogService
 * @since JDK1.8
 */
public interface PersonfileOperateLogService {

    /**
     * 新增
     *
     * @param personfileOperateLog 待新增实体
     * @return 新增条数
     */
    int insert(PersonfileOperateLog personfileOperateLog);

}
