package com.intellif.cloud.personfile.manage.services.sub;

import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import feign.Param;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface SubArchiveService {
    /**
     * 根据档案ID查询基础信息
     *
     * @param personFileId 档案ID
     * @return PersonfileBasics
     */
    PersonfileBasics findBaseInfoByPersonFileId(String personFileId);
    
    /**
     * 根据档案标签查询基础信息档案id
     *
     * @param lableIdList 标签名
     * @return PersonfileBasics
     */
    List<String> findBaseInfoByLabels(List<Integer> lableIdList);
    
    /**
     * 根据档案ID查询基础信息(包括标签名)
     *
     * @param personFileId 档案ID
     * @return PersonfileBasicsVO
     */
    PersonfileBasicsVO findBaseInfoVOByPersonFileId(String personFileId);
    
    /**
     * 根据档案添加标签
     *
     * @return
     * @see
     */
    int insertPersonfileBasicsLabel(String personFileId, Integer labelId) throws BusinessException;
    
    /**
     * 根据档案删除标签
     *
     * @return
     * @see
     */
    int deletePersonfileBasicsLabel(String personFileId, Integer labelId);
    
    /**
     * 编辑档案的基本信息
     *
     * @return
     * @see
     */
    int updatePersonfileBasics(PersonfileBasics personfileBasics);
    
    /**
     * 根据档案ID删除基本信息
     *
     * @param personfileId 档案ID
     * @return int
     */
    int deleteByPersonfileIdPersonfileBasics(String personfileId);
    
    /**
     * 保存基础信息
     *
     * @return int
     */
    int batchInsertPersonfileBasics(List<PersonfileBasics> personfileBasics);
    
    
    /**
     * 根据参数查找
     *
     * @param params 参数集
     * @return List
     */
    List<PersonfileBasics> findAutoByParam(Map<String, Object> params);
    
    /**
     * 统计新增和未实名新增的档案数量
     *
     * @param clusterStartTime 归档统计开始时间（聚那一天的类就是哪一天）
     * @param clusterEndTime 归档统计结果时间（聚那一天的类就是哪一天）
     * @param isRealName  是否实名（true：实名新增 false：新增总数）
     * @return Long
     */
    Integer statisticNewPersonfile(@Param(value = "clusterStartTime") String clusterStartTime, @Param(value = "clusterEndTime") String clusterEndTime, @Param(value = "isRealName") Boolean isRealName);
    
    
    /**
     * 档案合并/删除成功之后处理
     *
     * @param passivePersonFileId 档案ID
     */
    void personfileHandle(String passivePersonFileId, String initiativPersonFileId) throws BusinessException, IllegalAccessException;
    
    /**
     * 根据档案ID集合查找label信息
     *
     * @param personFileIds 档案ID集合
     * @return LIST
     */
    List<Map<String, Object>> findByPersonfileIds(List<String> personFileIds);
    
    /**
     * 档案中心搜索
     *
     * @param listFilterDTO 查询条件
     * @return List
     */
    BasePageRespDTO findByFilterParams(ListFilterDTO listFilterDTO);
    
    /**
     * 档案中心搜索-获取总数
     *
     * @param listFilterDTO 查询条件
     * @return Long
     */
    Long findPersonfilePageTotal(ListFilterDTO listFilterDTO);
    
    /**
     * 分页查找
     *
     * @return List
     */
    List<PersonfileClusterFinishDTO> findByPage(int pageNo, int perpage);
    
    /**
     * 查找出被删除档案的id
     *
     * @param personfilesIdList
     * @return List
     */
    List<String> findDeletedPersonfilesId(List<String> personfilesIdList);
    
    /**
     * 更新档案的ImageCount
     *
     * @param addImageCount eg: 1
     * @param personfileId
     * @return int
     */
    int updateImageCount(int addImageCount,String personfileId);
    
    /**
     * 年龄统计
     *
     * @return Map
     */
    Integer statisticAge(Integer startAge, Integer endAge, Boolean isEqual);
    
    /**
     * 档案中心查询
     *
     * @param listFilterDTO 参数集
     * @return List
     */
    List<PersonfileVO> findByParams(ListFilterDTO listFilterDTO);
    
    /**
     * 统计抓拍数和最近更新时间
     */
    void statisticImageCountAndGetRecentSnapTime() throws ParseException;
    
    void statisticImageCountAndRecentSnapTimeHandle(String table,Integer archiveBatch,Integer archiveSnapBatch) throws ParseException;
    
    /**
     * 批量更新基础信息
     *
     * @return int
     */
    int batchUpdatePersonfileBasics(List<PersonfileBasics> personfileBasics);
    
    void archiveSync(List<PersonfileBasics> personfileBasics);
    
}
