package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;


import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;

/**
 * 同行分析查询参数集合
 *
 * @author liuzj
 * @date 2019-06-20
 */
@Data
public class PeerTaskCreateDTO extends BaseAnalysisCreateDTO implements java.io.Serializable{
    
    private List<String> aids;
    
    private String aid;
    
    private List<String> sourceIds;
    
    private String startTime;
    
    private String endTime;
    
    private List<String> periods;
    
    private Long filterTimes;
    
    private Long interval;
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
