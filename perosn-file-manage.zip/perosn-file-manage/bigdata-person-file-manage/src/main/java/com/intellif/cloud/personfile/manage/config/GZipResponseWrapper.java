package com.intellif.cloud.personfile.manage.config;

import com.google.common.net.HttpHeaders;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPOutputStream;

public class GZipResponseWrapper extends HttpServletResponseWrapper {
        
        private GzipResponseStream gzipStream;
        
        private ServletOutputStream outputStream;
        
        private PrintWriter printWriter;
        
        public GZipResponseWrapper(HttpServletResponse response) {
            super(response);
            response.addHeader(HttpHeaders.CONTENT_ENCODING, "gzip");
        }
        
        public void finish() throws IOException {
            if (printWriter != null) {
                printWriter.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (gzipStream != null) {
                gzipStream.close();
            }
        }
        
        @Override
        public void flushBuffer() throws IOException {
            if (printWriter != null) {
                printWriter.flush();
            }
            if (outputStream != null) {
                outputStream.flush();
            }
            super.flushBuffer();
        }
        
        @Override
        public ServletOutputStream getOutputStream() throws IOException {
            if (printWriter != null) {
                throw new IllegalStateException("printWriter already defined");
            }
            if (outputStream == null) {
                initGzip();
                outputStream = gzipStream;
            }
            return outputStream;
        }
        
        @Override
        public PrintWriter getWriter() throws IOException {
            if (outputStream != null) {
                throw new IllegalStateException("printWriter already defined");
            }
            if (printWriter == null) {
                initGzip();
                printWriter = new PrintWriter(new OutputStreamWriter(gzipStream, getResponse().getCharacterEncoding()));
            }
            return printWriter;
        }
        
        private void initGzip() throws IOException {
            gzipStream = new GzipResponseStream(getResponse().getOutputStream());
        }
        
        private class GzipResponseStream extends ServletOutputStream {
        
        GZIPOutputStream gzipStream;
        final AtomicBoolean open = new AtomicBoolean(true);
        OutputStream output;
        
        public GzipResponseStream(OutputStream output) throws IOException {
            this.output = output;
            gzipStream = new GZIPOutputStream(output);
        }
        
        @Override
        public void close() throws IOException {
            if (open.compareAndSet(true, false)) {
                gzipStream.close();
            }
        }
        
        @Override
        public void flush() throws IOException {
            gzipStream.flush();
        }
        
        @Override
        public void write(byte b[]) throws IOException {
            write(b, 0, b.length);
        }
        
        @Override
        public void write(byte b[], int off, int len) throws IOException {
            if (!open.get()) {
                throw new IOException("Stream closed!");
            }
            gzipStream.write(b, off, len);
        }
        
        @Override
        public void write(int b) throws IOException {
            if (!open.get()) {
                throw new IOException("Stream closed!");
            }
            gzipStream.write(b);
        }
    
        @Override
        public boolean isReady() {
            return false;
        }
    
        @Override
        public void setWriteListener(WriteListener listener) {
        
        }
    }
}
