package com.intellif.cloud.personfile.manage.config;

import lombok.Data;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * kafka消费者配置
 *
 * @author liuzj
 * @date 2019-03-12
 */
@Configuration
@Data
public class KafkaProducerConfig {

    @Value("${kafka.producer.servers}")
    private String servers;

    @Value("${kafka.producer.retries}")
    private int retries;

    @Value("${kafka.producer.batch.size}")
    private int batchSize;

    @Value("${kafka.producer.linger}")
    private int linger;

    @Value("${kafka.producer.buffer.memory}")
    private int bufferMemory;

    @Value("${security.conf.path}")
    private String path;

    @Value("${user.keytab.file}")
    private String keyTabFile;

    @Value("${user.principal}")
    private String userPrincipal;

    @Value("${security.mode:false}")
    private boolean isSecurityMode;
    
    private static final String SECURITY_CONF_PATH = "security.conf.path";
    
    private static final String USER_KEYTAB_FILE = "user.keytab.file";

    private static final String USER_PRINCIPAL = "user.principal";

    public Properties getPorps(){
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
        properties.put(ProducerConfig.RETRIES_CONFIG, retries);
        properties.put(ProducerConfig.BATCH_SIZE_CONFIG, batchSize);
        properties.put(ProducerConfig.LINGER_MS_CONFIG, linger);
        properties.put(ProducerConfig.BUFFER_MEMORY_CONFIG, bufferMemory);
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        if (isSecurityMode) {
            properties.put(SECURITY_CONF_PATH, path);
            properties.put(USER_KEYTAB_FILE, keyTabFile);
            properties.put(USER_PRINCIPAL, userPrincipal);
        }
        return properties;
    }

}
