package com.intellif.cloud.personfile.manage.services.datastistic;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;

/**
 * 人员类型接口
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月29日
 * @see StatisticPersonfileTypeService
 * @since JDK1.8
 */
public interface StatisticPersonfileTypeService {
    /**
     * 根据人员类型id累加人员档案数量
     *
     * @param personFileTypeId 人员类型id
     * @param personFileNum    档案数量
     * @return
     */
    BaseDataRespDTO updateNumByPersonTypeId(String personFileTypeId, int personFileNum);
    
    /**
     * 新增人员类型统计
     *
     * @param statisticPersonfileType
     * @return
     */
    BaseDataRespDTO insertPersonfileType(StatisticPersonfileType statisticPersonfileType);
    
    /**
     * 根据人员类型id修改人员类型名称
     *
     * @param personFileTypeId
     * @param personFileTypeName
     * @return
     */
    BaseDataRespDTO updatePersonfileTypeNameByTypeId(Integer personFileTypeId, String personFileTypeName);
    
    /**
     * 根据人员类型id删除类型统计
     *
     * @param personFileTypeId
     * @return
     */
    BaseDataRespDTO deletePersonfileTypeByTypeId(Integer personFileTypeId);
}
