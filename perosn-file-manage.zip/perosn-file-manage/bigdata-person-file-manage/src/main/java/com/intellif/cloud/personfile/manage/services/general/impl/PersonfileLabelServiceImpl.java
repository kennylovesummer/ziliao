package com.intellif.cloud.personfile.manage.services.general.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabel;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabelRecord;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileLabelService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @ClassName PersonfileLabelServiceImpl
 * @Author liuYu
 * @create 2018-10-16 17:33
 * @Version 1.0
 * @desc
 */

@Service
public class PersonfileLabelServiceImpl extends BaseServiceImpl implements PersonfileLabelService {
    
    @Autowired
    private StatisticPersonfileTypeService statisticPersonfileTypeService;

    @Override
    public PersonfileLabel queryPersonfileLabelById(Integer id){
        PersonfileLabel personfileLabel = new PersonfileLabel();
        personfileLabel.setId(id);
        return (PersonfileLabel) this.baseDao.findById(personfileLabel);
    }

    @Override
    public int insertPersonfileLabel(PersonfileLabel personfileLabel){
        int result = this.baseDao.insert(personfileLabel);
        if (result == 1) {
            StatisticPersonfileType statisticPersonfileType = new StatisticPersonfileType();
            statisticPersonfileType.setPersonFileTypeId(personfileLabel.getId());
            statisticPersonfileType.setPersonFileTypeName(personfileLabel.getLabelName());
            statisticPersonfileType.setPersonFileNum(0L);
            statisticPersonfileTypeService.insertPersonfileType(statisticPersonfileType);
            return 1;
        }
        return 0;
    }

    @Override
    public Page<PersonfileLabel> queryPersonfileLabelList(int pageNum, int pageSize){
        QueryEvent event = new QueryEvent<>();
        event.setStatement("findPersonfileLabelList");
        PageHelper.startPage(pageNum, pageSize);
        List<PersonfileLabel> personfileLabelList = this.baseDao.findAllIsPageByCustom(event);
        return (Page<PersonfileLabel>) personfileLabelList;
    }

    @Override
    public List<PersonfileLabel> findAllPersonfileLabel(){
        PersonfileLabel personfileLabel = new PersonfileLabel();
        return this.baseDao.findAll(personfileLabel);
    }

    @Override
    public PersonfileLabel queryPersonfileLabelByName(Integer id, String labelName){
        QueryEvent<PersonfileLabel> event = new QueryEvent<>();
        PersonfileLabel personfileLabel = new PersonfileLabel();
        personfileLabel.setId(id);
        personfileLabel.setLabelName(labelName);
        event.setObj(personfileLabel);
        event.setStatement("findPersonfileLabelByName");
        return (PersonfileLabel) this.baseDao.findOneByCustom(event);
    }

    @Override
    public int updatePersonfileLabel(PersonfileLabel personfileLabel){
        int result = this.baseDao.update(personfileLabel);
        if (result > 0) {
            statisticPersonfileTypeService.updatePersonfileTypeNameByTypeId(personfileLabel.getId(), personfileLabel.getLabelName());
            return 1;
        }
        return 0;
    }

    @Override
    public int deletePersonfileLabel(Integer id){
        PersonfileLabel personfileLabel = new PersonfileLabel();
        personfileLabel.setId(id);
        personfileLabel.setIsDeleted(1);
        int result = this.baseDao.delete(personfileLabel);
        if (result == 1) {
            statisticPersonfileTypeService.deletePersonfileTypeByTypeId(personfileLabel.getId());
            PersonfileLabelRecord personfileLabelRecord = new PersonfileLabelRecord();
            personfileLabelRecord.setLabelId(Long.valueOf(id));
            this.baseDao.updateStatement("deletePersonfilelabelRecord", personfileLabelRecord);
            return 1;
        }
        return 0;
    }

    @Override
    public List<PersonfileLabelVO> findPersonfileLabelRecordByPersonfileIds(List<String> ids) {
        QueryEvent<PersonfileLabel> event = new QueryEvent<>();
        Map<String,Object> params = Maps.newHashMap();
        params.put("ids", ids);
        event.setParameter(params);
        event.setStatement("findPersonfileLabelRecordByPersonfileIds");
        if (CollectionUtils.isNotEmpty(ids)) {
            return (List<PersonfileLabelVO>) this.baseDao.findAllIsPageByCustom(event);
        }
        return Lists.newArrayList();
    }

    @Override
    public List<PersonfileLabelVO> findLabelRecordByLabelId(List<String> ids) {
        QueryEvent<PersonfileLabel> event = new QueryEvent<>();
        Map<String,Object> params = Maps.newHashMap();
        params.put("ids", ids);
        event.setParameter(params);
        event.setStatement("findLabelRecordByLabelId");
        if (CollectionUtils.isNotEmpty(ids)) {
            return (List<PersonfileLabelVO>) this.baseDao.findAllIsPageByCustom(event);
        }
        return Lists.newArrayList();
    }
}
