package com.intellif.cloud.personfile.manage.model.dto.snap;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import lombok.Data;

import java.io.Serializable;

/**
 * @author liuyu
 * @className SnapMapDTO
 * @date 2019/3/19 17:50
 * @description
 */
@Data
public class SnapMapDTO extends BasePageReqDTO implements Serializable {

    private static final long serialVersionUID = -5946613962612807927L;

    /**
     * 档案ID（必填）
     */
    private String personFileId;

    /**
     * 摄像头id
     */
    private String sourceId;

    /**
     * 创建开始日期
     */
    private String startTime;
    /**
     * 创建结束日期
     */
    private String endTime;

    /**
     * 事件类型(0-全部,1-抓拍，2-乘车，3-住宿)
     */
    private String eventType;

    public SnapMapDTO() {
    }

    public SnapMapDTO(String personFileId, String sourceId, String startTime, String endTime) {
        this.personFileId = personFileId;
        this.sourceId = sourceId;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
