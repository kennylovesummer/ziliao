package com.intellif.cloud.personfile.manage.model.vo.label;

import java.io.Serializable;

/**
 * 档案标签关联表
 *
 * @author liuzj
 * @date 2019-05-14
 */
public class PersonfileLabelVO implements Serializable {

    /**
     * 档案ID
     */
    private String aid;

    /**
     * 标签ID
     */
    private String labelId;

    /**
     * 标签名称
     */
    private String labelName;

    public String getLabelName() {
        return labelName;
    }

    public void setLabelName(String labelName) {
        this.labelName = labelName;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId;
    }
}
