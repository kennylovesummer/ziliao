package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * 离线任务创建
 *
 * @author liuzj
 * @date 2019-10-17
 */
@Data
public class OffLineTaskDTO implements java.io.Serializable{
    
    private static final long serialVersionUID = 7697778103621287163L;
    
    private String bizCode;
    
    private String taskType;
    
    private Object params;
    
    private String taskName;
    
    private String opCode;
    
    private String taskId;
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
