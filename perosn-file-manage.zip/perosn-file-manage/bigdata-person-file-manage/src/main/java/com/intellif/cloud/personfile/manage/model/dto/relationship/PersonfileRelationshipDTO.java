/*
 * 文件名：TestPageReq.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月10日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.model.dto.relationship;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;

/**
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月16日
 * @see PersonfileRelationshipDTO
 * @since JDK1.8
 */
public class PersonfileRelationshipDTO implements Serializable {


    private static final long serialVersionUID = 5330129448951744501L;
    // 被关联档案ID
    private String relatedPersonFileId;

    // 关联档案ID
    private String relatePersonFileId;

    // 关联关系
    private String relationCode;

    private String oldRelationCode;

    public String getRelatedPersonFileId() {
        return relatedPersonFileId;
    }

    public void setRelatedPersonFileId(String relatedPersonFileId) {
        this.relatedPersonFileId = relatedPersonFileId;
    }

    public String getRelatePersonFileId() {
        return relatePersonFileId;
    }

    public void setRelatePersonFileId(String relatePersonFileId) {
        this.relatePersonFileId = relatePersonFileId;
    }

    public String getRelationCode() {
        return relationCode;
    }

    public void setRelationCode(String relationCode) {
        this.relationCode = relationCode;
    }

    public String getOldRelationCode() {
        return oldRelationCode;
    }

    public void setOldRelationCode(String oldRelationCode) {
        this.oldRelationCode = oldRelationCode;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
