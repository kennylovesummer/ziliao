package com.intellif.cloud.personfile.manage.services.general.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.*;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.feignclient.DeepEyeClient;
import com.intellif.cloud.personfile.manage.model.dto.camera.DeepEyeCameraDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import com.intellif.cloud.personfile.manage.services.general.ImageService;
import com.intellif.cloud.personfile.manage.thrift.ifaas.E_FACE_ATTRIBUTE_LIST;
import com.intellif.cloud.personfile.manage.thrift.ifaas.IFaaServiceThriftClient;
import com.intellif.cloud.personfile.manage.thrift.ifaas.T_AttrDetectRstItem_v2;
import com.intellif.cloud.personfile.manage.thrift.ifaas.T_MulAttrDetectRstRsp_v2;
import com.intellif.cloud.personfile.manage.utils.PersonHttpClientUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.xml.bind.DatatypeConverter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 深目的接口实现类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月22日
 * @see DeepEyeServiceImpl
 * @since JDK1.8
 */
@Service
public class DeepEyeServiceImpl implements DeepEyeService {
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    /**
     * 深目的feignClient
     */
    @Resource
    private DeepEyeClient deepEyeClient;
    
    private static String DEEPEYE_TOKEN = "bearer ";
    
    @Autowired
    ImageService imageService;
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    /**
     * 调用深目的登录接口
     *
     * @return
     */
    private String login() {
        String tokenResult;
        try {
            logger.info("深目 登录 startTime:" + System.currentTimeMillis());
            tokenResult = deepEyeClient.login(personPropertiest.getDeepEyeLoginUserName(), personPropertiest.getDeepEyeLoginPassword(), PersonPropertiest.DEEP_EYE_LOGIN_GRAN_TTYPE);
            logger.info("深目 登录 endTime:" + System.currentTimeMillis());
        } catch (Exception e) {
            logger.error("调用深目的登录接口异常:" + e.getMessage());
            return null;
        }
        if (StringUtils.isBlank(tokenResult)) {
            logger.info("获取深目登录的接口返回为空");
            return null;
        }
        logger.info("调用深目的接口返回结果:" + tokenResult);
        JSONObject jsonObject = JSONObject.parseObject(tokenResult);
        String accessToken = "bearer " + jsonObject.getString("access_token");
        return accessToken;
    }
    
    /**
     * 获取所有摄像头
     *
     * @return
     */
    @Override
    public List<DeepEyeCameraDTO> getCameraList() {
        // 获取token
        String accessToken = getToken();
        
        Map<String, String> tokenMap = new HashMap<>(1);
        try {
            tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
            
            // 获取摄像头列表
            logger.info("深目 摄像头列表 startTime:" + System.currentTimeMillis());
            String result = PersonHttpClientUtil.httpGet(personPropertiest.getDeepEyeCameraUrl(), tokenMap);
            logger.info("深目 摄像头列表 endTime:" + System.currentTimeMillis());
            JSONObject jsonObject = JSONObject.parseObject(result);
            String isExpiredToken = isExpiredToken(jsonObject);
            if (null == isExpiredToken) {
                return JSONArray.parseArray(jsonObject.getJSONArray(ServiceReturnConstant.DATA).toJSONString(), DeepEyeCameraDTO.class);
                // token过期,登录&重新请求一次
            } else {
                accessToken = isExpiredToken;
                tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
                
                result = PersonHttpClientUtil.httpGet(personPropertiest.getDeepEyeCameraUrl(), tokenMap);
                jsonObject = JSONObject.parseObject(result);
                if (isSuccess(jsonObject)) {
                    return JSONArray.parseArray(jsonObject.getJSONArray(ServiceReturnConstant.DATA).toJSONString(), DeepEyeCameraDTO.class);
                }
                return new ArrayList<>(0);
            }
        } catch (Exception e) {
            logger.error("调用深目获取所有摄像头接口异常:" + e.getMessage());
            return new ArrayList<>(0);
        }
    }
    
    
    @Override
    public BaseDataRespDTO getTreeCameraInfo() {
        try {
            String accessToken = DEEPEYE_TOKEN;
            // 获取token
            Map<String, String> tokenMap = new HashMap<>(1);
            tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
    
            JSONObject params = new JSONObject();
            params.put("id", 0);
            params.put("nodeType", "district");
            params.put("countNodeType", "camera");
            params.put("spreadNodeType", "camera");
            // 获取摄像头列表
            String result = PersonHttpClientUtil.httpPost(IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_GET_TREE_CAMERA,params, tokenMap);
            JSONObject jsonObject = JSONObject.parseObject(result);
    
            if (jsonObject != null && DeepResultConstant.invalidToken.equals(jsonObject.getString(DeepResultConstant.error))) {
                // 获取token
                accessToken = getToken();
                DEEPEYE_TOKEN = accessToken;
                tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
                result = PersonHttpClientUtil.httpPost(IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_GET_TREE_CAMERA,params, tokenMap);
                jsonObject = JSONObject.parseObject(result);
            }
            return new BaseDataRespDTO(jsonObject, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("调用深目获取树状摄像头接口异常:" + e.getMessage());
            return new BaseDataRespDTO(null,IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    @Override
    public BaseDataRespDTO searchCrmereByName(String id,String name,Integer page,Integer perpage) {
        try {
            String accessToken = DEEPEYE_TOKEN;
            
            Map<String, String> tokenMap = new HashMap<>(1);
            tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
        
            JSONObject params = new JSONObject();
            params.put("id", id);
            params.put("nodeType", "district");
            params.put("queryBy", "name");
            params.put("query", name);
            // 获取摄像头
            String result = PersonHttpClientUtil.httpPost(IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_SEARCH_CAMERA_BY_NAME + "/page/" + page + "/pagesize/" + perpage,params, tokenMap);
           
            JSONObject jsonObject = JSONObject.parseObject(result);
            
            if (jsonObject != null && DeepResultConstant.invalidToken.equals(jsonObject.getString(DeepResultConstant.error))) {
                // 获取token
                accessToken = getToken();
                DEEPEYE_TOKEN = accessToken;
                tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
                result = PersonHttpClientUtil.httpPost(IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_SEARCH_CAMERA_BY_NAME + "/page/" + page + "/pagesize/" + perpage,params, tokenMap);
                jsonObject = JSONObject.parseObject(result);
            }
            
            return new BaseDataRespDTO(jsonObject,IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("调用深目获取树状摄像头接口异常:" + e.getMessage());
            return new BaseDataRespDTO(null,IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    /**
     * 图片上传 获取特征值
     *
     * @param url 图片地址
     * @return
     */
    @Override
    public BaseDataRespDTO imageUploadUrl(String url, Boolean isIfass) {
        
        return isIfass ? imageService.uploadImage(url) : getFeatureByImage(url);
    }
    
    @Override
    public String getFeatureFromEngineByUrl(String fileUrl) {
        try {
            IFaaServiceThriftClient iFaaServiceThriftClient = IFaaServiceThriftClient.getInstance(personPropertiest.getEngineIp(), personPropertiest.getEnginePort());
            List<Integer> attrList = new ArrayList<>(6);
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_AGE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_DRESS.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue());
            T_MulAttrDetectRstRsp_v2 t = iFaaServiceThriftClient.if_image_detect_extract_url_v2(fileUrl, attrList, 1, personPropertiest.getEngineAlgVersion());
            if (null == t) {
                return null;
            }
            List<T_AttrDetectRstItem_v2> sttrDetectRstItemV2List = t.getFaceAttrList();
            if (CollectionUtils.isEmpty(sttrDetectRstItemV2List)) {
                return null;
            }
            // 多个人脸默认返回第一个
            return DatatypeConverter.printBase64Binary(sttrDetectRstItemV2List.get(0).getFeature());
        } catch (TException e) {
            logger.error("提取特征值异常:" + e.getMessage());
        }
        return null;
    }
    
    /**
     * 根据图片地址提取特征值
     *
     * @param fileUrl
     * @return
     */
    private BaseDataRespDTO getFeatureByImage(String fileUrl) {
        try {
            IFaaServiceThriftClient iFaaServiceThriftClient = IFaaServiceThriftClient.getInstance(personPropertiest.getEngineIp(), personPropertiest.getEnginePort());
            List<Integer> attrList = new ArrayList<>(6);
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_AGE.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_DRESS.getValue());
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue());
            T_MulAttrDetectRstRsp_v2 t = iFaaServiceThriftClient.if_image_detect_extract_url_v2(fileUrl, attrList, 1, personPropertiest.getEngineAlgVersion());
            if (null == t) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "搜索异常", "搜索异常");
            }
            List<T_AttrDetectRstItem_v2> sttrDetectRstItemV2List = t.getFaceAttrList();
            if (sttrDetectRstItemV2List.isEmpty()) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.FACE_NOT_FOUND_IN_THE_PICTURE.getMessage(), ResultMessageEnum.FACE_NOT_FOUND_IN_THE_PICTURE.getMessage());
            }
            JSONObject faceObject = new JSONObject();
            // 图片id
            faceObject.put("id", "");
            // 图片地址
            faceObject.put("uri", fileUrl);
            // 人脸数
            faceObject.put("faces", sttrDetectRstItemV2List.size());
            // 时间戳
            faceObject.put("time", System.currentTimeMillis());
            JSONObject jsonObject = new JSONObject();
            JSONArray rectArray = new JSONArray();
            for (T_AttrDetectRstItem_v2 face : sttrDetectRstItemV2List) {
                jsonObject.put("rect", JSONObject.parseObject(face.getFaceAttrInfo()).getJSONArray("face_rect").get(0).toString());
                jsonObject.put("base64FaceFeature", DatatypeConverter.printBase64Binary(face.getFeature()));
                rectArray.add(jsonObject);
            }
            faceObject.put("faceList", rectArray);
            
            return new BaseDataRespDTO(faceObject, IResultCode.SUCCESS, ResultMessageEnum.IMAGE_UPLOAD_SUCCESS.getMessage(), ResultMessageEnum.IMAGE_UPLOAD_SUCCESS.getMessage());
        } catch (TException e) {
            logger.error("提取特征值异常:" + e.getMessage());
        }
        return new BaseDataRespDTO();
    }
    
    /**
     * 根据小图查询大图
     *
     * @param id 小图id
     * @return
     */
    @Override
    public BaseDataRespDTO getBigImage(String id) {
        Map<String, String> tokenMap = Maps.newHashMap();
        String accessToken = getToken();
        if (StringUtils.isBlank(accessToken)) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "查看大图失败", ResultMessageEnum.DEEP_EYE_LOGIN_FAIL.getMessage());
        }
        tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
        String url = IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_BIMAGE_URL + id;
        JSONObject jsonObject;
        try {
            String imageResult = PersonHttpClientUtil.httpGet(url, tokenMap);
            JSONObject imageObject = JSONObject.parseObject(imageResult);
            accessToken = isExpiredToken(imageObject);
            jsonObject = imageObject.getJSONObject(ICommonConstant.ResultDataFormat.data);
            if (null == accessToken) {
                JSONObject data = convert(jsonObject);
                return new BaseDataRespDTO(data, IResultCode.SUCCESS, ResultMessageEnum.SMALL_TO_LARGE_SUCCESS.getMessage(), ResultMessageEnum.SMALL_TO_LARGE_SUCCESS.getMessage());
            } else {
                logger.info("深目 根据小图查询大图 startTime:" + System.currentTimeMillis());
                imageResult = PersonHttpClientUtil.httpGet(url, tokenMap);
                logger.info("深目 根据小图查询大图 endTime:" + System.currentTimeMillis());
                imageObject = JSONObject.parseObject(imageResult);
                jsonObject = imageObject.getJSONObject(ICommonConstant.ResultDataFormat.data);
                JSONObject data = convert(jsonObject);
                if (StringUtils.isBlank(imageResult)) {
                    return new BaseDataRespDTO(null, IResultCode.ERROR, "暂无大图", "暂无大图");
                }
                return new BaseDataRespDTO(data, IResultCode.SUCCESS, ResultMessageEnum.SMALL_TO_LARGE_SUCCESS.getMessage(), ResultMessageEnum.SMALL_TO_LARGE_SUCCESS.getMessage());
            }
        } catch (Exception e) {
            logger.error("调用深目的根据小图查询大图接口异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "根据小图查询大图失败", "根据小图查询大图失败:" + e.getMessage());
        }
    }
    
    private JSONObject convert(JSONObject jsonObject) {
        if (jsonObject != null) {
            String json = jsonObject.getString("json");
            JSONObject faceJson = JSONObject.parseObject(json);
            jsonObject.put("faceJson", faceJson);
            return jsonObject;
        }
        return null;
    }
    
    /**
     * 根据大图查询小图
     *
     * @param id 大图id
     * @return
     */
    @Override
    public BaseDataRespDTO getSmallImage(String id) {
        Map<String, String> tokenMap = new HashMap<>(1);
        String accessToken = getToken();
        if (StringUtils.isBlank(accessToken)) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "查看小图失败", ResultMessageEnum.DEEP_EYE_LOGIN_FAIL.getMessage());
        }
        tokenMap.put(HttpHeaders.AUTHORIZATION, accessToken);
        String url = IPersonfilesManageConstant.Internet.HTTP_SLASH + personPropertiest.getDeepEyeUrlPrefix() + PersonPropertiest.DEEP_EYE_SIMAGE_URL + id;
        try {
            String imageResult = PersonHttpClientUtil.httpGet(url, tokenMap);
            JSONObject imageObject = JSONObject.parseObject(imageResult);
            accessToken = isExpiredToken(imageObject);
            if (null == accessToken) {
                return new BaseDataRespDTO(imageObject.getJSONArray(ICommonConstant.ResultDataFormat.data), IResultCode.SUCCESS, ResultMessageEnum.LARGE_TO_SMALL_SUCCESS.getMessage(), ResultMessageEnum.LARGE_TO_SMALL_SUCCESS.getMessage());
            } else {
                logger.info("深目 根据大图查询小图 startTime:" + System.currentTimeMillis());
                imageResult = PersonHttpClientUtil.httpGet(url, tokenMap);
                logger.info("深目 根据小图查询大图 endTime:" + System.currentTimeMillis());
                imageObject = JSONObject.parseObject(imageResult);
                return new BaseDataRespDTO(imageObject.getJSONArray(ICommonConstant.ResultDataFormat.data), IResultCode.SUCCESS, ResultMessageEnum.LARGE_TO_SMALL_SUCCESS.getMessage(), ResultMessageEnum.LARGE_TO_SMALL_SUCCESS.getMessage());
            }
        } catch (Exception e) {
            logger.error("调用深目的根据小图查询大图接口异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "根据小图查询大图失败", "根据小图查询大图失败:" + e.getMessage());
        }
    }
    
    /**
     * 获取token
     *
     * @return
     */
    public String getToken() {
        return login();
    }
    
    /**
     * 判断token是否过期
     * 过期重新登录返回新的token
     * 未过期返回null
     *
     * @param jsonObject
     */
    public String isExpiredToken(JSONObject jsonObject) {
        // token 过期
        if (jsonObject != null && DeepResultConstant.invalidToken.equals(jsonObject.getString(DeepResultConstant.error))) {
            // 重新登录,获取token
            return login();
        }
        return null;
    }
    
    /**
     * 是否成功
     *
     * @param jsonObject
     * @return
     */
    public boolean isSuccess(JSONObject jsonObject) {
        return null != jsonObject && 0 == jsonObject.getInteger(DeepResultConstant.errCode);
    }
}
