package com.intellif.cloud.personfile.manage.model.vo.statistic;

import com.alibaba.fastjson.JSON;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileAge;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;

import java.io.Serializable;
import java.util.List;

/**
 * @program ifaas-person-file-datastatistics
 * @Author liuYu
 * @create 2018-10-26 17:51
 * @Version 1.0
 * @desc
 */

public class StatsticPersonfileTypeAndAgeVO implements Serializable {

    private static final long serialVersionUID = 7054205157838730117L;

    private List<StatisticPersonfileAge> ageList;

    private List<StatisticPersonfileType> personfileTypeList;
    
    public List<StatisticPersonfileAge> getAgeList() {
        return ageList;
    }
    
    public void setAgeList(List<StatisticPersonfileAge> ageList) {
        this.ageList = ageList;
    }
    
    public List<StatisticPersonfileType> getPersonfileTypeList() {
        return personfileTypeList;
    }
    
    public void setPersonfileTypeList(List<StatisticPersonfileType> personfileTypeList) {
        this.personfileTypeList = personfileTypeList;
    }
    
    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
