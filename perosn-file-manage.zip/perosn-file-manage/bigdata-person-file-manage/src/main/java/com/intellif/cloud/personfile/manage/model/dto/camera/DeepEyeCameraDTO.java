package com.intellif.cloud.personfile.manage.model.dto.camera;

/**
 * 文件名：DeepEyeCameraDTO.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 深目的摄像头
 * @author ：tianhao
 * 创建时间：2018年10月20日
 * 修改理由：
 * 修改内容：
 */
public class DeepEyeCameraDTO implements java.io.Serializable {
    /**
     * 摄像头编号
     */
    private String id;
    /**
     * 摄像头经纬度
     */
    private String geoString;

    /**
     * 所在城市
     */
    private String city;
    private String county;
    /**
     * 所在街道地址
     */
    private String addr;
    /**
     * 摄像头流媒体地址
     */
    private String rtspuri;
    /**
     * 摄像头ip
     */
    private String uri;
    /**
     * 摄像头状态
     * 0:off  1：on
     */
    private Long status;
    /**
     * 摄像头端口
     */
    private Long port;
    /**
     * 摄像头全称
     */
    private String name;
    /**
     * 摄像头模式
     * 0: 抓拍模式 1： 取ipc流软解码 2：取IPC流硬解码 3：取rtsp流软解码4：取rtsp流硬解码
     */
    private int capability;
    /**
     * 0/1:是否采集;
     */
    private Long type;
    /**
     * 预留字段
     */
    private String cover;
    /**
     * 所属派出所id
     */
    private String stationId;
    /**
     * 是否为候问室
     * 0：是  1：否
     */
    private long inStation;
    /**
     * 所属派出所
     */
    private String areaName;
    /**
     * 编码
     */
    private String code;
    /**
     * 应用场景类型
     */
    private String appType;
    /**
     * 应用场景类型具体值
     */
    private String appValue;
    private Long placeTypeId;
    private Long placeTypeName;
    private String maxCaptureCount;
    private Long captureCount;
    private String captureBankId;
    private String fromTable;
    /**
     * 摄像头名称和编码
     * Name+code的值
     */
    private String nameAndCode;
    /**
     * 摄像头区域所属派出所和名称和编码
     * areaCode+Name+code的值
     */
    private String displayName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGeoString() {
        return geoString;
    }

    public void setGeoString(String geoString) {
        this.geoString = geoString;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getRtspuri() {
        return rtspuri;
    }

    public void setRtspuri(String rtspuri) {
        this.rtspuri = rtspuri;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public Long getPort() {
        return port;
    }

    public void setPort(Long port) {
        this.port = port;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapability() {
        return capability;
    }

    public void setCapability(int capability) {
        this.capability = capability;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public long getInStation() {
        return inStation;
    }

    public void setInStation(long inStation) {
        this.inStation = inStation;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public String getAppValue() {
        return appValue;
    }

    public void setAppValue(String appValue) {
        this.appValue = appValue;
    }

    public Long getPlaceTypeId() {
        return placeTypeId;
    }

    public void setPlaceTypeId(Long placeTypeId) {
        this.placeTypeId = placeTypeId;
    }

    public Long getPlaceTypeName() {
        return placeTypeName;
    }

    public void setPlaceTypeName(Long placeTypeName) {
        this.placeTypeName = placeTypeName;
    }

    public String getMaxCaptureCount() {
        return maxCaptureCount;
    }

    public void setMaxCaptureCount(String maxCaptureCount) {
        this.maxCaptureCount = maxCaptureCount;
    }

    public Long getCaptureCount() {
        return captureCount;
    }

    public void setCaptureCount(Long captureCount) {
        this.captureCount = captureCount;
    }

    public String getCaptureBankId() {
        return captureBankId;
    }

    public void setCaptureBankId(String captureBankId) {
        this.captureBankId = captureBankId;
    }

    public String getFromTable() {
        return fromTable;
    }

    public void setFromTable(String fromTable) {
        this.fromTable = fromTable;
    }

    public String getNameAndCode() {
        return nameAndCode;
    }

    public void setNameAndCode(String nameAndCode) {
        this.nameAndCode = nameAndCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return "SMCameraDTO{" +
                "id='" + id + '\'' +
                ", geoString='" + geoString + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", addr='" + addr + '\'' +
                ", rtspuri='" + rtspuri + '\'' +
                ", uri='" + uri + '\'' +
                ", status=" + status +
                ", port=" + port +
                ", name='" + name + '\'' +
                ", capability=" + capability +
                ", type=" + type +
                ", cover='" + cover + '\'' +
                ", stationId='" + stationId + '\'' +
                ", inStation=" + inStation +
                ", areaName='" + areaName + '\'' +
                ", code='" + code + '\'' +
                ", appType='" + appType + '\'' +
                ", appValue='" + appValue + '\'' +
                ", placeTypeId=" + placeTypeId +
                ", placeTypeName=" + placeTypeName +
                ", maxCaptureCount='" + maxCaptureCount + '\'' +
                ", captureCount=" + captureCount +
                ", captureBankId='" + captureBankId + '\'' +
                ", fromTable='" + fromTable + '\'' +
                ", nameAndCode='" + nameAndCode + '\'' +
                ", displayName='" + displayName + '\'' +
                '}';
    }
}
