package com.intellif.cloud.personfile.manage.feignclient.fallback;

import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.feignclient.DeepEyeClient;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.online.OnlineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.SimilarArchiveDTO;
import org.springframework.stereotype.Component;


/**
 * @author liuzhijian
 * @version 1.2.0
 * @date 2019年05月29日
 * @see DeepEyeClient
 * @since JDK1.8
 */
@Component
public class AnalysisFeignHystrix implements AnalysisFeignClient {
    
    @Override
    public String addTask(OffLineTaskDTO offLineTaskDTO) {
        return null;
    }
    
    @Override
    public String delTask(OffLineTaskDTO offLineTaskDTO) {
        return null;
    }
    
    @Override
    public String getTaskStatus(OffLineTaskDTO offLineTaskDTO) {
        return null;
    }
    
    @Override
    public String getTaskResult(AnalysisTaskResultDTO analysisTaskResultDTO) {
        return null;
    }
    
    @Override
    public String delTaskResult(AnalysisTaskResultDTO analysisTaskResultDTO) {
        return null;
    }
    
    @Override
    public String analysisOnlineTaskCreate(OnlineTaskDTO onlineTaskDTO) {
        return null;
    }
    
    @Override
    public String getSimilarArchives(SimilarArchiveDTO similarArchiveDTO) {
        return null;
    }
}
