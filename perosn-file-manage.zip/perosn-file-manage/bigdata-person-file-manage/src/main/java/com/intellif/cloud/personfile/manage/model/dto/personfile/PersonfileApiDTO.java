package com.intellif.cloud.personfile.manage.model.dto.personfile;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.xdata.BaseReqDTO;
import org.apache.logging.log4j.util.Strings;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 对外接口参数接收集合
 *
 * @author liuzj
 * @date 2019-05-16
 */
public class PersonfileApiDTO extends BaseReqDTO{

    @NotBlank(message = "【imageType】不能为空")
    private String imageType;

    @NotBlank(message = "【image】不能为空")
    private String image;

    private String similarity;

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Double getSimilarity() {
        try {
            if (Strings.isBlank(this.similarity)) {
                return null;
            }
            Double tempValue = Double.valueOf(similarity);
            if (tempValue < 0 || tempValue > 1) {
                return null;
            }
            return tempValue;
        }catch (Exception e){
            return null;
        }
    }

    public void setSimilarity(String similarity) {
        this.similarity = similarity;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
