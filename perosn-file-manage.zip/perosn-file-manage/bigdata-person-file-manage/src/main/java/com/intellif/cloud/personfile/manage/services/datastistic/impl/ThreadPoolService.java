package com.intellif.cloud.personfile.manage.services.datastistic.impl;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.intellif.cloud.personfile.manage.contants.ThreadPoolConstant;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 文件名：ThreadPoolService.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 线程池 初始化
 *
 * @author ：tianhao
 * 创建时间：2018年10月29日
 * 修改理由：
 * 修改内容：
 */
public class ThreadPoolService {
    /**
     * 线程池定义
     */
    public static final ThreadPoolExecutor threadPool;

    /**
     * 初始化线程
     */
    static {
        threadPool = new ThreadPoolExecutor(
                ThreadPoolConstant.COREPOOL_SIZE,
                ThreadPoolConstant.MAXIMUM_POOL_SIZE,
                ThreadPoolConstant.KEEP_ALIVE_TIME,
                TimeUnit.SECONDS,
                ThreadPoolConstant.WORKQUEUE,
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build(),
                new ThreadPoolExecutor.CallerRunsPolicy());
    }

    private ThreadPoolService() {
    }
}
