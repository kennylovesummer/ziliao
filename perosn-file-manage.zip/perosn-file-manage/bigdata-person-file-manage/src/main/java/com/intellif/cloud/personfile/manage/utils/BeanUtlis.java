package com.intellif.cloud.personfile.manage.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Bean有关的操作
 *
 * @author liuzj
 * @date 2019-07-22
 */
@Component
public class BeanUtlis implements ApplicationContextAware {
    
    private static ApplicationContext applicationContext;
    
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        if (BeanUtlis.applicationContext == null) {
            BeanUtlis.applicationContext = applicationContext;
        }
    }
    
    public static ApplicationContext getApplicationContext(){
        return applicationContext;
    }
    
    public static Object getBean(String name) {
        return applicationContext.getBean(name);
    }
    
    public static <T> T getBean(Class<T> clazz) {
        return applicationContext.getBean(clazz);
    }
}
