package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.LingerTaskCreateDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

/**
 * 徘徊分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisLingerCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    AnalysisLingerCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        LingerTaskCreateDTO lingerTaskCreateDTO = JSONObject.parseObject(params.toJSONString(), LingerTaskCreateDTO.class);
        // 参数校验
        if (CollectionUtils.isEmpty(lingerTaskCreateDTO.getSourceIds())
                || Strings.isBlank(lingerTaskCreateDTO.getStartTime())
                || Strings.isBlank(lingerTaskCreateDTO.getEndTime())) {
            throw new BusinessException(IResultCode.ERROR,"参数异常");
        }
    
        if (lingerTaskCreateDTO.getRules() == null) {
            Props rules = new Props();
            String rulesConfig = personPropertiest.getDataAnalysisLingerRules();
            if (Strings.isBlank(rulesConfig)) {
                rules.setFilterTimes(1);
                rules.setInterval(60);
            } else {
                String[] ruleArray = rulesConfig.split(ICommonConstant.Symbol.AND);
                if (ruleArray.length != 2) {
                    rules.setFilterTimes(1);
                    rules.setInterval(60);
                } else {
                    rules.setInterval(Integer.valueOf(ruleArray[0].trim()));
                    rules.setFilterTimes(Integer.valueOf(ruleArray[1].trim()));
                }
            }
            lingerTaskCreateDTO.setRules(rules);
        }
        
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setTaskType(DataStisticTypeEnum.LINGER.getName());
        offLineTaskDTO.setParams(lingerTaskCreateDTO.toString());
        offLineTaskDTO.setTaskName(lingerTaskCreateDTO.getTaskName());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
    
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setType(DataStisticTypeEnum.LINGER.getName());
        bigdataAnalysisTask.setName(lingerTaskCreateDTO.getTaskName());
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        
        return execId;
    }
}
