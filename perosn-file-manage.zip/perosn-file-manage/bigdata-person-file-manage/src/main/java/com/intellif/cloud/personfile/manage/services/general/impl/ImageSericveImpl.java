package com.intellif.cloud.personfile.manage.services.general.impl;

/*
 * 文件名：ImageSericveImpl.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：  图片接口实现类
 * 创建人：tianhao
 * 创建时间：2018年11月06日
 * 修改理由：
 * 修改内容：
 */

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.ImageService;
import com.intellif.cloud.personfile.manage.utils.PersonHttpClientUtil;
import com.intellif.log.LoggerUtilI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import javax.xml.bind.DatatypeConverter;
import java.util.List;

/**
 * 图片接口实现类 -- 采集服务
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年11月06日
 * @see ImageSericveImpl
 * @since JDK1.8
 */
@Service
public class ImageSericveImpl implements ImageService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    /**
     * 上传图片检测
     *
     * @param imageUrl 照片url
     * @return BaseDataRespDTO
     */
    @Override
    public BaseDataRespDTO uploadImage(String imageUrl) {
        // 构造参数
        List<JSONObject> targetInfo = Lists.newArrayList();
        JSONObject info = new JSONObject();
        info.put("target", "face");
        List<Integer> algVersion = Lists.newArrayList();
        algVersion.add(personPropertiest.getEngineAlgVersion());
        info.put("algVersion", algVersion);
        List<java.lang.String> attribute = Lists.newArrayList();
        attribute.add("landmark");
        info.put("attribute", attribute);
        targetInfo.add(info);
        // 传入参数
        JSONObject jsonParam = new JSONObject();
        jsonParam.put("imageType", "url");
        jsonParam.put("image", imageUrl);
        jsonParam.put("targetInfo", targetInfo);
        // 调用引擎获取特征值
        StringBuilder url = new StringBuilder();
        url.append(IPersonfilesManageConstant.Internet.HTTP_SLASH)
                .append(personPropertiest.getEngineIp())
                .append(ICommonConstant.Symbol.COLON)
                .append(personPropertiest.getEnginePort())
                .append(PersonPropertiest.DEEP_EYE_GET_FACE_FEATURE);
        String result = PersonHttpClientUtil.httpPost(url.toString(), jsonParam, Maps.newHashMap(), MediaType.APPLICATION_JSON_UTF8_VALUE);
        JSONObject resultObject = JSONObject.parseObject(result);
        
        // 判断是否有人脸信息
        JSONArray faceArray = (resultObject != null && resultObject.containsKey("data") && resultObject.getJSONObject("data").containsKey("targetInfo"))
                ? resultObject.getJSONObject("data").getJSONArray("targetInfo").getJSONObject(0).getJSONArray("result")
                : null;
        // 有人脸则信息数据结构重构，反之返回照片无人脸
        if (faceArray != null) {
            JSONObject faceObject = new JSONObject();
            // 图片id
            faceObject.put("id", "");
            // 图片地址
            faceObject.put("uri", imageUrl);
            // 人脸数
            faceObject.put("faces", faceArray.size());
            // 时间戳
            faceObject.put("time", System.currentTimeMillis());
            // 特征值
            JSONObject jsonObject = new JSONObject();
            JSONArray rectArray = new JSONArray();
            JSONObject rect = new JSONObject();
            for (int i = 0; i < faceArray.size(); i++) {
                // 人脸框
                JSONArray rects = faceArray.getJSONObject(i).getJSONArray("targetRect");
                rect.put("top", rects.get(1));
                rect.put("right", rects.get(2));
                rect.put("bottom", rects.get(3));
                rect.put("left", rects.get(0));
                jsonObject.put("rect", rect);
                // 特征值 Base64
                jsonObject.put("base64FaceFeature", DatatypeConverter.printBase64Binary(faceArray.getJSONObject(i).getJSONArray("featureInfo").getJSONObject(0).getJSONArray("feature").toJSONString().getBytes()));
                rectArray.add(jsonObject);
            }
            faceObject.put("faceList", rectArray);
            return new BaseDataRespDTO(faceObject, IResultCode.SUCCESS, "图片上传成功", "图片上传成功");
        } else {
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, ResultMessageEnum.FACE_NOT_FOUND_IN_THE_PICTURE.getMessage(), ResultMessageEnum.FACE_NOT_FOUND_IN_THE_PICTURE.getMessage());
        }
    }
}
