package com.intellif.cloud.personfile.manage.feignclient.fallback;

import com.intellif.cloud.personfile.manage.feignclient.DeepEyeClient;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataRelationReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import org.springframework.stereotype.Component;


/**
 * @author liuzhijian
 * @version 1.2.0
 * @date 2019年05月29日
 * @see DeepEyeClient
 * @since JDK1.8
 */
@Component
public class XdataFeignHystrix implements XdataFeignClient {
    
    @Override
    public String eventList(XdataReqDTO xdataReqDTO) {
        return null;
    }
    
    @Override
    public String merge(XdataReqDTO xdataReqDTO) {
        return null;
    }
    
    @Override
    public String delete(XdataReqDTO xdataReqDTO) {
        return null;
    }
    
    @Override
    public String singlePersonRlation(XdataRelationReqDTO xdataRelationReqDTO) {
        return null;
    }
    
    @Override
    public String multiplePersonRlation(XdataRelationReqDTO xdataRelationReqDTO) {
        return null;
    }
    
    @Override
    public String insertRelationship(XdataRelationReqDTO xdataRelationDTO) {
        return null;
    }
    
    @Override
    public String deleteRelationship(XdataRelationReqDTO xdataRelationDTO) {
        return null;
    }
    
    @Override
    public String getPersonfileById(XdataReqDTO xdataReqDTO) {
        return null;
    }
    
}
