/*  
 * 文件名：LogVO.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月17日    
 * 修改理由：  
 * 修改内容：  
 */

package com.intellif.cloud.personfile.manage.model.dto.req;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

public class LogVO implements Serializable {

	/**  
	 *   
	 */
	private static final long serialVersionUID = -6260511020361150131L;

	/**
	 * logId
	 */
	private String logId;

	/**
	 * 入参
	 */
	private String inParam;

	/**
	 * 出参
	 */
	private String outParam;

	/**
	 * 信息
	 */
	private String message;

	public LogVO() {
	}

	public LogVO(String logId, String inParam) {
		this.logId = logId;
		this.inParam = inParam;
	}

	public LogVO(String logId, String inParam, String message) {
		this.logId = logId;
		this.inParam = inParam;
		this.message = message;
	}

	public LogVO(String logId, String inParam, String outParam, String message) {
		this.logId = logId;
		this.inParam = inParam;
		this.message = message;
		this.outParam = outParam;
	}

	public String getLogId() {
		return logId;
	}

	public LogVO setLogId(String logId) {
		this.logId = logId;
		return this;
	}

	public String getInParam() {
		return inParam;
	}

	public LogVO setInParam(String inParam) {
		this.inParam = inParam;
		return this;
	}

	public String getOutParam() {
		return outParam;
	}

	public LogVO setOutParam(String outParam) {
		this.outParam = outParam;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public LogVO setMessage(String message) {
		this.message = message;
		return this;
	}

	@SuppressWarnings("static-access")
	@Override
	public String toString() {
		return StringUtils.join("|", getProperties(logId), "|", getProperties(inParam), "|", getProperties(outParam),
				"|", getProperties(message));

	}

	protected String getProperties(String propertiesKey) {
		return StringUtils.isBlank(propertiesKey) ? "" : propertiesKey;
	}

}
