package com.intellif.cloud.personfile.manage.model.dto.analysis.online;

import lombok.Data;

/**
 * 数据分析-同行分析参数集合
 *
 * @author liuzj
 * @date 2019-09-12
 */
@Data
public class OnlineTaskDTO implements java.io.Serializable{
    
    private static final long serialVersionUID = 9090418166633267648L;
    
    private String bizCode;
    
    private Object params;
    
    private String taskType;
    
}
