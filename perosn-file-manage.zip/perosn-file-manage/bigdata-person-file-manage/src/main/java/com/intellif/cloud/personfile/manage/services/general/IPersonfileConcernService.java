package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;

import java.util.List;

/**
 * @author liuzhijian
 * @version 1.0
 * @see IPersonfileConcernService
 * @since JDK1.8
 * @date 2018年10月17日
 */
public interface IPersonfileConcernService {

    /**
     * 根据关注者姓名查询
     * @param name 关注者姓名
     * @return list
     */
    List<PersonfileConcern> findByConcerner(String name);

    /**
     * 统计查询
     * @return list
     */
    List<PersonfileConcern> findByConcerner(ListFilterDTO listFilterDTO);

    /**
     * 根据档案ID查询档案
     * @param personfileId 档案ID
     * @return PersonfileConcern
     */
    PersonfileConcern findByPersonfileId(String personfileId);

    /**
     * 更新
     * @param personfileConcern 待更新数据集
     * @return 更新条数
     */
    int updatePersonfileConcern(PersonfileConcern personfileConcern);

}
