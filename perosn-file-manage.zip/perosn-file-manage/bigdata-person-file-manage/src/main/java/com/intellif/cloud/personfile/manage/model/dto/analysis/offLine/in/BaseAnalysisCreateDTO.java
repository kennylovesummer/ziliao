package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;

import lombok.Data;

@Data
public class BaseAnalysisCreateDTO implements java.io.Serializable {
    
    private static final long serialVersionUID = 6268250716646433073L;
    
    private String taskName;
    
    private String taskType;
}
