package com.intellif.cloud.personfile.manage.services.datastistic;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfile;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;
import com.intellif.cloud.personfile.manage.model.vo.statistic.StatsticPersonfileTypeAndAgeVO;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 档案统计
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月20日
 * @see StatisticPersonfileService
 * @since JDK1.8
 */
public interface StatisticPersonfileService {
    
    /**
     * 根据归档时间查询统计结果
     *
     * @param start 开始时间
     * @param end   结束时间
     * @return list
     */
    List<StatisticPersonfile> findByBtwStatisticDate(String start, String end);
    
    /**
     * 按周分组统计
     *
     * @param start 开始时间
     * @param end   结束时间
     * @return List
     */
    List<Map<String, Object>> findGroupByWeek(String start, String end);
    
    /**
     * 数据插入
     *
     * @param statisticPersonfile 待插入的实体对象
     * @return int
     */
    int insertStatisticPersonfile(StatisticPersonfile statisticPersonfile);
    
    /**
     * 更新数据
     *
     * @param statisticPersonfile 待更新的实体对象
     * @return int
     */
    int updateStatisticPersonfile(StatisticPersonfile statisticPersonfile);
    
    /**
     * 查询统计档案类型和年龄分布
     *
     * @return
     */
    StatsticPersonfileTypeAndAgeVO getStatisticPersonfile();
    
    /**
     * 统计人员流动
     *
     * @param startDay 开始时间
     * @param endDay   结束时间
     * @return List<StatisticPersonfileFlow>
     */
    List<StatisticPersonfileFlow> getPersonfileFlow(LocalDate startDay, LocalDate endDay);
    
    /**
     * 获取第一条数据（根据归档时间降序排序）
     *
     * @param statisticDate 归档日期
     * @return StatisticPersonfileFlow
     */
    StatisticPersonfile findTopOne(String statisticDate);
    
    /**
     * 更新统计
     *
     * @param incTotal         总数新增
     * @param incRealNameTotal 实名新增
     */
    void updateStatistic(Integer incTotal, Integer incRealNameTotal);
}
