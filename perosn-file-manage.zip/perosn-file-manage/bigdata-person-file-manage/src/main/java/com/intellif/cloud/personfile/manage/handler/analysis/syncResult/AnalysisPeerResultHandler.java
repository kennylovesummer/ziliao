package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.vo.peer.PeerListVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.ArchiveDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.EventDetailVO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisPeerService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

/**
 * 数据分析同行结果处理器
 *
 * @author liuzj
 * @date 2019-07-19
 */
public class AnalysisPeerResultHandler extends AbstractAnalysisSyncResultHandler {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final BigdataAnalysisPeerService bigdataAnalysisPeerService = BeanUtlis.getBean(BigdataAnalysisPeerService.class);
    
    public AnalysisPeerResultHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected void syncData(AnalysisTaskResultDTO analysisTaskResultDTO) throws ParseException {
        // 清空历史数据
        clearHistoryData(analysisTaskResultDTO);
        bigdataAnalysisPeerService.deleteBigdataAnalysisPeerByTaskId(analysisTaskResultDTO.getTaskId2());
        
        JSONObject result = getResult(analysisTaskResultDTO);
        
        Long taskId = analysisTaskResultDTO.getTaskId2();
        
        if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
            // 同行结果列表处理
            String listResult = Strings.EMPTY;
            String detailResult = Strings.EMPTY;
            
            String peerInfo = result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("peerInfos");
            String targetArchive = result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("targetArchive");
            
            if (Strings.isNotBlank(peerInfo) && Strings.isNotBlank(targetArchive)) {
                List<PeerListVO> xdataPeerVOList = JSONObject.parseArray(peerInfo, PeerListVO.class);
                Map<String,List<PeerListVO>> groupByAid = xdataPeerVOList.stream().collect(Collectors.groupingBy(PeerListVO::getAid));
                List<PeerListVO> relData = Lists.newArrayList();
                groupByAid.forEach((key,value) -> {
                    if (CollectionUtils.isNotEmpty(value)) {
                        PeerListVO peerListVOItem = value.get(0);
                        peerListVOItem.setPeerTimes(value.size());
                        relData.add(peerListVOItem);
                    }
                });
                listResult = listHandle(relData, taskId);
    
                ArchiveDetailVO archiveDetailVO = JSONObject.parseObject(targetArchive, ArchiveDetailVO.class);
                detailResult = detailHaldle(xdataPeerVOList, archiveDetailVO, taskId);
            }
            
            analysisTaskResultDTO.setRemark("同行数据同步结束：" + listResult + detailResult);
            updateTaskStatus(analysisTaskResultDTO, true);
        } else {
            analysisTaskResultDTO.setRemark("同行数据同步结束，" + (result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : ""));
            updateTaskStatus(analysisTaskResultDTO, false);
        }
    }
    
    /**
     * 同行结果处理
     *
     * @param peerListVOList 数据集
     * @param taskId         后台任务ID
     */
    private String listHandle(List<PeerListVO> peerListVOList, Long taskId) {
        if (CollectionUtils.isEmpty(peerListVOList)) {
            logger.error("任务：" + taskId + " 同行分析结果无数据");
            return "同行分析结果无数据。";
        }
        
        List<String> personFileIds = peerListVOList.stream().map(PeerListVO::getAid).collect(Collectors.toList());
        
        Map<String, Object> params = Maps.newHashMap();
        params.put("personFilesIds", personFileIds);
        List<PersonfileBasics> personFileBasicsList = subArchiveService.findAutoByParam(params);
        
        if (CollectionUtils.isEmpty(personFileBasicsList)) {
            logger.error("任务：" + taskId + " 同行分析结果导入异常：档案异常");
            return "同行分析结果导入异常：档案异常。";
        }
        
        PersonfileBasics personfileBasics;
        List<BigdataAnalysisArchive> analysisArchiveList = Lists.newArrayList();
        for (PeerListVO peerListVO : peerListVOList) {
            personfileBasics = personFileBasicsList.stream().filter(personfile -> personfile.getPersonFilesId().equals(peerListVO.getAid())).findAny().orElse(new PersonfileBasics());
            
            if (Strings.isBlank(personfileBasics.getPersonFilesId())) {
                continue;
            }
            
            BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
            bigdataAnalysisArchive.setAid(peerListVO.getAid());
            bigdataAnalysisArchive.setTaskId(taskId);
            bigdataAnalysisArchive.setCid(personfileBasics.getCid());
            bigdataAnalysisArchive.setPersonName(personfileBasics.getName());
            bigdataAnalysisArchive.setCurrAddr(personfileBasics.getDomicilePlace());
            bigdataAnalysisArchive.setFaceUrl(personfileBasics.getHeadImageUrl());
            bigdataAnalysisArchive.setEventTimes(peerListVO.getPeerTimes());
            bigdataAnalysisArchive.setImageCount(0);
            
            analysisArchiveList.add(bigdataAnalysisArchive);
            
            if (analysisArchiveList.size() == BATCH_INSERT_NUM) {
                bigdataAnalysisArchiveService.batchInsertAnalysisArchive(analysisArchiveList);
                analysisArchiveList.clear();
            }
        }
        
        if (CollectionUtils.isNotEmpty(analysisArchiveList)) {
            bigdataAnalysisArchiveService.batchInsertAnalysisArchive(analysisArchiveList);
        }
        
        return "同行结果数据同步成功。";
    }
    
    /**
     * 同行详情处理
     *
     * @param xdataPeerVOList 同行详情数据
     * @param taskId          后台任务ID
     */
    private String detailHaldle(List<PeerListVO> xdataPeerVOList, ArchiveDetailVO archiveDetailVO, Long taskId) throws ParseException {
        
        if (CollectionUtils.isEmpty(xdataPeerVOList)) {
            logger.error("任务：" + taskId + " 同行分析结果详情无数据");
            return "同行分析结果详情无数据。";
        }
        
        
        Set<String> devIds = xdataPeerVOList.stream().map(xdataCrashVO -> xdataCrashVO.getPeerEvents().get(0).getCameraId()).collect(Collectors.toSet());
        List<PersonfileCamera> devs = iPersonfileCameraService.findCameraByDevIdList(Lists.newArrayList(devIds));
        
        if (CollectionUtils.isEmpty(devs)) {
            logger.error("任务：" + taskId + " 同行分析结果导入失败：设备异常");
            return "同行分析结果导入失败：设备异常。";
        }
        
        BigdataAnalysisTask task = bigdataAnalysisTaskService.findBigdataAnalysisTaskById(taskId);
        if (task == null) {
            logger.error("任务：" + taskId + " 同行分析结果导入失败：任务不存在");
            return "同行分析结果导入失败：任务不存在。";
        }
        
        // 构造数据
        List<BigdataAnalysisPeer> peers = Lists.newLinkedList();
        List<BigdataAnalysisEvent> faces = Lists.newArrayList();
        List<BigdataAnalysisEvent> faceItem = Lists.newArrayList();
        for (PeerListVO xdataPeerVO : xdataPeerVOList) {
            String cameraId = xdataPeerVO.getPeerEvents().get(0).getCameraId();
            if (Strings.isBlank(cameraId)){
                continue;
            }
            
            BigdataAnalysisPeer analysisPeer = new BigdataAnalysisPeer();
            analysisPeer.setCameraId(cameraId);
            
            PersonfileCamera dev = devs.stream().filter(d -> d.getDevId().equals(cameraId)).findAny().orElse(new PersonfileCamera());
            
            if (Strings.isBlank(dev.getName())) {
                continue;
            }
            
            if (CollectionUtils.isEmpty(xdataPeerVO.getTargetEvents()) || CollectionUtils.isEmpty(xdataPeerVO.getPeerEvents())) {
                continue;
            }
            
            EventDetailVO targetEvent = xdataPeerVO.getTargetEvents().get(0);
            EventDetailVO peerEvent = xdataPeerVO.getPeerEvents().get(0);
            List<EventDetailVO> allEvents = Lists.newArrayList();
            allEvents.addAll(xdataPeerVO.getTargetEvents());
            allEvents.addAll(xdataPeerVO.getPeerEvents());
    
            long targetTime = org.apache.commons.lang3.time.DateUtils.parseDate(targetEvent.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime();
            
            long peerTime = org.apache.commons.lang3.time.DateUtils.parseDate(peerEvent.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime();
    
            analysisPeer.setCameraName(dev.getName());
            analysisPeer.setGeoString(dev.getGeoString());
            analysisPeer.setTaskId(taskId);
            analysisPeer.setAid(xdataPeerVO.getAid());
            analysisPeer.setDate(org.apache.commons.lang3.time.DateUtils.parseDate(targetEvent.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S));
            analysisPeer.setFaceId(targetEvent.getFaceId());
            analysisPeer.setFaceUrl(targetEvent.getFaceUrl());
            analysisPeer.setImageCount(0L);
            analysisPeer.setTime(targetTime);
            boolean t = targetTime > peerTime;
            analysisPeer.setStartTime(!t ? targetTime : peerTime);
            analysisPeer.setEndTime(t ? targetTime : peerTime);
            try {
                analysisPeer.setTimeSpan(t ? ((targetTime - peerTime) / 1000)  : ((peerTime - targetTime) / 1000));
            } catch (Exception e) {
                logger.error("同行分析时间异常： " + e.getMessage());
                analysisPeer.setTimeSpan(0L);
            }
            
            for (EventDetailVO event: allEvents) {
                BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
                
                if (event.getAid().equals(archiveDetailVO.getAid())) {
                    bigdataAnalysisEvent.setSourceAid(xdataPeerVO.getAid());
                }
                
                // 同行人员抓拍
                bigdataAnalysisEvent = new BigdataAnalysisEvent();
                bigdataAnalysisEvent.setFaceId(event.getFaceId());
                bigdataAnalysisEvent.setFaceUrl(event.getFaceUrl());
                bigdataAnalysisEvent.setTime(org.apache.commons.lang3.time.DateUtils.parseDate(event.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                bigdataAnalysisEvent.setTaskId(taskId);
                bigdataAnalysisEvent.setCameraId(event.getCameraId());
                bigdataAnalysisEvent.setAid(event.getAid());
                bigdataAnalysisEvent.setDate(org.apache.commons.lang3.time.DateUtils.parseDate(event.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                bigdataAnalysisEvent.setImageId(event.getImageId());
                bigdataAnalysisEvent.setImageUrl(event.getImageUrl());
                bigdataAnalysisEvent.setTargetRect(event.getTargetRect());
                faceItem.add(bigdataAnalysisEvent);
            }
            // 去重
            faceItem = faceItem.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(BigdataAnalysisEvent::getFaceId))), ArrayList::new));
            faces.addAll(faceItem);
            faceItem.clear();
            peers.add(analysisPeer);
            
            if (peers.size() == BATCH_INSERT_NUM) {
                bigdataAnalysisPeerService.batchInsertAnalysisPeer(peers);
                peers.clear();
            }

            if (faces.size() == BATCH_INSERT_NUM) {
                bigdataAnalysisEventService.batchInsertAnalysisEvent(faces);
                faces.clear();
            }
            
        }
        
        bigdataAnalysisPeerService.batchInsertAnalysisPeer(peers);
        
        bigdataAnalysisEventService.batchInsertAnalysisEvent(faces);
        
        return "同行详情数据同步成功！";
    }
}