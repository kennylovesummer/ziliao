package com.intellif.cloud.personfile.manage.task;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;

/**
 * 档案更新worker
 *
 * @author liuzj
 * @date 2019-12-09
 */
public class ArchiveImageCountAndSnapTimeUpdateWork implements Runnable {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    private SubArchiveService subArchiveService;
    
    private String tableName;
    
    private Integer archiveBatch;
    
    private Integer archiveSnapBatch;
    
    public ArchiveImageCountAndSnapTimeUpdateWork(SubArchiveService subArchiveService,String tableName,Integer archiveBatch,Integer archiveSnapBatch) {
        this.subArchiveService = subArchiveService;
        this.tableName = tableName;
        this.archiveBatch = archiveBatch;
        this.archiveSnapBatch = archiveSnapBatch;
    }
    
    @Override
    public void run() {
        try {
            subArchiveService.statisticImageCountAndRecentSnapTimeHandle(tableName,archiveBatch,archiveSnapBatch);
        } catch (ParseException e) {
            logger.info(Thread.currentThread().getName() + "-update imageCount and recentSnapTime error: " + e.getMessage());
        }
    }
}
