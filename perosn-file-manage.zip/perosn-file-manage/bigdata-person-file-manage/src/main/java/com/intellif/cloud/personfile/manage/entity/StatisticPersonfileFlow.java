package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName StatisticPersonfileFlow
 * @Author liuzhijian
 * @create 2018-10-20
 * @Version 1.0
 * @desc 档案流动情况统计
 */

public class StatisticPersonfileFlow implements Serializable {

    private static final long serialVersionUID = -5721700669421383402L;

    private Long id;

    private Date createTime;

    private Date modifiedTime;

    private Date statisticDate;

    private Integer statisticWeek;

    private Integer statisticFlowTotal;

    private Integer statisticFlowMissTotal;

    private Integer statisticEvent;

    public Integer getStatisticEvent() {
        return statisticEvent;
    }

    public void setStatisticEvent(Integer statisticEvent) {
        this.statisticEvent = statisticEvent;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Date getStatisticDate() {
        return statisticDate;
    }

    public void setStatisticDate(Date statisticDate) {
        this.statisticDate = statisticDate;
    }

    public Integer getStatisticWeek() {
        return statisticWeek;
    }

    public void setStatisticWeek(Integer statisticWeek) {
        this.statisticWeek = statisticWeek;
    }

    public Integer getStatisticFlowTotal() {
        return statisticFlowTotal;
    }

    public void setStatisticFlowTotal(Integer statisticFlowTotal) {
        this.statisticFlowTotal = statisticFlowTotal;
    }

    public Integer getStatisticFlowMissTotal() {
        return statisticFlowMissTotal;
    }

    public void setStatisticFlowMissTotal(Integer statisticFlowMissTotal) {
        this.statisticFlowMissTotal = statisticFlowMissTotal;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}