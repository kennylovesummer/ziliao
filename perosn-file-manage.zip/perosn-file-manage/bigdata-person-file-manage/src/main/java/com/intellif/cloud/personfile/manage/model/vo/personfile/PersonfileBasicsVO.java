package com.intellif.cloud.personfile.manage.model.vo.personfile;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @program ifaas-person-file-manage
 * @Author liuYu
 * @create 2018-10-29 09:59
 * @Version 1.0
 * @desc
 */

@Data
public class PersonfileBasicsVO implements Serializable {

    private static final long serialVersionUID = -1046463825756938711L;

    private Long id;

    private String personFilesId;

    private String labelId;

    private String labelName;

    private String domicilePlace;

    private String phoneNumber;

    private String residencePlace;

    private Integer sex;

    private Integer age;

    private String phoneMac;

    private String transportationCard;

    private String transportation;

    private Date birthDate;

    private Integer imageCount;

    private Date appearTime;

    private String cid;

    private String name;

    @Override
    public String toString()
    {
        return JSONObject.toJSONString(this);
    }
}