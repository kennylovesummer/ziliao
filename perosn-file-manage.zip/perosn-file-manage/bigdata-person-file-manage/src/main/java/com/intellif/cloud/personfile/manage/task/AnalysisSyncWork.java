package com.intellif.cloud.personfile.manage.task;

import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;

import java.util.concurrent.Callable;

/**
 * 数据分析任务完成消息处理
 *
 * @author liuzj
 * @date 2019-07-22
 */
public class AnalysisSyncWork implements Callable<Boolean> {
    
    private BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    private String execId;
    
    public AnalysisSyncWork(BigdataAnalysisTaskService bigdataAnalysisTaskService, String execId) {
        this.bigdataAnalysisTaskService = bigdataAnalysisTaskService;
        this.execId = execId;
    }
    
    @Override
    public Boolean call() {
        Thread.currentThread().setName("数据分析同步数据线程-" + execId);
        return bigdataAnalysisTaskService.analysisTaskStatusHandler(execId);
    }
}
