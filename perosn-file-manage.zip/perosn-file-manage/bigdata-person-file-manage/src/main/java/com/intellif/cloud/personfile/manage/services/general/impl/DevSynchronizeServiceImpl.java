package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.model.dto.camera.DeepEyeCameraDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import com.intellif.cloud.personfile.manage.services.general.IDevSynchronizeService;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 设备列表同步接口实现类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月15日
 * @see DevSynchronizeServiceImpl
 * @since JDK1.8
 */
@Service
public class DevSynchronizeServiceImpl implements IDevSynchronizeService {

    /**
     * 摄像头service
     */
    @Resource
    private PersonfileCameraServiceImpl personfileCameraService;
    /**
     * 深目
     */
    @Resource
    private DeepEyeService deepEyeService;

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    /**
     * 同步设备列表-深目
     *
     * @return
     */
    @Override
    public BaseDataRespDTO devSynchDeepEye() {
        // 清空原有数据
        personfileCameraService.deletePersonfileCamera();
        // 深目的所有列表
        List<DeepEyeCameraDTO> deepEyeServiceCameraList = deepEyeService.getCameraList();
        if (CollectionUtils.isNotEmpty(deepEyeServiceCameraList)) {
            List<PersonfileCamera> personfileCameras = objectConvertCamera(deepEyeServiceCameraList);
            personfileCameraService.insertPersonfileCameraBatch(personfileCameras);
        }
        return new BaseDataRespDTO();
    }

    /**
     * 深目的摄像头对象转化为一人一档的摄像头对象
     *
     * @param deepEyeServiceCameraList
     * @return
     */
    private List<PersonfileCamera> objectConvertCamera(List<DeepEyeCameraDTO> deepEyeServiceCameraList) {
        List<PersonfileCamera> personfileCameraList = Lists.newArrayList();
        for (DeepEyeCameraDTO deepEyeCameraDTO : deepEyeServiceCameraList) {
            PersonfileCamera personfileCamera = new PersonfileCamera();
            BeanUtils.copyProperties(deepEyeCameraDTO, personfileCamera);
            personfileCamera.setDevId(deepEyeCameraDTO.getId());
            personfileCamera.setIp(deepEyeCameraDTO.getUri());
            personfileCamera.setPort(deepEyeCameraDTO.getPort().intValue());
            personfileCamera.setOpType(1L);
            personfileCamera.setStatus(deepEyeCameraDTO.getStatus().intValue());
            personfileCamera.setDeleteStatus(0);
            personfileCameraList.add(personfileCamera);
            if (personfileCameraList.size() == 5000) {
                personfileCameraService.insertPersonfileCameraBatch(personfileCameraList);
                personfileCameraList.clear();
            }
        }
        return personfileCameraList;
    }
}
