package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.DownloadParam;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.AnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.utils.FileUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileNotFoundException;
import java.util.concurrent.RejectedExecutionException;

/**
 * 数据分析下载Controller
 *
 * @author Administrator
 * @date 2019-07-14
 */
@Api(tags = "数据分析-数据下载")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.RequestUrl.ANALYSIS_DOWLOAD)
public class AnalysisDownloadController {

    @Autowired
    private BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;

    @Autowired
    private AnalysisExportTaskService analysisExportTaskService;

    /**
     * 后台下载
     *
     * @param downloadParam 下载参数
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "数据下载")
    @PostMapping(value = "/do")
    public BaseDataRespDTO submitTask(@RequestBody DownloadParam downloadParam){
        try {
            // 解析和校验参数
            if (downloadParam.getTaskId() == null || !downloadParam.getReqParams().containsKey("type")) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "参数异常");
            }

            return analysisExportTaskService.submit(downloadParam);

        } catch (RejectedExecutionException rejectedExecutionException){
            return new BaseDataRespDTO(null, IResultCode.ERROR,"任务创建失败,任务队列已饱和") ;
        } catch (Exception e){
            return new BaseDataRespDTO(null, IResultCode.ERROR,"创建下载任务失败") ;
        }
    }

    /**
     * 获取任务列表
     *
     * @param analysisTaskDTO 参数集合
     * @return BasePageRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "分页获取下载任务列表")
    @PostMapping(value = "task/list")
    public BasePageRespDTO listTask(@RequestBody AnalysisTaskDTO analysisTaskDTO){
        try {
            Page<BigdataAnalysisExportTask> page = bigdataAnalysisExportTaskService.findAnalysisExportTaskByParams(analysisTaskDTO);
            return new BasePageRespDTO(page.getResult(),page.getPages(),Integer.parseInt(page.getTotal() + ""), IResultCode.SUCCESS,"获取成功");
        }catch (Exception e){
            return new BasePageRespDTO(null,0,0, IResultCode.ERROR,"获取失败",e.getMessage());
        }
    }

    /**
     * 文件下载
     *
     * @param response HttpServletResponse
     * @param request HttpServletRequest
     * @param taskId 任务ID
     */
    @ApiOperation(httpMethod = "GET", value = "压缩包下载")
    @GetMapping(value = "{taskId}")
    public String download(HttpServletResponse response, HttpServletRequest request, @PathVariable(name = "taskId")Long taskId){
        try {
            if (taskId == null) {
                return "参数异常";
            }
            BigdataAnalysisExportTask bigdataAnalysisExportTask = bigdataAnalysisExportTaskService.selectAnalysisExportTaskById(taskId);
            if (bigdataAnalysisExportTask == null) {
                return "下载异常！任务异常！";
            }
            FileUtils.downloadFile(response,request,bigdataAnalysisExportTask.getFileName() + ".zip",bigdataAnalysisExportTask.getFilePath() + bigdataAnalysisExportTask.getFileName());
            return "正在下载...";
        } catch (FileNotFoundException fileExection) {
            return "下载异常！文件不存在！";
        } catch (Exception e) {
            return "下载异常！Caused by: " + e.getMessage();
        }
    }

    /**
     * 根据ID获取单个任务
     *
     * @param taskId 任务ID
     */
    @ApiOperation(httpMethod = "GET", value = "根据任务ID获取单个任务")
    @GetMapping(value = "findDownLoadTaskById/{taskId}")
    public BaseDataRespDTO findDownLoadTaskById(@PathVariable(name = "taskId")Long taskId){
        try {
            if (taskId == null) {
                return new BaseDataRespDTO(null, IResultCode.ERROR,"参数异常");
            }
            return new BaseDataRespDTO(bigdataAnalysisExportTaskService.selectAnalysisExportTaskById(taskId), IResultCode.SUCCESS,"获取任务成功") ;
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IResultCode.ERROR,"获取失败",e.getMessage());
        }
    }

    /**
     * 根据ID删除单个任务
     *
     * @param taskId 任务ID
     */
    @ApiOperation(httpMethod = "DELETE", value = "删除单个任务")
    @DeleteMapping(value = "delete/{taskId}")
    public BaseDataRespDTO del(@PathVariable(name = "taskId")Long taskId){
        try {
            if (taskId == null) {
                return new BaseDataRespDTO(null, IResultCode.ERROR,"参数异常");
            }
            BigdataAnalysisExportTask bigdataAnalysisExportTask = bigdataAnalysisExportTaskService.selectAnalysisExportTaskById(taskId);

            if (bigdataAnalysisExportTask == null) {
                return new BaseDataRespDTO(null, IResultCode.ERROR,"任务异常，删除失败");
            }

            bigdataAnalysisExportTaskService.deleteAnalysisExportTask(bigdataAnalysisExportTask);
            return new BaseDataRespDTO(null, IResultCode.SUCCESS,"删除成功") ;

        } catch (Exception e) {
            e.printStackTrace();
            return new BaseDataRespDTO(null, IResultCode.ERROR,"删除失败",e.getMessage());
        }
    }

}
