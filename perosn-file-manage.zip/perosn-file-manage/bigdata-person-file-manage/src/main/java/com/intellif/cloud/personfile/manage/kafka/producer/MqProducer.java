package com.intellif.cloud.personfile.manage.kafka.producer;
import com.bigdata.mq.kafka.producer.SecurityKafkaProducer20;
import com.bigdata.mq.kafka.producer.StandardKafkaProducer20;
import com.bigdata.mq.kafka.util.ProducerPropsUtil;
import com.intellif.cloud.personfile.manage.config.KafkaProducerConfig;

import com.intellif.log.LoggerUtilI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Properties;

/**
 * kafka producer
 * @author liuzhijian
 * @date 2019-03-12
 */
@Component
public class MqProducer {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private KafkaProducerConfig config;
    
    /**
     * 发送消息
     *
     * @param msg 消息
     * @param topic 主题
     */
    public void send(String msg,String topic){
        Properties kafkaProperties = config.getPorps();
        if (config.isSecurityMode()) {
            ProducerPropsUtil.getSecurityProps(kafkaProperties);
            SecurityKafkaProducer20 securityProducer = SecurityKafkaProducer20.getInstance(kafkaProperties);
            logger.info("安全模式kafka配置为：" + kafkaProperties.toString());
            securityProducer.checkSecurity(kafkaProperties);
            securityProducer.send(topic, msg);
        } else {
            ProducerPropsUtil.getStandardKafkaProps(kafkaProperties);
            StandardKafkaProducer20 standardProducer = StandardKafkaProducer20.getInstance(kafkaProperties);
            logger.info("标准模式kafka配置为：" + kafkaProperties.toString());
            standardProducer.checkSecurity(kafkaProperties);
            standardProducer.send(topic, msg);
        }

    }
}

