package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.List;

@Data
public class BlockTrceMetaVO {

    private String aid;
    
    private List<EventDetailVO> events;
}
