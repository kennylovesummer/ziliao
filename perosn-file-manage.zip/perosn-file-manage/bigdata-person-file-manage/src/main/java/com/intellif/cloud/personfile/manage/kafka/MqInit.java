package com.intellif.cloud.personfile.manage.kafka;

import com.bigdata.mq.kafka.util.ConsumerPropsUtil;
import com.intellif.cloud.personfile.manage.config.KafkaConsumerConfig;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.kafka.consumer.*;
import com.intellif.log.LoggerUtilI;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Properties;

/**
 * 监听Mq消息
 *
 * @author admin
 * @version 1.0
 * @date 2018年10月23日
 * @see MqInit
 * @since JDK1.8
 */
@Component
public class MqInit {

    private final LoggerUtilI LOG = LoggerUtilI.getLogger(this.getClass().getName());

    @Autowired
    private KafkaConsumerConfig consumerConfig;

    @Autowired
    private MqMessageHandle mqMessageHandle;

    @Autowired
    private PersonPropertiest personPropertiest;

    /**
     * 档案consumer
     */
    public void archiveConsumer() {
        try {
            LOG.info("档案消费者启动...");
            Properties properties = consumerConfig.getPorps();
            if (consumerConfig.isSecurityMode()) {
                LOG.info("启用安全模式...");
                ThreadPoolService.threadPool.execute(
                        new SecurityKafkaFileConsumer(mqMessageHandle, ConsumerPropsUtil.getSecurityProps(properties),
                                personPropertiest.getKafkaListenerPersonfileTopic())
                );
            } else {
                LOG.info("启用标准模式...");
                ThreadPoolService.threadPool.execute(
                        new NormalKafkaFileConsumer(mqMessageHandle, ConsumerPropsUtil.getStandardKafkaProps(properties),
                                personPropertiest.getKafkaListenerPersonfileTopic())
                );
            }
            LOG.info("档案消费者启动完成!");
        } catch (Exception e) {
            LOG.error("档案消费者启动失败" + e.getMessage());
        }
    }
    
    /**
     * 档案刷入solr consumer
     */
    public void archiveToSolrConsumer() {
        try {
            LOG.info("档案消费者2启动...");
            Properties properties = consumerConfig.getPorps();
            properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG,properties.getProperty(ConsumerConfig.GROUP_ID_CONFIG) + "-to-solr");
            if (consumerConfig.isSecurityMode()) {
                LOG.info("启用安全模式...");
                ThreadPoolService.threadPool.execute(
                        new SecurityKafkaFileToSolrConsumer(mqMessageHandle, ConsumerPropsUtil.getSecurityProps(properties),
                                personPropertiest.getKafkaListenerPersonfileTopic())
                );
            } else {
                LOG.info("启用标准模式...");
                ThreadPoolService.threadPool.execute(
                        new NormalKafkaFileToSolrConsumer(mqMessageHandle, ConsumerPropsUtil.getStandardKafkaProps(properties),
                                personPropertiest.getKafkaListenerPersonfileTopic())
                );
            }
            LOG.info("档案消费者2启动完成!");
        } catch (Exception e) {
            LOG.error("档案消费者2启动失败" + e.getMessage());
        }
    }

    /**
     * 抓拍consumer
     */
    public void eventConsumer() {
        try {
            LOG.info("事件消费者启动...");
            Properties properties = consumerConfig.getPorps();
            if (consumerConfig.isSecurityMode()) {
                LOG.info("启用安全模式...");
                ThreadPoolService.threadPool.execute(
                        new SecurityKafkaEventConsumer(mqMessageHandle, ConsumerPropsUtil.getSecurityProps(properties),
                                personPropertiest.getKafkaListenerPersonEventTopic())
                );
            } else {
                LOG.info("启用标准模式...");
                ThreadPoolService.threadPool.execute(
                        new NormalKafkaEventConsumer(mqMessageHandle, ConsumerPropsUtil.getStandardKafkaProps(properties),
                                personPropertiest.getKafkaListenerPersonEventTopic())
                );
            }
            LOG.info("事件消费者启动完成!");
        } catch (Exception e) {
            LOG.error("事件消费者启动失败" + e.getMessage());
        }
    }
    
    
    /**
     * 合并档案
     */
    public void mergeArchiveConsumer() {
        try {
            LOG.info("合并档案消费者启动...");
            Properties properties = consumerConfig.getPorps();
            if (consumerConfig.isSecurityMode()) {
                LOG.info("启用安全模式...");
                ThreadPoolService.threadPool.execute(
                        new SecurityKafkaFileMergeConsumer(mqMessageHandle, ConsumerPropsUtil.getSecurityProps(properties),
                                personPropertiest.getKafkaListenerPersonfileMergeTopic())
                );
            } else {
                LOG.info("启用标准模式...");
                ThreadPoolService.threadPool.execute(
                        new NormalKafkaMergeFileConsumer(mqMessageHandle, ConsumerPropsUtil.getStandardKafkaProps(properties),
                                personPropertiest.getKafkaListenerPersonfileMergeTopic())
                );
            }
            LOG.info("合并档案消费者启动完成!");
        } catch (Exception e) {
            LOG.error("合并档案消费者启动失败" + e.getMessage());
        }
    }

}
