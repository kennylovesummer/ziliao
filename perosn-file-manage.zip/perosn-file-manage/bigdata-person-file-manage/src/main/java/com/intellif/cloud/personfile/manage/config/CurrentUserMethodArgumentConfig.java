/*  
 * 文件名：CurrentUserMethodArgumentConfig.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月23日    
 * 修改理由：  
 * 修改内容：  
 */  

package com.intellif.cloud.personfile.manage.config;

import com.intellif.cloud.personfile.manage.exceptions.GlobalExceptionHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class CurrentUserMethodArgumentConfig extends WebMvcConfigurerAdapter{

	private static final Logger logger = LoggerFactory.getLogger(CurrentUserMethodArgumentConfig.class);

	
	@Bean
	public GlobalExceptionHandler newGlobalExceptionHandler()
	{
		logger.info("初始化GlobalExceptionHandler类");
		GlobalExceptionHandler globalExceptionHandler = new GlobalExceptionHandler();
		return globalExceptionHandler;
	}
	
}
