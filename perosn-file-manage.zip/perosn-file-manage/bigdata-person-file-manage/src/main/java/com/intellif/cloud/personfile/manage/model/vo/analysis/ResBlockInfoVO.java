package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.List;

@Data
public class ResBlockInfoVO {
    
    private String blockCode;
    
    private String startTime;
    
    private String endTime;
    
    private List<BlockTrceMetaVO> targetTraceInfos;
    
}
