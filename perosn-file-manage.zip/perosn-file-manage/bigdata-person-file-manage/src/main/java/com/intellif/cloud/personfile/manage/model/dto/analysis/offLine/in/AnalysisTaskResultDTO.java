package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;

import com.intellif.cloud.personfile.manage.model.dto.xdata.BaseReqDTO;
import lombok.Data;

/**
 * 获取分析任务结果参数集
 *
 * @author liuzj
 * @date 2019-07-19
 */
@Data
public class AnalysisTaskResultDTO extends BaseReqDTO implements java.io.Serializable {
    
    private static final long serialVersionUID = 2978950671430138545L;
    
    /**
     * 数据平台任务ID
     */
    private String taskId;
    
    /**
     * 后台任务ID
     */
    private Long taskId2;
    
    private String taskType;
    
    private Integer startCount;
    
    private String type;
    
    private Long costTime;
    
    private String crashResult;
    
    private String remark;
    
    private String bizCode;
    
    private String opCode;
    
}
