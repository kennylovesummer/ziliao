package com.intellif.cloud.personfile.manage.model.dto.snap;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author liuyu
 * @className SnapMapResp
 * @date 2019/3/20 14:21
 * @description
 */
@Data
public class SnapMapResp implements Serializable {

    private static final long serialVersionUID = -6998975281880029262L;

    /**
     * 事件发生日期
     */
    private String occurrenceDate;

    /**
     * 抓拍图片集合
     */
    private List<SnapMapVO> snapMapVOList;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
