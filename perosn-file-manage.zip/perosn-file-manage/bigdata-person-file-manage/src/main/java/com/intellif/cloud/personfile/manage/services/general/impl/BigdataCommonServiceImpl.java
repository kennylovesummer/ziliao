package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @see  BigdataCommonService
 */
@Service
public class BigdataCommonServiceImpl extends BaseServiceImpl implements BigdataCommonService {

    @Override
    public int insertBigdataCommon(BigdataCommon bigdataCommon) {
        return this.baseDao.insert(bigdataCommon);
    }

    @Override
    public int updateBigdataCommon(BigdataCommon bigdataCommon) {
        return this.baseDao.update(bigdataCommon);
    }

    @Override
    public List<BigdataCommon> findBigdataCommonByContentType(String contentType) {
        QueryEvent queryEvent = new QueryEvent();
        Map<String, Object> paramMap = new HashMap<>(1);
        paramMap.put("contentType", contentType);
        queryEvent.setParameter(paramMap);
        queryEvent.setStatement("findBigdataCommonByContentType");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (List<BigdataCommon>) object : Lists.newArrayList();
    }
}
