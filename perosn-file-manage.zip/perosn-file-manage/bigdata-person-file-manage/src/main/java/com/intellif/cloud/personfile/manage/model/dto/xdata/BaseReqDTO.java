package com.intellif.cloud.personfile.manage.model.dto.xdata;

/**
 * 基础查询参数
 *
 * @author liuzj
 * @version 1.0
 * @date 2019年04月13日
 * @see BaseReqDTO
 * @since JDK1.8
 */
public class BaseReqDTO {

    /**
     * 数据库名字
     */
    protected String dbName;

    /**
     * 创建开始日期
     */
    protected String startTime;
    /**
     * 创建结束日期
     */
    protected String endTime;

    /**
     * 页码
     */
    protected int pageNo;
    /**
     * 每页数据条数
     */
    protected int pageSize;

    /**
     * 请求来源系统编码（后期作为统计和追溯使用）
     */
    protected String sysCode = "archive";

    /**
     * 当前请求时间 （后期作为统计和追溯使用）
     */
    protected String currTime = System.currentTimeMillis() + "";

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getSysCode() {
        return sysCode;
    }

    public void setSysCode(String sysCode) {
        this.sysCode = sysCode;
    }

    public String getCurrTime() {
        return currTime;
    }

    public void setCurrTime(String currTime) {
        this.currTime = currTime;
    }
}
