package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

public class PersonfileOperateLog implements Serializable {

    private static final long serialVersionUID = -3057179204441833256L;

    private Integer id;

    private Date createTime;

    private Date modifiedTime;

    private String operateUserName;

    private Integer operateUserId;

    private Date operateTime;

    private String operateName;

    private String operateUserIp;

    private String remark;

    public Integer getId() {
        return id;
    }

    public PersonfileOperateLog setId(Integer id) {
        this.id = id;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public PersonfileOperateLog setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public PersonfileOperateLog setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
        return this;
    }

    public Integer getOperateUserId() {
        return operateUserId;
    }



    public Date getOperateTime() {
        return operateTime;
    }

    public PersonfileOperateLog setOperateTime(Date operateTime) {
        this.operateTime = operateTime;
        return this;
    }

    public String getOperateName() {
        return operateName;
    }

    public PersonfileOperateLog setOperateName(String operateName) {
        this.operateName = operateName == null ? null : operateName.trim();
        return this;
    }

    public String getOperateUserIp() {
        return operateUserIp;
    }

    public PersonfileOperateLog setOperateUserIp(String operateUserIp) {
        this.operateUserIp = operateUserIp == null ? null : operateUserIp.trim();
        return this;
    }

    public String getRemark() {
        return remark;
    }

    public PersonfileOperateLog setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
        return this;
    }

    public String getOperateUserName() {
        return operateUserName;
    }

    public PersonfileOperateLog setOperateUserName(String operateUserName) {
        this.operateUserName = operateUserName;
        return this;
    }

    public void setOperateUserId(Integer operateUserId) {
        this.operateUserId = operateUserId;
    }

    @Override
    public String toString()
    {
        return JSONObject.toJSONString(this);
    }
}