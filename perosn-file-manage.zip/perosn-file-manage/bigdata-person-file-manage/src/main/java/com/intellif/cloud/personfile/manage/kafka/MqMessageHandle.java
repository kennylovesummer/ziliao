/*
 *文件名： MqListener.java
 *版权： Copyright by 云天励飞 intellif.com
 *描述： Description
 *创建人：mozping
 *创建时间： 2018/8/23 16:07
 *修改理由：
 *修改内容：
 */
package com.intellif.cloud.personfile.manage.kafka;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileMergeDTO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileFlowService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import com.intellif.cloud.personfile.manage.services.sub.AbstractSubService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveAvatorService;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.Collection;
import java.util.List;
import java.util.Objects;


/**
 * kafka监听
 *
 * @author MqListener
 * @version 1.0
 * @date 2018年10月22日
 * @see MqMessageHandle
 * @since JDK1.8
 */
@Component
public class MqMessageHandle {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private SubArchiveAvatorService subArchiveAvatorService;
    
    @Autowired
    private SubArchiveServiceImpl subArchiveService;
    
    @Autowired
    XdataFeignClient xdataFeignClient;
    
    @Autowired
    private SubEventServiceImpl subEventService;
    
    @Autowired
    private PersonfileSolrService personfileSolrService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private StatisticPersonfileService statisticPersonfileService;
    
    @Autowired
    private StatisticPersonfileFlowService statisticPersonfileFlowService;
    
    private static final String[] dateFormat = {"yyyy-MM-dd"};
    
    private static final String TABLE_NAME = "t_bigdata_archive";
    
    private static final String AVATOR_TABLE_NAME = "t_bigdata_avatar_info";
    
    private static final String EVENT_TABLE_NAME = "t_bigdata_event";
    
    private static final String[] ignoreFields = {"featureInfo"};
    
    private static final String BASE_ARCHIVE_TABLE = TABLE_NAME + ICommonConstant.Symbol.UNDERLINE;
    
    private static final String BASE_AVATOR_ARCHIVE_TABLE = AVATOR_TABLE_NAME + ICommonConstant.Symbol.UNDERLINE;
    
    /**
     * 每归档成功一个则进行档案数据新增或者更新
     *
     * @param consumerRecords 接收的消息集合
     */
    public void archiveHandle(Collection<String> consumerRecords) {
        List<PersonfileBasics> personFileBasicsList = Lists.newLinkedList();
        List<PersonfileHeadPicture> personFileHeadPictures = Lists.newLinkedList();

        for (String record : consumerRecords) {
            JSONObject jsonParam = JSONObject.parseObject(Objects.requireNonNull(record));
            PersonfileClusterFinishDTO personfileClusterFinishDTO = JSON.parseObject(String.valueOf(jsonParam), PersonfileClusterFinishDTO.class);
            if (!"update".equals(jsonParam.get("action")) && (personfileClusterFinishDTO.getPersonFileCreateTime() == null
                    || personfileClusterFinishDTO.getAlgoVersion() == null)) {
                logger.warn("接收到数据平台的异常归档kafka消息(无创建时间或版本号):" + personfileClusterFinishDTO.getPersonFilesId());
                continue;
            }

            if (StringUtils.isNotBlank(personfileClusterFinishDTO.getPersonFilesId())) {

                PersonfileBasics personfileBasics = new PersonfileBasics();
                PersonfileHeadPicture personfileHeadPicture = new PersonfileHeadPicture();

                BeanUtils.copyProperties(personfileClusterFinishDTO, personfileBasics);
                BeanUtils.copyProperties(personfileClusterFinishDTO, personfileHeadPicture, ignoreFields);
    
                if ("delete".equals(personfileClusterFinishDTO.getAction())) {
                    personfileBasics.setIsDeleted(IPersonfilesManageConstant.BaseByte.IS_DELETE);
                }
    
                int num = AbstractSubService.hash(personfileBasics.getPersonFilesId(), personPropertiest.getArchiveTableMaxTables());
                personfileBasics.setTableName(BASE_ARCHIVE_TABLE + num);
                personfileHeadPicture.setTableName(BASE_AVATOR_ARCHIVE_TABLE + num);
                
                personFileBasicsList.add(personfileBasics);
                personFileHeadPictures.add(personfileHeadPicture);
            }
        }
        
        long startTime = System.currentTimeMillis();
        if (CollectionUtils.isNotEmpty(personFileBasicsList)) {
            subArchiveService.archiveSync(personFileBasicsList);
        }
        if (CollectionUtils.isNotEmpty(personFileHeadPictures)) {
            subArchiveAvatorService.archiveImageSync(personFileHeadPictures);
        }

//      日志
        if (personPropertiest.getKafkaConsumerLogEnable()) {
            logger.info("档案插入耗时：" + (System.currentTimeMillis() - startTime) + "--已接收档案-->" + consumerRecords.size());
        }
    }
    
    /**
     * 档案刷到Solr
     *
     * @param consumerRecords 接收的消息集合
     */
    public void archiveToSolrHandle(Collection<String> consumerRecords) {
        List<PersonfileClusterFinishDTO> personFileClusterFinishDTOList = Lists.newLinkedList();
        for (String record : consumerRecords) {
            JSONObject jsonParam = JSONObject.parseObject(Objects.requireNonNull(record));
            PersonfileClusterFinishDTO personfileClusterFinishDTO = JSON.parseObject(String.valueOf(jsonParam), PersonfileClusterFinishDTO.class);
            if (!"update".equals(jsonParam.get("action")) && (personfileClusterFinishDTO.getPersonFileCreateTime() == null
                    || personfileClusterFinishDTO.getAlgoVersion() == null || personfileClusterFinishDTO.getFeatureInfo() == null)) {
                logger.warn("异常档案无法刷入solr:" + personfileClusterFinishDTO.getPersonFilesId());
                continue;
            }
            if (StringUtils.isNotBlank(personfileClusterFinishDTO.getPersonFilesId())) {
                personFileClusterFinishDTOList.add(personfileClusterFinishDTO);
            }
        }
        // 将数据刷到solr
        if (CollectionUtils.isNotEmpty(personFileClusterFinishDTOList)) {
            personfileSolrService.insert(personFileClusterFinishDTOList);
        }
    }
    
    /**
     * 档案自动合并
     *
     * @param consumerRecords 合并信息
     */
    public void archiveMerge(Collection<String> consumerRecords) {
        List<PersonfileBasics> personfileBasicsList = Lists.newArrayList();
        List<PersonfileMergeDTO> personfileSnapList = Lists.newLinkedList();
        for (String record : consumerRecords) {
            JSONObject jsonParam = JSONObject.parseObject(Objects.requireNonNull(record));
            if (jsonParam.containsKey("fromAids") && jsonParam.containsKey("targetAid")) {
                JSONArray fromAids = jsonParam.getJSONArray("fromAids");
                for (int i = 0; i < fromAids.size(); i++) {
                    // 处理档案
                    PersonfileBasics personfileBasics = new PersonfileBasics();
                    personfileBasics.setIsDeleted(IPersonFilesConstant.BaseByte.IS_DELETE);
                    personfileBasics.setPersonFilesId(fromAids.getString(i));
                    personfileBasics.setTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileBasics.getPersonFilesId(), personPropertiest.getArchiveTableMaxTables()));
                    personfileBasicsList.add(personfileBasics);
                }
                
                // 处理事件
                personfileSnapList.add(JSONObject.parseObject(record, PersonfileMergeDTO.class));
            }
        }
        if (CollectionUtils.isNotEmpty(personfileBasicsList)) {
            subArchiveService.batchInsertPersonfileBasics(personfileBasicsList);
        }
        
        if (CollectionUtils.isNotEmpty(personfileSnapList)) {
            subEventService.updateSnapAid(personfileSnapList);
        }
    }
    
    /**
     * 事件同步
     *
     * @param consumerRecords 接收的kafka消息体
     */
    public void eventHandle(Collection<String> consumerRecords) {
        List<PersonfileSnap> personFileSnapList = Lists.newLinkedList();
        String baseTableName = EVENT_TABLE_NAME + ICommonConstant.Symbol.UNDERLINE;
        for (String record : consumerRecords) {
            JSONObject jsonParam = JSONObject.parseObject(Objects.requireNonNull(record));
            PersonfileSnap personfileSnap = JSON.parseObject(String.valueOf(jsonParam), PersonfileSnap.class);
            if (personfileSnap.isNormalSnap()) {
                personfileSnap.setTableName(baseTableName+ DateFormatUtils.format(personfileSnap.getSnapTime(),"yyyyMMdd"));
                personFileSnapList.add(personfileSnap);
            } else {
                logger.warn("接收到数据平台抓拍kafka消息异常:" + record);
            }
        }
        
        long startTime = System.currentTimeMillis();
        if (CollectionUtils.isNotEmpty(personFileSnapList)) {
            subEventService.eventSync(personFileSnapList);
        }
        if (personPropertiest.getKafkaConsumerLogEnable()) {
            logger.info("事件插入耗时：" + (System.currentTimeMillis() - startTime) + "---已接收事件kafka消息-->" + personFileSnapList.size());
        }
    }
    
    /**
     * 归档完成统计
     *
     * @param clusterDate 归档日期
     * @throws ParseException 异常
     */
    public void clusterStatisticFinish(String clusterDate, String clusterStartTime, String clusterEndTime) throws Exception {
        Integer newTotal = subArchiveService.statisticNewPersonfile(clusterStartTime, clusterEndTime, false);
        Integer newRealNameTotal = subArchiveService.statisticNewPersonfile(clusterStartTime, clusterEndTime, true);
    
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        listFilterDTO.setPersonFileType(1);
        Long realNameTotal = subArchiveService.findPersonfilePageTotal(listFilterDTO);
    
        listFilterDTO.setPersonFileType(null);
        Long total = subArchiveService.findPersonfilePageTotal(listFilterDTO);
        
        // 档案新增（新增总数和实名）统计
        logger.info("新增总数,实名总数统计开始...");
        try {
            StatisticPersonfile statisticPersonfile = new StatisticPersonfile();
            statisticPersonfile.setStatisticDate(org.apache.commons.lang.time.DateUtils.parseDate(clusterDate, dateFormat));
            statisticPersonfile.setStatisticNewNum(newTotal);
            statisticPersonfile.setStatisticRealNameTotal(realNameTotal.intValue());
            statisticPersonfile.setStatisticTotal(total.intValue());
            statisticPersonfileService.insertStatisticPersonfile(statisticPersonfile);
            
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("新增总数,实名总数统计完毕-【新增：" + newTotal + "】" + "【实名总数：" + newRealNameTotal + "】"+ "【档案总数：" + total + "】");
        
        try {
            // 查询是否有此记录
            StatisticPersonfileFlow statisticPersonfileFlow = statisticPersonfileFlowService.findByStatisticDate(clusterDate);
            if (statisticPersonfileFlow == null) {
                statisticPersonfileFlow = new StatisticPersonfileFlow();
            }
            String[] formatType = {ICommonConstant.DateFormatType.Y_M_D};
            
            statisticPersonfileFlow.setStatisticDate(org.apache.commons.lang.time.DateUtils.parseDate(clusterDate, formatType));
            
            statisticPersonfileFlow.setStatisticFlowMissTotal(0);
            statisticPersonfileFlow.setStatisticFlowTotal(newTotal);
            
            if (statisticPersonfileFlow.getId() != null) {
                statisticPersonfileFlowService.update(statisticPersonfileFlow);
            } else {
                statisticPersonfileFlowService.insert(statisticPersonfileFlow);
            }
            
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        
    }
}

