package com.intellif.cloud.personfile.manage.config;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * 属性的获取
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月22日
 * @see PersonPropertiest
 * @since JDK1.8
 */
@Configuration
public class PersonPropertiest {
    
    /**
     * 深目 请求地址前缀
     */
    public String deepEyeUrlPrefix;
    
    /**
     * 深目 设备列表请求地址
     */
    public String deepEyeCameraUrl;
    
    /**
     * 深目 登录的用户名
     */
    public String deepEyeLoginUserName;
    
    /**
     * 深目 登录的密码
     */
    public String deepEyeLoginPassword;
    
    /**
     * 深目 登录授权类型
     */
    public static final String DEEP_EYE_LOGIN_GRAN_TTYPE = "password";
    
    /**
     * 深目 大图获取小图 根据大图编号（imageid）获取图片中的人脸（face）信息
     */
    public static final String DEEP_EYE_SIMAGE_URL = "/api/intellif/face/image/";
    
    /**
     * 深目 小图获取大图 根据人脸编号（faceid）获取人脸所在的大图（image）的信息
     */
    public static final String DEEP_EYE_BIMAGE_URL = "/api/intellif/image/face/json/";
    
    /**
     * 深目 摄像头列表 地址 前缀
     */
    public static final String DEEP_EYE_CAMERA_URL_PREFIX = "/api/intellif/camera";
    
    /**
     * 深目 提取抓拍人脸特征值
     */
    public static final String DEEP_EYE_GET_FACE_FEATURE = "/api/intellif/engine/target/feature/1.0";
    
    /**
     * 获取摄像头树状结构数据
     */
    public static final String DEEP_EYE_GET_TREE_CAMERA = "/api/intellif/zone/child";
    
    /**
     * 根据名字搜索摄像头
     */
    public static final String DEEP_EYE_SEARCH_CAMERA_BY_NAME = "/api/intellif/camera";
    
    /**
     * 特征值提取使用的引擎(ifaas/deepEye),默认ifaas
     */
    public String personfileEngineType;
    
    /**
     * 文件服务的前缀
     */
    public String fileUrlPrefix;
    
    /**
     * 算法版本
     */
    public int engineAlgVersion;
    /**
     * 引擎类型 thrift/http
     */
    public String engineType;
    /**
     * 引擎ip
     */
    public String engineIp;
    /**
     * 引擎端口
     */
    public int enginePort;
    
    /**
     * solr url
     */
    public static String SOLRURL;
    
    /**
     * 配置IP
     */
    private String ip;
    
    /**
     * 是否使用本地ip (1: 是； 0：否)
     */
    private int personfileFilterIpLocalhost;
    
    /**
     * 图片上传-获取图片的端口
     */
    private String personfileFilterPort;
    
    /**
     * 数据平台 获取单个档案数据库
     */
    private String personFileDBName2;
    
    /**
     * 数据平台 合并/删除档案数据库
     */
    private String personFileDBName;
    
    /**
     * 数据平台 人际关系数据库
     */
    private String personFileRelationshipDBName;
    
    /**
     * 数据平台 人际关系添加数据库
     */
    private String personfileRelationshipAddDBName;
    
    /**
     * 数据平台 轨迹分析数据库
     */
    private String traceDBName;
    
    /**
     * 数据平台 碰撞分析数据库
     */
    private String crashDBName;
    
    /**
     * 数据平台 多区域碰撞分析数据库
     */
    private String multiCrashDBName;
    
    /**
     * 数据平台 同行分析数据库
     */
    private String peerDBName;
    
    /**
     * 回收站照片推送至kafka对应的topic
     */
    private String kafkaListenerPersonfileRubbishTopic;
    
    /**
     * 档案topic
     */
    private String kafkaListenerPersonfileTopic;
    
    /**
     * 档案合并topic
     */
    private String kafkaListenerPersonfileMergeTopic;
    
    /**
     * 事件topic
     */
    private String kafkaListenerPersonEventTopic;
    
    /**
     * 数据分析导出目录
     */
    private String dataAnalysisExportBasePath;
    
    /**
     * 数据分析数据导出超时设置
     */
    private Long dataAnalysisExportTimeOutMillis;
    
    /**
     * 数据分析任务状态更新超时
     */
    private Long dateAnalysisTaskTimeOutMillis;
    
    /**
     * 档案和事件kafka接收数据日志打印开关
     */
    private Boolean kafkaConsumerLogEnable;
    
    /**
     * 档案表单表最大数据限制
     */
    private Integer archiveTableMaxTables;
    
    /**
     * 事件表单表最大数据限制
     */
    private Long eventTableMaxRows;
    
    private Integer similarPersonFileMaxNum;
    
    private Boolean slaveDBEnable;
    
    private String bizCode;
    
    private String dataAnalysisActivityRules;
    
    private String dataAnalysisCrashRules;
    
    private String dataAnalysisLingerRules;
    
    private String dataAnalysisNocturnalRules;
    
    private String dataAnalysisPeerRules;
    
    private String dataAnalysisTraceRules;
    
    // 单点登录
    private String ssoLoginUrl;
    
    private Integer archiveImageCountAndRecentSnapTimeUpdateBatch;
    
    private Integer archiveImageCountAndRecentSnapTimeUpdateSnapBatch;
    
    public Integer getArchiveImageCountAndRecentSnapTimeUpdateSnapBatch() {
        return archiveImageCountAndRecentSnapTimeUpdateSnapBatch;
    }
    
    @Value("${archive.image-count.recent-snap-time.update.snap.batch:1000}")
    public void setArchiveImageCountAndRecentSnapTimeUpdateSnapBatch(Integer archiveImageCountAndRecentSnapTimeUpdateSnapBatch) {
        this.archiveImageCountAndRecentSnapTimeUpdateSnapBatch = archiveImageCountAndRecentSnapTimeUpdateSnapBatch;
    }
    
    public Integer getArchiveImageCountAndRecentSnapTimeUpdateBatch() {
        return archiveImageCountAndRecentSnapTimeUpdateBatch;
    }
    
    @Value("${archive.image-count.recent-snap-time.update.batch:50000}")
    public void setArchiveImageCountAndRecentSnapTimeUpdateBatch(Integer archiveImageCountAndRecentSnapTimeUpdateBatch) {
        this.archiveImageCountAndRecentSnapTimeUpdateBatch = archiveImageCountAndRecentSnapTimeUpdateBatch;
    }
    
    public String getSsoLoginUrl() {
        return ssoLoginUrl;
    }
    
    @Value("${sso.login.url:localhost}")
    public void setSsoLoginUrl(String ssoLoginUrl) {
        this.ssoLoginUrl = ssoLoginUrl;
    }
    
    public String getDataAnalysisActivityRules() {
        return dataAnalysisActivityRules;
    }
    
    @Value("${data.analysis.activity.rules}")
    public void setDataAnalysisActivityRules(String dataAnalysisActivityRules) {
        this.dataAnalysisActivityRules = dataAnalysisActivityRules;
    }
    
    public String getDataAnalysisCrashRules() {
        return dataAnalysisCrashRules;
    }
    
    @Value("${data.analysis.crash.rules}")
    public void setDataAnalysisCrashRules(String dataAnalysisCrashRules) {
        this.dataAnalysisCrashRules = dataAnalysisCrashRules;
    }
    
    public String getDataAnalysisLingerRules() {
        return dataAnalysisLingerRules;
    }
    
    @Value("${data.analysis.linger.rules}")
    public void setDataAnalysisLingerRules(String dataAnalysisLingerRules) {
        this.dataAnalysisLingerRules = dataAnalysisLingerRules;
    }
    
    public String getDataAnalysisNocturnalRules() {
        return dataAnalysisNocturnalRules;
    }
    
    @Value("${data.analysis.nocturnal.rules}")
    public void setDataAnalysisNocturnalRules(String dataAnalysisNocturnalRules) {
        this.dataAnalysisNocturnalRules = dataAnalysisNocturnalRules;
    }
    
    public String getDataAnalysisPeerRules() {
        return dataAnalysisPeerRules;
    }
    
    @Value("${data.analysis.peer.rules:}")
    public void setDataAnalysisPeerRules(String dataAnalysisPeerRules) {
        this.dataAnalysisPeerRules = dataAnalysisPeerRules;
    }
    
    public String getDataAnalysisTraceRules() {
        return dataAnalysisTraceRules;
    }
    
    @Value("${data.analysis.trace.rules:}")
    public void setDataAnalysisTraceRules(String dataAnalysisTraceRules) {
        this.dataAnalysisTraceRules = dataAnalysisTraceRules;
    }
    
    public String getBizCode() {
        return bizCode;
    }
    
    @Value("${xapi.bizcode}")
    public void setBizCode(String bizCode) {
        this.bizCode = bizCode;
    }
    
    public Boolean getSlaveDBEnable() {
        return slaveDBEnable;
    }
    
    @Value("${slave.db.enable:false}")
    public void setSlaveDBEnable(Boolean slaveDBEnable) {
        this.slaveDBEnable = slaveDBEnable;
    }
    
    
    public Integer getSimilarPersonFileMaxNum() {
        return similarPersonFileMaxNum;
    }
    
    @Value("${personfile.similar.max.num:100}")
    public void setSimilarPersonFileMaxNum(Integer similarPersonFileMaxNum) {
        this.similarPersonFileMaxNum = similarPersonFileMaxNum;
    }
    
    public Long getEventTableMaxRows() {
        return eventTableMaxRows;
    }
    
    @Value("${event.table.max.rows:1000000}")
    public void setEventTableMaxRows(Long eventTableMaxRows) {
        this.eventTableMaxRows = eventTableMaxRows;
    }
    
    public Integer getArchiveTableMaxTables() {
        return archiveTableMaxTables;
    }
    
    @Value("${archive.table.max.tables:10}")
    public void setArchiveTableMaxTables(Integer archiveTableMaxTables) {
        this.archiveTableMaxTables = archiveTableMaxTables;
    }
    
    public Boolean getKafkaConsumerLogEnable() {
        return kafkaConsumerLogEnable;
    }
    
    @Value("${kafka.consumer.log.enable:false}")
    public void setKafkaConsumerLogEnable(Boolean kafkaConsumerLogEnable) {
        this.kafkaConsumerLogEnable = kafkaConsumerLogEnable;
    }
    
    public Long getDateAnalysisTaskTimeOutMillis() {
        return dateAnalysisTaskTimeOutMillis;
    }
    
    @Value("${data.analysis.task.timeout.millis}")
    public void setDateAnalysisTaskTimeOutMillis(Long dateAnalysisTaskTimeOutMillis) {
        this.dateAnalysisTaskTimeOutMillis = dateAnalysisTaskTimeOutMillis;
    }
    
    public Long getDataAnalysisExportTimeOutMillis() {
        return dataAnalysisExportTimeOutMillis;
    }
    
    @Value("${data.analysis.export.timeout.millis}")
    public void setDataAnalysisExportTimeOutMillis(Long dataAnalysisExportTimeOutMillis) {
        this.dataAnalysisExportTimeOutMillis = dataAnalysisExportTimeOutMillis;
    }
    
    public String getDataAnalysisExportBasePath() {
        return dataAnalysisExportBasePath;
    }
    
    @Value("${data.analysis.export.base-path}")
    public void setDataAnalysisExportBasePath(String dataAnalysisExportBasePath) {
        this.dataAnalysisExportBasePath = dataAnalysisExportBasePath;
    }
    
    public String getMultiCrashDBName() {
        return multiCrashDBName;
    }
    
    @Value("${xdata.multi.crash.db.name}")
    public void setMultiCrashDBName(String multiCrashDBName) {
        this.multiCrashDBName = multiCrashDBName;
    }
    
    public String getTraceDBName() {
        return traceDBName;
    }
    
    @Value("${xdata.trace.db.name}")
    public void setTraceDBName(String traceDBName) {
        this.traceDBName = traceDBName;
    }
    
    public String getCrashDBName() {
        return crashDBName;
    }
    
    @Value("${xdata.crash.db.name}")
    public void setCrashDBName(String crashDBName) {
        this.crashDBName = crashDBName;
    }
    
    public String getPeerDBName() {
        return peerDBName;
    }
    
    @Value("${xdata.peer.db.name}")
    public void setPeerDBName(String peerDBName) {
        this.peerDBName = peerDBName;
    }
    
    public String getPersonfileFilterPort() {
        return personfileFilterPort;
    }
    
    @Value("${personfile.manage.filter.port:26002}")
    public void setPersonfileFilterPort(String personfileFilterPort) {
        this.personfileFilterPort = personfileFilterPort;
    }
    
    public String getKafkaListenerPersonfileRubbishTopic() {
        return kafkaListenerPersonfileRubbishTopic;
    }
    
    @Value("${kafka.listener.personfile.rubbish.topic}")
    public void setKafkaListenerPersonfileRubbishTopic(String kafkaListenerPersonfileRubbishTopic) {
        this.kafkaListenerPersonfileRubbishTopic = kafkaListenerPersonfileRubbishTopic;
    }
    public String getKafkaListenerPersonfileTopic() {
        return kafkaListenerPersonfileTopic;
    }
    
    @Value("${kafka.listener.personfile.topic}")
    public void setKafkaListenerPersonfileTopic(String kafkaListenerPersonfileTopic) {
        this.kafkaListenerPersonfileTopic = kafkaListenerPersonfileTopic;
    }
    
    public String getKafkaListenerPersonfileMergeTopic() {
        return kafkaListenerPersonfileMergeTopic;
    }
    
    @Value("${kafka.listener.personfile.merge.topic}")
    public void setKafkaListenerPersonfileMergeTopic(String kafkaListenerPersonfileMergeTopic) {
        this.kafkaListenerPersonfileMergeTopic = kafkaListenerPersonfileMergeTopic;
    }
    
    public String getKafkaListenerPersonEventTopic() {
        return kafkaListenerPersonEventTopic;
    }
    
    @Value("${kafka.listener.personfile.snap.topic}")
    public void setKafkaListenerPersonEventTopic(String kafkaListenerPersonEventTopic) {
        this.kafkaListenerPersonEventTopic = kafkaListenerPersonEventTopic;
    }
    
    public String getPersonFileDBName() {
        return personFileDBName;
    }
    
    @Value("${xdata.personfile.db.name}")
    public void setPersonFileDBName(String personFileDBName) {
        this.personFileDBName = personFileDBName;
    }
    
    public String getPersonFileDBName2() {
        return personFileDBName2;
    }
    
    @Value("${xdata.personfile2.db.name}")
    public void setPersonFileDBName2(String personFileDBName2) {
        this.personFileDBName2 = personFileDBName2;
    }
    
    public String getPersonFileRelationshipDBName() {
        return personFileRelationshipDBName;
    }
    
    @Value("${xdata.personfile.relationship.db.name}")
    public void setPersonFileRelationshipDBName(String personFileRelationshipDBName) {
        this.personFileRelationshipDBName = personFileRelationshipDBName;
    }
    
    public String getPersonfileRelationshipAddDBName() {
        return personfileRelationshipAddDBName;
    }
    
    @Value("${xdata.personfile.relationship.add.db.name}")
    public void setPersonfileRelationshipAddDBName(String personfileRelationshipAddDBName) {
        this.personfileRelationshipAddDBName = personfileRelationshipAddDBName;
    }
    
    public int getPersonfileFilterIpLocalhost() {
        return personfileFilterIpLocalhost;
    }
    
    @Value("${personfile.similar.filter.ip.localhost}")
    public void setPersonfileFilterIpLocalhost(int personfileFilterIpLocalhost) {
        this.personfileFilterIpLocalhost = personfileFilterIpLocalhost;
    }
    
    public String getIp() {
        return ip;
    }
    
    @Value("${ip}")
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    @Value("${solr.url}")
    public void setSolrUrl(String solrUrl) {
        SOLRURL = solrUrl;
    }
    
    public String getDeepEyeUrlPrefix() {
        return deepEyeUrlPrefix;
    }
    
    @Value("${deepEye.url.prefix}")
    public void setDeepEyeUrlPrefix(String deepEyeUrlPrefix) {
        this.deepEyeUrlPrefix = deepEyeUrlPrefix;
    }
    
    public String getDeepEyeCameraUrl() {
        return deepEyeCameraUrl;
    }
    
    @Value("${deepEye.url.prefix}")
    public void setDeepEyeCameraUrl(String deepEyeUrlPrefix) {
        if (!deepEyeUrlPrefix.contains(ICommonConstant.Internet.HTTP_SLASH)) {
            this.deepEyeCameraUrl = IPersonfilesManageConstant.Internet.HTTP_SLASH + deepEyeUrlPrefix + PersonPropertiest.DEEP_EYE_CAMERA_URL_PREFIX;
        } else {
            this.deepEyeCameraUrl = deepEyeUrlPrefix + PersonPropertiest.DEEP_EYE_CAMERA_URL_PREFIX;
        }
    }
    
    public String getDeepEyeLoginUserName() {
        return deepEyeLoginUserName;
    }
    
    @Value("${deepEye.login.username}")
    public void setDeepEyeLoginUserName(String deepEyeLoginUserName) {
        this.deepEyeLoginUserName = deepEyeLoginUserName;
    }
    
    public String getDeepEyeLoginPassword() {
        return deepEyeLoginPassword;
    }
    
    @Value("${deepEye.login.password}")
    public void setDeepEyeLoginPassword(String deepEyeLoginPassword) {
        this.deepEyeLoginPassword = deepEyeLoginPassword;
    }
    
    @Value("${personfile.engine.type:ifaas}")
    public void setPersonfileEngineType(String personfileEngineType) {
        this.personfileEngineType = personfileEngineType;
    }
    
    public String getFileUrlPrefix() {
        return fileUrlPrefix;
    }
    
    @Value("${file.url.prefix}")
    public void setFileUrlPrefix(String fileUrlPrefix) {
        this.fileUrlPrefix = fileUrlPrefix;
    }
    
    public int getEngineAlgVersion() {
        return engineAlgVersion;
    }
    
    @Value("${engine.algVersion:5029}")
    public void setEngineAlgVersion(String engineAlgVersion) {
        if (engineAlgVersion.indexOf(IPersonfilesManageConstant.Symbol.COMMA) != -1) {
            this.engineAlgVersion = Integer.parseInt(engineAlgVersion.split(IPersonfilesManageConstant.Symbol.COMMA)[0]);
        } else {
            this.engineAlgVersion = Integer.parseInt(engineAlgVersion);
        }
    }
    
    public String getEngineType() {
        return engineType;
    }
    
    @Value("${engine.type:deepEye}")
    public void setEngineType(String engineType) {
        this.engineType = engineType;
    }
    
    public String getEngineIp() {
        return engineIp;
    }
    
    @Value("${engine.ip:127.0.0.1}")
    public void setEngineIp(String engineIp) {
        this.engineIp = engineIp;
    }
    
    public int getEnginePort() {
        return enginePort;
    }
    
    @Value("${engine.port:13456}")
    public void setEnginePort(int enginePort) {
        this.enginePort = enginePort;
    }
    
    /**
     * 推荐档案相似默认值
     */
    private Float similarRate;
    
    private String version;
    
    public String getVersion() {
        return version;
    }
    
    @Value("${face.version}")
    public void setVersion(String version) {
        this.version = version;
    }
    
    public Float getSimilarRate() {
        return similarRate;
    }
    
    @Value("${personfile.similar.rate:0.92}")
    public void setSimilarRate(Float similarRate) {
        this.similarRate = similarRate;
    }
}
