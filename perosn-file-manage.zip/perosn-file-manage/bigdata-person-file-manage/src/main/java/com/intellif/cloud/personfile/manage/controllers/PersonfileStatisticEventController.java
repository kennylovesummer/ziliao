package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.contants.IPersonfilesStatisticsConstant;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 事件统计
 *
 * @author liuzj
 * @version 1.0
 * @date 2019年05月24日
 * @see PersonfileStatisticEventController
 * @since JDK1.8
 */
@Api(tags = "事件统计")
@RestController
@RequestMapping(IPersonfilesStatisticsConstant.RequestUrl.PERSON_EVENT)
public class PersonfileStatisticEventController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    /**
     * 获取抓拍总数
     *
     * @return 数量
     */
    @ApiOperation(httpMethod = "GET",value = "获取抓拍总数")
    @GetMapping("statisticEvent")
    public Integer statisticEvent() {
        try {
            return statisticPersonfileEventService.statisticEvent();
        } catch (Exception e) {
            logger.error("获取抓拍总数异常：" + e.getMessage());
        }
        return 0;
    }
    
    /**
     * 更新统计
     *
     * @param incNum 新增数
     * @param dt     时间
     */
    @Deprecated
    @ApiOperation(httpMethod = "POST",value = "更新统计")
    @PostMapping(value = "/updateStatistic/{incNum}/{dt}")
    public void updateStatisticEvent(@PathVariable(name = "incNum") Integer incNum,
                                     @PathVariable(name = "dt") String dt) {
        try {
            statisticPersonfileEventService.updateStatisticEvent(incNum, dt);
        } catch (Exception e) {
            logger.error("更新事件统计异常：" + e.getMessage());
        }
        
    }
    
}
