/*
 * 文件名：PersonfilesManageApplication.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年10月10日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.intellif.annotation.EnableDiscoveryClientI;
import com.intellif.cloud.personfile.manage.services.base.BaseDaoImpl;
import com.intellif.commons.util.DbUtil;
import com.intellif.log.annotation.EnableForwardCommonReqHeadIntellif;
import com.intellif.log.annotation.EnableModifyLogLevelIntellif;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.servlet.MultipartConfigElement;

/**
 * 〈一句话简述该类/接口的功能〉
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @version 1.0
 * @date 2018年10月10日
 * @see PersonfilesManageApplication
 * @since JDK1.8
 */
@SpringBootApplication
@EnableDiscoveryClientI
@EnableFeignClients
//@EnableAutoConfigI
@EnableScheduling
//@EnableCaching
@EnableTransactionManagement
@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
/**
 * 公共配置
 */
@EnableApolloConfig({"application", "intellif.common"})
@EnableModifyLogLevelIntellif
@EnableForwardCommonReqHeadIntellif
@EnableHystrix
@Import({BaseDaoImpl.class})
public class PersonfilesManageApplication {
    
    public static void main(String[] args) {
        try {
            DbUtil.initDbAndFlyWay();
        } catch (Exception e) {
            e.printStackTrace();
        }
        SpringApplication.run(PersonfilesManageApplication.class, args);
    }
    
    
    /**
     * 图片上传配置
     *
     * @return
     */
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory config = new MultipartConfigFactory();
        //需要制定apollo的nameSpace获取到指定的配置列表
        Config commonConfig = ConfigService.getConfig("intellif.common");
        config.setMaxFileSize(commonConfig.getProperty("multipart.maxFileSize", "128MB"));
        config.setMaxRequestSize(commonConfig.getProperty("multipart.maxRequestSize", "512MB"));
        return config.createMultipartConfig();
    }
}
