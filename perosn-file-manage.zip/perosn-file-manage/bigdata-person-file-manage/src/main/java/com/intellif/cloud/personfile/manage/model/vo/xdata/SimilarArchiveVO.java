package com.intellif.cloud.personfile.manage.model.vo.xdata;

import lombok.Data;

@Data
public class SimilarArchiveVO {
    
    private Double similarity;
    
    private String archiveId;
}
