/*  
 * 文件名：BaseResp.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月10日    
 * 修改理由：  
 * 修改内容：  
 */  

package com.intellif.cloud.personfile.manage.model.dto.req;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.IResultCode;

import java.io.Serializable;

public class BaseResp implements Serializable
{
    
    /**  
	 *   
	 */
	private static final long serialVersionUID = 1150113732670378528L;

	/**
     * 返回码，默认成功
     */
    
    private int respCode = IResultCode.SUCCESS;
    
    /**
     * 返回码，默认成功
     */
    private String respMessage = "SUCCESS";
    
    public void setRespCode(int respCode)
    {
        this.respCode = respCode;
        if (IResultCode.SUCCESS == respCode)
        {
            this.setRespMessage("SUCCESS");
        }
    }
    
    public int getRespCode()
    {
        return respCode;
    }
    
    public String getRespMessage()
    {
        return respMessage;
    }
    
    public void setRespMessage(String respMessage)
    {
        this.respMessage = respMessage;
    }
    
    /**
     * 得到属性字符串
     * @return String 属性字符串
     */
    @Override
    public String toString()
    {
        return JSONObject.toJSONString(this);
    }
}

