package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class PersonfileConcern implements Serializable {

    private static final long serialVersionUID = 5154656669561870707L;

    private Long id;

    private Date createTime;

    private String creater;

    private Date modifiedTime;

    private String modifier;

    private String personFilesId;

    private String concerner;

    private Integer isDeleted;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}