package com.intellif.cloud.personfile.manage.enums;

/**
 * @author liuzhijian
 * @version 1.0
 * @see PersonfileTypeEnum
 * @since JDK1.8
 * @date 2018年10月17日
 */
public enum PersonfileTypeEnum {

	/**
	 * 全部档案
	 */
	ALL(0, "全部档案","all"),

	/**
	 * 实名档案
	 */
	REAL(1, "实名档案","realName"),

	/**
	 * 未实名档案
	 */
	NOTREAL(2, "未实名档案","noRealName"),

	/**
	 * 我的关注
	 */
	FOCUS(3, "我的关注","focus");

	private int id;

	private String name;

	private String totalName;

	PersonfileTypeEnum(int id, String name, String totalName) {
		this.name = name;
		this.id = id;
		this.totalName = totalName;
	}

	public static PersonfileTypeEnum setFileType(int fileType){
		for (PersonfileTypeEnum realNameArgEnum: PersonfileTypeEnum.values()) {
			if (realNameArgEnum.id == fileType) {
				return realNameArgEnum;
			}
		}
		return PersonfileTypeEnum.ALL;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTotalName() {
		return totalName;
	}

	public static PersonfileTypeEnum getById(int id) {
		for (PersonfileTypeEnum c : PersonfileTypeEnum.values()) {
			if (c.getId() == id) {
				return c;
			}
		}
		return null;
	}

	public Object getRealNameArg(){
		switch (this){
			case REAL:
				return 1;
			case NOTREAL:
				return 0;
			default:
				return null;
		}
	}

	@Override
	public String toString() {
		return name;
	}

}
