package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.AnalysisOnlineTaskService;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 数据在线分析任务
 *
 * @author lzj
 * @version 1.0
 * @date 2019年07月01日
 * @see AnalysisOnlineTaskController
 * @since JDK1.8
 */
@Api(tags = "数据分析-在线任务")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.ANALYSIS_ONLINE_TASK)
public class AnalysisOnlineTaskController {
    
    private final LoggerUtilI LOG = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private AnalysisOnlineTaskService analysisOnlineTaskService;
    
    @Autowired
    private AnalysisFeignClient analysisFeignClient;
    
    
    /**
     * 新建任务（同行、徘徊）
     *
     * @param jsonObject 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "创建在线任务")
    @PostMapping(value = "create")
    public BaseDataRespDTO creatTask(@RequestBody JSONObject jsonObject) {
        try {
            if (!jsonObject.containsKey("taskType")) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "参数【taskType】异常");
            }
            JSONObject result = JSONObject.parseObject(analysisFeignClient.analysisOnlineTaskCreate(analysisOnlineTaskService.paseParam(jsonObject)));
            if (SuccessRespUtil.isSuccess(result)) {
                return new BaseDataRespDTO(result.get(ICommonConstant.ResultDataFormat.data),IResultCode.SUCCESS,"分析成功!");
            } else {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "分析失败", result.getString(ICommonConstant.ResultDataFormat.respMessage));
            }
        } catch (Exception e) {
            LOG.error("数据实时分析失败：" + e.getMessage());
            return new BaseDataRespDTO(null, IResultCode.ERROR, "分析失败", e.getMessage());
        }
    }
    
}
