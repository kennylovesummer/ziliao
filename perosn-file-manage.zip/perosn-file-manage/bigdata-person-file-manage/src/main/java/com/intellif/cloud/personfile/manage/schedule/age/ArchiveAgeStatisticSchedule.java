package com.intellif.cloud.personfile.manage.schedule.age;

import com.intellif.cloud.personfile.manage.enums.PersonfileAgeEnum;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticAgeService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class ArchiveAgeStatisticSchedule {
    
    @Resource
    private StatisticAgeService statisticAgeService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    
    @Scheduled(cron = "0 */35 * * * ?")
    public void statisticAge() {
        for (int j = 0; j <= 9; j++) {
            PersonfileAgeEnum personfileAgeEnum = PersonfileAgeEnum.getAgeByAgeId(j);
            statisticAgeService.updateAgeNumByAgeId(j, subArchiveService.statisticAge(personfileAgeEnum.getStartAge(), personfileAgeEnum.getEndAge(), personfileAgeEnum.getEndAge() == 0 ? true : false));
        }
    }
}
