package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description: 通用表
 * @author： liuzj
 * @date：   2019-05-22
 * @version： V1.0
 */
@Data
public class BigdataCommon implements Serializable {

    private static final long serialVersionUID = 1L;

	/**主键*/
	private Integer id;

	/**具体内容*/
	private String content;

	/**标识*/
	private String contentType;

	/**备注*/
	private String remark;

	/**创建时间*/
	private Date createTime;

	/**更新时间*/
	private Date modifyTime;

	/**是否删除(0-未删除，1-已删除)*/
	private Integer isDeleted;

	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}
}
