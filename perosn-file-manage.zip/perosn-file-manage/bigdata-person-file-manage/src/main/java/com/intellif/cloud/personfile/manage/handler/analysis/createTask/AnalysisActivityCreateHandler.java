package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.ActivityTaskCreateDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

/**
 * 活动规律分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisActivityCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    AnalysisActivityCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        ActivityTaskCreateDTO activityTaskCreateDTO = JSONObject.parseObject(params.toJSONString(), ActivityTaskCreateDTO.class);
        // 参数校验
        if (CollectionUtils.isEmpty(activityTaskCreateDTO.getAids())
                || Strings.isBlank(activityTaskCreateDTO.getStartTime())
                || Strings.isBlank(activityTaskCreateDTO.getEndTime())) {
            throw new BusinessException(IResultCode.ERROR,"参数异常");
        }
    
        // 人员是否存在校验
        PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(activityTaskCreateDTO.getAids().get(0));
        if (personfileBasics == null) {
            throw new BusinessException(IResultCode.ERROR,"分析档案不存在");
        }
    
        if (activityTaskCreateDTO.getRules() == null) {
            Props rules = new Props();
            String rulesConfig = personPropertiest.getDataAnalysisActivityRules();
            if (Strings.isBlank(rulesConfig)) {
                rules.setFilterTimes(1);
                rules.setInterval(60);
            } else {
                String[] ruleArray = rulesConfig.split(ICommonConstant.Symbol.AND);
                if (ruleArray.length != 2) {
                    rules.setFilterTimes(1);
                    rules.setInterval(60);
                } else {
                    rules.setInterval(Integer.valueOf(ruleArray[0].trim()));
                    rules.setFilterTimes(Integer.valueOf(ruleArray[1].trim()));
                }
            }
            activityTaskCreateDTO.setRules(rules);
        }
    
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setTaskType(DataStisticTypeEnum.ACTIVITY.getName());
        offLineTaskDTO.setParams(activityTaskCreateDTO.toString());
        offLineTaskDTO.setTaskName(activityTaskCreateDTO.getTaskName());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
    
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setType(DataStisticTypeEnum.ACTIVITY.getName());
        bigdataAnalysisTask.setName(activityTaskCreateDTO.getTaskName());
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        
        return execId;
    }
}
