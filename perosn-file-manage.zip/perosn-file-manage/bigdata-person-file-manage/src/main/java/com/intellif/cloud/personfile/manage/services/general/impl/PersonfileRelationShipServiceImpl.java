package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.entity.PersonfileRelationShip;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRelationShipService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileRelationShipServiceImpl
 * @date 2019/4/15 11:00
 * @description
 */
@Service
public class PersonfileRelationShipServiceImpl extends BaseServiceImpl implements PersonfileRelationShipService {
    @Override
    public PersonfileRelationShip findPersonfileRelationShipById(Integer id) {
        PersonfileRelationShip personfileRelationShip = new PersonfileRelationShip();
        personfileRelationShip.setId(id);
        return (PersonfileRelationShip) this.baseDao.findById(personfileRelationShip);
    }

    @Override
    public int insertPersonfileRelationShip(PersonfileRelationShip personfileRelationShip) {
        return this.baseDao.insert(personfileRelationShip);
    }

    @Override
    public List<PersonfileRelationShip> findAllPersonfileRelationShip(String relationShipName) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("relationShipName", relationShipName);
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("findAllPersonfileRelationShip");
        queryEvent.setParameter(map);
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    @Override
    public PersonfileRelationShip findPersonfileRelationShipByName(Integer id, String relationShipName, String label) {
        QueryEvent<PersonfileRelationShip> event = new QueryEvent<>();
        PersonfileRelationShip personfileRelationShip = new PersonfileRelationShip();
        personfileRelationShip.setId(id);
        personfileRelationShip.setRelationShipName(relationShipName);
        personfileRelationShip.setLabel(label);
        event.setObj(personfileRelationShip);
        event.setStatement("findPersonfileRelationShipByName");
        return (PersonfileRelationShip) this.baseDao.findOneByCustom(event);
    }

    @Override
    public int updatePersonfileRelationShip(PersonfileRelationShip personfileRelationShip) {
        return this.baseDao.update(personfileRelationShip);
    }

    @Override
    public int deletePersonfileRelationShip(Integer id) {
        PersonfileRelationShip personfileRelationShip = new PersonfileRelationShip();
        personfileRelationShip.setId(id);
        personfileRelationShip.setIsDeleted(1);
        return this.baseDao.update(personfileRelationShip);
    }
}
