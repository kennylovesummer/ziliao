package com.intellif.cloud.personfile.manage.controllers;

import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.model.dto.label.LabelDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileMapService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program ifaas-person-file-manage
 * @Author liuYu
 * @create 2018-10-29 10:54
 * @Version 1.0
 * @desc 标签地图
 */
@Api(tags = "标签地图")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.MAP)
public class PersonfileMapController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final PersonfileMapService personfileMapService;

    @Autowired
    public PersonfileMapController(PersonfileMapService personfileMapService) {
        this.personfileMapService = personfileMapService;
    }
    
    @ApiOperation(httpMethod = "POST",value = "获取标签地图数据")
    @PostMapping("/distribute/{version}")
    public BaseDataRespDTO get(@RequestBody LabelDTO labelDTO) {
        List<SnapMapVO> personfileMapVOS = null;
        try {
            personfileMapVOS = personfileMapService.get(labelDTO.getLableIds());
            if (CollectionUtils.isNotEmpty(personfileMapVOS)) {
                List<SnapMapVO> result = Lists.newArrayList();
                Map<String,List<SnapMapVO>> groupByDevId = personfileMapVOS.stream().collect(Collectors.groupingBy(SnapMapVO::getDevId));
                groupByDevId.forEach((key,value)->{
                    SnapMapVO snapMapVO = new SnapMapVO();
                    SnapMapVO item = value.get(0);
                    BeanUtils.copyProperties(item,snapMapVO);
                    snapMapVO.setPersonFileCount(value.stream().mapToInt(SnapMapVO::getPersonFileCount).sum());
                    result.add(snapMapVO);
                });
                personfileMapVOS = result;
            }
            
            return IPersonFilesResultInfo.ok(personfileMapVOS, "标签地图查询成功!");
        } catch (Exception e) {
            logger.error("标签地图查询异常:" + e.getMessage());
            return IPersonFilesResultInfo.unknownError( "标签地图查询失败!","异常：" + e.getMessage());
        }
    }
}
