package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.analysis.online.OnlineTaskDTO;
import com.intellif.cloud.personfile.manage.services.analysis.AnalysisOnlineTaskService;
import com.intellif.log.LoggerUtilI;
import org.springframework.stereotype.Service;

/**
 * @see AnalysisOnlineTaskService
 */
@Service
public class AnalysisOnlineTaskServiceImpl implements AnalysisOnlineTaskService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Override
    public OnlineTaskDTO paseParam(JSONObject params) {
        OnlineTaskDTO onlineTaskDTO = new OnlineTaskDTO();
        onlineTaskDTO.setBizCode("bigdata");
        onlineTaskDTO.setTaskType(params.getString("taskType"));
        onlineTaskDTO.setParams(params.toJSONString());
        System.out.println(JSONObject.toJSONString(onlineTaskDTO));
        return onlineTaskDTO;
    }
}
