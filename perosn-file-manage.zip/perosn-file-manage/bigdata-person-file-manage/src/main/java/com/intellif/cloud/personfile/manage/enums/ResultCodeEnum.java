/*
 * 文件名：ResultCodeEnum.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月18日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.enums;

/**
 * 返回结果状态码
 *
 * @author liuzj
 * @version 1.0
 * @date 2018年12月13日
 * @see ResultCodeEnum
 * @since JDK1.8
 */
public enum ResultCodeEnum {

    SUCCESS(10000000, "success", "成功"),

    UNKOWN_ERROR(33000001, "unkownError", "未知异常"),

    PARAM_ERROR(33000002, "parameterError", "参数错误"),

    PARAM_INVALID(33000003, "parameterInvalid", "请求参数非法"),

    JSON_ERROR(33000004, "jsonError", "JSON转换失败"),

    DB_ERROR(33000005, "dbError", "数据库异常"),

    NETWORK_ERROR(33000006, "networkError", "网络异常"),

    HANDLE_DATA_EXCEPTION(33000007, "handleDataException", "数据处理异常");

    private int resultCode;

    /***
     * 状态码定义
     */
    private String name;

    /***
     * 状态码详细描述
     */
    private String message;

    private ResultCodeEnum(int resultCode, String name, String message) {
        this.resultCode = resultCode;
        this.name = name;
        this.message = message;
    }

    public int getResultCode() {
        return resultCode;
    }

    public String getMessage() {
        return message;
    }

    public String getName() {
        return name;
    }

    public static ResultCodeEnum get(int resultCode) {
        if (resultCode > 0) {
            return null;
        }
        for (ResultCodeEnum c : ResultCodeEnum.values()) {
            if (c.getResultCode() == resultCode) {
                return c;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return message;
    }

}
