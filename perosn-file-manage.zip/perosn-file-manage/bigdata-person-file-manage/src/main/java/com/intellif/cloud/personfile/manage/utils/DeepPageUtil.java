package com.intellif.cloud.personfile.manage.utils;


/**
 * 文件名：DeepPageUtil.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 分页的工具类
 * @author ：tianhao
 * 创建时间：2018年10月20日
 * 修改理由：
 * 修改内容：
 */
public class DeepPageUtil {
    /**
     * 获取分页的开始
     * 例如前台传第1页,但数据库的分页第0条开始
     * @param reqPageNum
     * @return
     */
    public static int getPageNum(int reqPageNum){
        if(reqPageNum>0) {
            return reqPageNum-1;
        }
        return reqPageNum;
    }

    /**
     * 返回最大页数
     *
     * @param pageSize 每页显示的记录数
     * @param total    总记录数
     * @return
     */
    public static int getMaxPage(int pageSize, int total) {
        if(0==total) {
            return 0;
        }
        return total % pageSize == 0 ? total / pageSize : (total / pageSize) + 1;
    }
}
