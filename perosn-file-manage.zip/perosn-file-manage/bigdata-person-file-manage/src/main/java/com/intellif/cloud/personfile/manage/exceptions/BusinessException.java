/*  
 * 文件名：BusinessException.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月24日    
 * 修改理由：  
 * 修改内容：  
 */  

package com.intellif.cloud.personfile.manage.exceptions;
  
public class BusinessException extends Exception{

	/**  
	 *   
	 */
	private static final long serialVersionUID = -6912520793426501776L;
	
	
	 /**
     * 异常返回码
     */
    private int code;
    
    /**
     * 异常描述
     */
    private String exceptionMsg;
    
    public BusinessException(int resultCode)
    {
        this.code = resultCode;
    }
    
    public BusinessException(int code, String exceptionMsg)
    {
        this.code = code;
        this.exceptionMsg = exceptionMsg;
    }
    
    public void setCode(int code)
    {
        this.code = code;
    }
    
    public void setExceptionMsg(String exceptionMsg)
    {
        this.exceptionMsg = exceptionMsg;
    }
    
    /**
     * 返回异常码
     * @return code 异常返回码
     */
    public int getCode()
    {
        return code;
    }
    
    /**
     * 返回异常消息
     * @return exceptionMsg 异常消息
     */
    public String getExceptionMsg()
    {
        return exceptionMsg;
    }

}
