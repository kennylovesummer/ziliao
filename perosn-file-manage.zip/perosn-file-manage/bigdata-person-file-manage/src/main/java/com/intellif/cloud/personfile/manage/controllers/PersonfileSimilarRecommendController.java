package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.SimilarArchiveDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.model.vo.xdata.SimilarArchiveVO;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSimilarRecommendService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.cloud.personfile.manage.utils.ListPageUtil;
import com.intellif.cloud.personfile.manage.utils.ListUtils;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * @author liuyu
 * @className PersonfileSimilarRecommendController
 * @date 2019/2/25 14:05
 * @description
 */
@Api(tags = "相似档案推荐")
@RestController
@RequestMapping(IPersonfilesManageConstant.BaseUrl.RESOURCE_BASE)
public class PersonfileSimilarRecommendController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final PersonfileSimilarRecommendService personfileSimilarRecommendService;
    
    private final SubArchiveService subArchiveService;
    
    private final AnalysisFeignClient analysisFeignClient;
    
    private final PersonPropertiest personPropertiest;
    
    private final BigdataCommonService bigdataCommonService;
    
    @Autowired
    public PersonfileSimilarRecommendController(PersonfileSimilarRecommendService personfileSimilarRecommendService,
                                                SubArchiveService subArchiveService,
                                                AnalysisFeignClient analysisFeignClient,
                                                PersonPropertiest personPropertiest,
                                                BigdataCommonService bigdataCommonService) {
        this.personfileSimilarRecommendService = personfileSimilarRecommendService;
        this.subArchiveService = subArchiveService;
        this.analysisFeignClient = analysisFeignClient;
        this.personPropertiest = personPropertiest;
        this.bigdataCommonService = bigdataCommonService;
    }
    
    @Deprecated
    @ApiOperation(httpMethod = "GET",value = "相似档案推荐（< 1.3.0）")
    @GetMapping("/similarPersonFile/recommend/{personFileId}/{version}")
    public BasePageRespDTO put(@PathVariable(name = "personFileId") @NotNull String personFileId,
                               @RequestParam("page") Integer pageNo,
                               @RequestParam("perpage") Integer pageSize,
                               @PathVariable(name = "version") String version) {
        try {
            List<Map<String, Object>> list =
                    personfileSimilarRecommendService.getPersonfileSimilarRecommend(personFileId);
            if (CollectionUtils.isEmpty(list)) {
                return IPersonFilesResultInfo.success(null, 0, 0, "推荐相似档案成功！");
            }
            list = list.stream().filter(element -> !personFileId.equals(element.get("personfileId"))).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(list)) {
                return IPersonFilesResultInfo.success(list, 0, 0, "推荐相似档案成功！");
            }
            List<String> personfilesIdList = list.stream().map(element -> String.valueOf(element.get("personfileId"))).collect(Collectors.toList());
            List<String> deletedPersonfilesId = subArchiveService.findDeletedPersonfilesId(personfilesIdList);
            if (CollectionUtils.isNotEmpty(deletedPersonfilesId)) {
                list = list.stream().filter(element -> !deletedPersonfilesId.contains(element.get("personfileId"))).collect(Collectors.toList());
            }
            ListPageUtil listPageUtil = new ListPageUtil(list, pageNo, pageSize);
            List pagedList = listPageUtil.getPagedList();
            return IPersonFilesResultInfo.success(pagedList, list.size() <= pageSize ? 1 : list.size() / pageSize, list.size(), "推荐相似档案成功！");
        } catch (Exception e) {
            logger.error("相似推荐档案异常:", e);
            return new BasePageRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "推荐相似档案失败", "异常：" + e.getMessage());
        }
    }
    
    
    /**
     * 推荐相似档（数据平台接口）
     *
     * @param personFileId 档案ID
     * @param pageNo 页码
     * @param pageSize 页码大小
     * @param version 版本
     * @return BasePageRespDTO
     */
    @ApiOperation(httpMethod = "GET",value = "相似档案推荐（1.3.0）")
    @GetMapping("/similarArchive/{personFileId}/{version}")
    public BasePageRespDTO similarArchive(@PathVariable(name = "personFileId") @NotNull String personFileId,
                                          @RequestParam("page") Integer pageNo,
                                          @RequestParam("perpage") Integer pageSize,
                                          @PathVariable(name = "version") String version){
        try {
            float simiRateTemp = personPropertiest.getSimilarRate();
//          获取当前相似度
            List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(IPersonfilesManageConstant.IRedisCacheKey.PERSONFILES_SIMILAR_RATE);
            if (CollectionUtils.isNotEmpty(bigdataCommons)) {
                simiRateTemp = Float.valueOf(bigdataCommons.get(0).getContent());
            }
            
            SimilarArchiveDTO similarArchiveDTO = new SimilarArchiveDTO();
//            Map<String,Object> params = Maps.newHashMap();
            SimilarArchiveDTO.Params params = similarArchiveDTO.new Params();
            params.setFromId(personFileId);
//            params.put("threshold",(double)simiRateTemp);
//            params.put("num",personPropertiest.getSimilarPersonFileMaxNum());
            params.setThreshold((double)simiRateTemp);
            params.setNum(personPropertiest.getSimilarPersonFileMaxNum());
            similarArchiveDTO.setBizCode(personPropertiest.getBizCode());
            similarArchiveDTO.setParams(params);
            
            JSONObject result = JSONObject.parseObject(analysisFeignClient.getSimilarArchives(similarArchiveDTO));
            List<Map<String, Object>> data = Lists.newLinkedList();
            if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
                List<SimilarArchiveVO> similarArchiveVOList = JSONObject.parseArray(result.getString(ICommonConstant.ResultDataFormat.data), SimilarArchiveVO.class);
                if (CollectionUtils.isNotEmpty(similarArchiveVOList)) {
                    similarArchiveVOList.forEach(similar -> {
                        ListFilterDTO filterDTO = new ListFilterDTO();
                        filterDTO.setPersonFileIds(Collections.singletonList(similar.getArchiveId()));
                        BasePageRespDTO basePageRespDTO = subArchiveService.findByFilterParams(filterDTO);
                        List<PersonfileVO> page = (List<PersonfileVO>) basePageRespDTO.getData();
                        if (!page.isEmpty()) {
                            Map<String, Object> item = new HashMap<>(5);
                
                            PersonfileVO personfileVO = page.get(0);
                            item.put("personName", personfileVO.getPersonName());
                            item.put("imageUrl", personfileVO.getImageUrl());
                            item.put("imageCount", personfileVO.getImageCount());
                            item.put("personfileId", similar.getArchiveId());
                            item.put("score", similar.getSimilarity());
    
                            data.add(item);
                        }
                    });
                }
                
                if (CollectionUtils.isNotEmpty(data)) {
                    List<Map<String, Object>> result2 = ListUtils.sort(data);
                    Collections.reverse(result2);
                    ListPageUtil listPageUtil = new ListPageUtil(result2, pageNo, pageSize);
                    List pagedList = listPageUtil.getPagedList();
                    return new BasePageRespDTO(pagedList, data.size() <= pageSize ? 1 : data.size() / pageSize, data.size(), IResultCode.SUCCESS,"推荐相似档案成功！");
                }
    
                return new BasePageRespDTO(data, 0,0, IResultCode.SUCCESS,"推荐相似档案成功！");
            } else{
                return new BasePageRespDTO(data, 0, 0, IPersonFilesResultCode.IManageResultCode.ERROR,"获取数据异常",result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : "");
            }
            
        } catch (Exception e) {
            logger.error("相似推荐档案异常:", e);
            return new BasePageRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "推荐相似档案失败", "异常：" + e.getMessage());
        }
    }
    
}
