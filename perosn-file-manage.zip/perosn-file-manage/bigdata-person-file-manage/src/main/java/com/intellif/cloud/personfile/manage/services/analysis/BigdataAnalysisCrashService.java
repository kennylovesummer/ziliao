package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrash;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashDTO;

import java.util.List;

/**
 * 数据分析事件
 *
 * @author liuzj
 * @date 2019-07-18
 */
public interface BigdataAnalysisCrashService {
    
    /**
     * 根据ID查找
     *
     * @param id ID
     * @return entity
     */
    BigdataAnalysisCrash findAnalysisCrashById(Long id);
    
    /**
     * 根据ID删除对象
     *
     * @param bigdataAnalysisCrash 要删除的对象
     */
    void deleteAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisCrash 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash);
    
    /**
     * 批量插入
     *
     * @param crashList 待插入的数据
     */
    void batchInsertAnalysisCrash(List<BigdataAnalysisCrash> crashList);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisCrash 待更新的对象
     */
    void updateAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash);
    
    /**
     * 分页查找
     *
     * @param crashDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisCrash> findAnalysisCrashByParams(CrashDTO crashDTO);
    
    /**
     * 根据任务ID删除
     *
     * @param taskId 任务ID
     */
    void deleteBigdataAnalysisCrashByTaskId(Long taskId);
    
}
