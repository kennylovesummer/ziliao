package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liuyu
 * @className StatisticPersonfileImage
 * @date 2019/3/14 13:53
 * @description
 */
public class StatisticPersonfileImage implements Serializable {

    private static final long serialVersionUID = 3450470248519732194L;

    private Integer id;

    private Integer fileCount;

    private Integer imageCount;

    private Date createTime;

    private Date modifiedTime;

    private Date statisticDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFileCount() {
        return fileCount;
    }

    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }

    public Integer getImageCount() {
        return imageCount;
    }

    public void setImageCount(Integer imageCount) {
        this.imageCount = imageCount;
    }

    public Date getStatisticDate() {
        return statisticDate;
    }

    public void setStatisticDate(Date statisticDate) {
        this.statisticDate = statisticDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public StatisticPersonfileImage() {
    }

    public StatisticPersonfileImage(Integer fileCount, Integer imageCount, Date statisticDate) {
        this.fileCount = fileCount;
        this.imageCount = imageCount;
        this.statisticDate = statisticDate;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
