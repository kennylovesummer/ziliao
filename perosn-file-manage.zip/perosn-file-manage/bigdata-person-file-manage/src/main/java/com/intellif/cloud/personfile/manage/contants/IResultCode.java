/*
 * 文件名：ResultCode.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月8日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.contants;

/**
 *
 * 返回编码接口 请各自定义好自己的业务模块的返回编码含义等 编码开头 25-30
 *
 * @author Administrator
 * @version 1.0
 * @see IResultCode
 * @since JDK1.8
 * @date 2018年8月8日
 */
public interface IResultCode {

	int SUCCESS = 10000000;

	int ERROR = 10000001;

}
