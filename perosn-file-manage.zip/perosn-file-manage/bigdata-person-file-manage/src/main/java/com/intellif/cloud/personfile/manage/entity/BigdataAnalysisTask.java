package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 碰撞分析人物表
 *
 * @author liuzj
 * @date 2019-06-26
 */
@Data
public class BigdataAnalysisTask implements Serializable {
    private static final long serialVersionUID = -441920423048496424L;
    
    private Long id;
    
    private String name;
    
    private Long costTime;
    
    private Integer status;
    
    private String result;
    
    private String execId;
    
    private String aid;
    
    private String type;
    
    private String remark;
    
    private String params;
    
    private Date createTime;
    
    private String createBy;
    
    private Date modifyTime;
    
    private String modifyBy;
    
    private Integer isDeleted;
}
