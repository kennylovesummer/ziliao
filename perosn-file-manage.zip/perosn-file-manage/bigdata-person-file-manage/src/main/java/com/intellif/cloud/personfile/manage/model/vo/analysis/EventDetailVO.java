package com.intellif.cloud.personfile.manage.model.vo.analysis;

import com.alibaba.fastjson.annotation.JSONField;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import com.intellif.commons.util.DateUtil;
import lombok.Data;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;

import java.util.Date;

@Data
public class EventDetailVO {
    
    @JSONField(name = "thumbnailId")
    private String faceId;
    
    @JSONField(name = "thumbnailUrl")
    private String faceUrl;
    
    private String imageId;
    
    private String imageUrl;
    
    private String targetRect;
    
    private String aid;
    
    private String sysCode;
    
    private String time;
    
    @JSONField(name = "sourceId")
    private String cameraId;
    
    private String site;
    
    private Date date;
    
    public Date getDate() {
        Date result = null;
        try {
            if (this.time != null) {
                result = DateUtils.parseDate(DateFormatUtils.format(DateUtils.parseDate(this.time, ICommonConstant.DateFormatType.DATE_TIME_FORMAT_ARRAY),"yyyy-MM-dd"),ICommonConstant.DateFormatType.DATE_FORMAT_ARRAY);
            }
        } catch (Exception e) {
            return null;
        }
        return result;
    }
}
