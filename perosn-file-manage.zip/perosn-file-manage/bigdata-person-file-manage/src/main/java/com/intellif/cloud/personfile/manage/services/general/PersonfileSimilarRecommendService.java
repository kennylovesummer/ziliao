package com.intellif.cloud.personfile.manage.services.general;

import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileSimilarRecommendService
 * @date 2019/2/25 14:13
 * @description
 */
public interface PersonfileSimilarRecommendService {

    List<Map<String, Object>> getPersonfileSimilarRecommend(String personFileId) throws Exception;
}
