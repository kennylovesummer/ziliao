package com.intellif.cloud.personfile.manage.services.analysis;

import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrashArea;

import java.util.List;

/**
 * 碰撞地区
 *
 * @author liuzj
 * @date 2019-06-26
 */
public interface BigdataAnalysisCrashAreaService {
    
    /**
     * 根据ID获取碰撞地区
     *
     * @return BigdataAnalysisCrashArea
     */
    BigdataAnalysisCrashArea findAnalysisCrashAreaById(Long id);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisCrashArea 参数集
     * @return Integer
     */
    Integer insertAnalysisCrashArea(BigdataAnalysisCrashArea bigdataAnalysisCrashArea);
    
    /**
     * 批量新增
     *
     * @param analysisCrashAreas 参数集
     */
    void batchInsert(List<BigdataAnalysisCrashArea> analysisCrashAreas);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisCrashArea 参数集
     */
    void updateAnalysisCrashArea(BigdataAnalysisCrashArea bigdataAnalysisCrashArea);
    
    /**
     * 根据任务ID获取地区
     *
     * @param taskId 任务ID
     * @return List
     */
    List<BigdataAnalysisCrashArea> findAnalysisCrashAreaByTaskId(Long taskId);
    
    /**
     * 根据任务ID集合获取地区
     *
     * @param taskIds 任务ID集合
     * @return List
     */
    List<BigdataAnalysisCrashArea> findAnalysisCrashAreaByTaskIds(List<Long> taskIds);
    
    /**
     * 根据任务ID删除地区数据
     *
     * @param taskId 任务ID
     */
    void deleteByTaskId(Long taskId);
}
