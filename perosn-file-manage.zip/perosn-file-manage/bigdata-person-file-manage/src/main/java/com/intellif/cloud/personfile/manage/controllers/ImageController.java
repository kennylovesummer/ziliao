package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ProjectTypeEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import com.intellif.cloud.personfile.manage.utils.FileUtils;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.util.Strings;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;


/**
 * 图片的控制层
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月22日
 * @see ImageController
 * @since JDK1.8
 */
@Api(tags = "图片上传接口")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.IMAGE)
public class ImageController implements java.io.Serializable {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final PersonPropertiest personPropertiest;
    
    @Resource
    private DeepEyeService deepEyeService;
    
    @Autowired
    public ImageController(PersonPropertiest personPropertiest) {
        this.personPropertiest = personPropertiest;
    }
    
    /**
     * 图片上传,提取人脸特征值
     *
     * @param file
     */
    @ApiOperation(httpMethod = "POST",value = "文件上传获取特征值")
    @PostMapping(value = "/upload/{version}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public BaseDataRespDTO uploadImage(@RequestPart(value = "file") @Valid @NotNull @NotBlank MultipartFile file) {
        UUID uuid = UUID.randomUUID();
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            FileUtils.saveFileToLocal(file.getBytes(), "/person-file-manage/" + simpleDateFormat.format(new Date()),"/person-file-manage-filter-" + uuid + ".jpg");
            String ip = "";
            if (personPropertiest.getPersonfileFilterIpLocalhost() == 1) {
                InetAddress addr;
                try {
                    addr = InetAddress.getLocalHost();
                    ip = addr.getHostAddress();
                } catch (UnknownHostException e) {
                    logger.error("获取本地ip异常：" + e.getMessage());
                }
            } else {
                ip = personPropertiest.getIp();
            }
            
            StringBuilder url = new StringBuilder();
            url.append("http://").
                    append(ip).
                    append(":").
                    append(personPropertiest.getPersonfileFilterPort()).
                    append("/personfile/manage/image/filter/image/").
                    append(uuid);
            
            return deepEyeService.imageUploadUrl(url.toString(), Strings.isNotBlank(personPropertiest.getEngineType()) && ProjectTypeEnum.IFAAS.getValue().equals(personPropertiest.getEngineType()));
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "图片上传失败", e.getMessage());
        } finally {
//          刪除临时照片
//            FileUtils.deleteFileByPath("/person-file-manage-filter-" + uuid + ".jpg");
        }
    }
    
    /**
     * 内部接口获取本地图片数据
     *
     * @return
     */
    @ApiOperation(httpMethod = "GET",value = "获取上传文件（对内）")
    @GetMapping(value = "/filter/image/*")
    public byte[] filterImage(HttpServletRequest request) {
        String url = request.getRequestURL().toString();
        String[] urls = url.split("/");
        String uuid = urls[urls.length - 1];
        FileInputStream fileInputStream = null;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            
            fileInputStream = new FileInputStream("/person-file-manage/" + simpleDateFormat.format(new Date()) + "/person-file-manage-filter-" + uuid + ".jpg");
            byte[] imageBytes = new byte[fileInputStream.available()];
            fileInputStream.read(imageBytes);
            return imageBytes;
        } catch (IOException e) {
            logger.error("读取文件异常：" + e.getMessage());
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    logger.error("流关闭异常：" + e.getMessage());
                }
            }
        }
        return null;
    }
    
    /**
     * 对外接口获取本地图片数据
     *
     * @return
     */
    @ApiOperation(httpMethod = "GET",value = "获取上传文件（对外）")
    @GetMapping(value = "/api/image/*")
    public byte[] apiImage(HttpServletRequest request) {
        String url = request.getRequestURL().toString();
        String[] urls = url.split("/");
        String uuid = urls[urls.length - 1];
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream("/person-file-manage-api-" + uuid + ".jpg");
            byte[] imageBytes = new byte[fileInputStream.available()];
            fileInputStream.read(imageBytes);
            return imageBytes;
        } catch (IOException e) {
            logger.error("读取文件异常：" + e.getMessage());
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    logger.error("流关闭异常：" + e.getMessage());
                }
            }
        }
        return null;
    }
    
}
