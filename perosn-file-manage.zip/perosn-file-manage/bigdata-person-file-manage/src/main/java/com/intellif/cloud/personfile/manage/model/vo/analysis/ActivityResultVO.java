package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.List;

@Data
public class ActivityResultVO {
    
    private String aid;
    
    private List<LocationInfo> locations;
    
    private List<String> periods;
    
    private Long activeCount;
}
