package com.intellif.cloud.personfile.manage.services.datastistic.impl;

import com.intellif.cloud.personfile.manage.contants.IPersonFilesConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 人员类型接口实现类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月29日
 * @see StatisticPersonfileTypeService
 * @since JDK1.8
 */
@Service
public class StatisticPersonfileTypeServiceImpl extends BaseServiceImpl implements StatisticPersonfileTypeService {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private static final String PERSON_FILE_MUST_BE_NOT_NULL = "参数personFileTypeId必传";

    private static final String PERSON_FILE_TYPE_ID = "personFileTypeId";

    /**
     * 根据人员类型id累加人员档案数量
     *
     * @param personFileTypeId 人员类型id
     * @param personFileNum    档案数量
     * @return
     */
    @Override
    public BaseDataRespDTO updateNumByPersonTypeId(String personFileTypeId, int personFileNum) {
        if (StringUtils.isBlank(personFileTypeId)) {
            return new BaseDataRespDTO(IResultCode.ERROR, "修改错误", PERSON_FILE_MUST_BE_NOT_NULL);
        }
        Map map = new HashMap(2);
        map.put(PERSON_FILE_TYPE_ID, personFileTypeId);
        map.put("personFileNum", personFileNum);
        try {
            int result = this.baseDao.updateStatement("updateNumByPersonTypeId", map);
            return new BaseDataRespDTO(IResultCode.SUCCESS, "修改成功", "修改成功,成功条数:" + result);
        } catch (Exception e) {
            logger.error("根据人员类型id累加人员档案数量异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "修改异常", ResultMessageEnum.EXCEPTION_INFO + e.getMessage());
        }
    }

    /**
     * 新增人员类型统计
     *
     * @param statisticPersonfileType
     * @return
     */
    @Override
    public BaseDataRespDTO insertPersonfileType(StatisticPersonfileType statisticPersonfileType) {
        if (null == statisticPersonfileType.getPersonFileTypeId()) {
            return new BaseDataRespDTO(IResultCode.ERROR, "修改错误", PERSON_FILE_MUST_BE_NOT_NULL);
        }
        if (countPersonfileTypeByTypeId(statisticPersonfileType.getPersonFileTypeId()) > 0) {
            return new BaseDataRespDTO(IResultCode.ERROR, "新增失败", "人员类型已存在");
        }
        try {
            statisticPersonfileType.setModifiedTime(new Date());
            int result = this.baseDao.insert(statisticPersonfileType);
            return new BaseDataRespDTO(IResultCode.SUCCESS, "新增成功", "新增成功,成功条数:" + result);
        } catch (Exception e) {
            logger.error("新增人员类型统计异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "新增异常", ResultMessageEnum.EXCEPTION_INFO + e.getMessage());
        }
    }

    /**
     * 根据人员类型id修改人员类型名称
     *
     * @param personFileTypeId   人员类型id
     * @param personFileTypeName 人员类型名称
     * @return
     */
    @Override
    public BaseDataRespDTO updatePersonfileTypeNameByTypeId(Integer personFileTypeId, String personFileTypeName) {
        if (personFileTypeId == null) {
            return new BaseDataRespDTO(IResultCode.ERROR, "修改错误", PERSON_FILE_MUST_BE_NOT_NULL);
        }
        Map map = new HashMap(2);
        map.put(PERSON_FILE_TYPE_ID, personFileTypeId);
        map.put("personFileTypeName", personFileTypeName);
        try {
            int result = this.baseDao.updateStatement("updatePersonfileTypeNameByTypeId", map);
            return new BaseDataRespDTO(IResultCode.SUCCESS, "修改成功", "修改成功,成功条数:" + result);
        } catch (Exception e) {
            logger.error("根据人员类型id修改人员类型名称异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "修改异常", ResultMessageEnum.EXCEPTION_INFO + e.getMessage());
        }
    }

    /**
     * 根据人员类型id统计人员类型数量(判断此类型是否存在)
     *
     * @param personfileTypeId
     * @return
     */
    private int countPersonfileTypeByTypeId(Integer personfileTypeId) {
        // 根据类型id查询是否存在
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("countPersonfileTypeByTypeId");
        Map map = new HashMap(1);
        map.put(PERSON_FILE_TYPE_ID, personfileTypeId);
        queryEvent.setParameter(map);
        try {
            return (int) this.baseDao.count(queryEvent);
        } catch (Exception e) {
            logger.error("根据人员类型id统计人员类型数量异常:" + e.getMessage());
            return 0;
        }
    }

    /**
     * 根据人员类型id删除类型统计
     *
     * @param personFileTypeId
     * @return
     */
    @Override
    public BaseDataRespDTO deletePersonfileTypeByTypeId(Integer personFileTypeId) {
        // 删除类型统计
        StatisticPersonfileType statisticPersonfileType = new StatisticPersonfileType();
        statisticPersonfileType.setPersonFileTypeId(personFileTypeId);
        // 状态:已删除
        statisticPersonfileType.setDeleteStatus(IPersonFilesConstant.BaseByte.IS_DELETE);
        try {
            this.baseDao.updateStatement("deletePersonfileTypeByTypeId", statisticPersonfileType);
            return new BaseDataRespDTO(IResultCode.SUCCESS, "删除成功", "删除成功");
        } catch (Exception e) {
            logger.error("根据人员类型删除统计人员类型异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, "删除异常", "删除异常,异常信息:" + e.getMessage());
        }
    }
}
