package com.intellif.cloud.personfile.manage.task;

import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.DownloadParam;
import com.intellif.cloud.personfile.manage.model.vo.analysis.DownloadVO;
import com.intellif.cloud.personfile.manage.services.analysis.AnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;

import java.util.Date;
import java.util.concurrent.Callable;

/**
 * 下载任务
 *
 * @author liuzj
 * @date 2019-07-14
 */
public class DownloadTask implements Callable<Boolean> {
    
    private DownloadParam param ;
    
    private BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;
    
    private AnalysisExportTaskService analysisExportTaskService;
    
    private BigdataAnalysisExportTask bigdataAnalysisExportTask;
    
    public DownloadTask(DownloadParam param,
                        BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService,
                        AnalysisExportTaskService analysisExportTaskService,
                        BigdataAnalysisExportTask bigdataAnalysisExportTask){
        this.param = param ;
        this.bigdataAnalysisExportTaskService = bigdataAnalysisExportTaskService;
        this.analysisExportTaskService = analysisExportTaskService;
        this.bigdataAnalysisExportTask = bigdataAnalysisExportTask;
    }
    
    @Override
    public Boolean call() {
        DownloadVO downloadVO = null;
        try {
            bigdataAnalysisExportTask.setStartTime(new Date());
            bigdataAnalysisExportTask.setStatus(1);
            bigdataAnalysisExportTaskService.updateAnalysisExportTask(bigdataAnalysisExportTask);
            Thread.currentThread().setName("数据分析下载线程-" + bigdataAnalysisExportTask.getId());
        
            downloadVO = analysisExportTaskService.export(param);
            return true;
        } catch (Exception e){
            bigdataAnalysisExportTask.setDownloadMsg("任务异常：" + e.getMessage());
            return true;
        } finally {
            if (downloadVO != null) {
                BeanUtils.copyProperties(downloadVO,bigdataAnalysisExportTask);
            } else {
                bigdataAnalysisExportTask.setStatus(-1);
                bigdataAnalysisExportTask.setEndTime(new Date());
                bigdataAnalysisExportTask.setDownloadMsg(Strings.isNotBlank(bigdataAnalysisExportTask.getDownloadMsg()) ? bigdataAnalysisExportTask.getDownloadMsg() : "未知异常");
            }
            bigdataAnalysisExportTask.setUseTime(bigdataAnalysisExportTask.getEndTime().getTime() - bigdataAnalysisExportTask.getStartTime().getTime());
            bigdataAnalysisExportTaskService.updateAnalysisExportTask(bigdataAnalysisExportTask);
        }
    }
}
