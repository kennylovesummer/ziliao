package com.intellif.cloud.personfile.manage.model.vo.thrift;

/**
 * @Description :
 * @Author dyl
 * @Date 15:51 2018/12/28
 */
public class Pose {

    private Integer Pitch;

    private Integer Roll;

    private Integer Yaw;


    public Pose(Integer pitch, Integer roll, Integer yaw) {
        Pitch = pitch;
        Roll = roll;
        Yaw = yaw;
    }

    public Pose() {
    }

    public Integer getPitch() {
        return Pitch;
    }

    public void setPitch(Integer pitch) {
        Pitch = pitch;
    }

    public Integer getRoll() {
        return Roll;
    }

    public void setRoll(Integer roll) {
        Roll = roll;
    }

    public Integer getYaw() {
        return Yaw;
    }

    public void setYaw(Integer yaw) {
        Yaw = yaw;
    }
}
