package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesStatisticsConstant;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfile;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileEvent;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.enums.StatisticFilterTimeTypeEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.statistic.PersonfileStatisticVO;
import com.intellif.cloud.personfile.manage.model.vo.statistic.StatsticPersonfileTypeAndAgeVO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileFlowService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileService;
import com.intellif.cloud.personfile.manage.utils.DateUtils;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @program ifaas-person-file-manage
 * @Author liuYu
 * @create 2018-10-26 14:33
 * @Version 1.0
 * @desc 档案人员类型和年龄统计
 */
@Api(tags = "数据统计")
@RestController
@RequestMapping(IPersonfilesStatisticsConstant.BaseUrl.RESOURCE_BASE)
public class PersonfileStatisticController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private StatisticPersonfileService statisticPersonfileService;
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    @Autowired
    private StatisticPersonfileFlowService statisticPersonfileFlowService;
    
    private static final String[] dateFormat = {"yyyy-MM-dd"};
    
    
    /**
     * 人员类型和年龄统计
     *
     * @return
     */
    @ApiOperation(httpMethod = "GET",value = "人员类型和年龄统计")
    @GetMapping("/typeage/{version}")
    public BaseDataRespDTO get() {
        try {
            StatsticPersonfileTypeAndAgeVO statsticPersonfileTypeAndAgeVO = statisticPersonfileService.getStatisticPersonfile();
            return IPersonFilesResultInfo.ok(statsticPersonfileTypeAndAgeVO, "人员类型和年龄分布查询成功！");
        } catch (Exception e) {
            logger.error("人员类型和年龄分布查询异常：" + e.getMessage());
            return IPersonFilesResultInfo.ok("人员类型和年龄分布查询异常", e.getCause().toString());
        }
        
    }
    
    /**
     * 人员流动，人员新增，日抓拍数统计
     *
     * @return
     */
    @ApiOperation(httpMethod = "GET",value = "人员流动，人员新增，日抓拍数统计")
    @GetMapping("/flow/{timeType}/{version}")
    @ResponseBody
    public BaseDataRespDTO getpersonFlow(@PathVariable("timeType") Integer timeType) {
        try {
            LocalDate startDay = DeepDateUtil.getSameDayOfWeek();
            LocalDate endDay = DeepDateUtil.getSameDayOfYesterday();
            List<Date> betweenDates = DeepDateUtil.getBetweenDates(startDay, endDay);
            betweenDates.add(DeepDateUtil.localDate2Date(startDay));
            betweenDates.add(DeepDateUtil.localDate2Date(endDay));
            List<StatisticPersonfileFlow> personfileFlowVOList = statisticPersonfileService.getPersonfileFlow(startDay, endDay);
            List<Date> dateList = personfileFlowVOList.stream().map(StatisticPersonfileFlow::getStatisticDate).collect(Collectors.toList());
            betweenDates.stream().forEach(date -> {
                if (!dateList.contains(date)) {
                    StatisticPersonfileFlow statisticPersonfileFlow = new StatisticPersonfileFlow();
                    statisticPersonfileFlow.setStatisticDate(date);
                    statisticPersonfileFlow.setStatisticFlowTotal(0);
                    statisticPersonfileFlow.setStatisticFlowMissTotal(0);
                    personfileFlowVOList.add(statisticPersonfileFlow);
                }
            });
            List<StatisticPersonfileEvent> statisticPersonfileEvents = statisticPersonfileEventService.findStatisticEventDailyByDate(startDay.toString(), endDay.toString());
            
            List<StatisticPersonfileFlow> sortedStatisticPersonfileFlowList = personfileFlowVOList.stream().
                    sorted(Comparator.comparing(StatisticPersonfileFlow::getStatisticDate)).
                    collect(Collectors.toList());
            
            sortedStatisticPersonfileFlowList.forEach(e -> {
                e.setStatisticEvent(statisticPersonfileEvents.stream().filter(event -> event.getDt().compareTo(e.getStatisticDate()) == 0).findAny().orElse(new StatisticPersonfileEvent()).getIncNum());
            });
            
            return IPersonFilesResultInfo.ok(sortedStatisticPersonfileFlowList, "人员流动查询成功！");
        } catch (Exception e) {
            logger.error("查询失败:" + e.getMessage());
            return IPersonFilesResultInfo.unknownError("人员流动查询失败！", "异常：" + e.getMessage());
        }
    }
    
    /**
     * 档案总数统计（总数，实名档案总数） & 新增档案统计
     *
     * @param timeType 时间类型（0: 按周统计（默认）1：按天统计 ）
     * @param version  版本（目前默认1.0）
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "GET",value = "档案总数统计（总数，实名档案总数） & 新增档案统计")
    @GetMapping(value = {"/{timeType}/{startTime}/{endTime}/{version}", "/increase/{timeType}/{startTime}/{endTime}/{version}"})
    public BaseDataRespDTO getDistributionData(@PathVariable(value = "timeType") Integer timeType,
                                               @PathVariable(value = "startTime") String startTime,
                                               @PathVariable(value = "endTime") String endTime,
                                               @PathVariable(value = "version") Integer version) {
        try {
            Date startDate = org.apache.commons.lang.time.DateUtils.parseDate(startTime, dateFormat);
            Date endDate = org.apache.commons.lang.time.DateUtils.parseDate(endTime, dateFormat);
            
            // 按周统计
            if (StatisticFilterTimeTypeEnum.WEEK.getId() == timeType) {
                List<Map<String, Object>> data = statisticPersonfileService.findGroupByWeek(startTime, endTime);
                int startWeek = DeepDateUtil.getDayWeekOfYear(startDate);
                int endWeek = DeepDateUtil.getDayWeekOfYear(endDate);
                LinkedList<Map<String, Object>> result = new LinkedList<>();
                int num = 1;
                while (startWeek <= endWeek) {
                    boolean exist = false;
                    for (Map item : data) {
                        String statisticWeek = (String) item.get("weekCount");
                        if (statisticWeek.substring(4).equals(startWeek + "")) {
                            exist = true;
                            if (num == 1) {
                                if (startWeek == endWeek) {
                                    item.put("statisticWeek", startTime + "~" + DateFormatUtils.format(endDate, "MM-dd"));
                                } else {
                                    item.put("statisticWeek", startTime + "~" + DateUtils.getLastDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1));
                                }
                            } else {
                                if (startWeek == endWeek) {
                                    item.put("statisticWeek", DateUtils.getFirstDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1) + "~" + DateFormatUtils.format(endDate, "MM-dd"));
                                } else {
                                    item.put("statisticWeek", DateUtils.getFirstDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1) + "~" + DateUtils.getLastDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1));
                                }
                            }
                            
                            result.add(item);
                            break;
                        }
                    }
                    if (!exist) {
                        Map<String, Object> tempMap = new HashMap<>();
                        tempMap.put("statisticTotal", 0);
                        tempMap.put("statisticRealNameTotal", 0);
                        tempMap.put("statisticNewNum", 0);
                        if (num == 1) {
                            if (startWeek == endWeek) {
                                tempMap.put("statisticWeek", DateFormatUtils.format(startDate, "MM-dd") + "~" + DateFormatUtils.format(endDate, "MM-dd"));
                            } else {
                                tempMap.put("statisticWeek", DateFormatUtils.format(startDate, "MM-dd") + "~" + DateUtils.getLastDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1));
                            }
                        } else {
                            if (startWeek == endWeek) {
                                tempMap.put("statisticWeek", DateUtils.getFirstDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1) + "~" + DateFormatUtils.format(endDate, "MM-dd"));
                            } else {
                                tempMap.put("statisticWeek", DateUtils.getFirstDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1) + "~" + DateUtils.getLastDayOfWeek(DeepDateUtil.getYear(new Date()), startWeek - 1));
                            }
                        }
                        
                        result.add(tempMap);
                        num++;
                    }
                    startWeek++;
                }
                return new BaseDataRespDTO(result, IPersonFilesResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            // 按天统计
            if (StatisticFilterTimeTypeEnum.MONTH.getId() == timeType) {
                List<StatisticPersonfile> data = statisticPersonfileService.findByBtwStatisticDate(startTime, endTime);
                List<StatisticPersonfile> result = new LinkedList<>();
                while (startDate.compareTo(endDate) <= 0) {
                    boolean exist = false;
                    for (StatisticPersonfile item : data) {
                        if (item.getStatisticDate().compareTo(startDate) == 0) {
                            exist = true;
                            result.add(item);
                            break;
                        }
                    }
                    if (!exist) {
                        StatisticPersonfile tempPOJO = new StatisticPersonfile();
                        tempPOJO.setStatisticRealNameTotal(0);
                        tempPOJO.setStatisticNewNum(0);
                        tempPOJO.setStatisticTotal(0);
                        tempPOJO.setStatisticDate(startDate);
                        tempPOJO.setStatisticWeek(0);
                        result.add(tempPOJO);
                    }
                    startDate = org.apache.commons.lang.time.DateUtils.addDays(startDate, 1);
                }
                return new BaseDataRespDTO(result, IPersonFilesResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            return new BaseDataRespDTO(null, IPersonFilesResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage());
        } catch (ParseException e) {
            logger.error(e.getMessage());
            return new BaseDataRespDTO(null, IPersonFilesResultCode.ERROR, "获取异常:" + e.getMessage());
        }
    }
    
    /**
     * 新增档案统计，实名档案总数以及档案总数统计
     *
     * @param personfileStatisticVO 参数集合
     * @return String
     */
    @Deprecated
    @ApiOperation(httpMethod = "POST",value = "新增档案统计，实名档案总数以及档案总数统计")
    @PostMapping(value = "/job/statistic")
    public String personfileStatistic(@RequestBody PersonfileStatisticVO personfileStatisticVO) {
        try {
            // 查找离 statisticDate 日期最近的统计记录
            StatisticPersonfile lastStatisticPersonfile = statisticPersonfileService.findTopOne(personfileStatisticVO.getStatisticDate());
            logger.info("最近的统计记录：" + (lastStatisticPersonfile != null ? lastStatisticPersonfile.toString() : "暂无记录"));
            
            StatisticPersonfile statisticPersonfile = new StatisticPersonfile();
            // 实名总数
            statisticPersonfile.setStatisticRealNameTotal(lastStatisticPersonfile != null ?
                    lastStatisticPersonfile.getStatisticRealNameTotal() + personfileStatisticVO.getRealNameTotal() :
                    personfileStatisticVO.getRealNameTotal());
            // 新增总数
            statisticPersonfile.setStatisticNewNum(personfileStatisticVO.getNewTotal());
            // 总数
            statisticPersonfile.setStatisticTotal(lastStatisticPersonfile != null ?
                    lastStatisticPersonfile.getStatisticTotal() + personfileStatisticVO.getNewTotal() :
                    personfileStatisticVO.getNewTotal());
            // 统计日期
            statisticPersonfile.setStatisticDate(org.apache.commons.lang.time.DateUtils.parseDate(personfileStatisticVO.getStatisticDate(), dateFormat));
            
            statisticPersonfileService.insertStatisticPersonfile(statisticPersonfile);
            
            return JSONObject.toJSONString(new BaseDataRespDTO(IPersonFilesResultCode.SUCCESS, "档案新增以及总数统计数据更新成功！"));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return JSONObject.toJSONString(new BaseDataRespDTO(IPersonFilesResultCode.ERROR, "人员流动统计数据更新异常:" + e.getMessage()));
        }
    }
    
    /**
     * 更新统计
     *
     * @param incTotal         总数新增
     * @param incRealNameTotal 实名新增
     */
    @Deprecated
    @ApiOperation(httpMethod = "POST",value = "更新档案统计")
    @PostMapping(value = "/updateStatistic/{incTotal}/{incRealNameTotal}")
    public void updateStatistic(@PathVariable(name = "incTotal") Integer incTotal,
                                @PathVariable(name = "incRealNameTotal") Integer incRealNameTotal) {
        try {
            statisticPersonfileService.updateStatistic(incTotal, incRealNameTotal);
        } catch (Exception e) {
            logger.error("更新档案统计异常：" + e.getMessage());
        }
        
    }
    
    /**
     * 人员流动统计
     *
     * @param missNum       失踪人员
     * @param newNum        新增人员
     * @param statisticDate 归档时间
     * @return String
     * @throws ParseException 异常
     */
    @Deprecated
    @ApiOperation(httpMethod = "PUT",value = "人员流动统计")
    @PutMapping(value = "/update/personfileFlow/{missNum}/{newNum}/{statisticDate}")
    public String updatePersonfileFlow(@PathVariable(name = "missNum") Integer missNum,
                                       @PathVariable(name = "newNum") Integer newNum
            , @PathVariable(name = "statisticDate") String statisticDate) {
        try {
            // 查询是否有此记录
            StatisticPersonfileFlow statisticPersonfileFlow = statisticPersonfileFlowService.findByStatisticDate(statisticDate);
            if (statisticPersonfileFlow == null) {
                statisticPersonfileFlow = new StatisticPersonfileFlow();
            }
            String[] formatType = {ICommonConstant.DateFormatType.Y_M_D};
            
            statisticPersonfileFlow.setStatisticDate(org.apache.commons.lang.time.DateUtils.parseDate(statisticDate, formatType));
            
            statisticPersonfileFlow.setStatisticFlowMissTotal(missNum);
            statisticPersonfileFlow.setStatisticFlowTotal(newNum);
            
            if (statisticPersonfileFlow.getId() != null) {
                statisticPersonfileFlowService.update(statisticPersonfileFlow);
            } else {
                statisticPersonfileFlowService.insert(statisticPersonfileFlow);
            }
            
            return JSONObject.toJSONString(new BaseDataRespDTO(IPersonFilesResultCode.SUCCESS, "人员流动统计数据更新成功！"));
        } catch (Exception e) {
            logger.error(e.getMessage());
            return JSONObject.toJSONString(new BaseDataRespDTO(IPersonFilesResultCode.ERROR, "人员流动统计数据更新异常:" + e.getMessage()));
        }
    }
    
    /**
     * 获取档案总数
     *
     * @return Integer
     */
    @ApiOperation(httpMethod = "GET",value = "获取档案总数")
    @GetMapping(value = "getPersonfileTotal")
    public Integer getPersonfileTotal() {
        try {
            StatisticPersonfile statisticPersonfile = statisticPersonfileService.findTopOne(DateFormatUtils.format(org.apache.commons.lang.time.DateUtils.addDays(new Date(), 1), ICommonConstant.DateFormatType.Y_M_D));
            return statisticPersonfile != null ? statisticPersonfile.getStatisticTotal() : 0;
        } catch (Exception e) {
            logger.error("获取档案总数异常：" + e.getMessage());
            return 0;
        }
        
    }
    
}
