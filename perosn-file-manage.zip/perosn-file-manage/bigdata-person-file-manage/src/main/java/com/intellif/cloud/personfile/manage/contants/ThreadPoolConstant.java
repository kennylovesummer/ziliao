package com.intellif.cloud.personfile.manage.contants;


import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * 文件名：ThreadPoolConstant.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：  手动创建线程的常量配置
 * @author ：wangyi
 * 创建时间：2018年9月20日
 * 修改理由：
 * 修改内容：
 */
public class ThreadPoolConstant {
	/**
     * 线程池的基本大小
     */
    public static final int COREPOOL_SIZE = 10;
    /**
     * 线程池最大数量
     */
    public static final int MAXIMUM_POOL_SIZE = 15;
    /**
     * 线程活动保持时间
     */
    public static final int KEEP_ALIVE_TIME = 2;
    /**
     * 任务队列
     */
    public static final ArrayBlockingQueue WORKQUEUE = new ArrayBlockingQueue(5);
    /**
     * 无限队列
     */
    public static final LinkedBlockingQueue LINKED_BLOCKIN_GQUEUE = new LinkedBlockingQueue();
    
    private ThreadPoolConstant() {
    }
}
