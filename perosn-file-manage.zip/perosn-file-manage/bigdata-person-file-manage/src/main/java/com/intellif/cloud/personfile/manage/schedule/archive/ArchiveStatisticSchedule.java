package com.intellif.cloud.personfile.manage.schedule.archive;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author liuyu
 * @className PersonfileStatisticSchedule
 * @date 2019/4/12 10:38
 * @description
 */
@Component
public class ArchiveStatisticSchedule {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    
    private final MqMessageHandle mqMessageHandle;
    
    @Autowired
    public ArchiveStatisticSchedule(MqMessageHandle mqMessageHandle) {
        this.mqMessageHandle = mqMessageHandle;
    }
    
    @Scheduled(cron = "0 */30 * * * ?")
    public BaseDataRespDTO clusterStatisticFinish() {
        try {
            for (int i = 0;i <= 1;i++) {
                mqMessageHandle.clusterStatisticFinish(DeepDateUtil.dateToString(DateUtils.addDays(new Date(),-i)),DeepDateUtil.dateToString(DateUtils.addDays(new Date(),-i)) + ICommonConstant.DateStr.START_TIME,DeepDateUtil.dateToString(DateUtils.addDays(new Date(),-i)) + ICommonConstant.DateStr.END_TIME);
            }
        } catch (Exception e) {
            logger.error("归档统计异常：", e.getMessage());
            return new BaseDataRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "归档统计失败");
        }
        return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.EXECUTE_SUCCESS.getMessage());
    }
}
