package com.intellif.cloud.personfile.manage.services.account.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.model.dto.account.AccountDTO;
import com.intellif.cloud.personfile.manage.services.account.BigdataAccountService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @see BigdataAccountService
  */
@Service
public class BigdataAccountServiceImpl extends BaseServiceImpl implements BigdataAccountService {
    
    @Override
    public BigdataAccount findBigdataAccountById(Long id) {
        if (id == null) {
            return null;
        }
        QueryEvent<BigdataAccount> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("id", id);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBigdataAccountById");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (BigdataAccount) object;
    }
    
    @Override
    public int insertBigdataAccount(BigdataAccount account) {
        return this.baseDao.insert(account);
    }
    
    @Override
    public int deleteBigdataAccountById(Long id) {
        if (id == null) {
            return 0;
        }
        BigdataAccount bigdataAccount = new BigdataAccount();
        bigdataAccount.setId(id);
        this.baseDao.delete(bigdataAccount);
        return 1;
    }
    
    @Override
    public int deleteById(Long id) {
        BigdataAccount bigdataAccount = new BigdataAccount();
        bigdataAccount.setId(id);
        bigdataAccount.setIsDeleted(1);
        return updateBigdataAccount(bigdataAccount);
    }
    
    @Override
    public int updateBigdataAccount(BigdataAccount account) {
        return this.baseDao.update(account);
    }
    
    @Override
    public Page<BigdataAccount> findBigdataAccountByPage(AccountDTO accountDTO) {
        BigdataAccount bigdataAccount = new BigdataAccount();
        BeanUtils.copyProperties(accountDTO,bigdataAccount);
        QueryEvent<BigdataAccount> queryEvent = new QueryEvent<>();
        queryEvent.setObj(bigdataAccount);
        Page<BigdataAccount> page = PageHelper.startPage(accountDTO.getPage(), accountDTO.getPerpage(), accountDTO.getOrderBy());
        queryEvent.setStatement("findBigdataAccountByPage");
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public BigdataAccount findBigdataAccountByAccountAndPassword(AccountDTO accountDTO) {
        BigdataAccount bigdataAccount = new BigdataAccount();
        BeanUtils.copyProperties(accountDTO,bigdataAccount);
        QueryEvent<BigdataAccount> queryEvent = new QueryEvent<>();
        queryEvent.setObj(bigdataAccount);
        queryEvent.setStatement("findBigdataAccountByAccountAndPassword");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object != null ? (BigdataAccount) object : null;
    }
}
