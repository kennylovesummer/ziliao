package com.intellif.cloud.personfile.manage.utils;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.util.List;

/**
 * 字串工具类
 *
 * @author liuzj
 * @date 2019-06-28
 */
public class StringsUtils {
    
    /**
     * 集合转换为字符串
     *
     * @param list
     * @param separator
     * @return
     */
    public static String listToString(List list, String separator) {
        if (CollectionUtils.isEmpty(list)) {
            return Strings.EMPTY;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i)).append(separator);
        }
        return sb.toString().substring(0, sb.toString().length() - 1);
    }
}
