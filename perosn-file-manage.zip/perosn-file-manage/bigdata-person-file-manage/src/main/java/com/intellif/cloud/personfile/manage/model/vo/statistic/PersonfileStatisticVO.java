package com.intellif.cloud.personfile.manage.model.vo.statistic;

import java.io.Serializable;

/**
 * 档案新增，总数以及人员流动统计数据结构
 *
 * @author liuzj
 * @date 2019-05-29
 */
public class PersonfileStatisticVO implements Serializable {
    
    private Integer newTotal;
    
    private Integer realNameTotal;
    
    private String statisticDate;
    
    public String getStatisticDate() {
        return statisticDate;
    }
    
    public void setStatisticDate(String statisticDate) {
        this.statisticDate = statisticDate;
    }
    
    public Integer getNewTotal() {
        return newTotal;
    }
    
    public void setNewTotal(Integer newTotal) {
        this.newTotal = newTotal;
    }
    
    public Integer getRealNameTotal() {
        return realNameTotal;
    }
    
    public void setRealNameTotal(Integer realNameTotal) {
        this.realNameTotal = realNameTotal;
    }
}
