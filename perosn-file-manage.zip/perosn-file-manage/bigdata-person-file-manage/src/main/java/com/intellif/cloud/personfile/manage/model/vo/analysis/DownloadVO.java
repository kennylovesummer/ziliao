package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.Date;

/**
 * 下载返回参数
 *
 * @author liuzj
 * @date 2019-07-14
 */
@Data
public class DownloadVO {
    
    private Date endTime;
    
    private String fileName;
    
    private String filePath;
    
    private Integer status;
    
    private String downloadMsg;
    
    public DownloadVO(Date endTime, String fileName, String filePath, Integer status, String downloadMsg) {
        this.endTime = endTime;
        this.fileName = fileName;
        this.filePath = filePath;
        this.status = status;
        this.downloadMsg = downloadMsg;
    }
    
    public DownloadVO(Date endTime, Integer status, String downloadMsg) {
        this.endTime = endTime;
        this.status = status;
        this.downloadMsg = downloadMsg;
    }
}
