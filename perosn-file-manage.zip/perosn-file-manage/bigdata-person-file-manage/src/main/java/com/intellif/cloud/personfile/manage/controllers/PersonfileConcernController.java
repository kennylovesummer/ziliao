package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileConcernDto;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileConcernService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @ClassName PersonfileConcernController
 * @Author liuYu
 * @create 2018-10-19 18:13
 * @Version 1.0
 * @desc 档案关注
 */
@Api(tags = "档案关注")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.CONCERN)
public class PersonfileConcernController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final PersonfileConcernService personfileConcernService;

    @Autowired
    public PersonfileConcernController(PersonfileConcernService personfileConcernService) {
        this.personfileConcernService = personfileConcernService;
    }
    
    @ApiOperation(httpMethod = "POST",value = "档案关注接口")
    @PostMapping("/{version}")
    public BaseDataRespDTO insert(@RequestBody @Valid PersonfileConcernDto personfileConcernDto) {
        try {
            if (personfileConcernDto.getIsFocused() == 1) {
                PersonfileConcern personfileConcern = new PersonfileConcern();
                personfileConcern.setPersonFilesId(personfileConcernDto.getPersonFilesId());
                int result = personfileConcernService.insertPersonfileConcern(personfileConcern);
                if (result == 0) {
                    return IPersonFilesResultInfo.ok("关注失败！");
                }
                return IPersonFilesResultInfo.ok("关注成功！");
            }
        } catch (Exception e) {
            logger.error("关注失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("关注失败!" + e.getMessage());
        }
        try {
            int result = personfileConcernService.deleteByIdPersonfileConcern(personfileConcernDto.getPersonFilesId());
            if (result == 0) {
                return IPersonFilesResultInfo.ok("取消关注失败！");
            }
            return IPersonFilesResultInfo.ok("取消关注成功！");
        } catch (Exception e) {
            logger.error("取消关注失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("取消关注失败!");
        }
    }
}
