/*
 * 文件名：BasePageRespDTO.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月10日
 * 修改理由：
 * 修改内容：
 */
package com.intellif.cloud.personfile.manage.model.dto.req;


import com.alibaba.fastjson.JSONObject;

/**
 * 分页
 *
 * @author wangyi
 * @version 1.0
 * @date 2018年10月11日
 * @see BasePageReqDTO
 * @since JDK1.8
 */
public class BasePageReqDTO extends BaseReq {

    /**
     *
     */
    private static final long serialVersionUID = 1277656612410060018L;


    /**
     * 数据分页页码，不传该参数默认为第一页
     */
    private int page = 1;

    /**
     * 每页显示的最大数据条数，系统默认为10条
     */
    private int perpage = 10;
    
    /**
     * 排序，eg: id desc
     */
    private String orderBy;
    
    public String getOrderBy() {
        return orderBy;
    }
    
    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }
    
    /**
     * @return 返回 page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page 对reqPageNum进行赋值
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return 返回 perpage
     */
    public int getPerpage() {
        return perpage;
    }

    /**
     * @param perpage 对maxResults进行赋值
     */
    public void setPerpage(int perpage) {
        this.perpage = perpage;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }

}