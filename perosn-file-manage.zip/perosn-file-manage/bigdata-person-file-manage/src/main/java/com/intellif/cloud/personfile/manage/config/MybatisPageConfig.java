/*  
 * 文件名：MybatisPageConfig.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月11日    
 * 修改理由：  
 * 修改内容：  
 */

package com.intellif.cloud.personfile.manage.config;

import com.github.pagehelper.PageInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class MybatisPageConfig {

	@Bean
	public PageInterceptor pageHelper() {
		
		PageInterceptor pageHelper = new PageInterceptor();
		Properties p = new Properties();
		p.setProperty("offsetAsPageNum", "true");
		p.setProperty("rowBoundsWithCount", "true");
		p.setProperty("reasonable", "true");
		p.setProperty("dialect","com.github.pagehelper.dialect.helper.MySqlDialect"); 
		pageHelper.setProperties(p);
		return pageHelper;
	}

}
