package com.intellif.cloud.personfile.manage.model.vo.relationship;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 关系图谱默认查询条件
 *
 * @author liuzj
 * @date 2019-05-22
 */
@Data
public class RelationshipDefaultFilterVO  implements Serializable {

    @NotNull
    private Integer relationDepth;
    
    @NotNull
    private Integer frequency;
    
    @NotNull
    private Integer timeInterval;
    
    @NotNull
    private Integer multipleDepth;
    
    @NotNull
    private Integer multipleFrequency;
    
    @NotNull
    private Integer multipleInterval;
    
    @NotNull
    private Float similarScore;
    
    @NotNull
    private Integer topNum;
    
    @NotNull
    private Float multipleSimilarScore;
    
    @NotNull
    private Integer multipleTopNum;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
