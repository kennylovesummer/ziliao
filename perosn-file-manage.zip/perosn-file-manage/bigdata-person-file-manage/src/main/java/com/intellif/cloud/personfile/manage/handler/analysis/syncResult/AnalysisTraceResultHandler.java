package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTrace;
import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.EventDetailVO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTraceService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.cloud.personfile.manage.utils.DateUtils;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.net.CookieHandler;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

/**
 * 数据分析轨迹结果处理器
 *
 * @author liuzj
 * @date 2019-07-19
 */
public class AnalysisTraceResultHandler extends AbstractAnalysisSyncResultHandler {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final BigdataAnalysisTraceService bigdataAnalysisTraceService = BeanUtlis.getBean(BigdataAnalysisTraceService.class);
    
    public AnalysisTraceResultHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected void syncData(AnalysisTaskResultDTO analysisTaskResultDTO) {
        // 清除数据
        clearHistoryData(analysisTaskResultDTO);
        bigdataAnalysisTraceService.deleteBigdataAnalysisTraceByTaskId(analysisTaskResultDTO.getTaskId2());
        
        JSONObject result = getResult(analysisTaskResultDTO);
        
        Long taskId = analysisTaskResultDTO.getTaskId2();
        if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
            JSONArray resultArry = result.getJSONArray(ICommonConstant.ResultDataFormat.data);
            if (resultArry == null || resultArry.size() == 0) {
                logger.error("任务：" + taskId + " 轨迹结果无数据");
                analysisTaskResultDTO.setRemark("轨迹结果无数据");
                updateTaskStatus(analysisTaskResultDTO, true);
                return;
            }
            List<EventDetailVO> traceVOList = JSONObject.parseArray(resultArry.getJSONObject(0).getString("events"), EventDetailVO.class);
            if (CollectionUtils.isEmpty(traceVOList)) {
                logger.error("任务：" + taskId + " 轨迹结果无数据");
                analysisTaskResultDTO.setRemark("轨迹结果无数据");
                updateTaskStatus(analysisTaskResultDTO, true);
                return;
            }
            // 去重
            traceVOList = traceVOList.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(EventDetailVO::getFaceId))), ArrayList::new));
            
            Map<Long, List<EventDetailVO>> resultGroupByDate = traceVOList.stream().collect(Collectors.groupingBy(e -> e.getDate().getTime()));
            Set<String> devIds = traceVOList.stream().map(EventDetailVO::getCameraId).collect(Collectors.toSet());
            List<PersonfileCamera> devs = iPersonfileCameraService.findCameraByDevIdList(new ArrayList<>(devIds));
            
            if (CollectionUtils.isEmpty(devs)) {
                logger.error("任务：" + taskId + " 摄像头数据异常");
                analysisTaskResultDTO.setRemark("摄像头数据异常");
                updateTaskStatus(analysisTaskResultDTO, false);
                return;
            }
            
            List<BigdataAnalysisTrace> traceList = Lists.newArrayList();
            
            List<BigdataAnalysisEvent> eventList = Lists.newArrayList();
            
            resultGroupByDate.forEach((key, value) -> {
                if (CollectionUtils.isNotEmpty(value)) {
                    
                    Map<String, List<EventDetailVO>> resultGroupBySourceId = value.stream().collect(Collectors.groupingBy(EventDetailVO::getCameraId));
                    
                    Long date = DateUtils.getDate(key);
                    
                    resultGroupBySourceId.forEach((key2, value2) -> {
                        
                        PersonfileCamera dev = devs.stream().filter(d -> d.getDevId().equals(key2)).findAny().orElse(new PersonfileCamera());
                        
                        if (Strings.isNotBlank(dev.getDevId())) {
                            BigdataAnalysisTrace bigdataAnalysisTrace = new BigdataAnalysisTrace();
                            bigdataAnalysisTrace.setDate(date);
                            bigdataAnalysisTrace.setCameraId(dev.getDevId());
                            bigdataAnalysisTrace.setTaskId(taskId);
                            bigdataAnalysisTrace.setCameraName(dev.getName());
                            bigdataAnalysisTrace.setGeoString(dev.getGeoString());
                            traceList.add(bigdataAnalysisTrace);
                        }
                        
                        if (traceList.size() == BATCH_INSERT_NUM) {
                            bigdataAnalysisTraceService.batchInsertAnalysisTrace(traceList);
                            traceList.clear();
                        }
                        
                        value2.forEach(face -> {
                            BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
                            bigdataAnalysisEvent.setFaceId(face.getFaceId());
                            bigdataAnalysisEvent.setFaceUrl(face.getFaceUrl());
                            bigdataAnalysisEvent.setTaskId(taskId);
                            bigdataAnalysisEvent.setAid(face.getAid());
                            bigdataAnalysisEvent.setCameraId(face.getCameraId());
                            try {
                                bigdataAnalysisEvent.setTime(org.apache.commons.lang3.time.DateUtils.parseDate(face.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            bigdataAnalysisEvent.setDate(date);
                            bigdataAnalysisEvent.setImageId(face.getImageId());
                            bigdataAnalysisEvent.setImageUrl(face.getImageUrl());
                            bigdataAnalysisEvent.setTargetRect(face.getTargetRect());
                            eventList.add(bigdataAnalysisEvent);
                            
                            if (eventList.size() == BATCH_INSERT_NUM) {
                                bigdataAnalysisEventService.batchInsertAnalysisEvent(eventList);
                                eventList.clear();
                            }
                        });
                    });
                }
            });
            
            if (CollectionUtils.isNotEmpty(traceList)) {
                bigdataAnalysisTraceService.batchInsertAnalysisTrace(traceList);
            }
           
            if (CollectionUtils.isNotEmpty(eventList)) {
                bigdataAnalysisEventService.batchInsertAnalysisEvent(eventList);
            }
            
            analysisTaskResultDTO.setRemark("轨迹分析数据同步成功！");
            updateTaskStatus(analysisTaskResultDTO, true);
        } else if (result == null || result.get(ICommonConstant.ResultDataFormat.data) == null) {
            analysisTaskResultDTO.setRemark("轨迹分析数据同步结束: " + "无数据");
            updateTaskStatus(analysisTaskResultDTO, true);
        } else {
            analysisTaskResultDTO.setRemark("轨迹分析数据同步结束：" + (result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : ""));
            updateTaskStatus(analysisTaskResultDTO, false);
        }
    }
}
