package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Administrator
 */
@Data
public class BigdataAnalysisExportTask  implements Serializable {
    private static final long serialVersionUID = 2454807294252474711L;
    
    private Long id;

    private Long taskId;

    private String taskType;

    private String fileName;
    
    private String taskName;

    private String filePath;

    private Date startTime;

    private Date endTime;

    private String execId;

    private Long useTime;

    private Integer status;

    private String downloadMsg;

    private Integer retryTimes;

    private String createBy;

    private Date createTime;

    private Date modifyTime;

    private String modifyBy;

    private String reqParams;
}