package com.intellif.cloud.personfile.manage.model.dto.snap;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author liuyu
 * @className EventSnapDetailResp
 * @date 2019/3/19 14:52
 * @description
 */
@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class EventSnapDetailResp implements Serializable {

    private static final long serialVersionUID = -949158798872263499L;

    /**
     * 事件类型
     */
    private Integer eventType;

    /**
     * 抓拍总数
     */
    private Integer imageCount;
    
    /**
     * 当前查询的抓拍数
     */
    private Integer snapSize;

    /**
     * 事件发生日期
     */
    private String occurrenceDate;

    /**
     * 抓拍图片集合
     */
    private List<EventSnapDetailVO> snap;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
