package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabel;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileLabelService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

/**
 * @ClassName PersonfileLabelController
 * @Author liuYu
 * @create 2018-10-16 19:49
 * @Version 1.0
 * @desc 标签
 */
@Api(tags = "档案标签")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.LABEL)
public class PersonfileLabelController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final PersonfileLabelService personfileLabelService;
    
    @Autowired
    public PersonfileLabelController(PersonfileLabelService personfileLabelService) {
        this.personfileLabelService = personfileLabelService;
    }
    
    @ApiOperation(httpMethod = "GET",value = "查询标签")
    @GetMapping("/{labelId}/{version}")
    public BaseDataRespDTO getById(@PathVariable("labelId") @NotNull Integer labelId) {
        try {
            PersonfileLabel personfileLabel = personfileLabelService.queryPersonfileLabelById(labelId);
            return IPersonFilesResultInfo.ok(personfileLabel, "标签查询成功");
        } catch (Exception e) {
            logger.error("标签查询失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("标签查询失败!");
        }
    }
    
    @ApiOperation(httpMethod = "POST",value = "添加标签")
    @PostMapping("/{version}")
    public BaseDataRespDTO post(@RequestBody @Valid PersonfileLabel personfileLabel, BindingResult bindingResult) {
        try {
            if (bindingResult.hasErrors()) {
                Map<String, Object> result = Maps.newHashMap();
                if (bindingResult.hasErrors()) {
                    FieldError error = (FieldError) bindingResult.getAllErrors().get(0);
                    result.put("code", "400");
                    result.put("message", error.getDefaultMessage());
                }
                return IPersonFilesResultInfo.unknownError(result.toString(), "添加标签失败!");
            }
            // 判重
            PersonfileLabel existLabel = personfileLabelService.queryPersonfileLabelByName(null, personfileLabel.getLabelName());
            if (existLabel != null) {
                return IPersonFilesResultInfo.unknownError("此标签已存在！");
            }
            
            int result = personfileLabelService.insertPersonfileLabel(personfileLabel);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("添加标签失败！");
            }
            return IPersonFilesResultInfo.ok("添加标签成功！");
        } catch (Exception e) {
            logger.error("添加标签失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("添加标签失败!");
        }
    }
    
    @ApiOperation(httpMethod = "PUT",value = "修改标签")
    @PutMapping("/{labelId}/{version}")
    public BaseDataRespDTO put(@PathVariable("labelId") @NotNull Integer
                                       labelId, @RequestBody @Valid PersonfileLabel personfileLabel, BindingResult bindingResult) throws BusinessException {
        try {
            if (bindingResult.hasErrors()) {
                IPersonFilesResultInfo.unknownError(bindingResult.getFieldError().getDefaultMessage());
            }
            // 判空
            PersonfileLabel existLabel = personfileLabelService.queryPersonfileLabelByName(null, personfileLabel.getLabelName());
            if (existLabel != null) {
                return IPersonFilesResultInfo.unknownError("标签已存在!");
            }
            personfileLabel.setId(labelId);
            personfileLabelService.updatePersonfileLabel(personfileLabel);
            return IPersonFilesResultInfo.ok("修改标签成功！");
        } catch (Exception e) {
            logger.error("修改标签异常:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("修改标签失败!");
        }
    }
    
    @ApiOperation(httpMethod = "DELETE",value = "删除标签")
    @DeleteMapping("/{labelId}/{version}")
    public BaseDataRespDTO delete(@PathVariable("labelId") @NotNull Integer labelId) {
        try {
            int result = personfileLabelService.deletePersonfileLabel(labelId);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("删除标签失败！");
            }
            return IPersonFilesResultInfo.ok("删除标签成功！");
        } catch (Exception e) {
            logger.error("删除标签异常:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("删除标签失败!");
        }
    }
    
    @ApiOperation(httpMethod = "GET",value = "分页查询标签")
    @GetMapping("/page/{version}")
    public BasePageRespDTO get(@RequestParam(required = false, defaultValue = "1") int pageNum,
                               @RequestParam(required = false, defaultValue = "10") int pageSize) {
        try {
            Page<PersonfileLabel> personfileLabelList = personfileLabelService.queryPersonfileLabelList(pageNum, pageSize);
            return IPersonFilesResultInfo.success(personfileLabelList, personfileLabelList.getPages(),
                    (int) personfileLabelList.getTotal(), "标签查询成功");
        } catch (Exception e) {
            logger.error("标签查询异常:", e.getMessage());
            return IPersonFilesResultInfo.error(null, 0, 0, "标签查询失败!");
        }
    }
    
    @ApiOperation(httpMethod = "GET",value = "获取标签")
    @GetMapping("/{version}")
    public BaseDataRespDTO get(@RequestParam(name = "labelName", required = false) String labelName) {
        try {
            if (StringUtils.isBlank(labelName)) {
                List<PersonfileLabel> personfileLabels = personfileLabelService.findAllPersonfileLabel();
                return IPersonFilesResultInfo.ok(personfileLabels, "查询标签成功！");
            }
            PersonfileLabel personfileLabel = personfileLabelService.queryPersonfileLabelByName(null, labelName);
            List<PersonfileLabel> result = Lists.newArrayList();
            if (personfileLabel != null) {
                result.add(personfileLabel);
            }
            return IPersonFilesResultInfo.ok(result, "查询标签名成功！");
        } catch (Exception e) {
            logger.error("查询标签异常:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("查询标签失败!");
        }
    }
}
