package com.intellif.cloud.personfile.manage.model.vo.thrift;

/**
 * @Description :
 * @Author dyl
 * @Date 15:44 2018/12/28
 */
public class Attributes {

    private Integer age;

    private String ethnicity;

    private String gender;

    private String glass;

    private String hat;

    private String headpose;

    private Float quality;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGlass() {
        return glass;
    }

    public void setGlass(String glass) {
        this.glass = glass;
    }

    public String getHat() {
        return hat;
    }

    public void setHat(String hat) {
        this.hat = hat;
    }

    public String getHeadpose() {
        return headpose;
    }

    public void setHeadpose(String headpose) {
        this.headpose = headpose;
    }

    public Float getQuality() {
        return quality;
    }

    public void setQuality(Float quality) {
        this.quality = quality;
    }
}
