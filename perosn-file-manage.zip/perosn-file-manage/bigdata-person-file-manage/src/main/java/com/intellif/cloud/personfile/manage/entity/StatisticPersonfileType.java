package com.intellif.cloud.personfile.manage.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName StatisticPersonfileType
 * @Author liuzhijian
 * @create 2018-10-20
 * @Version 1.0
 * @desc 档案类型统计（重点人员、常住人员等）
 */
public class StatisticPersonfileType implements Serializable {
    
    private Integer id;

    private Date createTime;

    private Date modifiedTime;

    private Integer personFileTypeId;

    private String personFileTypeName;

    private Long personFileNum;

    /**
     * 是否删除(0-未删除， 1-已删除)
     * 对应数据库的字段名: is_delete
     */
    private int deleteStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Integer getPersonFileTypeId() {
        return personFileTypeId;
    }

    public void setPersonFileTypeId(Integer personFileTypeId) {
        this.personFileTypeId = personFileTypeId;
    }

    public String getPersonFileTypeName() {
        return personFileTypeName;
    }

    public void setPersonFileTypeName(String personFileTypeName) {
        this.personFileTypeName = personFileTypeName == null ? null : personFileTypeName.trim();
    }

    public Long getPersonFileNum() {
        return personFileNum;
    }

    public void setPersonFileNum(Long personFileNum) {
        this.personFileNum = personFileNum;
    }

    public int getDeleteStatus() {
        return deleteStatus;
    }

    public void setDeleteStatus(int deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    @Override
    public String toString() {
        return "StatisticPersonfileType{" +
                "id=" + id +
                ", createTime=" + createTime +
                ", modifiedTime=" + modifiedTime +
                ", personFileTypeId=" + personFileTypeId +
                ", personFileTypeName='" + personFileTypeName + '\'' +
                ", personFileNum=" + personFileNum +
                ", deleteStatus=" + deleteStatus +
                '}';
    }
}