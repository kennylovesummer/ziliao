package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import org.apache.logging.log4j.util.Strings;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liuyu
 * @className PersonfileSnap
 * @date 2019/3/18 20:38
 * @description
 */
public class PersonfileSnap implements Serializable {

    private static final long serialVersionUID = 1417717873126992374L;
    
    private String tableName;
    
    public String getTableName() {
        return tableName;
    }
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    @JSONField(name = "aid")
    private String personFilesId;

    @JSONField(name = "thumbnailId")
    private String faceId;

    @JSONField(name = "thumbnailUrl")
    private String faceUrl;

    private String imageId;

    private String imageUrl;

    private String sysCode;

    private String algoVersion;

    private String genderInfo;

    private String ageInfo;

    private String hairstyleInfo;

    private String hatInfo;

    private String glassesInfo;

    private String raceInfo;

    private String maskInfo;

    private String skinInfo;

    private String poseInfo;

    private Float qualityInfo;

    private String targetRect;

    private String targetRectFloat;

    private String landMarkInfo;

    private Float featureQuality;

    private String sourceId;

    private String sourceType;

    private String site;

    @JSONField(name = "time")
    private Date snapTime;

    @JSONField(name = "createTime")
    private Date createTime;

    private String column1;

    private String column2;

    private String column3;
    
    public String getPersonFilesId() {
        return personFilesId;
    }

    public void setPersonFilesId(String personFilesId) {
        this.personFilesId = personFilesId;
    }

    public String getFaceId() {
        return faceId;
    }

    public void setFaceId(String faceId) {
        this.faceId = faceId;
    }

    public String getFaceUrl() {
        return faceUrl;
    }

    public void setFaceUrl(String faceUrl) {
        this.faceUrl = faceUrl;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getSysCode() {
        return sysCode;
    }

    public void setSysCode(String sysCode) {
        this.sysCode = sysCode;
    }

    public String getAlgoVersion() {
        return algoVersion;
    }

    public void setAlgoVersion(String algoVersion) {
        this.algoVersion = algoVersion;
    }

    public String getGenderInfo() {
        return genderInfo;
    }

    public void setGenderInfo(String genderInfo) {
        this.genderInfo = genderInfo;
    }

    public String getAgeInfo() {
        return ageInfo;
    }

    public void setAgeInfo(String ageInfo) {
        this.ageInfo = ageInfo;
    }

    public String getHairstyleInfo() {
        return hairstyleInfo;
    }

    public void setHairstyleInfo(String hairstyleInfo) {
        this.hairstyleInfo = hairstyleInfo;
    }

    public String getHatInfo() {
        return hatInfo;
    }

    public void setHatInfo(String hatInfo) {
        this.hatInfo = hatInfo;
    }

    public String getGlassesInfo() {
        return glassesInfo;
    }

    public void setGlassesInfo(String glassesInfo) {
        this.glassesInfo = glassesInfo;
    }

    public String getRaceInfo() {
        return raceInfo;
    }

    public void setRaceInfo(String raceInfo) {
        this.raceInfo = raceInfo;
    }

    public String getMaskInfo() {
        return maskInfo;
    }

    public void setMaskInfo(String maskInfo) {
        this.maskInfo = maskInfo;
    }

    public String getSkinInfo() {
        return skinInfo;
    }

    public void setSkinInfo(String skinInfo) {
        this.skinInfo = skinInfo;
    }

    public String getPoseInfo() {
        return poseInfo;
    }

    public void setPoseInfo(String poseInfo) {
        this.poseInfo = poseInfo;
    }

    public Float getQualityInfo() {
        return qualityInfo;
    }

    public void setQualityInfo(Float qualityInfo) {
        this.qualityInfo = qualityInfo;
    }

    public String getTargetRect() {
        return targetRect;
    }

    public void setTargetRect(String targetRect) {
        this.targetRect = targetRect;
    }

    public String getTargetRectFloat() {
        return targetRectFloat;
    }

    public void setTargetRectFloat(String targetRectFloat) {
        this.targetRectFloat = targetRectFloat;
    }

    public String getLandMarkInfo() {
        return landMarkInfo;
    }

    public void setLandMarkInfo(String landMarkInfo) {
        this.landMarkInfo = landMarkInfo;
    }

    public Float getFeatureQuality() {
        return featureQuality;
    }

    public void setFeatureQuality(Float featureQuality) {
        this.featureQuality = featureQuality;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Date getSnapTime() {
        return snapTime;
    }

    public void setSnapTime(Date snapTime) {
        this.snapTime = snapTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }

    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }

    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
    
    public Boolean isNormalSnap(){
        return Strings.isNotBlank(this.personFilesId)
                && Strings.isNotBlank(this.faceId)
                && Strings.isNotBlank(this.faceUrl)
                && this.algoVersion != null
                && this.sourceId != null
                && this.sourceType != null
                && this.createTime != null
                && this.snapTime != null;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
