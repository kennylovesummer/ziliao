/*
 * 文 件 名:  BaseService.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2015/7/14
 */
package com.intellif.cloud.personfile.manage.services.base;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * service基类
 * @author wangyi
 * @version [版本号, 2015/7/14]
 */
public class BaseServiceImpl implements IBaseService
{
    protected Log logs = LogFactory.getLog(getClass());
    
    /**
     * 数据库操作baseDao
     */
    @SuppressWarnings("rawtypes")
    @Autowired
    protected IBaseDao baseDao;
    
}
