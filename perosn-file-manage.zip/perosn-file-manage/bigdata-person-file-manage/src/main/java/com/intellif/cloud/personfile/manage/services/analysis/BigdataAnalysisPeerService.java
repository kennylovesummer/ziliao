package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisPeer;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.PeerDTO;

import java.util.List;

/**
 * 数据分析事件
 *
 * @author liuzj
 * @date 2019-07-18
 */
public interface BigdataAnalysisPeerService {
    
    /**
     * 根据ID查找
     *
     * @param id ID
     * @return entity
     */
    BigdataAnalysisPeer findAnalysisPeerById(Long id);
    
    /**
     * 根据ID删除对象
     *
     * @param bigdataAnalysisPeer 要删除的对象
     */
    void deleteAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisPeer 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer);
    
    /**
     * 批量插入
     *
     * @param peerList 数据集
     */
    void batchInsertAnalysisPeer(List<BigdataAnalysisPeer> peerList);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisPeer 待更新的对象
     */
    void updateAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer);
    
    /**
     * 分页查找
     *
     * @param peerDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisPeer> findAnalysisPeerByParams(PeerDTO peerDTO);
    
    /**
     * 根据任务ID删除
     *
     * @param taskId 任务ID
     */
    void deleteBigdataAnalysisPeerByTaskId(Long taskId);
}
