package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrash;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * 碰撞分析
 *
 * @author lzj
 * @version 1.0
 * @date 2019年06月20日
 * @see CrashAnalysisController
 * @since JDK1.8
 */
@Api(tags = "数据分析-碰撞分析")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.CRASH)
public class CrashAnalysisController implements java.io.Serializable {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    @Autowired
    private BigdataAnalysisCrashService bigdataAnalysisCrashService;
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    /**
     * 获取碰撞分析结果
     *
     * @param crashDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取碰撞人员列表")
    @PostMapping(value = "list")
    public BasePageRespDTO result(@RequestBody CrashDTO crashDTO) {
        try {
            // 参数校验
            if (crashDTO.getTaskId() == null) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "参数异常");
            }
            
            Page<BigdataAnalysisArchive> page = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(crashDTO);
            List<BigdataAnalysisArchive> bigdataAnalysisArchiveList = page.getResult();
    
            if (CollectionUtils.isNotEmpty(bigdataAnalysisArchiveList)) {
//                List<Map<String, Object>> personfileBasicsList = subArchiveService.findByPersonfileIds(bigdataAnalysisArchiveList.stream().map(BigdataAnalysisArchive::getAid).collect(Collectors.toList()));
                for (BigdataAnalysisArchive item: bigdataAnalysisArchiveList) {
                    PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(item.getAid());
                    item.setImageCount(personfileBasics != null ? personfileBasics.getImageCount() : null);
                    item.setPersonName(personfileBasics != null ? personfileBasics.getName() : null);
                    item.setCid(personfileBasics != null ? personfileBasics.getCid() : null);
//                    item.setImageCount((Integer) personfileBasicsList.stream().filter(m -> item.getAid().equals(m.get("personFileId"))).findAny().orElse(Maps.newHashMap()).get("imageCount"));
                }
            }
    
            bigdataAnalysisArchiveList.stream().sorted(Comparator.comparingInt(BigdataAnalysisArchive::getImageCount).reversed());
            return new BasePageRespDTO(bigdataAnalysisArchiveList, page.getPages(), Integer.parseInt(page.getTotal() + ""), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("碰撞分析结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), e.getMessage());
        }
    }
    
    /**
     * 获取碰撞分析结果详情
     *
     * @param crashDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取单个区域人员活动详情")
    @PostMapping(value = "single/detail")
    public BasePageRespDTO resultDetail(@RequestBody CrashDTO crashDTO) {
        try {
            // 参数校验
            if (crashDTO.getTaskId() == null || Strings.isBlank(crashDTO.getAid()) || Strings.isBlank(crashDTO.getAreaCode())) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "参数异常");
            }
            
            Page<BigdataAnalysisCrash> page = bigdataAnalysisCrashService.findAnalysisCrashByParams(crashDTO);
            List<BigdataAnalysisCrash> crashList = page.getResult();
            
            if (CollectionUtils.isEmpty(crashList)) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            EventDTO eventDTO = new EventDTO();
            BeanUtils.copyProperties(crashDTO, eventDTO);
            Page<BigdataAnalysisEvent> eventPage;
            eventDTO.setAid(crashDTO.getAid());
            for (BigdataAnalysisCrash crash : crashList) {
                eventDTO.setDate(crash.getDate());
                eventDTO.setCameraId(crash.getCameraId());
                eventDTO.setPerpage(0);
                eventPage = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
                List<BigdataAnalysisEvent> faces = eventPage.getResult();
                if (CollectionUtils.isNotEmpty(faces)) {
                    faces.stream().sorted(Comparator.comparingLong(BigdataAnalysisEvent::getTime).reversed());
                }
                crash.setFaces(faces);
            }
            
            eventDTO.setDate(null);
            eventDTO.setCameraId(null);
            return new BasePageRespDTO(crashList, page.getPages(), Integer.parseInt(bigdataAnalysisEventService.findCountByParams(eventDTO) + ""), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("碰撞分析结果详情查询异常：" + e.getMessage());
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), e.getMessage());
        }
    }
    
    /**
     * 获取碰撞分析结果详情
     *
     * @param crashDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取全部区域人员活动详情")
    @PostMapping(value = "detail")
    public BasePageRespDTO multiResultDetail(@RequestBody CrashDTO crashDTO) {
        try {
            // 参数校验
            if (crashDTO.getTaskId() == null || Strings.isBlank(crashDTO.getAid()) || Strings.isBlank(crashDTO.getAreaCode())) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "参数异常");
            }
            
            Page<BigdataAnalysisCrash> page = bigdataAnalysisCrashService.findAnalysisCrashByParams(crashDTO);
            List<BigdataAnalysisCrash> crashList = page.getResult();
            
            if (CollectionUtils.isEmpty(crashList)) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            EventDTO eventDTO = new EventDTO();
            BeanUtils.copyProperties(crashDTO, eventDTO);
            Page<BigdataAnalysisEvent> eventPage;
            eventDTO.setAid(crashDTO.getAid());
            for (BigdataAnalysisCrash crash : crashList) {
                eventDTO.setDate(crash.getDate());
                eventDTO.setCameraId(crash.getCameraId());
                eventDTO.setPerpage(0);
                eventPage = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
                List<BigdataAnalysisEvent> faces = eventPage.getResult();
                if (CollectionUtils.isNotEmpty(faces)) {
                    faces.stream().sorted(Comparator.comparingLong(BigdataAnalysisEvent::getTime).reversed());
                }
                crash.setFaces(faces);
            }
            
            List<Map<String, Object>> result = Lists.newArrayList();
            Map<String, List<BigdataAnalysisCrash>> groupByAreaCode = crashList.stream().collect(Collectors.groupingBy(BigdataAnalysisCrash::getAreaCode));
            eventDTO.setDate(null);
            eventDTO.setCameraId(null);
            groupByAreaCode.forEach((key, value) -> {
                Map<String, Object> resultItem = Maps.newHashMap();
                resultItem.put("areaCode", key);
                resultItem.put("crashResult", value);
                eventDTO.setAreaCode(key);
                resultItem.put("total", bigdataAnalysisEventService.findCountByParams(eventDTO));
                result.add(resultItem);
            });
            
            return new BasePageRespDTO(result, page.getPages(), Integer.parseInt(bigdataAnalysisEventService.findCountByParams(eventDTO) + ""), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("碰撞分析结果详情查询异常：" + e.getMessage());
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), e.getMessage());
        }
    }
}
