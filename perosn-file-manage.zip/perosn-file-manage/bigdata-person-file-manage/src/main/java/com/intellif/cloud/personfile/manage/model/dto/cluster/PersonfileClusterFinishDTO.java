package com.intellif.cloud.personfile.manage.model.dto.cluster;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.intellif.cloud.personfile.manage.utils.AgeivisionUtil;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import org.apache.logging.log4j.util.Strings;

import java.util.Date;

public class PersonfileClusterFinishDTO {

    /**
     * 档案ID
     */
    @JSONField(name = "aid")
    private String personFilesId;

    /**
     * 姓名
     */
    @JSONField(name = "personName")
    private String name;

    /**
     * 身份证
     */
    @JSONField(name = "identityNo")
        private String cid;

    /**
     * 最近抓拍时间
     */
    private Date recentSnapTime;

    /**
     * 创建时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss",name = "createTime")
    private Date personFileCreateTime;

    /**
     * 户籍地
     */
    private String residencePlace;

    /**
     * 现居住地
     */
    @JSONField(name = "currAddress")
    private String domicilePlace;

    /**
     * 性别
     */
    @JSONField(name = "gender")
    private Integer sex;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 生日
     */
    @JSONField(name = "birthday", format = "yyyy-MM-dd")
    private Date birthDate;

    /**
     * 头像地址
     */
    @JSONField(name = "avatarUrl")
    private String headImageUrl;

    /**
     * 手机号
     */
    @JSONField(name = "phoneNo")
    private String phoneNumber;

    /**
     * 汇集图片数
     */
    private Integer imageCount;

    /**
     * 算法版本
     */
    private String algoVersion;

    // ------------------------------ 照片信息 ---------------------------------

    /**
     * 特征值
     */
    @JSONField(name = "featureInfo")
    private byte[] featureInfo;

    /**
     * 大图地址
     */
    @JSONField(name = "imageUrl")
    private String bigImageUrl;

    /**
     * 小图地址
     */
    @JSONField(name = "thumbnailUrl")
    private String smallImageUrl;

    /**
     * 人脸框位置
     */
    private String targetRect;
    
    /**
     * 操作类型（update | insert）
     */
    private String action;
    
    // ------------------------------ 照片信息 ---------------------------------
    
    
    public String getAction() {
        return action;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
    
    public PersonfileClusterFinishDTO() {

    }

    public String getPersonFilesId() {
        return personFilesId;
    }

    public void setPersonFilesId(String personFilesId) {
        this.personFilesId = personFilesId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        if (Strings.isNotBlank(cid)) {
            this.cid = cid;
        }
    }

    public Date getRecentSnapTime() {
        return recentSnapTime;
    }

    public void setRecentSnapTime(Date recentSnapTime) {
        this.recentSnapTime = recentSnapTime;
    }

    public String getResidencePlace() {
        return residencePlace;
    }

    public void setResidencePlace(String residencePlace) {
        this.residencePlace = residencePlace;
    }

    public String getDomicilePlace() {
        return domicilePlace;
    }

    public void setDomicilePlace(String domicilePlace) {
        this.domicilePlace = domicilePlace;
    }

    public Integer getSex() {
        if (Strings.isNotBlank(this.cid)) {
            return Integer.valueOf(AgeivisionUtil.getBirAgeSex(this.cid).get("sex") + "");
        }
        if (this.sex == null || this.sex == 3) {
            return 0;
        }
        return this.sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthDate() {
        if (Strings.isNotBlank(this.cid)) {
            try {
                return DeepDateUtil.strToDate((String) AgeivisionUtil.getBirAgeSex(this.cid).get("birthday"));
            } catch (Exception e) {
                return null;
            }
        }
        return this.birthDate;

    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public byte[] getFeatureInfo() {
        return featureInfo;
    }

    public void setFeatureInfo(byte[] featureInfo) {
        this.featureInfo = featureInfo;
    }

    public String getBigImageUrl() {
        return bigImageUrl;
    }

    public void setBigImageUrl(String bigImageUrl) {
        this.bigImageUrl = bigImageUrl;
    }

    public String getSmallImageUrl() {
        return smallImageUrl;
    }

    public void setSmallImageUrl(String smallImageUrl) {
        this.smallImageUrl = smallImageUrl;
    }

    public String getHeadImageUrl() {
        if (Strings.isBlank(headImageUrl)) {
            return null;
        }
        return headImageUrl;
    }

    public void setHeadImageUrl(String headImageUrl) {
        this.headImageUrl = headImageUrl;
    }

    public String getTargetRect() {
        return targetRect;
    }

    public void setTargetRect(String targetRect) {
        this.targetRect = targetRect;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getAge() {
        if (Strings.isNotBlank(this.cid)) {
            return Integer.valueOf(AgeivisionUtil.getBirAgeSex(this.cid).get("age") + "");
        }
        if (this.age == null) {
            return 0;
        }
        return this.age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getPersonFileCreateTime() {
        return personFileCreateTime;
    }

    public void setPersonFileCreateTime(Date personFileCreateTime) {
        this.personFileCreateTime = personFileCreateTime;
    }

    public Integer getImageCount() {
        return imageCount;
    }

    public void setImageCount(Integer imageCount) {
        this.imageCount = imageCount;
    }

    public String getAlgoVersion() {
        return algoVersion;
    }

    public void setAlgoVersion(String algoVersion) {
        this.algoVersion = algoVersion;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }

}
