package com.intellif.cloud.personfile.manage.model.vo.crash;

import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrashArea;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 碰撞列表返回数据集
 *
 * @author liuzj
 * @date 2019-06-29
 */
@Data
public class CrashVO {

    private Long id;
    
    private String type;
    
    private String typeName;
    
    private Long taskId;
    
    private String code;
    
    private String personfileId;
    
    private String personName;
    
    private String cid;
    
    private String taskName;
    
    private List<Object> faceList;
    
    private Long archiveTotal;
    
    private String execId;
    
    private BigdataAnalysisCrashArea area1;
    
    private BigdataAnalysisCrashArea area2;
    
    List<BigdataAnalysisCrashArea> areas;
    
    private String creater;
    
    private Date createTime;
    
    private Long costTime;
    
    private Integer status;
    
    private String faceUrl;
    
    private String params;
    
    private String result;
    
}
