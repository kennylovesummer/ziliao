package com.intellif.cloud.personfile.manage.task;

import com.intellif.cloud.personfile.manage.plugin.SqlCostTimeMonitor;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.concurrent.Callable;

public class SubWork implements Callable<Object> {
    
    Logger LOG = LoggerFactory.getLogger(SqlCostTimeMonitor.class);
    
    private ProceedingJoinPoint pjp;
    
    private String subTableName;
    
    private String tableName;
    
    public SubWork(ProceedingJoinPoint pjp,String subTableName,String tableName) {
        this.pjp = pjp;
        this.tableName = tableName;
        this.subTableName = subTableName;
    }
    
    @Override
    public Object call() {
        ThreadLocalUtil.setTableName(tableName);
        ThreadLocalUtil.setSubTableName(subTableName);
        try {
            return pjp.proceed();
        } catch (Throwable throwable) {
            LOG.error("SubWork error: " + throwable.getMessage());
        }
        return null;
    }
}
