package com.intellif.cloud.personfile.manage.model.vo.snap;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;

/**
 * @author liuyu
 * @className SnapMapVO
 * @date 2019/3/19 19:18
 * @description
 */
@Data
public class SnapMapVO implements Serializable {

    private static final long serialVersionUID = -9046388198620601557L;
    
    /**
     * 档案ID
     */
    private String aid;

    /**
     * 设备id
     */
    private String devId;
    /**
     * 设备位置
     */
    private String geoString;
    /**
     * 设备名称
     */
    private String devName;
    /**
     * 小图id
     */
    private String faceId;
    /**
     * 小图地址
     */
    private String faceUrl;
    /**
     * 大图id
     */
    private String imageId;
    /**
     * 大图地址
     */
    private String imageUrl;
    /**
     * 人脸区域
     */
    private String targetRect;
    /**
     * 事件抓拍时间
     */
    private String snapTime;
    /**
     * 事件抓拍日期
     */
    private String snapDate;
    /**
     * 摄像头抓拍的数量
     */
    private Integer personFileCount;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
