package com.intellif.cloud.personfile.manage.entity;

/**
 * 人员档案的摄像头
 * 数据的表名为t_personfile_camera_info
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月17日
 * @see PersonfileCamera
 * @since JDK1.8
 */
public class PersonfileCamera implements java.io.Serializable {
    /**
     * 主键
     */
    private Long id;
    /**
     * 摄像头id
     */
    private String devId;
    /**
     * 操作类型:1:深目,2:基础服务 默认2
     */
    private Long opType;
    /**
     * 存放摄像头IP
     */
    private String ip;
    /**
     * 存放摄像头端口
     */
    private int port;
    /**
     * 摄像所属区域ID
     */
    private int areaId;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 更新时间
     */
    private String modifiedTime;
    /**
     * 经纬度
     */
    private String geoString;
    /**
     * 是否删除(0-未删除， 1-已删除)
     * 对应数据库的字段名: is_delete
     */
    private Integer deleteStatus;
    /**
     * 摄像头名字
     */
    private String name;
    /**
     * 设备类型
     */
    private String deviceType;
    /**
     * 创建人登录账号
     */
    private String creater;
    /**
     * 修改人账号
     */
    private String modifier;
    /**
     * 摄像头状态：1-有效 0-无效
     */
    private Integer status;

    public PersonfileCamera() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getAreaId() {
        return areaId;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getGeoString() {
        return geoString;
    }

    public void setGeoString(String geoString) {
        this.geoString = geoString;
    }

    public int getDeleteStatus() {
        return deleteStatus;
    }

    public void setDeleteStatus(int deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getDevId() {
        return devId;
    }

    public void setDevId(String devId) {
        this.devId = devId;
    }

    public Long getOpType() {
        return opType;
    }

    public void setOpType(Long opType) {
        this.opType = opType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
