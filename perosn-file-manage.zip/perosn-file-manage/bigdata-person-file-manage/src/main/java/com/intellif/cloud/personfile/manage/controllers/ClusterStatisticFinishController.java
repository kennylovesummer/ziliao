package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @author liuyu
 * @className clusterStatisticFinishController
 * @date 2019/4/12 10:48
 * @description
 */
@Api(tags = "档案统计")
@Deprecated
@RestController
@RequestMapping(value = IPersonfilesManageConstant.BaseUrl.RESOURCE_BASE)
public class ClusterStatisticFinishController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final MqMessageHandle mqMessageHandle;

    @Autowired
    public ClusterStatisticFinishController(MqMessageHandle mqMessageHandle) {
        this.mqMessageHandle = mqMessageHandle;
    }

    @PostMapping("/clusterStatisticFinish/{version}")
    public BaseDataRespDTO clusterStatisticFinish() {
        try {
            for (int i = 0;i <= 1;i++) {
                ThreadPoolService.threadPool.execute(new PersonFileStatisticWork(mqMessageHandle,i));
            }
            
        } catch (Exception e) {
            logger.error("归档统计异常：", e.getMessage());
            return new BaseDataRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "归档统计失败");
        }
        return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.EXECUTE_SUCCESS.getMessage());
    }
    
    
    class PersonFileStatisticWork implements Runnable {
        
        private MqMessageHandle mqMessageHandle;
        
        private Integer preDayNum;
        
        public PersonFileStatisticWork(MqMessageHandle mqMessageHandle, Integer preDayNum) {
            this.mqMessageHandle = mqMessageHandle;
            this.preDayNum = preDayNum;
        }
    
        @Override
        public void run() {
            try {
                mqMessageHandle.clusterStatisticFinish(DeepDateUtil.dateToString(DateUtils.addDays(new Date(),- preDayNum)),DeepDateUtil.dateToString(DateUtils.addDays(new Date(),-preDayNum)) + ICommonConstant.DateStr.START_TIME,DeepDateUtil.dateToString(DateUtils.addDays(new Date(),-preDayNum)) + ICommonConstant.DateStr.END_TIME);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
