package com.intellif.cloud.personfile.manage.model.vo.crash;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

/**
 * 碰撞结果返回数据集
 *
 * @author liuzj
 * @date 2019-06-29
 */
@Data
public class CrashResultVO {

    @JSONField(name = "aid")
    private String personFileId;
    
    private String personName;
    
    @JSONField(name = "eventNum")
    private Integer imageCount;
    
    private String cid;
    
    private String currAddr;
    
    private String faceUrl;
    
    private String taskId;
    
}
