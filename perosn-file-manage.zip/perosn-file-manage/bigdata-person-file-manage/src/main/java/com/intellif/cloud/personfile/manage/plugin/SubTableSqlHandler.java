package com.intellif.cloud.personfile.manage.plugin;

import com.google.common.base.Strings;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.plugin.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.Properties;

/**
 * 动态定位表
 *
 * @author liuzj
 * @date 2018-12-26
 * <p>
 * MyBatis 允许使用插件来拦截的方法有一下一些：
 * 1.Executor (update, query, flushStatements, commit, rollback,getTransaction, close, isClosed)
 * 2.ParameterHandler (getParameterObject, setParameters)
 * 3.ResultSetHandler (handleResultSets, handleOutputParameters)
 * 4.StatementHandler (prepare, parameterize, batch, update, query)
 */
@Intercepts({@Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class})})
public class SubTableSqlHandler implements Interceptor {
    
    Logger logger = LoggerFactory.getLogger(SubTableSqlHandler.class);
    
    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        StatementHandler handler = (StatementHandler) invocation.getTarget();
        BoundSql boundSql = handler.getBoundSql();
        String sql = boundSql.getSql();
        // 修改 sql
        if (!Strings.isNullOrEmpty(sql) && !Strings.isNullOrEmpty(ThreadLocalUtil.getSubTableName()) && sql.contains(ThreadLocalUtil.getTableName())) {
            if (!sql.contains("t_bigdata_archive_label_record") || ((sql.contains("JOIN") || sql.contains("join")))) {
                Field sqlField = boundSql.getClass().getDeclaredField("sql");
                sqlField.setAccessible(true);
                String subTableName = ThreadLocalUtil.getSubTableName();
                String tableName = ThreadLocalUtil.getTableName();
                sqlField.set(boundSql, sql.replaceAll(tableName, subTableName));
                if (((sql.contains("JOIN") || sql.contains("join")))) {
                    sqlField.set(boundSql, sql.replaceFirst(tableName, subTableName));
                    if (sql.contains("t_bigdata_avatar_info")) {
                        sqlField.set(boundSql, sql.replaceFirst(tableName, subTableName).replaceFirst("t_bigdata_avatar_info", "t_bigdata_avatar_info_" + subTableName.substring(subTableName.length() - 1)));
                    }
                }
            }
            if (ThreadLocalUtil.needClear() == null) {
                ThreadLocalUtil.removeSubTableName();
                ThreadLocalUtil.remove();
            }
        }
        
        return invocation.proceed();
    }
    
    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }
    
    @Override
    public void setProperties(Properties properties) {
    }
}
