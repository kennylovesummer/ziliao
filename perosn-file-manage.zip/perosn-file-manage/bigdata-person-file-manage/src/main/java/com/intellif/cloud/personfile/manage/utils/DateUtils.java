package com.intellif.cloud.personfile.manage.utils;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * 时间工具类
 *
 * @author liuzj
 * @date 2019-05-29
 */
public class DateUtils {
    
    /**
     * 获取一周第一天
     *
     * @param year 年
     * @param week 第几周
     * @return String
     */
    public static String getFirstDayOfWeek(int year, int week) {
        Calendar c = new GregorianCalendar();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, Calendar.JANUARY);
        c.set(Calendar.DATE, 1);
        
        Calendar cal = (GregorianCalendar) c.clone();
        cal.add(Calendar.DATE, week * 7);
        
        return DateFormatUtils.format(getFirstDayOfWeek(cal.getTime()),"MM-dd");
    }
    
    /**
     * 获取一周最后一天
     *
     * @param year 年
     * @param week 第几周
     * @return String
     */
    public static String getLastDayOfWeek(int year, int week) {
        Calendar c = new GregorianCalendar();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, Calendar.JANUARY);
        c.set(Calendar.DATE, 1);
        
        Calendar cal = (GregorianCalendar) c.clone();
        cal.add(Calendar.DATE, week * 7);
        
        return DateFormatUtils.format(getLastDayOfWeek(cal.getTime()),"MM-dd");
    }
    
    /**
     * 获取一周第一天
     *
     * @param date 日期
     * @return Date
     */
    public static Date getFirstDayOfWeek(Date date) {
        Calendar c = new GregorianCalendar();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setTime(date);
        c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek());
        return c.getTime();
    }
    
    /**
     * 获取一周第一天
     *
     * @param date 日期
     * @return Date
     */
    public static Date getLastDayOfWeek(Date date) {
        Calendar c = new GregorianCalendar();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setTime(date);
        c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek() + 6);
        return c.getTime();
    }
    
    /**
     * 将时间戳转为日期时间戳
     *
     * @param time 时间
     * @return
     * @throws ParseException
     */
    public static Long getDate(Long time){
        if (time == null) {
            return 0L;
        }
        String date = DateFormatUtils.format(time, ICommonConstant.DateFormatType.Y_M_D);
        String[] formatType = {ICommonConstant.DateFormatType.Y_M_D};
        try {
            return org.apache.commons.lang3.time.DateUtils.parseDate(date,formatType).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0L;
        }
    }
}
