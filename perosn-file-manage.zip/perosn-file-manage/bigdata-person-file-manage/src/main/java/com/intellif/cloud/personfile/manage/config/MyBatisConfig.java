/*
 * 文件名：MyBatisConfig.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月8日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.config;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import com.intellif.cloud.personfile.manage.enums.DBTypeEnum;
import com.intellif.cloud.personfile.manage.plugin.SqlCostTimeMonitor;
import com.intellif.cloud.personfile.manage.plugin.SubTableSqlHandler;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableApolloConfig("application")
public class MyBatisConfig {
    
    @Value("${mybatis.config-location}")
    private String configLocation;
    
    
    @Value("${mybatis.mapper-locations}")
    private String mapperLocations;
    
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource.master")
    public DataSource masterDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean
    @ConfigurationProperties("spring.datasource.slave")
    public DataSource slaveDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    @Bean
    public DataSource myRoutingDataSource(@Qualifier("masterDataSource") DataSource masterDataSource,
                                          @Qualifier("slaveDataSource") DataSource slaveDataSource) {
        Map<Object, Object> targetDataSources = new HashMap<>(2);
        targetDataSources.put(DBTypeEnum.master, masterDataSource);
        targetDataSources.put(DBTypeEnum.slave, slaveDataSource);
        MyRoutingDataSource myRoutingDataSource = new MyRoutingDataSource();
        myRoutingDataSource.setDefaultTargetDataSource(masterDataSource);
        myRoutingDataSource.setTargetDataSources(targetDataSources);
        return myRoutingDataSource;
    }
    
    /**
     * @Title: sqlSessionFactory @Description:
     * 根据数据源创建SqlSessionFactory @param @param ds @param @return @param @throws
     * Exception @return SqlSessionFactory @throws
     */
    @Bean
    public SqlSessionFactory sqlSessionFactory(@Qualifier("myRoutingDataSource") DataSource myRoutingDataSource) throws Exception {
        SqlSessionFactoryBean sfb = new SqlSessionFactoryBean();
        sfb.setDataSource(myRoutingDataSource);
        PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver();
        sfb.setConfigLocation(
                pathMatchingResourcePatternResolver.getResource(configLocation));
        // 下边两句仅仅用于*.xml文件，如果整个持久层操作不需要使用到xml文件的话（只用注解就可以搞定），则不加
        sfb.setMapperLocations(
                pathMatchingResourcePatternResolver.getResources(mapperLocations));
        Interceptor[] plugins = {new SubTableSqlHandler()};
        sfb.setPlugins(plugins);
        return sfb.getObject();
    }

//	@Bean
//	public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
//		SqlSessionFactoryBean sfb = new SqlSessionFactoryBean();
//		sfb.setDataSource(dataSource);
//		PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver();
//		sfb.setConfigLocation(
//				pathMatchingResourcePatternResolver.getResource(configLocation));
//		// 下边两句仅仅用于*.xml文件，如果整个持久层操作不需要使用到xml文件的话（只用注解就可以搞定），则不加
//		sfb.setMapperLocations(
//				pathMatchingResourcePatternResolver.getResources(mapperLocations));
//		Interceptor[] plugins = {new SqlCostTimeMonitor(),new SubTableSqlHandler()};
//		sfb.setPlugins(plugins);
//		return sfb.getObject();
//	}
    
    /**
     * @Title: sqlSessionFactory @Description:
     * 根据数据源创建SqlSessionFactory @param @param ds @param @return @param @throws
     * Exception @return SqlSessionFactory @throws
     */
    @Bean
    public SqlSessionTemplate sqlSession(SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
    
    
}
