package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisActivity;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisActivityService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @see BigdataAnalysisActivityService
 * @author liuzj
 */
@Service
public class BigdataAnalysisActivityServiceImpl extends BaseServiceImpl implements BigdataAnalysisActivityService {
    
    private static final BigdataAnalysisActivity BIGDATA_ANALYSIS_ACTIVITY = new BigdataAnalysisActivity();
    
    
    @Override
    public BigdataAnalysisActivity findAnalysisActivityByTaskId(Long taskId) {
        if (taskId != null) {
            QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("taskId", taskId);
            queryEvent.setParameter(parameters);
            queryEvent.setStatement("findAnalysisActivityByTaskId");
            Object object = this.baseDao.findOneByCustom(queryEvent);
            return object == null ? null : (BigdataAnalysisActivity) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisActivityByTaskId(Long taskId) {
        if (taskId != null) {
            BigdataAnalysisActivity bigdataAnalysisActivity = new BigdataAnalysisActivity();
            bigdataAnalysisActivity.setTaskId(taskId);
            this.baseDao.delete(bigdataAnalysisActivity);
        }
    }
    
    @Override
    public Long insertAnalysisActivity(BigdataAnalysisActivity bigdataAnalysisActivity) {
        if (bigdataAnalysisActivity != null) {
            bigdataAnalysisActivity.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisActivity.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisActivity);
        return bigdataAnalysisActivity.getId();
    }
    
    @Override
    public void batchInsertAnalysisActivity(List<BigdataAnalysisActivity> analysisActivities) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_ACTIVITY,null,analysisActivities);
    }
    
    @Override
    public void updateAnalysisActivity(BigdataAnalysisActivity bigdataAnalysisActivity) {
        this.baseDao.update(bigdataAnalysisActivity);
    }
    
    @Override
    public Page<BigdataAnalysisActivity> findAnalysisActivityByParams(AnalysisDTO analysisDTO) {
        QueryEvent<AnalysisDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(analysisDTO);
        queryEvent.setStatement("findAnalysisActivityByParams");
    
        Page<BigdataAnalysisActivity> page = PageHelper.startPage(analysisDTO.getPage(), analysisDTO.getPerpage(),analysisDTO.getOrderBy());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
}
