package com.intellif.cloud.personfile.manage.contants;


/**
 * 常量定义
 *
 * @author liuzhijian
 */
public interface IPersonfilesStatisticsConstant extends IPersonFilesConstant {

    /**
     * redis key 的定义
     */
    interface IRedisCacheKey {
        /**
         *  人员档案的档案hash key
         *  避免数据平台发送的kafka重复消费
         */
        String PERSONFILES_ARCHIVE="personfiles_archive";
    }
    interface BaseUrl {

        /**
         * 一人一档的人员档案统计模块基础地址
         */
        String RESOURCE_BASE = "personfile/statistic";
    }

    /**
     * 请求地址
     */
    interface RequestUrl {
        /**
         * 人员类型
         */
        String PERSON_TYPE = BaseUrl.RESOURCE_BASE + "/persontype";

        /**
         * 年龄分布
         */
        String PERSON_AGE = BaseUrl.RESOURCE_BASE + "/personage";

        /**
         * 事件日统
         */
        String PERSON_EVENT = BaseUrl.RESOURCE_BASE + "/event";
    }


}
