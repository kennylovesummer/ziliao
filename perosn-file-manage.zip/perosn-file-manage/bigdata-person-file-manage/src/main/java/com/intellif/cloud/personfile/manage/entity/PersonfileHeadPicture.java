package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;

import java.io.Serializable;
import java.util.Date;

public class PersonfileHeadPicture implements Serializable {

	private static final long serialVersionUID = 5345200852273087943L;

	private Long id;

    private Date createTime = new Date();

    private String creater = IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME;

    private Date modifiedTime = new Date();

    private String modifier = IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME;

    /**
     * 档案ID
     */
    private String personFilesId;

    /**
     * 特征值
     */
    private byte[] featureInfo;

    /**
     * 大图地址
     */
    private String bigImageUrl;

    /**
     * 小图地址
     */
    private String smallImageUrl;

    /**
     * 人脸框
     */
    private String targetRect;
    
    private Date personFileCreateTime;
    
    private String tableName;
    
    public String getTableName() {
        return tableName;
    }
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public Date getPersonFileCreateTime() {
        return personFileCreateTime;
    }
    
    public void setPersonFileCreateTime(Date personFileCreateTime) {
        this.personFileCreateTime = personFileCreateTime;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getPersonFilesId() {
        return personFilesId;
    }

    public void setPersonFilesId(String personFilesId) {
        this.personFilesId = personFilesId;
    }

    public byte[] getFeatureInfo() {
        return featureInfo;
    }

    public void setFeatureInfo(byte[] featureInfo) {
        this.featureInfo = featureInfo;
    }

    public String getBigImageUrl() {
        return bigImageUrl;
    }

    public void setBigImageUrl(String bigImageUrl) {
        this.bigImageUrl = bigImageUrl;
    }

    public String getSmallImageUrl() {
        return smallImageUrl;
    }

    public void setSmallImageUrl(String smallImageUrl) {
        this.smallImageUrl = smallImageUrl;
    }

    public String getTargetRect() {
        return targetRect;
    }

    public void setTargetRect(String targetRect) {
        this.targetRect = targetRect;
    }

    @Override
    public String toString()
    {
    	return JSONObject.toJSONString(this);
    }
}