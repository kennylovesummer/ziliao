package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTrace;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.TraceDTO;

import java.util.List;

/**
 * 数据分析档案
 *
 * @author liuzj
 * @date 2019-07-18
 */
public interface BigdataAnalysisTraceService {
    
    /**
     * 根据ID查找
     *
     * @param id ID
     * @return entity
     */
    BigdataAnalysisTrace findAnalysisTraceById(Long id);
    
    /**
     * 根据ID删除对象
     *
     * @param bigdataAnalysisTrace 要删除的对象
     */
    void deleteAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisTrace 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace);
    
    /**
     * 批量插入
     *
     * @param traceList 数据集
     */
    void batchInsertAnalysisTrace(List<BigdataAnalysisTrace> traceList);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisTrace 待更新的对象
     */
    void updateAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace);
    
    /**
     * 分页查找
     *
     * @param traceDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisTrace> findAnalysisTraceByParams(TraceDTO traceDTO);
    
    /**
     * 分页查找轨迹结果
     *
     * @param taskId 任务ID
     * @return List
     */
    Page<Long> findAnalysisTraceByPage(Long taskId,Integer pageNo,Integer pageSize);
    
    /**
     * 根据任务ID删除
     *
     * @param taskId 任务ID
     */
    void deleteBigdataAnalysisTraceByTaskId(Long taskId);
    
    Long findCameraToal(Long taskId);
    
    Long findEventToal(Long taskId);
}
