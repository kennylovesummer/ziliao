/*
 * 文件名：IDevSynchronizeService.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：  设备列表同步
 * 创建人：tianhao
 * 创建时间：2018年10月17日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;

/**
 * 设备列表同步接口类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月17日
 * @see IDevSynchronizeService
 * @since JDK1.8
 */
public interface IDevSynchronizeService {
    /**
     * 设备同步
     * @return
     */
    BaseDataRespDTO devSynchDeepEye();
}








