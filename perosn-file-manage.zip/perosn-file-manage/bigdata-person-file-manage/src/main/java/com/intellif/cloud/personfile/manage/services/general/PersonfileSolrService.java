package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import org.apache.solr.client.solrj.SolrServerException;

import java.io.IOException;
import java.util.List;

/**
 * 特征值搜索
 *
 * @author liuzj
 * @date 2019-03-15
 */
public interface PersonfileSolrService {

    /**
     * 根据特征值搜索
     *
     * @param listFilterDTO 对象
     * @throws Exception 异常
     */
    void findByFeature(ListFilterDTO listFilterDTO) throws Exception;

    /**
     * 将数据导入到solr中
     *
     * @param personfileClusterFinishDTOList 导入的数据
     */
    void insert(List<PersonfileClusterFinishDTO> personfileClusterFinishDTOList);

    /**
     * 删除档案
     *
     * @param personfileId 档案ID
     * @throws IOException
     * @throws SolrServerException
     */
    void deleteByPersonfileId(String personfileId) throws IOException, SolrServerException;
}
