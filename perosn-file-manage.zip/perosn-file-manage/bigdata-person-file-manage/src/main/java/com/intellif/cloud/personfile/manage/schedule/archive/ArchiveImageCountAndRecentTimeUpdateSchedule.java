package com.intellif.cloud.personfile.manage.schedule.archive;

import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.log.LoggerUtilI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @author liuyu
 * @className PersonfileScheduleJob
 * @date 2019/4/23 16:43
 * @description
 */
@Component
public class ArchiveImageCountAndRecentTimeUpdateSchedule {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    /**
     * 抓拍照片数和最新抓拍时间
     */
    @Scheduled(cron = "0 */30 * * * ?")
    public void getImageCountAndSnapTime() {
        try {
            logger.info("抓拍照片数和最新抓拍时间定时任务开始...");
            subArchiveService.statisticImageCountAndGetRecentSnapTime();
            logger.info("抓拍照片数和最新抓拍时间定时任务结束。");
        } catch (Exception e) {
            e.printStackTrace();
//            logger.info("抓拍照片数和最新抓拍时间定时任务失败:", e.getMessage());
        }
    }
}
