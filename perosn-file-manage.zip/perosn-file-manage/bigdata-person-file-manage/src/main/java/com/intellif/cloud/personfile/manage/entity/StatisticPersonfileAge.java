package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName StatisticPersonfileAge
 * @Author liuzhijian
 * @create 2018-10-20
 * @Version 1.0
 * @desc 档案年龄情况统计
 */
public class StatisticPersonfileAge implements Serializable {

    private static final long serialVersionUID = 7406803135893653589L;

    private Integer id;

    private Date createTime;

    private Date modifiedTime;

    private Integer personFileAgeId;

    private String personFileAgeName;

    private Long personFileAgeNum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public Integer getPersonFileAgeId() {
        return personFileAgeId;
    }

    public void setPersonFileAgeId(Integer personFileAgeId) {
        this.personFileAgeId = personFileAgeId;
    }

    public String getPersonFileAgeName() {
        return personFileAgeName;
    }

    public void setPersonFileAgeName(String personFileAgeName) {
        this.personFileAgeName = personFileAgeName == null ? null : personFileAgeName.trim();
    }

    public Long getPersonFileAgeNum() {
        return personFileAgeNum;
    }

    public void setPersonFileAgeNum(Long personFileAgeNum) {
        this.personFileAgeNum = personFileAgeNum;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}