package com.intellif.cloud.personfile.manage.services.account;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.model.dto.account.AccountDTO;

/**
 * 用户
 *
 * @author admin
 * @date 2019-08-26
 */
public interface BigdataAccountService {
    
    /**
     * 根据ID查找记录
     *
     * @param id ID
     * @return BigdataAccount
     */
    BigdataAccount findBigdataAccountById(Long id);
    
    /**
     * 插入
     *
     * @param account 待插入记录
     * @return int
     */
    int insertBigdataAccount(BigdataAccount account);
    
    /**
     * 真刪除
     *
     * @param id 记录ID
     * @return int
     */
    int deleteBigdataAccountById(Long id);
    
    /**
     * 伪删除
     *
     * @param id 记录ID
     * @return int
     */
    int deleteById(Long id);
    
    /**
     * 更新
     *
     * @param account 待更新记录
     * @return int
     */
    int updateBigdataAccount(BigdataAccount account);
    
    /**
     * 分页查询
     *
     * @param accountDTO 参数集
     * @return List
     */
    Page<BigdataAccount> findBigdataAccountByPage(AccountDTO accountDTO);
    
    /**
     * 根据账号密码查找用户
     *
     * @param accountDTO 参数集
     * @return BigdataAccount
     */
    BigdataAccount findBigdataAccountByAccountAndPassword(AccountDTO accountDTO);
}