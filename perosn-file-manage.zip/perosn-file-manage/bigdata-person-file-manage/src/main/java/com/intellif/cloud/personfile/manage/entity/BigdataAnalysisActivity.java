package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 活动规律分析业务表
 *
 * @author liuzj
 * @date 2019-10-22
 */
@Data
public class BigdataAnalysisActivity implements Serializable {
    
    private Long id;

    private Long taskId;
    
    private String aid;

    private String sourceId;

    private String periods;

    private Long imageCount;

    private String site;

    private Date createTime;

    private String createBy;

    private Date modifyTime;

    private String modifyBy;

}