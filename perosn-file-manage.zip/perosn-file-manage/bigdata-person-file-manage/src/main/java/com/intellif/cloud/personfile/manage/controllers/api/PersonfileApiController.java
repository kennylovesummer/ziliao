package com.intellif.cloud.personfile.manage.controllers.api;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileApiDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import com.intellif.cloud.personfile.manage.utils.FileUtils;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.commons.util.RegExpUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Base64;
import java.util.UUID;

/**
 * 对外提供的接口
 *
 * @author liuzj
 * @date 2019-05-16
 */
@Api(tags = "以图搜档接口（对外）")
@RestController
@RequestMapping("api/archive")
public class PersonfileApiController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private static final String URL = "url";
    
    private static final String DATA = "data";
    
    private static final String REG = "^(([^0][0-9]+|0)\\.([0-9]{1,2})$)|^([^0][0-9]+|0|1|1.0|1.00)$";
    
    private final PersonPropertiest personPropertiest;
    
    private final DeepEyeService deepEyeService;
    
    private final PersonfileSolrService personfileSolrService;
    
    private final XdataFeignClient xdataFeignClient;
    
    @Autowired
    public PersonfileApiController(PersonPropertiest personPropertiest,
                                   DeepEyeService deepEyeService,
                                   PersonfileSolrService personfileSolrService,
                                   XdataFeignClient xdataFeignClient) {
        this.personPropertiest = personPropertiest;
        this.deepEyeService = deepEyeService;
        this.xdataFeignClient = xdataFeignClient;
        this.personfileSolrService = personfileSolrService;
    }
    
    /**
     * 以图搜档
     *
     * @param personfileApiDTO 参数集合
     * @return BasePageRespDTO
     */
    @ApiOperation(value = "以图搜档", httpMethod = "POST")
    @PostMapping(value = "image")
    public BaseDataRespDTO findByImage(@RequestBody @Valid PersonfileApiDTO personfileApiDTO, BindingResult bindingResult) {
        UUID uuid = null;
        try {
            // 入参校验
            if (bindingResult.hasErrors()) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), bindingResult.getFieldError().getDefaultMessage());
            }
            if (personfileApiDTO.getSimilarity() == null || !RegExpUtil.isMatche(personfileApiDTO.getSimilarity() + "", REG)) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "【similarity】不能为空且取值范围为[0,1],最多保留两位小数");
            }
            
            // 判断传入的参数是url还是图片数据，如果是url则直接传入结构化引擎获取特征值，否则先将图片存到本地然后通过url获取特征值
            String imageUrl;
            if (URL.equalsIgnoreCase(personfileApiDTO.getImageType())) {
                imageUrl = personfileApiDTO.getImage();
            } else if (DATA.equalsIgnoreCase(personfileApiDTO.getImageType())) {
                // 将图片存储到本地
                uuid = UUID.randomUUID();
                FileUtils.saveFileToLocal(Base64.getDecoder().decode(personfileApiDTO.getImage()), null,"/person-file-manage-api-" + uuid + ".jpg");
                // 获取服务器IP,使用配置文件配置的IP或者使用本地IP
                String ip = "";
                if (personPropertiest.getPersonfileFilterIpLocalhost() == 1) {
                    InetAddress addr;
                    try {
                        addr = InetAddress.getLocalHost();
                        ip = addr.getHostAddress();
                    } catch (UnknownHostException e) {
                        logger.error("获取本地ip异常：" + e.getMessage());
                    }
                    
                } else {
                    ip = personPropertiest.getIp();
                }
                StringBuilder url = new StringBuilder();
                url.append("http://").
                        append(ip).
                        append(":").
                        append(personPropertiest.getPersonfileFilterPort()).
                        append("/personfile/manage/image/api/image/").
                        append(uuid);
                
                imageUrl = url.toString();
            } else {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "参数【imageType】异常,只能是url或data");
            }
            
            // 从引擎获取特征值
            String feature = deepEyeService.getFeatureFromEngineByUrl(imageUrl);
            if (Strings.isBlank(feature)) {
                return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            // 从solr搜索相似档案
            ListFilterDTO listFilterDTO = new ListFilterDTO();
            listFilterDTO.setFeature(feature);
            listFilterDTO.setSimilarRate(personfileApiDTO.getSimilarity());
            personfileSolrService.findByFeature(listFilterDTO);
            if (CollectionUtils.isEmpty(listFilterDTO.getSimilars())) {
                return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            
            // 从数据平台获取档案详情
            XdataReqDTO xdataReqDTO = new XdataReqDTO();
            xdataReqDTO.setAid(listFilterDTO.getPersonFileIds().get(0));
            xdataReqDTO.setDbName(personPropertiest.getPersonFileDBName2());
            String result = xdataFeignClient.getPersonfileById(xdataReqDTO);
            if (Strings.isNotBlank(result) && SuccessRespUtil.isSuccess(JSONObject.parseObject(result))) {
                return new BaseDataRespDTO(JSONObject.parseObject(result).get(DATA), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(), "查询成功");
            } else {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "查询异常");
            }
        } catch (Exception e) {
            logger.error("以图搜档异常：" + e.getMessage());
            return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "服务异常");
        } finally {
            if (uuid != null) {
                FileUtils.deleteFileByPath("/person-file-manage-api-" + uuid + ".jpg");
            }
        }
    }
}
