/*
 * 文件名：BaseRespDTO.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月10日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.model.dto.req;

import com.alibaba.fastjson.JSONObject;

public class BaseDataRespDTO extends BaseResp {
	/**
	 *
	 */
	private static final long serialVersionUID = -2481981050895084529L;

	private Object data;

	private String respMark;

	public BaseDataRespDTO(Object data) {
		this.data = data;
	}

	public BaseDataRespDTO() {
		super();
	}

	public BaseDataRespDTO(int respCode) {
		super.setRespCode(respCode);
	}

	public BaseDataRespDTO(int respCode, String description) {
		super.setRespCode(respCode);
		super.setRespMessage(description);
	}

	public BaseDataRespDTO(Object data, int respCode, String description) {
		this.data = data;
		super.setRespCode(respCode);
		super.setRespMessage(description);
	}

	public BaseDataRespDTO(Object data, int respCode, String description, String respMark) {
		this.data = data;
		super.setRespCode(respCode);
		super.setRespMessage(description);
		this.respMark = respMark;
	}

	public BaseDataRespDTO(int respCode, String description, String respMark) {
		super.setRespCode(respCode);
		super.setRespMessage(description);
		this.respMark = respMark;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getRespMark() {
		return respMark;
	}

	public void setRespMark(String respMark) {
		this.respMark = respMark;
	}

	/**
	 * 得到属性字符串
	 *
	 * @return String 属性字符串
	 */
	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}

}
