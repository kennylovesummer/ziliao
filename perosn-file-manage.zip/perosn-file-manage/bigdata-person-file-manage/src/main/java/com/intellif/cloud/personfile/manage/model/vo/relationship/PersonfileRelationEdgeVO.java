package com.intellif.cloud.personfile.manage.model.vo.relationship;

import com.alibaba.fastjson.JSONObject;
import org.apache.logging.log4j.util.Strings;

import java.io.Serializable;

/**
 * 关系图谱-边
 *
 * @author liuzj
 * @date 2019-04-13
 */
public class PersonfileRelationEdgeVO  implements Serializable {

    private String fromId;

    private String targetId;

    private String label;

    private String labelName;

    private String direction;

    private String weight;

    private Object props;

    private String createTime;

    private String modifyTime;

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelName() {
        return labelName;
    }

    public void setLabelName(String labelName) {
        this.labelName = labelName;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Object getProps() {
        return props;
    }

    public void setProps(String props) {
        if (Strings.isNotBlank(props)) {
            this.props = JSONObject.parse(props);
        }
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }
}
