package com.intellif.cloud.personfile.manage.services.datastistic.impl;

import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileEvent;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.log.LoggerUtilI;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 抓拍日統接口实现类
 *
 * @author liuzj
 * @version 1.0
 * @date 2019年05月24日
 * @see StatisticPersonfileEventServiceImpl
 * @since JDK1.8
 */
@Service
public class StatisticPersonfileEventServiceImpl extends BaseServiceImpl implements StatisticPersonfileEventService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Override
    public int insertStatisticPersonfileEvent(StatisticPersonfileEvent statisticPersonfileEvent) {
        return this.baseDao.insert(statisticPersonfileEvent);
    }
    
    @Override
    public List<StatisticPersonfileEvent> findStatisticEventDailyByDate(String startTime, String endTime) {
        QueryEvent<StatisticPersonfileFlow> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(2);
        parameters.put("startTime", startTime);
        parameters.put("endTime", endTime);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findStatisticEventDailyByDate");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (List<StatisticPersonfileEvent>) object : Lists.newArrayList();
    }
    
    @Override
    public Integer statisticEvent() {
        QueryEvent<StatisticPersonfileFlow> queryEvent = new QueryEvent<>();
        queryEvent.setStatement("statisticEvent");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object != null ? (Integer) object : 0;
    }
    
    @Override
    public void updateStatisticEvent(Integer incNum, String dt) {
        HashMap<String, Object> params = new HashMap<>(2);
        params.put("incNum", incNum);
        params.put("dt", dt);
        this.baseDao.updateStatement("updateStatisticEvent",params);
    }
}
