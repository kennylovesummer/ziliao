/*
 * 文件名：IPersonfilesConstant.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：admin
 * 创建时间：2018年10月15日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.contants;


/**
 * 常量定义
 * 〈功能详细描述〉
 *
 * @author wangyi
 * @version 1.0
 * @date 2018年11月15日
 * @see IPersonfilesManageConstant
 * @since JDK1.8
 */
public interface IPersonfilesManageConstant extends IPersonFilesConstant {
    
    /**
     * redis key
     * 〈功能详细描述〉
     *
     * @author admin
     * @version 1.0
     * @date 2018年10月15日
     * @see IRedisCacheKey
     * @since JDK1.8
     */
    interface IRedisCacheKey {
        
        /**
         * 相似度阈值配置
         */
        String PERSONFILES_SIMILAR_RATE = "personfiles_similar_rate";
    }
    
    interface BaseUrl {
        
        /**
         * 一人一档的人员档案模块基础地址
         */
        String RESOURCE_BASE = "personfile/manage";
    }
    
    /**
     * 请求地址
     */
    interface RequestUrl {
        /**
         * 档案详情->事件流
         */
        String EVENTFLOW = BaseUrl.RESOURCE_BASE + "/eventflow";
        /**
         * 档案详情->事件流->事件类型
         */
        String EVENTFLOW_TYPE = BaseUrl.RESOURCE_BASE + "/eventflow/eventype";
        /**
         * 档案详情->人际关系
         */
        String RELATIONSHIPS = BaseUrl.RESOURCE_BASE + "/relationships";
        /**
         * 档案详情->活动规律
         */
        String ACTIVITYROUTINES = BaseUrl.RESOURCE_BASE + "/activityroutines";
        /**
         * 档案详情->回收站
         */
        String RUBBISH = BaseUrl.RESOURCE_BASE + "/rubbish";
        /**
         * 档案详情->标签
         */
        String LABEL = BaseUrl.RESOURCE_BASE + "/label";
        /**
         * 档案详情->设备
         */
        String CAMERA_BASE_URL = BaseUrl.RESOURCE_BASE + "/camera";
        
        /**
         * 档案详情->关注
         */
        String CONCERN = BaseUrl.RESOURCE_BASE + "/focus";
        /**
         * 档案中心->列表
         */
        String LIST = BaseUrl.RESOURCE_BASE + "/list";
        /**
         * 档案中心->列表
         */
        String HIT = BaseUrl.RESOURCE_BASE + "/hit";
        /**
         * 档案首页->地图
         */
        String MAP = BaseUrl.RESOURCE_BASE + "/map";
        /**
         * 档案首页->图片
         */
        String IMAGE = BaseUrl.RESOURCE_BASE + "/image";
    
        /**
         * 数据分析->轨迹
         */
        String TRACE = BaseUrl.RESOURCE_BASE + "/trace";
    
        /**
         * 数据分析->同行
         */
        String PEER = BaseUrl.RESOURCE_BASE + "/peer";
    
        /**
         * 数据分析->徘徊
         */
        String LINGER = BaseUrl.RESOURCE_BASE + "/linger";
    
        /**
         * 数据分析->活动规律
         */
        String ACTIVITY = BaseUrl.RESOURCE_BASE + "/activity";
    
        /**
         * 数据分析->碰撞
         */
        String CRASH = BaseUrl.RESOURCE_BASE + "/crash";
    
        /**
         * 基础数据->摄像头列表
         */
        String CAMERA = BaseUrl.RESOURCE_BASE + "/camera";
    
        /**
         * 数据分析->任务
         */
        String ANALYSIS_TASK = BaseUrl.RESOURCE_BASE + "/analysis/task";
    
        /**
         * 在线数据分析->任务
         */
        String ANALYSIS_ONLINE_TASK = BaseUrl.RESOURCE_BASE + "/analysis/online/task";
    
        /**
         * 数据分析->任务结果下载
         */
        String ANALYSIS_DOWLOAD = BaseUrl.RESOURCE_BASE + "/analysis/download";
    
        /**
         * 登录->用户登录
         */
        String LOGIN = BaseUrl.RESOURCE_BASE + "/login";
    
        /**
         * 用户->用户管理
         */
        String ACCOUNT = BaseUrl.RESOURCE_BASE + "/account";
    
        /**
         * sso登录->柳州
         */
        String SSO_LIU_ZHOU = BaseUrl.RESOURCE_BASE + "/api";
    }
    
    /**
     * 当前默认用户
     */
    interface DefaultUser {
        String DEFAULT_USER_NAME = "superuser";
    }
    
}
