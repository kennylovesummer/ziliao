/*  
 * 文件名：GlobalExceptionHandler.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月21日    
 * 修改理由：  
 * 修改内容：  
 */  

package com.intellif.cloud.personfile.manage.exceptions;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.enums.ResultCodeEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ControllerAdvice
@Component
public class GlobalExceptionHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleException(Exception e){
    	BaseDataRespDTO respDTO = new BaseDataRespDTO(ResultCodeEnum.PARAM_ERROR.getResultCode());
        
    	logger.error(e.getMessage(), e);
     
        //Hibernate Validator验证消息返回
        BindingResult result = null;
        if (e instanceof MethodArgumentNotValidException){
            result = ((MethodArgumentNotValidException) e).getBindingResult();
        } else if (e instanceof BindException){
            result = ((BindException) e).getBindingResult();
        } else if (e instanceof ConstraintViolationException){
            Set<ConstraintViolation<?>> constraintViolations = ((ConstraintViolationException) e).getConstraintViolations();
            StringBuilder errorMsg = new StringBuilder();
            for (ConstraintViolation<?> violation : constraintViolations) {
                errorMsg.append(violation.getMessage()).append(",");
            }
            errorMsg.delete(errorMsg.length() - 1, errorMsg.length());
            respDTO.setRespMessage(errorMsg.toString());
            respDTO.setRespMark(errorMsg.toString());
            return JSONObject.toJSONString(respDTO);
            
            //业务异常
        } else if (e instanceof BusinessException){
        	BusinessException exception = (BusinessException) e;
        	respDTO.setRespCode(exception.getCode());
            respDTO.setRespMessage(exception.getExceptionMsg());
            respDTO.setRespMark(exception.getExceptionMsg());
            return JSONObject.toJSONString(respDTO);
        }
        if (result != null) {
            StringBuilder errorMsg = new StringBuilder();
            for (ObjectError error : result.getAllErrors()) {
                errorMsg.append(error.getDefaultMessage()).append(",");
            }
            errorMsg.delete(errorMsg.length() - 1, errorMsg.length());
            respDTO.setRespMessage(errorMsg.toString());
            respDTO.setRespMark(errorMsg.toString());
            return JSONObject.toJSONString(respDTO);
        }
        
        //未知异常
        respDTO.setRespCode(ResultCodeEnum.UNKOWN_ERROR.getResultCode());
        respDTO.setRespMessage(e.getMessage());
        respDTO.setRespMark(e.getMessage());
        return JSONObject.toJSONString(respDTO);
    }

}
