package com.intellif.cloud.personfile.manage.services.datastistic;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;

/**
 * @ClassName StatisticPersonfileFlowService
 * @Author liuzhijian
 * @create 2018-10-31
 * @Version 1.0
 * @desc 人员流动统计
 */
public interface StatisticPersonfileFlowService {
    
    /**
     * 新增
     *
     * @param statisticPersonfileFlow 待新增的实体
     * @return int
     */
    int insert(StatisticPersonfileFlow statisticPersonfileFlow);
    
    /**
     * 更新
     *
     * @param statisticPersonfileFlow 待更新的实体
     * @return int
     */
    int update(StatisticPersonfileFlow statisticPersonfileFlow);
    
    /**
     * 根据归档时间查询统计记录
     *
     * @param statisticDate 归档时间
     * @return StatisticPersonfileFlow
     */
    StatisticPersonfileFlow findByStatisticDate(String statisticDate);
    
}
