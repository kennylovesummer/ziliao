package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTrace;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.TraceDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTraceService;
import com.intellif.cloud.personfile.manage.utils.ListUtils;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;


/**
 * 轨迹分析
 *
 * @author lzj
 * @version 1.0
 * @date 2019年06月20日
 * @see TraceAnalysisController
 * @since JDK1.8
 */
@Api(tags = "数据分析-轨迹分析")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.TRACE)
public class TraceAnalysisController implements java.io.Serializable {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisTraceService bigdataAnalysisTraceService;
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    /**
     * 获取轨迹分析列表
     *
     * @param traceDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取轨迹分析人员列表")
    @PostMapping(value = "list")
    public BasePageRespDTO list(@RequestBody TraceDTO traceDTO) {
        try {
            // 参数校验
            if (traceDTO.getTaskId() == null) {
                return new BasePageRespDTO(null, 0,0, IResultCode.ERROR, "参数异常");
            }
    
            Page<Long> datePage = bigdataAnalysisTraceService.findAnalysisTraceByPage(traceDTO.getTaskId(),traceDTO.getPage(),traceDTO.getPerpage());
    
            List<Long> dates = datePage.getResult();
            if (CollectionUtils.isEmpty(dates)) {
                return new BasePageRespDTO(null, 0,0,IResultCode.SUCCESS, "暂无数据");
            }
    
            Collections.sort(dates);
    
            traceDTO.setStartDate(dates.get(0));
            traceDTO.setEndDate(dates.get(dates.size() - 1));
            traceDTO.setPerpage(0);
            Page<BigdataAnalysisTrace> tracePage = bigdataAnalysisTraceService.findAnalysisTraceByParams(traceDTO);
            List<BigdataAnalysisTrace> traceList = tracePage.getResult();
            Map<Long,List<BigdataAnalysisTrace>> traceGroupDate = traceList.stream().collect(Collectors.groupingBy(BigdataAnalysisTrace::getDate));
    
            List<Map<String,Object>> result = Lists.newLinkedList();
            EventDTO eventDTO = new EventDTO();
            eventDTO.setTaskId(traceDTO.getTaskId());
            
            Long cameraTotal = bigdataAnalysisTraceService.findCameraToal(traceDTO.getTaskId());
            Long evenetTotal = bigdataAnalysisTraceService.findEventToal(traceDTO.getTaskId());
            traceGroupDate.forEach((key,value)->{
                Map<String,Object> resultItem = Maps.newHashMap();
                resultItem.put("caremaCount",value.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(BigdataAnalysisTrace::getCameraId))), ArrayList::new)).size());
                resultItem.put("locusDate",key);
                resultItem.put("cameraTotal",cameraTotal);
                resultItem.put("evenetTotal",evenetTotal);
    
                List<Map<String,Object>> locusEventList = Lists.newArrayList();
                Map<String,Object> locusEvent;
                for (BigdataAnalysisTrace camera: value) {
                    locusEvent = Maps.newHashMap();
                    locusEvent.put("camera",camera);
                    
                    eventDTO.setDate(key);
                    eventDTO.setCameraId(camera.getCameraId());
                    eventDTO.setPerpage(0);
                    Map<String,Long> startTimeAndEndTime = bigdataAnalysisEventService.findMaxTimeAndMinTimeByParams(eventDTO);
    
                    locusEvent.put("startTime",startTimeAndEndTime.get("startTime"));
                    locusEvent.put("endTime",startTimeAndEndTime.get("endTime"));
                    locusEvent.put("imageCount",startTimeAndEndTime.get("imageCount"));
                    locusEventList.add(locusEvent);
                }
                resultItem.put("locusEventList",locusEventList);
                result.add(resultItem);
            });
    
            ListUtils.sort(result,"locusDate","desc");
            return new BasePageRespDTO(result, datePage.getPages(),Integer.parseInt(datePage.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
    
        } catch (Exception e){
            logger.error("轨迹结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    /**
     * 分页查询图片
     *
     * @param traceDTO 参数集合
     * @return BasePageRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取轨迹分析人员活动详情")
    @PostMapping(value = "image")
    public BasePageRespDTO image(@RequestBody TraceDTO traceDTO) {
        if (traceDTO.getTaskId() == null || traceDTO.getSnapDate() == null || Strings.isBlank(traceDTO.getCameraId())) {
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),"参数异常");
        }
        Page<BigdataAnalysisEvent> events = bigdataAnalysisEventService.findAnalysisEventByParams(traceDTO);
        if (CollectionUtils.isNotEmpty(events)) {
            return new BasePageRespDTO(events.getResult(), events.getPages(),Integer.parseInt(events.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        }
    
        return new BasePageRespDTO(null,0,0,IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(),"无数据");
    }
    
}
