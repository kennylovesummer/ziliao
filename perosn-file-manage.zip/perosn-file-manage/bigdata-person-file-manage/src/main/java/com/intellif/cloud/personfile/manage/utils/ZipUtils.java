package com.intellif.cloud.personfile.manage.utils;

import org.apache.logging.log4j.util.Strings;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * zip工具包
 *
 * @author liuzj
 * @date 2019-07-11
 */
public class ZipUtils {
    
    private static final Integer BUFFER_SIZE = 1024 * 1024 * 5;
    
    /**
     * 压缩并下载
     *
     * @param fileName 待压缩下载的文件
     * @param response HttpServletResponse
     * @param zipName 压缩包名字
     * @throws IOException 异常
     */
    public static void doCompress(String fileName, HttpServletResponse response,String zipName) throws IOException{
        OutputStream outputStream = null;
        ZipOutputStream zipOut = null;
        try {
            response.setContentType("APPLICATION/OCTET-STREAM");
            response.setHeader("Content-Disposition","attachment; filename=" + zipName + ".zip");
            response.setCharacterEncoding("UTF-8");
            outputStream = response.getOutputStream();
            zipOut = new ZipOutputStream(outputStream);
            doCompress(new File(fileName), zipOut,Strings.EMPTY,zipName);
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            if (zipOut != null) {
                zipOut.finish();
                zipOut.close();
            }
            
            if (outputStream != null) {
                outputStream.close();
            }
        }
    }
    
    /**
     * 压缩并下载
     *
     * @param inFile 待压缩下载的文件
     * @param zipOut ZipOutputStream
     * @param dir 输出的文件夹
     * @throws IOException
     */
    public static void doCompress(File inFile,ZipOutputStream zipOut,String dir,String zipName) throws IOException {
        if (inFile.isDirectory()) {
            File[] files = inFile.listFiles();
            if (files != null && files.length > 0) {
                for (File file : files) {
                    String name = inFile.getName();
                    if (Strings.isNotBlank(dir)) {
                        name = dir + "/" + name;
                    }
                    doCompress(file, zipOut, name,zipName);
                }
            }
        } else {
            doZip(inFile, zipOut, dir,zipName);
        }
    }
    
    /**
     * 压缩并下载
     *
     * @param inFile 待压缩下载的文件
     * @param zipOut ZipOutputStream
     * @param dir 输出的文件夹
     * @throws IOException
     */
    public static void doZip(File inFile, ZipOutputStream zipOut, String dir,String zipName) throws IOException {
        FileInputStream fis = null;
        try {
            String entryName;
            if (Strings.isNotBlank(dir)) {
                entryName = dir + "/" + inFile.getName();
            } else {
                entryName = inFile.getName();
            }
            ZipEntry entry = new ZipEntry(entryName);
            zipOut.putNextEntry(entry);
    
            int len;
            byte[] buffer = new byte[BUFFER_SIZE];
            fis = new FileInputStream(inFile);
            while ((len = fis.read(buffer)) > 0) {
                zipOut.write(buffer, 0, len);
            }
            zipOut.flush();
        } catch (Exception e){
            e.printStackTrace();
        }finally {
            if (fis != null) {
                fis.close();
            }
        }
    }
}
