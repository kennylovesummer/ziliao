/*
 * 文 件 名:  IBaseDao.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2014-11-26
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.intellif.cloud.personfile.manage.services.base;

import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;
import java.util.Map;


/**
 * 数据操作接口定义
 * <功能详细描述>
 * 
 * @author  wangyi
 * @version  [版本号, 2014-11-26]
 * @param <T>
 * @param <E>
 */
public interface IBaseDao<T, E>
{
    /**
     * 保存对象
     * <功能详细描述>
     * @param obj 表实体对象
     * @return int  
     * @see [类、类#方法、类#成员]
     */
    int insert(T obj);
    
    /**
     * 批量保存对象
     * <功能详细描述>
     * @param obj 表对应的对象 如果使用自定义标签就不用传，否则必传
     * @param statement 自定义标签
     * @param list list
     * @return int
     * @see [类、类#方法、类#成员]
     */
    int batchInsert(final T obj, String statement, List<E> list);
    
    int batchInsert(String statement,List<Map<String, Object>> params);
    
    /**
     * 单个删除对象
     * @param obj 表实体对象
     * @return int
     * pengzhizhong add
     */
    int delete(T obj);
    
    /**
     * 批量删除对象
     * <功能详细描述>
     * @param obj 表实体对象
     * @param map 要删除的对象或ID集合
     * @return int
     * @see [类、类#方法、类#成员]
     */
    int batchDelete(T obj, Map<String, List<E>> map);
    
    /**
     * 更新对象
     * <功能详细描述>
     * @param obj 表实体对象
     * @return int
     * @see [类、类#方法、类#成员]
     */
    int update(T obj);
    
    /**
     * 批量更新对象
     * <功能详细描述>
     * @param obj 表实体对象
     * @param map 我删除的对象集合
     * @return int
     * @see [类、类#方法、类#成员]
     */
    int batchUpdate(T obj, Map<String, List<E>> map);
    
    int batchUpdate(String statement,List<T> params);
    
    /**
     * 根据ID查询
     * <功能详细描述>
     * @param obj 表实体对象
     * @return T
     * @see [类、类#方法、类#成员]
     */
    T findById(T obj);
    
    /**
     * 根据实体对象查询所有的记录
     * <功能详细描述>
     * @param obj 表实体对象
     * @return
     */
    List<E> findAll(final T obj);
    
    /**
     * 分页查询和自定义查询
     * <功能详细描述>
     * @param event 查询条件对象封装，最终会转成MAP。
     * @return T
     * @see [类、类#方法、类#成员]
     */
    @SuppressWarnings("rawtypes")
    List<E> findAllIsPageByCustom(QueryEvent event);
    
    /**
     * 根据statementName 更新表数据
     * @param statementName
     * @param paramValue
     * @return
     */
    int updateStatement(String statementName, Object paramValue);
    
    /**
     * 自定义查询单个对象
     * <功能详细描述>
     * @param event 查询条件对象封装，最终会转成MAP。
     * @return
     */
    public Object findOneByCustom(final QueryEvent<T> event);
    
    /**
     * 执行存储过程
     * <功能详细描述>
     * @param statement  mybatis中SQL的ID
     * @param map  map中传入的为Map<String, String>
     * @return Map<String, Object> 返回值放到map中返回
     * 从map中取出存储过程返回的集合 如 ： List<Userinfo> list = (List<Userinfo>) map.get("USERINFO_CURSOR"); 
     */
    Map<String, Object> executeProcedure(final String statement, final Map<String, Object> map);
    
    /**
     * 执行自定义Count操作
     * <功能详细描述>
     * @param event 查询条件对象封装，最终会转成MAP。
     * @return  Object  数字对象
     * @see [类、类#方法、类#成员]
     */
    Object count(QueryEvent<T> event);
    
    /**
     * 获取sessionFactory
     *
     * @return SqlSessionFactory
     */
    SqlSessionFactory getSessionFactory();
}
