package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskDTO;

/**
 * 数据分析-数据导出
 *
 * @author liuzj
 * @date 2019-07-24
 */
public interface BigdataAnalysisExportTaskService {
    
    /**
     * 根据任务ID获取导出任务
     *
     * @param id 任务ID
     * @return BigdataAnalysisExportTask
     */
    BigdataAnalysisExportTask selectAnalysisExportTaskById(Long id);
    
    /**
     * 根据任务ID删除导出任务
     *
     * @param id 任务ID
     */
    void deleteAnalysisExportTaskById(Long id);
    
    /**
     * 删除导出任务
     *
     * @param bigdataAnalysisExportTask 待删除的导出任务
     */
    void deleteAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisExportTask 待新增的对象
     * @return Long
     */
    Long insertAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisExportTask 待更新对象
     */
    void updateAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask);
    
    /**
     * 分页查找
     *
     * @param analysisTaskDTO 参数集
     * @return Page
     */
    Page<BigdataAnalysisExportTask> findAnalysisExportTaskByParams(AnalysisTaskDTO analysisTaskDTO);
    
    /**
     * 删除
     */
    void deleteDiedAnalysisExportTask();
}
