package com.intellif.cloud.personfile.manage.model.vo.personfile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class PersonfileVO implements Serializable {

    @JSONField(name = "archiveId")
    private String personFileId;

    private String personName;

    private String personCid;

    private String imageUrl;

    private Date appearTime;

    @JSONField(name = "labelName")
    private String labelNames;

    private Integer imageCount;

    private Integer focused;

    @JSONField(name = "created")
    private Date createTime;

    private Long firstSnapTime;

    private Float similar;
    
    private Date modifyTime;

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
