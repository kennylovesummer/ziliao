package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import org.apache.logging.log4j.util.Strings;

import java.io.Serializable;
import java.util.Date;

//@Data
public class PersonfileBasics implements Serializable {

	private static final long serialVersionUID = 5345200852273087943L;

    private Date createTime = new Date();

    private String creater = IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME;

    private Date modifiedTime = new Date();

    private String modifier = IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME;

    private String personFilesId;
    
    private String baseInfoId;
 
    private Integer labelId;

    private String domicilePlace  = "_";

    private String phoneNumber = "";

    private String residencePlace = "_";

    private Integer sex = 0;

    private Integer age = 0;

    private String phoneMac  = "_";

    private String transportationCard  = "_";

    private String transportation  = "_";

    private Date birthDate;

    private Byte isDeleted;

    private String name;

    private String cid;

    private Date recentSnapTime;

    private Date personFileCreateTime;

    private Integer imageCount;

    private String headImageUrl;

    private String algoVersion;
    
    private Boolean updateFlag = false;
    
    private String tableName;
    
    public String getBaseInfoId() {
        return baseInfoId;
    }
    
    public void setBaseInfoId(String baseInfoId) {
        this.baseInfoId = baseInfoId;
    }
    
    public String getTableName() {
        return tableName;
    }
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public Boolean getUpdateFlag() {
        return updateFlag;
    }
    
    public void setUpdateFlag(Boolean updateFlag) {
        this.updateFlag = updateFlag;
    }
    
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    
    public Date getCreateTime() {
        return createTime;
    }
    
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
    public String getCreater() {
        return creater;
    }
    
    public void setCreater(String creater) {
        this.creater = creater;
    }
    
    public Date getModifiedTime() {
        return modifiedTime;
    }
    
    public void setModifiedTime(Date modifiedTime) {
        this.modifiedTime = modifiedTime;
    }
    
    public String getModifier() {
        return modifier;
    }
    
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }
    
    public String getPersonFilesId() {
        return personFilesId;
    }
    
    public void setPersonFilesId(String personFilesId) {
        this.personFilesId = personFilesId;
    }
    
    public Integer getLabelId() {
        return labelId;
    }
    
    public void setLabelId(Integer labelId) {
        this.labelId = labelId;
    }
    
    public String getDomicilePlace() {
        if (Strings.isBlank(domicilePlace)) {
            return "_";
        }
        return domicilePlace;
    }
    
    public void setDomicilePlace(String domicilePlace) {
        this.domicilePlace = domicilePlace;
    }
    
    public String getPhoneNumber() {
        if (Strings.isBlank(phoneNumber)) {
            return "";
        }
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getResidencePlace() {
        if (Strings.isBlank(residencePlace)) {
            return "_";
        }
        return residencePlace;
    }
    
    public void setResidencePlace(String residencePlace) {
        this.residencePlace = residencePlace;
    }
    
    public Integer getSex() {
        if (sex == null) {
            return 0;
        }
        return sex;
    }
    
    public void setSex(Integer sex) {
        this.sex = sex;
    }
    
    public Integer getAge() {
        if (age == null) {
            return 0;
        }
        return age;
    }
    
    public void setAge(Integer age) {
        this.age = age;
    }
    
    public String getPhoneMac() {
        if (Strings.isBlank(phoneMac)) {
            return "_";
        }
        return phoneMac;
    }
    
    public void setPhoneMac(String phoneMac) {
        this.phoneMac = phoneMac;
    }
    
    public String getTransportationCard() {
        if (Strings.isBlank(transportationCard)) {
            return "_";
        }
        return transportationCard;
    }
    
    public void setTransportationCard(String transportationCard)
    {
        this.transportationCard = transportationCard;
    }
    
    public String getTransportation() {
        if (Strings.isBlank(transportation)) {
            return "_";
        }
        return transportation;
    }
    
    public void setTransportation(String transportation) {
        this.transportation = transportation;
    }
    
    public Date getBirthDate() {
        return birthDate;
    }
    
    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    
    public Byte getIsDeleted() {
        return isDeleted;
    }
    
    public void setIsDeleted(Byte isDeleted) {
        this.isDeleted = isDeleted;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getCid() {
        if (Strings.isNotBlank(cid)) {
            return cid;
        } else {
            return null;
        }
    }
    
    public void setCid(String cid) {
        if (Strings.isNotBlank(cid)) {
            this.cid = cid;
        }
    }
    
    public Date getRecentSnapTime() {
        return recentSnapTime;
    }
    
    public void setRecentSnapTime(Date recentSnapTime) {
        this.recentSnapTime = recentSnapTime;
    }
    
    public Date getPersonFileCreateTime() {
        return personFileCreateTime;
    }
    
    public void setPersonFileCreateTime(Date personFileCreateTime) {
        this.personFileCreateTime = personFileCreateTime;
    }
    
    public Integer getImageCount() {
        return imageCount;
    }
    
    public void setImageCount(Integer imageCount) {
        this.imageCount = imageCount;
    }
    
    public String getHeadImageUrl() {
        return headImageUrl;
    }
    
    public void setHeadImageUrl(String headImageUrl) {
        this.headImageUrl = headImageUrl;
    }
    
    public String  getAlgoVersion() {
        return algoVersion;
    }
    
    public void setAlgoVersion(String algoVersion) {
        this.algoVersion = algoVersion;
    }
    
    @Override
    public String toString()
    {
    	return JSONObject.toJSONString(this);
    }
}