package com.intellif.cloud.personfile.manage.model.dto.camera;

/**
 * 文件名：BaseCameraQueryReq.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 基础服务的摄像头查询的请求
 *
 * @author ：tianhao
 * 创建时间：2018年8月18日
 * 修改理由：
 * 修改内容：
 */
public class BaseCameraQueryReqDTO implements java.io.Serializable {
    /**
     * 时间查询类型 1-按创建时间 2-按修改时间
     */
    private Integer dataSearchType;
    /**
     * 每页页数
     * 不必填,不传，则查全部
     */
    private Integer pageSize;
    /**
     * 第几页
     * 不必填 	不传，默认1
     */
    private Integer pageNo;

    /**
     * 开始时间,格式yyyy-MM-dd HH:mm:ss
     * 不必填
     */
    private String startDate;
    /**
     * 结束时间,格式yyyy-MM-dd HH:mm:ss
     * 不必填
     */
    private String endDate;

    public BaseCameraQueryReqDTO() {
    }

    public BaseCameraQueryReqDTO(Integer dataSearchType) {
        this.dataSearchType = dataSearchType;
    }

    public BaseCameraQueryReqDTO(Integer dataSearchType, String startDate, String endDate) {
        this.dataSearchType = dataSearchType;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Integer getDataSearchType() {
        return dataSearchType;
    }

    public void setDataSearchType(Integer dataSearchType) {
        this.dataSearchType = dataSearchType;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "BaseCameraQueryReqDTO{" +
                "dataSearchType=" + dataSearchType +
                ", pageSize=" + pageSize +
                ", pageNo=" + pageNo +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}
