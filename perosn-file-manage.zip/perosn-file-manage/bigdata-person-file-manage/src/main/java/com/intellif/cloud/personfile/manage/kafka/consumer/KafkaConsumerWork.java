package com.intellif.cloud.personfile.manage.kafka.consumer;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.log.LoggerUtilI;

import java.util.Collection;

/**
 * 抓拍消费工作线程
 *
 * @author liuzj
 * @date 2018-04-23
 */
public class KafkaConsumerWork implements Runnable{

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private Collection<String> consumerRecords;

    private MqMessageHandle mqMessageHandle;
    
    /**
     * 类型 （0：事件；1：档案）
     */
    private Integer type;

    public KafkaConsumerWork(Collection<String> consumerRecords, MqMessageHandle mqMessageHandle,Integer type) {
        this.consumerRecords = consumerRecords;
        this.mqMessageHandle = mqMessageHandle;
        this.type = type;
    }

    @Override
    public void run() {
        try{
            if (type == 0) {
                mqMessageHandle.eventHandle(consumerRecords);
            } else if (type == 1){
                mqMessageHandle.archiveHandle(consumerRecords);
            } else if (type == 2) {
                mqMessageHandle.archiveMerge(consumerRecords);
            }
        } catch (Exception e){
            if (type == 0) {
                logger.error("kafka事件数据同步异常：" + e.getMessage() + "异常数据：");
                for (String message: consumerRecords) {
                    logger.error(JSONObject.parseObject(message).getString("thumbnailId"));
                }
            } else{
                logger.error("kafka档案数据同步异常：" + e.getMessage());
                for (String message: consumerRecords) {
                    logger.error(JSONObject.parseObject(message).getString("aid"));
                }
            }
            throw e;
        }

    }
}
