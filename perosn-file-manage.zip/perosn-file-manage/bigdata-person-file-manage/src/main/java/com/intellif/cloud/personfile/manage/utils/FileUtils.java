package com.intellif.cloud.personfile.manage.utils;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.ThreadPoolConstant;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.util.Strings;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 文件操作工具类
 *
 * @author liuzj
 * @date 2017-05-16
 */
public class FileUtils {
    
    private static final Integer BUFFER_SIZE = 1024 * 1024 * 5;
    
    private static final String MSIE = "MSIE";
    
    private static final String TRIDENT = "Trident";
    
    /**
     * 线程池
     */
    public static final ThreadPoolExecutor threadPool;
    
    /**
     * 初始化线程
     */
    static {
        threadPool = new ThreadPoolExecutor(
                10,
                20,
                1,
                TimeUnit.SECONDS,
                ThreadPoolConstant.WORKQUEUE,
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build(),
                new ThreadPoolExecutor.CallerRunsPolicy());
    }
    
    /**
     * 将文件保存至本地
     *
     * @param imageData 文件数据
     * @param fileName  文件保存的名字
     * @param filePath  文件路径
     * @throws IOException IO异常
     */
    public static void saveFileToLocal(byte[] imageData, String filePath,String fileName) {
        // 将图片存储到本地
        FileOutputStream fileOutputStream = null;
        try {
            if (filePath != null) {
                File file = new File(filePath);
                if (!file.exists()) {
                    file.mkdirs();
                }
            }
            
            fileOutputStream = new FileOutputStream(filePath + fileName);
            fileOutputStream.write(imageData);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    /**
     * 刪除文件
     *
     * @param filePath 文件名
     */
    public static void deleteFileByPath(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
    }
    
    /**
     * 下载图片到指定目录下
     *
     * @param basePath      目录
     * @param urls          待下载的图片url集合
     * @param imageUrl      图片url(目录会根据这个url的图片名字命名)
     * @param isRelFileName 是否直接使用url作为目录名字
     * @return 最低级目录
     */
    public static String dowloadPicture(LinkedList<Future<Integer>> futures, String basePath, List<String> urls, String imageUrl, String filePre, boolean isRelFileName) {
        try {
            String selfDir = mkDir(basePath, imageUrl, isRelFileName);
            basePath = basePath + selfDir + File.separator;
            if (CollectionUtils.isEmpty(urls)) {
                return basePath;
            }
            if (urls.size() <= threadPool.getCorePoolSize()) {
                futures.add(threadPool.submit(new DownloadWork(basePath, urls, filePre)));
            } else {
                int part = urls.size() / threadPool.getCorePoolSize();
                List<String> urlsTemp;
                for (int i = 0; (i * part) < urls.size(); i++) {
                    if (((i + 1) * part) >= urls.size()) {
                        urlsTemp = urls.subList(i * part, urls.size());
                    } else {
                        urlsTemp = urls.subList(i * part, (i + 1) * part);
                    }
                    if (CollectionUtils.isNotEmpty(urlsTemp)) {
                        futures.add(threadPool.submit(new DownloadWork(basePath, urlsTemp, filePre)));
                    }
                }
            }
//            dowloadWorker(basePath,urls);
            return basePath;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Strings.EMPTY;
    }
    
    /**
     * 下载图片
     *
     * @param basePath 根目录
     * @param urls     图片url集合
     */
    public static Integer dowloadWorker(String basePath, List<String> urls, String filePre) {
        URL netUrl;
        DataInputStream dataInputStream = null;
        FileOutputStream fileOutputStream = null;
        try {
            for (String url : urls) {
                if (Strings.isBlank(url)) {
                    continue;
                }
                String[] urlTemps = StringUtils.split(url, "/");
                
                netUrl = new URL(url);
                dataInputStream = new DataInputStream(netUrl.openStream());
                String imageName = urlTemps[urlTemps.length - 1];
                if (Strings.isNotBlank(filePre)) {
                    imageName = filePre + "_" + imageName;
                }
                String filePath = basePath + imageName;
                fileOutputStream = new FileOutputStream(new File(filePath.replace(" ", "")));
                
                byte[] buffer = new byte[BUFFER_SIZE];
                int count;
                while ((count = dataInputStream.read(buffer)) > 0) {
                    fileOutputStream.write(buffer, 0, count);
                }
                fileOutputStream.flush();
            }
            System.out.println("线程" + Thread.currentThread().getName() + "下载：" + urls.size());
            return urls.size();
        } catch (Exception e) {
            e.printStackTrace();
            return urls.size();
        } finally {
            try {
                if (dataInputStream != null) {
                    dataInputStream.close();
                }
                
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * 创建目录
     *
     * @param basePath      基本目录
     * @param url           图片url(目录会根据这个url的图片名字命名)
     * @param isRelFileName 是否直接使用url作为目录名字
     * @return 目录名
     * @throws IOException
     */
    private static String mkDir(String basePath, String url, boolean isRelFileName) throws IOException {
        if (Strings.isBlank(url)) {
            return Strings.EMPTY;
        }
        String fileName = isRelFileName ? url : getImageName(url);
        String filePath = (basePath == null) ? fileName : basePath + fileName;
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        return fileName;
    }
    
    /**
     * 从图片url中获取图片名字（会去除所有空格）
     *
     * @param url 图片url
     * @return 图片名字
     */
    public static String getImageName(String url) {
        if (Strings.isBlank(url)) {
            return Strings.EMPTY;
        }
        url = url.replace(" ", "");
        String[] urlTemps = url.split("/");
        String imageName = urlTemps[urlTemps.length - 1];
        if (Strings.isBlank(imageName)) {
            return Strings.EMPTY;
        }
        return StringUtils.split(imageName, ICommonConstant.Symbol.POINT)[0];
    }
    
    /**
     * 下載文件
     *
     * @param response HttpServletResponse
     * @param fileName 文件名
     * @throws IOException 异常
     */
    public static void downloadFile(HttpServletResponse response, HttpServletRequest request, String fileName, String filePath) throws IOException {
        ChannelFileReader inStream = null;
        ServletOutputStream outStream = null;
        try {
            // java自带的stream readAllBytes 最大只能读取2G大小文件，超出则读取不了，需要进行分片读取
//            inStream = new FileInputStream(filePath + ".zip");
            // 分片读取
            inStream = new ChannelFileReader(filePath + ".zip", BUFFER_SIZE);
            outStream = response.getOutputStream();
            String userAgent = request.getHeader("User-Agent");
            // 针对IE或者以IE为内核的浏览器：
            if (userAgent.contains(MSIE) || userAgent.contains(TRIDENT)) {
                fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
            } else {
                // 非IE浏览器的处理：
                fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            }
            // 清除缓存
            response.reset();
            // 设置输出的格式
            response.setContentType("application/octet-stream");
            response.addHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));
            response.setCharacterEncoding("UTF-8");
            response.addHeader("Content-Length", "" + inStream.getFileLength());
            
            // 循环取出流中的数据
//            byte[] buffer = new byte[BUFFER_SIZE];
            int len;
            while ((len = inStream.read()) != -1) {
                outStream.write(inStream.getArray(), 0, len);
                // 刷新以及关闭流
                outStream.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (inStream != null) {
                try {
                    inStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    /**
     * 压缩成zip
     *
     * @param filepath 要被压缩的文件（文件夹）路径
     * @param zipPath  zip全路径
     */
    public static void toZip(String filepath, String zipPath) {
        OutputStream outputStream = null;
        ZipOutputStream zipout = null;
        try {
            File file = new File(filepath);
            outputStream = new FileOutputStream(zipPath + ".zip");
            zipout = new ZipOutputStream(outputStream);
            dozip(zipout, file, Strings.EMPTY);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (zipout != null) {
                    zipout.finish();
                    zipout.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }
    
    /**
     * 进行压缩
     *
     * @param zipout   ZipOutputStream
     * @param file     待压缩的文件（文件夹）
     * @param basePath 基本路径
     */
    private static void dozip(ZipOutputStream zipout, File file, String basePath) {
        InputStream input = null;
        BufferedInputStream buff = null;
        try {
            if (file.isDirectory()) {
                File[] files = file.listFiles();
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isDirectory()) {
                        dozip(zipout, files[i], basePath + files[i].getName() + "/");
                    } else {
                        dozip(zipout, files[i], basePath + files[i].getName());
                    }
                }
            } else {
                zipout.putNextEntry(new ZipEntry(basePath));
                input = new FileInputStream(file);
                buff = new BufferedInputStream(input);
                byte[] buffer = new byte[BUFFER_SIZE];
                int len;
                while ((len = buff.read(buffer)) != -1) {
                    zipout.write(buffer, 0, len);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (buff != null) {
                try {
                    buff.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private static class DownloadWork implements Callable<Integer> {
        
        private String basePath;
        
        private List<String> urls;
        
        private String filePre;
        
        DownloadWork(String basePath, List<String> urls, String filePre) {
            this.basePath = basePath;
            this.urls = urls;
            this.filePre = filePre;
        }
        
        @Override
        public Integer call() {
            return dowloadWorker(basePath, urls, filePre);
        }
    }
    
    private static class ChannelFileReader {
        
        private FileInputStream fileIn;
        
        private ByteBuffer byteBuf;
        
        private long fileLength;
        
        private byte[] array;
        
        public ChannelFileReader(String fileName, int arraySize) throws IOException {
            this.fileIn = new FileInputStream(fileName);
            this.fileLength = fileIn.getChannel().size();
            this.byteBuf = ByteBuffer.allocate(arraySize);
        }
        
        public int read() throws IOException {
            FileChannel fileChannel = fileIn.getChannel();
            // 读取到ByteBuffer中
            int bytes = fileChannel.read(byteBuf);
            if (bytes != -1) {
                // 字节数组长度为已读取长度
                array = new byte[bytes];
                byteBuf.flip();
                // 从ByteBuffer中得到字节数组
                byteBuf.get(array);
                byteBuf.clear();
                return bytes;
            }
            return -1;
        }
        
        public void close() throws IOException {
            fileIn.close();
            array = null;
        }
        
        public byte[] getArray() {
            return array;
        }
        
        public long getFileLength() {
            return fileLength;
        }
    }
}
