/*
 * 文件名：IImageService.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：  图片接口类
 * 创建人：tianhao
 * 创建时间：2018年11月06日
 * 修改理由：
 * 修改内容：
 */
package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;

/**
 * 图片接口类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年11月06日
 * @see ImageService
 * @since JDK1.8
 */
public interface ImageService {
    /**
     * 上传图片检测
     *
     * @param imageUrl 照片url
     * @return BaseDataRespDTO
     */
    BaseDataRespDTO uploadImage(String imageUrl);

}
