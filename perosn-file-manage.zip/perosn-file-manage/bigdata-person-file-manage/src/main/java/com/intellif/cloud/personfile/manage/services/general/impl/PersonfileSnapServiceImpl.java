package com.intellif.cloud.personfile.manage.services.general.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.annotation.SubSelectMore;
import com.intellif.cloud.personfile.manage.annotation.SubSelectOne;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileMergeDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapQueryDTO;
import com.intellif.cloud.personfile.manage.model.vo.activityRoutine.PersonfileActivityRoutinesVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileBaseInfoService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSnapService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileSnapServiceImpl
 * @date 2019/3/19 13:59
 * @description
 */
@Service
public class PersonfileSnapServiceImpl extends BaseServiceImpl implements PersonfileSnapService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonfileRubbishService personfileRubbishService;
    
    @Autowired
    private PersonfileBaseInfoService personfileBaseInfoService;
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    private static final PersonfileSnap PERSONFILE_SNAP = new PersonfileSnap();
    
    @Override
    @SubSelectMore
    public Page<EventSnapDetailVO> getPersonfileSnap(SnapQueryDTO snapQueryDTO) {
        QueryEvent event = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("personFilesId", snapQueryDTO.getPersonFileId());
        parameters.put("sourceId", snapQueryDTO.getDevId());
        event.setStatement("findEventSnapDetail");
        event.setParameter(parameters);
        PageHelper.startPage(0, 0,false);
        List<EventSnapDetailVO> personfileSnapList = this.baseDao.findAllIsPageByCustom(event);
        return personfileSnapList != null ? (Page<EventSnapDetailVO>) personfileSnapList : null;
    }
    
    @Override
    @SubSelectMore
    public Page<EventSnapDetailVO> getPersonfileSnapDetail(String personFilesId, int page, int perPage) {
        QueryEvent queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("personFilesId", personFilesId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("getPersonfileSnapDetail");
        PageHelper.startPage(page, perPage,false);
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (Page<EventSnapDetailVO>) object : null;
    }
    
    @Override
    public BaseDataRespDTO querySnapMapByPersonFilesId(SnapMapDTO snapMapDTO) {
        if (null == snapMapDTO.getStartTime()) {
            snapMapDTO.setStartTime("");
        }
        if (null == snapMapDTO.getEndTime()) {
            snapMapDTO.setEndTime("");
        }
        try {
            List<SnapMapVO> snapMapVOList = getSnapMapByPersonFilesId(snapMapDTO);
            Map<String, Object> map = Maps.newHashMap();
            String devId;
            List<SnapMapVO> list2 = Lists.newLinkedList();
            for (SnapMapVO snapMapVO : snapMapVOList) {
                devId = snapMapVO.getDevId();
                if (!map.containsKey(devId)) {
                    list2.add(snapMapVO);
                }
                map.put(devId, null);
            }
            return new BaseDataRespDTO(list2, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(), ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("获取所有设备(地图)异常:" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "获取所有设备(地图)异常" + e.getMessage());
        }
    }
    
    @Override
//    @SubSelectMore
    public Page<SnapMapVO> getSnapMapByPersonFilesId(SnapMapDTO snapMapDTO) {
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("getSnapMapByPersonFilesId");
        Map<String, Object> map = Maps.newHashMap();
        map.put("personFilesId", snapMapDTO.getPersonFileId());
//        map.put("startTime", snapMapDTO.getStartTime() + ICommonConstant.DateStr.START_TIME);
//        map.put("endTime", snapMapDTO.getEndTime() + ICommonConstant.DateStr.END_TIME);
        map.put("sourceId", snapMapDTO.getSourceId());
        map.put("tables", ThreadLocalUtil.getSubKnowTableName());
        queryEvent.setParameter(map);
        PageHelper.startPage(snapMapDTO.getPage(), snapMapDTO.getPerpage());
        Object result = this.baseDao.findAllIsPageByCustom(queryEvent);
        return result != null ? (Page<SnapMapVO>) result : null;
    }
    
    @Override
    @SubSelectMore
    public Page<SnapMapVO> querySnapMapDetail(SnapQueryDTO snapQueryDTO) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("sourceId", snapQueryDTO.getDevId());
        map.put("personFilesId", snapQueryDTO.getPersonFileId());
//        map.put("startTime", snapQueryDTO.getStartTime());
//        map.put("endTime", snapQueryDTO.getEndTime());
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("getSnapMapDetail");
        queryEvent.setParameter(map);
        PageHelper.startPage(snapQueryDTO.getPage(), snapQueryDTO.getPerpage(),false);
        Object result = this.baseDao.findAllIsPageByCustom(queryEvent);
        return result != null ? (Page<SnapMapVO>) result : null;
    }
    
    @Override
    @SubSelectMore
    public List<PersonfileRubbish> getByPersonfileId(String snapId, String personfileId,Integer page,Integer pageSize) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("thumbnailId", snapId);
        map.put("personFilesId", personfileId);
        map.put("page", page);
        map.put("pageSize", pageSize);
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("getByPersonfileId");
        queryEvent.setParameter(map);
        Object result = this.baseDao.findAllIsPageByCustom(queryEvent);
        return result != null ? (List<PersonfileRubbish>) result : null;
    }
    
    @Override
    @SubSelectMore
    public int deletePersonfileSnap(PersonfileSnap personfileSnap) {
        return this.baseDao.delete(personfileSnap);
    }
    
    /**
     * 删除抓拍事件中的照片
     *
     * @param faceId
     * @param personfileId
     * @return
     */
    @Override
    public void deleteEventSnapImg(String faceId, String personfileId) throws BusinessException {
        PersonfileRubbish personfileRubbish = getByPersonfileId(faceId, personfileId,null,null).get(0);
        //删除的抓拍到回收站
        int result = personfileRubbishService.insertPersonfileRubbish(personfileRubbish);
        if (result == 1) {
            PersonfileSnap personfileSnap = new PersonfileSnap();
            personfileSnap.setFaceId(faceId);
            //删除抓拍
            deletePersonfileSnap(personfileSnap);
            //档案imageCount - 1
            PersonfileBasicsVO personfileBasicsVO = personfileBaseInfoService.findBaseInfoVOByPersonFileId(personfileId);
            if (personfileBasicsVO.getImageCount() > 0) {
                personfileBaseInfoService.updateImageCount(-1, personfileId);
            }
            // 更新事件统计
            statisticPersonfileEventService.updateStatisticEvent(-1, DateFormatUtils.format(personfileRubbish.getCreateTime(), ICommonConstant.DateFormatType.Y_M_D));
        }
    }
    
    @Override
//    @SubSelectMore
    public Page<PersonfileActivityRoutinesVO> getSnapActivity(String personFilesId, String startTime, String endTime, Integer activityRoutineType, Integer page, Integer perpage) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("personFilesId", personFilesId);
        map.put("startTime", startTime);
        map.put("endTime", endTime);
        map.put("activityRoutineType", activityRoutineType);
        map.put("tables", ThreadLocalUtil.getSubKnowTableName());
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("getSnapActivity");
        queryEvent.setParameter(map);
        PageHelper.startPage(page, perpage,false);
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (Page<PersonfileActivityRoutinesVO>) object : null;
    }
    
    @Override
    @SubSelectMore
    public int getSnap(String startTime, String endTime) {
        QueryEvent queryEvent = new QueryEvent<>();
        Map<String, Object> map = Maps.newHashMap();
        map.put("startTime", startTime);
        map.put("endTime", endTime);
        queryEvent.setParameter(map);
        queryEvent.setStatement("getSnap");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object != null ? (Integer) object : 0;
    }
    
    @Override
    @SubSelectOne
    public String findByImageUrl(String imageUrl) {
        Map<String, Object> map = Maps.newHashMap();
        QueryEvent<PersonfileSnap> queryEvent = new QueryEvent();
        map.put("imageUrl", imageUrl);
        queryEvent.setParameter(map);
        queryEvent.setStatement("findByImageUrl");
        Object id = this.baseDao.findOneByCustom(queryEvent);
        return id != null ? (String) id : null;
    }
    
    @Override
    @SubSelectMore
    public Integer statisticSnapByDate() {
        QueryEvent<PersonfileSnap> queryEvent = new QueryEvent();
        queryEvent.setStatement("statisticSnapByDate");
        Object num = this.baseDao.findOneByCustom(queryEvent);
        return num != null ? (Integer) num : 0;
    }
    
    @Override
    @SubSelectMore
    public List<String> findSnapUrlsByPersonfileId(String personFileId) {
        Map<String, Object> map = Maps.newHashMap();
        QueryEvent<PersonfileSnap> queryEvent = new QueryEvent();
        map.put("personFileId", personFileId);
        queryEvent.setParameter(map);
        queryEvent.setStatement("findSnapUrlsByPersonfileId");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (List<String>) object : Lists.newArrayList();
    }
    
    @Override
    public int batchInsert(List<PersonfileSnap> personfileSnaps) {
        return this.baseDao.batchInsert(PERSONFILE_SNAP, null, personfileSnaps);
    }
    
    @Override
    @SubSelectOne
    public Date findFirstSnapTimeByPersonFileId(String personFileId) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("personFileId", personFileId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findFirstSnapTimeByPersonFileId");
        Object result = this.baseDao.findOneByCustom(queryEvent);
        return result != null ? (Date) result : null;
    }
    
    @Override
    public List<PersonfileBasics> findSnapTimeAndImageCount(String personFileId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("personFileId", personFileId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findSnapTimeAndImageCount");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (List<PersonfileBasics>) object : Lists.newArrayList();
    }
    
    @Override
    @SubSelectMore
    public List<PersonfileBasics> findSnapTimeAndImageCountByPersonfileId(List<String> personFileIds) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("personFileIds", personFileIds);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findSnapTimeAndImageCountByPersonfileId");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object != null ? (List<PersonfileBasics>) object : null;
    }
    
    @Override
    @SubSelectMore
    public void updateSnapAid(List<PersonfileMergeDTO> params) {
        this.baseDao.updateStatement("updateSnapAid",params);
    }
    
    @Override
    @SubSelectMore
    public List<SnapMapVO> getSnapMapByPersonFilesId(List<String> personfilesIdList) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("personfilesIdList", personfilesIdList);
        QueryEvent queryEvent = new QueryEvent();
        queryEvent.setStatement("getSnapMapDetailByPersonFilesId");
        queryEvent.setParameter(map);
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }
    
}
