package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.vo.activityRoutine.PersonfileActivityRoutinesVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.utils.DeepDateUtil;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import com.sun.tools.javac.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.stream.Collectors;

/**
 * @author liuyu
 * @className PersonfileActivityAnalysisController
 * @date 2019/3/21 11:40
 * @description
 */
@Api(tags = "档案中心-活动规律分析")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.ACTIVITYROUTINES)
public class PersonfileActivityAnalysisController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final SubEventService subEventService;

    @Autowired
    public PersonfileActivityAnalysisController(SubEventService subEventService) {
        this.subEventService = subEventService;
    }
    
    /**
     * 活动规律分析
     *
     * @param personFilesId
     * @param timeType
     * @param page
     * @param perpage
     * @return
     */
    @ApiOperation(httpMethod = "GET",value = "获取活动规律分析数据（实时）")
    @GetMapping("/{personFileId}/{version}")
    public BasePageRespDTO getActivityRountines(@PathVariable(name = "personFileId") String personFilesId,
                                                @RequestParam("timeType") Integer timeType,
                                                @RequestParam("activityRoutineType") Integer activityRoutineType,
                                                @RequestParam("page") Integer page,
                                                @RequestParam("perpage") Integer perpage) {
        try {
            String startTime = DeepDateUtil.nowDate();
            String endTime = DeepDateUtil.nowDate();
            switch (timeType) {
                case 0:
                    startTime = DeepDateUtil.getLastDayByWeek(startTime);
                    break;
                case 1:
                    startTime = DeepDateUtil.getLastMonthSameDay(startTime);
                    break;
                case 2:
                    startTime = DeepDateUtil.getLasthalfYearSameDay(startTime);
                    break;
                case 3:
                    startTime = DeepDateUtil.getLastYearSameDay(startTime);
                    break;
                default:
            }
            Page<PersonfileActivityRoutinesVO> snapActivity =
                    subEventService.getSnapActivity(personFilesId, startTime, endTime, activityRoutineType, page, perpage);
            
            if (CollectionUtils.isNotEmpty(snapActivity)) {
                return IPersonFilesResultInfo.success(snapActivity, snapActivity.getPages(),
                        (int) snapActivity.getTotal(), "活动规律查询成功！");
            } else {
                return IPersonFilesResultInfo.success(Lists.newArrayList(), 0, 0, "活动规律查询成功！");
            }
            
        } catch (Exception e) {
            logger.error("活动规律查询异常：", e.getMessage());
        }
        return IPersonFilesResultInfo.error(null, 0, 0, "活动规律详情查询失败!");
    }
    
    @ApiOperation(httpMethod = "GET",value = "分页获取活动详情")
    @GetMapping("/detail/{personFileId}/{version}")
    public BasePageRespDTO getActivityRountinesDetail(@PathVariable(name = "personFileId") String personFilesId,
                                                      @RequestParam("startTime") String startTime,
                                                      @RequestParam("endTime") String endTime,
                                                      @RequestParam("devIds") String sourceId,
                                                      @RequestParam("page") Integer pageNo,
                                                      @RequestParam("perpage") Integer pageSize) {
        try {
            SnapMapDTO snapMapDTO = new SnapMapDTO(personFilesId, sourceId + "", startTime, endTime);
            snapMapDTO.setPage(pageNo);
            snapMapDTO.setPerpage(pageSize);
            Page<SnapMapVO> snapMapVOList = subEventService.getSnapMapByPersonFilesId(snapMapDTO);
            snapMapVOList.forEach(snapMapVO -> {
                try {
                    Date date = DeepDateUtil.strToDateTime(snapMapVO.getSnapTime());
                    snapMapVO.setSnapTime(String.valueOf(date.getTime()));
                } catch (ParseException e) {
                    logger.error("时间转换异常：", e.getMessage());
                }
            });
            return IPersonFilesResultInfo.success(snapMapVOList, snapMapVOList.getPages(),
                    (int) snapMapVOList.getTotal(), "活动规律详情查询成功！");
        } catch (Exception e) {
            logger.error("活动规律详情查询异常：", e.getMessage());
            return IPersonFilesResultInfo.error(null, 0, 0, "活动规律详情查询失败!");
        }
    }
}

