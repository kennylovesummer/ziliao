package com.intellif.cloud.personfile.manage.utils;


import com.intellif.cloud.personfile.manage.contants.ICommonConstant;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 身份证相关工具类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月27日
 * @since JDK1.8
 */
public class IdcardUtil {
    
    
    /**
     * 根据身份证号输出年龄
     *
     * @param IdNO 身份证号
     * @return
     */
    public static int idNOToAge(String IdNO) {
        int leh = IdNO.length();
        String dates;
        if (leh == 18) {
            dates = IdNO.substring(6, 10);
            SimpleDateFormat df = new SimpleDateFormat(ICommonConstant.DateFormatType.Y);
            String year = df.format(new Date());
            return Integer.parseInt(year) - Integer.parseInt(dates);
        } else {
            dates = IdNO.substring(6, 8);
            return Integer.parseInt(dates);
        }
    }
    
}