package com.intellif.cloud.personfile.manage.model.vo.statistic;

import com.alibaba.fastjson.JSON;
import lombok.Data;

import java.io.Serializable;

/**
 * @program ifaas-person-file-datastatistics
 * @Author liuYu
 * @create 2018-10-29 14:06
 * @Version 1.0
 * @desc
 */
@Data
public class StatsticPersonfileAndImageVO implements Serializable {

    private static final long serialVersionUID = 3102912884445957189L;

    private Integer fileTotal;

    private Integer imageTotal;

    public StatsticPersonfileAndImageVO(Integer fileTotal, Integer imageTotal) {
        this.fileTotal = fileTotal;
        this.imageTotal = imageTotal;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
