package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.model.dto.camera.PersonfileCameraReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;

import java.util.List;

/**
 * 设备接口类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月17日
 * @see IPersonfileCameraService
 * @since JDK1.8
 */
public interface IPersonfileCameraService {
    /**
     * 根据摄像头id查询详情
     *
     * @param devId
     * @return
     */
    PersonfileCamera findCameraByDevId(String devId);

    /**
     * 根据摄像头id集合查询详情
     *
     * @param devIdList
     * @return
     */
    List<PersonfileCamera> findCameraByDevIdList(List<String> devIdList);


    /**
     * 新增
     *
     * @param personfileCamera
     * @return
     */
    int insertPersonfileCamera(PersonfileCamera personfileCamera);

    /**
     * 批量新增
     *
     * @param personfileCameraList
     * @return
     */
    int insertPersonfileCameraBatch(List<PersonfileCamera> personfileCameraList);

    /**
     * 设备列表分页查询
     * @param personfileCameraReqDTO 设备对象
     * @return 设备列表
     */
    BasePageRespDTO queryPersonfileCamera(PersonfileCameraReqDTO personfileCameraReqDTO);
    
    /**
     * 删除所有数据
     */
    void deletePersonfileCamera();
}
