package com.intellif.cloud.personfile.manage.model.dto.account;

import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import lombok.Data;

/**
 * 用户
 */
@Data
public class AccountDTO extends BasePageReqDTO implements java.io.Serializable{
    
    private Long id;
    
    private String name;

    private String account;

    private String password;
}