/*
 * 文件名：TestPageReq.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年8月10日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.model.dto.personfile;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class PersonfileConcernDto implements Serializable {

    private static final long serialVersionUID = 4313137546079175992L;

    private Long id;

    @NotBlank(message = "personFilesId字段不可为空!")
    private String personFilesId;

    private String concerner;

    @NotNull(message = "isFocused字段不可为空!")
    private Integer isFocused;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
