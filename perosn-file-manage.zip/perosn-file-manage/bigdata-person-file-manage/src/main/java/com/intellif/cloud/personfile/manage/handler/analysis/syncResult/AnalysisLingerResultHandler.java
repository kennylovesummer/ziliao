package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.EventDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.LingerResultVO;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

/**
 * 徘徊分析结果处理器
 *
 * @author liuzj
 * @date 2019-07-19
 */
public class AnalysisLingerResultHandler extends AbstractAnalysisSyncResultHandler {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    public AnalysisLingerResultHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected void syncData(AnalysisTaskResultDTO analysisTaskResultDTO) throws ParseException {
        // 清除数据
        clearHistoryData(analysisTaskResultDTO);
        
        JSONObject result = getResult(analysisTaskResultDTO);
        
        Long taskId = analysisTaskResultDTO.getTaskId2();
        List<BigdataAnalysisArchive> bigdataAnalysisArchiveList = Lists.newArrayList();
        List<BigdataAnalysisEvent> bigdataAnalysisEventList = Lists.newArrayList();
        List<String> faceResult = Lists.newArrayList();
        if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
            List<LingerResultVO> lingerResultVOList = JSONObject.parseArray(result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("targetInfo"), LingerResultVO.class);
            if (CollectionUtils.isNotEmpty(lingerResultVOList)) {
                for (LingerResultVO lingerResultVO: lingerResultVOList) {
    
                    List<EventDetailVO> eventDetailVOList = lingerResultVO.getEvents();
    
                    // 去重
                    eventDetailVOList = eventDetailVOList.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(EventDetailVO::getFaceId))), ArrayList::new));
    
                    BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
                    BeanUtils.copyProperties(lingerResultVO,bigdataAnalysisArchive);
                    bigdataAnalysisArchive.setPersonName(lingerResultVO.getName());
                    bigdataAnalysisArchive.setTaskId(taskId);
                    bigdataAnalysisArchive.setFaceUrl(lingerResultVO.getAvatarUrl());
                    bigdataAnalysisArchive.setLingerdCount(lingerResultVO.getLingeredCount());
                    bigdataAnalysisArchiveList.add(bigdataAnalysisArchive);
                    if (bigdataAnalysisArchiveList.size() == BATCH_INSERT_NUM) {
                        bigdataAnalysisArchiveService.batchInsertAnalysisArchive(bigdataAnalysisArchiveList);
                        bigdataAnalysisArchiveList.clear();
                    }
                   
                    for (EventDetailVO eventDetailVO: eventDetailVOList) {
                        BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
                        BeanUtils.copyProperties(eventDetailVO,bigdataAnalysisEvent);
                        bigdataAnalysisEvent.setTaskId(taskId);
                        bigdataAnalysisEvent.setTime(org.apache.commons.lang3.time.DateUtils.parseDate(eventDetailVO.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                        bigdataAnalysisEvent.setDate(eventDetailVO.getDate().getTime());
                        bigdataAnalysisEventList.add(bigdataAnalysisEvent);
                        if (bigdataAnalysisEventList.size() == BATCH_INSERT_NUM) {
                            bigdataAnalysisEventService.batchInsertAnalysisEvent(bigdataAnalysisEventList);
                            bigdataAnalysisEventList.clear();
                        }
                    }
    
                    if (faceResult.size() < 4) {
                        faceResult.add(bigdataAnalysisArchive.getFaceUrl());
                    }
                }
    
                if (CollectionUtils.isNotEmpty(bigdataAnalysisEventList)) {
                    bigdataAnalysisEventService.batchInsertAnalysisEvent(bigdataAnalysisEventList);
                }
                
                if (CollectionUtils.isNotEmpty(bigdataAnalysisArchiveList)) {
                    bigdataAnalysisArchiveService.batchInsertAnalysisArchive(bigdataAnalysisArchiveList);
                }
    
                // 存入四张结果图片
                BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskById(taskId);
                bigdataAnalysisTask.setResult(Strings.join(faceResult, ','));
                bigdataAnalysisTaskService.updateBigdataAnalysisTask(bigdataAnalysisTask);
            }
    
            analysisTaskResultDTO.setRemark("徘徊分析数据同步成功！");
            updateTaskStatus(analysisTaskResultDTO, true);
        } else if (result == null || result.get(ICommonConstant.ResultDataFormat.data) == null) {
            analysisTaskResultDTO.setRemark("徘徊分析数据同步结束: " + "无数据");
            updateTaskStatus(analysisTaskResultDTO, true);
        } else {
            analysisTaskResultDTO.setRemark("徘徊分析数据同步结束：" + (result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : ""));
            updateTaskStatus(analysisTaskResultDTO, false);
        }
    }
}
