package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.NocturnalTaskCreateDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

/**
 * 活动规律分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisNocturnalCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    AnalysisNocturnalCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        NocturnalTaskCreateDTO nocturnalTaskCreateDTO = JSONObject.parseObject(params.toJSONString(), NocturnalTaskCreateDTO.class);
        // 参数校验
        if (nocturnalTaskCreateDTO.getRules().getInterval() == null
                || nocturnalTaskCreateDTO.getRules().getFilterTimes() == null
                || CollectionUtils.isEmpty(nocturnalTaskCreateDTO.getSourceIds())
                || Strings.isBlank(nocturnalTaskCreateDTO.getStartTime())
                || Strings.isBlank(nocturnalTaskCreateDTO.getEndTime())) {
            throw new BusinessException(IResultCode.ERROR,"参数异常");
        }
    
        if (nocturnalTaskCreateDTO.getRules() == null) {
            Props rules = new Props();
            String rulesConfig = personPropertiest.getDataAnalysisNocturnalRules();
            if (Strings.isNotBlank(rulesConfig)) {
                String[] ruleArray = rulesConfig.split(ICommonConstant.Symbol.AND);
                if (ruleArray.length == 4) {
                    rules.setIncludePeriods(ruleArray[0].trim());
                    rules.setExcludePeriods(ruleArray[1].trim());
                    rules.setInterval(Integer.valueOf(ruleArray[2].trim()));
                    rules.setFilterTimes(Integer.valueOf(ruleArray[3].trim()));
                }
            }
            nocturnalTaskCreateDTO.setRules(rules);
        }
    
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setTaskType(DataStisticTypeEnum.NOCTURNAL.getName());
        offLineTaskDTO.setParams(nocturnalTaskCreateDTO.toString());
        offLineTaskDTO.setTaskName(nocturnalTaskCreateDTO.getTaskName());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
    
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setType(DataStisticTypeEnum.NOCTURNAL.getName());
        bigdataAnalysisTask.setName(nocturnalTaskCreateDTO.getTaskName());
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        
        return execId;
    }
}
