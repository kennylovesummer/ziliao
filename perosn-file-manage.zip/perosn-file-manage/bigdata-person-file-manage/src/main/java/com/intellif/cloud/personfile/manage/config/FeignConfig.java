package com.intellif.cloud.personfile.manage.config;

import feign.Request;
import feign.Retryer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Feign超时设置
 *
 * @author liuzj
 * @date 2019-07-02
 */
@Configuration
public class FeignConfig {
     
     @Value("${feign.connectTimeOutMillis:1800000}")
     public int connectTimeOutMillis;

     @Value("${feign.readTimeOutMillis:1800000}")
     public int readTimeOutMillis;
     
     /**
      * 超时设置
      *
      * @return
      */
     @Bean
     public Request.Options options() {
        return new Request.Options(connectTimeOutMillis, readTimeOutMillis);
     }
     
     /**
      * 重试次数
      *
      * @return
      */
     @Bean
     public Retryer feignRetryer() { return new Retryer.Default(); }
}
