package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrash;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuzj
 * @see BigdataAnalysisCrashService
 */
@Service
public class BigdataAnalysisCrashServiceImpl extends BaseServiceImpl implements BigdataAnalysisCrashService {
    
    private static final BigdataAnalysisCrash BIGDATA_ANALYSIS_CRASH = new BigdataAnalysisCrash();
    
    @Override
    public BigdataAnalysisCrash findAnalysisCrashById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryEvent.setParameter(parameters);
            queryEvent.setStatement("findAnalysisCrashById");
            Object object = this.baseDao.findOneByCustom(queryEvent);
            return object == null ? null : (BigdataAnalysisCrash) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash) {
        if (bigdataAnalysisCrash != null && bigdataAnalysisCrash.getId() != null) {
            this.baseDao.delete(bigdataAnalysisCrash);
        }
    }
    
    @Override
    public Long insertAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash) {
        if (bigdataAnalysisCrash != null) {
            bigdataAnalysisCrash.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisCrash.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisCrash);
        return bigdataAnalysisCrash.getId();
    }
    
    @Override
    public void batchInsertAnalysisCrash(List<BigdataAnalysisCrash> crashList) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_CRASH, null, crashList);
    }
    
    @Override
    public void updateAnalysisCrash(BigdataAnalysisCrash bigdataAnalysisCrash) {
        this.baseDao.update(bigdataAnalysisCrash);
    }
    
    @Override
    public Page<BigdataAnalysisCrash> findAnalysisCrashByParams(CrashDTO crashDTO) {
        QueryEvent<CrashDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(crashDTO);
        queryEvent.setStatement("findAnalysisCrashByParams");
        
        Page<BigdataAnalysisCrash> page = PageHelper.startPage(crashDTO.getPage(), crashDTO.getPerpage());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public void deleteBigdataAnalysisCrashByTaskId(Long taskId) {
        if (taskId == null) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        this.baseDao.updateStatement("deleteBigdataAnalysisCrashByTaskId",parameters);
    }
    
}
