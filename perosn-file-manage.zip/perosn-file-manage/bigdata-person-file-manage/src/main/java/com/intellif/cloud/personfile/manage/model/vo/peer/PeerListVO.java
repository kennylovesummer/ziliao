package com.intellif.cloud.personfile.manage.model.vo.peer;

import com.intellif.cloud.personfile.manage.model.vo.analysis.EventDetailVO;
import lombok.Data;

import java.util.List;

/**
 * @author liuzj
 * @data 2019-06-29
 */
@Data
public class PeerListVO {

    private String aid;
    
    private String name;
    
    private String cid;
    
    private String gender;
    
    private String avatarUrl;
    
    private String imageId;
    
    private String imageUrl;
    
    private String sysCode;
    
    private Long imageCount;
    
    private Integer peerTimes;
    
    private List<EventDetailVO> targetEvents;
    
    private List<EventDetailVO> peerEvents;
    
}
