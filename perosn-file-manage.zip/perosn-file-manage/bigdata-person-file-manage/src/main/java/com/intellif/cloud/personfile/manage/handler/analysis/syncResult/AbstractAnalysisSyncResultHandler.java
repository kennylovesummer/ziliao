package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.log.LoggerUtilI;
import org.apache.logging.log4j.util.Strings;

import java.text.ParseException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 数据分析结果处理器
 *
 * @author liuzj
 * @date 2019-07-19
 */
public abstract class AbstractAnalysisSyncResultHandler {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    protected static final Integer BATCH_INSERT_NUM = 1000;
    
    private final AnalysisFeignClient analysisFeignClient = BeanUtlis.getBean(AnalysisFeignClient.class);
    
    protected final BigdataAnalysisTaskService bigdataAnalysisTaskService = BeanUtlis.getBean(BigdataAnalysisTaskService.class);
    
    protected PersonPropertiest personPropertiest = BeanUtlis.getBean(PersonPropertiest.class);
    
    protected SubArchiveService subArchiveService = BeanUtlis.getBean(SubArchiveService.class);
    
    protected final BigdataAnalysisArchiveService bigdataAnalysisArchiveService = BeanUtlis.getBean(BigdataAnalysisArchiveService.class);
    
    protected IPersonfileCameraService iPersonfileCameraService = BeanUtlis.getBean(IPersonfileCameraService.class);
    
    protected final BigdataAnalysisEventService bigdataAnalysisEventService = BeanUtlis.getBean(BigdataAnalysisEventService.class);
    
    protected String type;
    
    private AbstractAnalysisSyncResultHandler nextImportService;
    
    public void setNextHandler(AbstractAnalysisSyncResultHandler nextImportService) {
        this.nextImportService = nextImportService;
    }
    
    public void syncResult(String type, AnalysisTaskResultDTO analysisTaskResultDTO) throws ParseException {
        if (this.type.equals(type)) {
            syncData(analysisTaskResultDTO);
        }
        if (nextImportService != null) {
            nextImportService.syncResult(type, analysisTaskResultDTO);
        }
    }
    
    /**
     * 数据同步
     *
     * @param analysisTaskResultDTO 参数集
     */
    abstract protected void syncData(AnalysisTaskResultDTO analysisTaskResultDTO) throws ParseException;
    
    /**
     * 参数校验以及数据获取
     *
     * @param analysisTaskResultDTO
     * @return JSONObject
     */
    protected JSONObject getResult(AnalysisTaskResultDTO analysisTaskResultDTO) {
        // 参数校验
        if (analysisTaskResultDTO.getType() == null || Strings.isBlank(analysisTaskResultDTO.getTaskId())) {
            logger.error("分析结果导入失败：参数异常");
            return null;
        }
        
        analysisTaskResultDTO.setTaskType(analysisTaskResultDTO.getType());
        analysisTaskResultDTO.setOpCode("GetResult");
        analysisTaskResultDTO.setBizCode(personPropertiest.getBizCode());
        return JSONObject.parseObject(analysisFeignClient.getTaskResult(analysisTaskResultDTO));
    }
    
    /**
     * 更新任务状态
     *
     * @param analysisTaskResultDTO 参数集
     * @param success               是否成功 （true: 成功；false：失败）
     */
    protected void updateTaskStatus(AnalysisTaskResultDTO analysisTaskResultDTO, Boolean success) {
        BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskById(analysisTaskResultDTO.getTaskId2());
        bigdataAnalysisTask.setStatus(success ? 1 : 0);
        bigdataAnalysisTask.setCostTime(analysisTaskResultDTO.getCostTime());
        bigdataAnalysisTask.setResult(analysisTaskResultDTO.getCrashResult());
        bigdataAnalysisTask.setRemark(analysisTaskResultDTO.getRemark());
        bigdataAnalysisTaskService.updateBigdataAnalysisTask(bigdataAnalysisTask);
    }
    
    /**
     * 清空对应任务历史数据
     *
     * @param analysisTaskResultDTO 参数集
     */
    protected void clearHistoryData(AnalysisTaskResultDTO analysisTaskResultDTO) {
        bigdataAnalysisEventService.deleteBigdataAnalysisEventByTaskId(analysisTaskResultDTO.getTaskId2());
        bigdataAnalysisArchiveService.deleteBigdataAnalysisArchiveByTaskId(analysisTaskResultDTO.getTaskId2());
    }
    
    /**
     * 去重
     *
     * @param keyExtractor
     * @param <T>
     * @return
     */
    protected static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object,Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
    
}
