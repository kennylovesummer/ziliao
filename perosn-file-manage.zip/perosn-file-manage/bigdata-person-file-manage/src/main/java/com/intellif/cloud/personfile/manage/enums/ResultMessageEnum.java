package com.intellif.cloud.personfile.manage.enums;

/**
 * 返回结果集合
 *
 * @author liuzj
 * @version 1.0
 * @date 2018年12月13日
 * @see ResultMessageEnum
 * @since JDK1.8
 */
public enum ResultMessageEnum {

    SEARCH_SUCCESS("查询成功!"),

    SEARCH_FAILED("查询失败!"),

    EXECUTE_SUCCESS("操作成功!"),

    EXECUTE_FAILED("操作失败!"),

    DELETE_SUCCESS("删除成功"),

    DELETE_FAILED("删除失败"),

    EXCEPTION_INFO("异常信息："),

    EVENT_ID_MUST_NOT_NULL("事件id不能为空"),

    EVENT_NOT_FOUND("查询抓拍事件详情异常"),

    EVENT_MORE_SUCCESS("查询更多抓拍图片成功"),

    EVENT_LIST_SUCCESS("获取事件(列表)成功"),

    FACE_NOT_FOUND_IN_THE_PICTURE("图片无人脸!"),

    FACE_NOT_FOUNT("暂无大图"),

    SMALL_TO_LARGE_SUCCESS("根据小图查询大图成功"),

    LARGE_TO_SMALL_SUCCESS("根据大图查询小图成功"),

    DEEP_EYE_LOGIN_FAIL("深目登录失败"),

    IMAGE_UPLOAD_SUCCESS("图片上传成功");

    private String message;

    ResultMessageEnum(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
