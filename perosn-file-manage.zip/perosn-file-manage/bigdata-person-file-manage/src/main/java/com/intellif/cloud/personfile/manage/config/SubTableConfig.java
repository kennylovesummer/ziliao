//package com.intellif.deep.cloud.archive.manage.config;
//
//import com.google.common.collect.Lists;
//import com.intellif.deep.cloud.common.constants.ICommonConstant;
//import org.apache.logging.log4j.util.Strings;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.Arrays;
//import java.util.List;
//
//@Configuration
//public class SubTableConfig {
//
//    @Value("${subTable.enable}")
//    private boolean enable;
//
//    @Value("${subTable.schema-root}")
//    private String schemaRoot;
//
//    @Value("${subTable.schemas}")
//    private String schemas;
//
//    @Value("${subTable.strategy}")
//    private String strategy;
//
//    public String getStrategy() {
//        return strategy;
//    }
//
//    public void setStrategy(String strategy) {
//        this.strategy = strategy;
//    }
//
//    public boolean isEnable() {
//        return enable;
//    }
//
//    public void setEnable(boolean enable) {
//        this.enable = enable;
//    }
//
//    public String getSchemaRoot() {
//        return schemaRoot;
//    }
//
//    public void setSchemaRoot(String schemaRoot) {
//        this.schemaRoot = schemaRoot;
//    }
//
//    public List<String> getSchemas() {
//        if (Strings.isNotEmpty(this.schemas)) {
//            return Arrays.asList(this.schemas.split(ICommonConstant.Symbol.COMMA));
//        }
//        return Lists.newArrayList();
//    }
//
//    public void setSchemas(String schemas) {
//        this.schemas = schemas;
//    }
//}
