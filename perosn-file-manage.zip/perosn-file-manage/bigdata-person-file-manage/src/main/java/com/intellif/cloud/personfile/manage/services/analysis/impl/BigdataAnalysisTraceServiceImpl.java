package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTrace;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.TraceDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTraceService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuzj
 * @see BigdataAnalysisTraceService
 */
@Service
public class BigdataAnalysisTraceServiceImpl extends BaseServiceImpl implements BigdataAnalysisTraceService {
    
    private static final BigdataAnalysisTrace BIGDATA_ANALYSIS_TRACE = new BigdataAnalysisTrace();
    
    @Override
    public BigdataAnalysisTrace findAnalysisTraceById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryTrace = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryTrace.setParameter(parameters);
            queryTrace.setStatement("findAnalysisTraceById");
            Object object = this.baseDao.findOneByCustom(queryTrace);
            return object == null ? null : (BigdataAnalysisTrace) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace) {
        if (bigdataAnalysisTrace != null && bigdataAnalysisTrace.getId() != null) {
            this.baseDao.delete(bigdataAnalysisTrace);
        }
    }
    
    @Override
    public Long insertAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace) {
        if (bigdataAnalysisTrace != null) {
            bigdataAnalysisTrace.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisTrace.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisTrace);
        return bigdataAnalysisTrace.getId();
    }
    
    @Override
    public void batchInsertAnalysisTrace(List<BigdataAnalysisTrace> traceList) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_TRACE, null, traceList);
    }
    
    @Override
    public void updateAnalysisTrace(BigdataAnalysisTrace bigdataAnalysisTrace) {
        this.baseDao.update(bigdataAnalysisTrace);
    }
    
    @Override
    public Page<BigdataAnalysisTrace> findAnalysisTraceByParams(TraceDTO traceDTO) {
        QueryEvent<TraceDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(traceDTO);
        queryEvent.setStatement("findAnalysisTraceByParams");
        
        Page<BigdataAnalysisTrace> page = PageHelper.startPage(traceDTO.getPage(), traceDTO.getPerpage());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public Page<Long> findAnalysisTraceByPage(Long taskId, Integer pageNo, Integer pageSize) {
        Map<String, Object> params = Maps.newHashMap();
        params.put("taskId", taskId);
        QueryEvent queryEvent = new QueryEvent<>();
        queryEvent.setParameter(params);
        queryEvent.setStatement("findAnalysisTraceByPage");
        
        Page<Long> page = PageHelper.startPage(pageNo, pageSize);
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public void deleteBigdataAnalysisTraceByTaskId(Long taskId) {
        if (taskId == null) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        this.baseDao.updateStatement("deleteBigdataAnalysisTraceByTaskId",parameters);
    }
    
    @Override
    public Long findCameraToal(Long taskId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findCameraToal");
        return (Long) this.baseDao.findOneByCustom(queryEvent);
    }
    
    @Override
    public Long findEventToal(Long taskId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findEventToal");
        return (Long) this.baseDao.findOneByCustom(queryEvent);
    }
    
}
