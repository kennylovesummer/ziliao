package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.personfile.manage.entity.PersonfileOperateLog;
import com.intellif.cloud.personfile.manage.services.general.PersonfileOperateLogService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * 操作日志
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年11月14日
 * @see PersonfileOperateLogService
 * @since JDK1.8
 */
@Service
public class PersonfileOperateLogServiceImpl extends BaseServiceImpl implements PersonfileOperateLogService {
    
    @Override
    public int insert(PersonfileOperateLog personfileOperateLog) {
        personfileOperateLog.setCreateTime(new Date()).setModifiedTime(new Date());
        return this.baseDao.insert(personfileOperateLog);
    }
}
