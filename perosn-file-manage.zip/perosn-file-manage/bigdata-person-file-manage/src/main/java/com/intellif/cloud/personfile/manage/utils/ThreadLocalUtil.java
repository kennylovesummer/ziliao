package com.intellif.cloud.personfile.manage.utils;

import com.github.pagehelper.util.StringUtil;
import com.google.common.base.Strings;
import org.springframework.util.CollectionUtils;

import java.util.List;

public class ThreadLocalUtil {
    
    private static ThreadLocal<String> threadLocalMap = new ThreadLocal<>();
    
    public static String getTableName() {
        return threadLocalMap.get();
    }
    
    public static void setTableName(String tableName) {
        if (StringUtil.isNotEmpty(tableName))
            threadLocalMap.set(tableName);
    }
    
    public static void remove() {
        threadLocalMap.remove();
    }
    
    
    
    private static ThreadLocal<String> threadLocalMapOfSubTable = new ThreadLocal<>();
    
    public static String getSubTableName() {
        return threadLocalMapOfSubTable.get();
    }
    
    public static void setSubTableName(String subTableName) {
        if (!Strings.isNullOrEmpty(subTableName))
            threadLocalMapOfSubTable.set(subTableName);
    }
    
    public static void removeSubTableName() {
        threadLocalMapOfSubTable.remove();
    }
    
    
    private static ThreadLocal<List<String>> threadLocalMapOfTable = new ThreadLocal<>();
    
    public static List<String> getSubKnowTableName() {
        return threadLocalMapOfTable.get();
    }
    
    public static void setSubKnowTableName(List<String> subKnowTableName) {
        if (!CollectionUtils.isEmpty(subKnowTableName))
            threadLocalMapOfTable.set(subKnowTableName);
    }
    
    public static void removeSubKnowTableName() {
        threadLocalMapOfTable.remove();
    }
    
    
    private static ThreadLocal<Boolean> threadLocalMapOfIsClear = new ThreadLocal<>();
    
    public static Boolean needClear() {
        return threadLocalMapOfIsClear.get();
    }
    
    public static void setneedClear(Boolean needClear) {
        if (needClear != null)
            threadLocalMapOfIsClear.set(needClear);
    }
    
    public static void removeNeedClearMap() {
        threadLocalMapOfIsClear.remove();
    }
    
}
