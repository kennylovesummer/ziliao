package com.intellif.cloud.personfile.manage.services.general;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;

import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileRubbishService
 * @date 2019/3/15 14:08
 * @description
 */
public interface PersonfileRubbishService {

    /**
     * 获取回收站图片列表
     *
     * @param pageNo
     * @param pageSize
     * @return list
     */
    Page<PersonfileRubbish> findPersonfileRubbish(int pageNo, int pageSize);

    /**
     * 删除单张照片到回收站
     *
     * @return int
     */
    int insertPersonfileRubbish(PersonfileRubbish personfileRubbish);

    /**
     * 删除回收站照片
     *
     * @return int
     */
    int deletePersonfileRubbish(PersonfileRubbish personfileRubbish);

    /**
     * 删除档案到回收站
     *
     * @return int
     */
    int insertBatchPersonfileRubbish(List<PersonfileRubbish> personfileRubbishes);

    /**
     * 回收站照片推送至数据平台
     *
     * @return Map
     */
    List<Map<String, Object>> findPersonfileRubbishToCluster(BasePageReqDTO basePageReqDTO);

    /**
     * 根据ID删除
     *
     * @param ids ID集合
     */
    void deleteByIds(List<Object> ids);

}
