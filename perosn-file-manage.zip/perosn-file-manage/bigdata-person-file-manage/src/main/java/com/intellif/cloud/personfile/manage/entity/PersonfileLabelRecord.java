package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author liuyu
 * @className PersonfileLabelRecord
 * @date 2019/4/12 15:14
 * @description
 */
@Data
public class PersonfileLabelRecord implements Serializable {

    private static final long serialVersionUID = -6870578081390007157L;

    private String aid;

    private Long labelId;

    private String labelName;
}
