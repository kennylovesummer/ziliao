package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.handler.analysis.syncResult.AnalysisResultHandler;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskListDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.crash.CrashVO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveAvatorService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

/**
 * 数据分析任务
 *
 * @author lzj
 * @version 1.0
 * @date 2019年07月01日
 * @see CrashAnalysisController
 * @since JDK1.8
 */
@Api(tags = "数据分析-分析任务")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.ANALYSIS_TASK)
public class AnalysisTaskController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    @Autowired
    private BigdataAnalysisCrashAreaService bigdataAnalysisCrashAreaService;
    
    @Autowired
    private IPersonfileCameraService iPersonfileCameraService;
    
    @Autowired
    private AnalysisFeignClient analysisFeignClient;
    
    @Autowired
    private SubArchiveService archiveService;
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    /**
     * 新建任务
     *
     * @param jsonObject 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "创建分析任务")
    @PostMapping(value = "add/task")
    public BaseDataRespDTO save(@RequestBody JSONObject jsonObject) {
        try {
            if (!jsonObject.containsKey("taskType") || !jsonObject.containsKey("taskName")) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "参数【taskType/taskName】异常");
            }
            
            return bigdataAnalysisTaskService.createTask(jsonObject);
            
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "任务新建失败", e.getMessage());
        }
    }
    
    /**
     * 删除任务
     *
     * @param taskId 任务ID
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "DELETE",value = "删除分析任务")
    @DeleteMapping(value = "delete/task/{taskId}/{execId}")
    public BaseDataRespDTO del(@PathVariable(value = "taskId") Long taskId,@PathVariable(value = "execId") String execId) {
        try {
            // 参数校验
            if (taskId == null || Strings.isBlank(execId)) {
                return new BaseDataRespDTO("任务删除失败", IResultCode.ERROR, "参数异常");
            }
    
            BigdataAnalysisTask task = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(execId);
            bigdataAnalysisTaskService.deleteTask(taskId);
            
            try {
                OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
                offLineTaskDTO.setOpCode("delete");
                offLineTaskDTO.setTaskId(execId);
                offLineTaskDTO.setTaskType(task.getType());
                analysisFeignClient.delTask(offLineTaskDTO);
            } catch (Exception e){
                e.printStackTrace();
            }
            
            return new BaseDataRespDTO("任务删除成功", IResultCode.SUCCESS, "任务删除成功");
        } catch (Exception e) {
            return new BaseDataRespDTO("任务删除失败", IResultCode.ERROR, "任务删除失败", e.getMessage());
        }
    }
    
    /**
     * 获取任务列表
     *
     * @param crashListDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取历史分析任务")
    @PostMapping(value = "list")
    public BasePageRespDTO list(@RequestBody AnalysisTaskListDTO crashListDTO) {
        try {
            if ((crashListDTO.getStartTime() == null && crashListDTO.getEndTime() != null)
                    || (crashListDTO.getStartTime() != null && crashListDTO.getEndTime() == null) ) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "时间参数异常", "时间参数异常");
            }
            
            List<CrashVO> result = Lists.newLinkedList();
            
            // 获取数据
            Page<CrashVO> page = bigdataAnalysisTaskService.findBigdataAnalysisTaskByParams(crashListDTO);
            
            // 数据处理
            List<CrashVO> crashVOList = page.getResult();
            if (CollectionUtils.isNotEmpty(crashVOList)) {
                for (CrashVO crashVO : crashVOList) {
                    if (crashVO.getStatus() == 3) {
                        crashVO.setStatus(2);
                    }
                    if (Strings.isNotBlank(crashVO.getPersonfileId())) {
                        PersonfileBasics personfileBasics = archiveService.findBaseInfoByPersonFileId(crashVO.getPersonfileId());
                        crashVO.setFaceUrl(personfileBasics != null ? personfileBasics.getHeadImageUrl() : null);
                        crashVO.setPersonName(personfileBasics != null ? personfileBasics.getName() : null);
                        crashVO.setCid(personfileBasics != null ? personfileBasics.getCid() : null);
                    }
    
                    // 地区详情
                    List<BigdataAnalysisCrashArea> analysisCrashAreas = bigdataAnalysisCrashAreaService.findAnalysisCrashAreaByTaskId(crashVO.getId());
                    if (CollectionUtils.isNotEmpty(analysisCrashAreas)) {
                        // 档案总数
                        CrashDTO crashDTO = new CrashDTO();
                        crashDTO.setTaskId(crashVO.getId());
                        Page<BigdataAnalysisArchive> archivePage = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(crashDTO);
                        if (archivePage != null) {
                            crashVO.setArchiveTotal(archivePage.getTotal());
                        }
                        
                        // 地区
                        if (Strings.isNotBlank(crashVO.getResult())) {
                            crashVO.setFaceList(Arrays.asList(crashVO.getResult().split(ICommonConstant.Symbol.COMMA)));
                            crashVO.setFaceUrl(CollectionUtils.isNotEmpty(crashVO.getFaceList()) ? (String)crashVO.getFaceList().get(0) : null);
                        }
                        for (BigdataAnalysisCrashArea area : analysisCrashAreas) {
                            PersonfileCamera personfileCamera = iPersonfileCameraService.findCameraByDevId(area.getFirstDevId());
                            area.setAddress(personfileCamera != null ? personfileCamera.getName() : null);
                        }
                        crashVO.setAreas(analysisCrashAreas);
                    }
                    
                    if (DataStisticTypeEnum.getByName(crashVO.getType()) != null) {
                        crashVO.setTypeName(DataStisticTypeEnum.getByName(crashVO.getType()).getChName());
                    }
                    
                    result.add(crashVO);
                }
            }
            return new BasePageRespDTO(result, page.getPages(), Integer.parseInt(page.getTotal() + ""), IResultCode.SUCCESS, "获取成功");
        } catch (Exception e) {
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "获取失败", e.getMessage());
        }
    }
    
    /**
     * 任务完成回调接口
     *
     * @param execid 任务ID
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "GET",value = "获取任务状态")
    @GetMapping(value = "finish/{execid}")
    public BaseDataRespDTO taskFinish(@PathVariable(value = "execid") String execid) {
        try {
            BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(execid);
            if (bigdataAnalysisTask.getStatus() == 3) {
                bigdataAnalysisTask.setStatus(2);
            }
            if (bigdataAnalysisTask != null) {
                return new BaseDataRespDTO(bigdataAnalysisTask, IResultCode.SUCCESS, "获取成功");
            } else {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "获取失败", "任务异常：任务不存在");
            }
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "获取失败", e.getMessage());
        }
    }
    
    @ApiOperation(httpMethod = "PUT",value = "获取任务状态以及同步分析数据：status = true ? 获取任务状态并拉取分析数据 : 拉取分析数据")
    @PutMapping(value = "test/task/finish/{execId}/{status}")
    public void syncData(@PathVariable(value = "execId") String execId,@PathVariable(value = "status") Boolean status) {
        try {
            if (status) {
                bigdataAnalysisTaskService.analysisTaskStatusHandler(execId);
            } else {
                BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(execId);
                AnalysisTaskResultDTO analysisTaskResultDTO = new AnalysisTaskResultDTO();
                analysisTaskResultDTO.setType(DataStisticTypeEnum.getByName(bigdataAnalysisTask.getType()).getResultName());
                analysisTaskResultDTO.setTaskId(execId);
                analysisTaskResultDTO.setTaskId2(bigdataAnalysisTask.getId());
                analysisTaskResultDTO.setCostTime(1000L);
                AnalysisResultHandler.getHandlerChain().syncResult(DataStisticTypeEnum.getByName(bigdataAnalysisTask.getType()).getResultName(), analysisTaskResultDTO);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
