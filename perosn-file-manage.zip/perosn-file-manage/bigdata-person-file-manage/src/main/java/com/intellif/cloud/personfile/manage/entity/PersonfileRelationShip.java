package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Administrator
 */
@Data
public class PersonfileRelationShip implements Serializable {

    private static final long serialVersionUID = 6325793976497817688L;

    private Integer id;

    private Date createTime;

    private Date modifiedTime;

    @NotBlank(message = "关系名不可为空")
    private String relationShipName;

    private String label;

    private Integer isDeleted;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}