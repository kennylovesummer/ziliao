package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 数据分析轨迹结果
 *
 * @author liuzj
 * @date 2019-07-18
 */
@Data
public class BigdataAnalysisTrace implements Serializable {
    private static final long serialVersionUID = 6197442847703817933L;
    private Long id;
    
    private Long taskId;

    private Long date;

    private String cameraId;

    private String cameraName;

    private String geoString;

    private Date createTime;

    private String createBy;

    private Date modifyTime;

    private String modifyBy;

}