package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName StatisticPersonfileEvent
 * @Author liuzj
 * @create 2019-05-24
 * @Version 1.0
 * @desc 事件日统
 */
public class StatisticPersonfileEvent implements Serializable {

    private Long id;

    private Date createTime;

    private Date modifyTime;

    private Date dt;

    private int incNum;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

    public int getIncNum() {
        return incNum;
    }

    public void setIncNum(int incNum) {
        this.incNum = incNum;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}