package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisTaskService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import org.apache.logging.log4j.util.Strings;

/**
 * 分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public abstract class AbstractAnalysisCreateTaskHandler {
    
    protected String type;
    
    protected final BigdataAnalysisTaskService bigdataAnalysisTaskService = BeanUtlis.getBean(BigdataAnalysisTaskService.class);
    
    protected final PersonPropertiest personPropertiest = BeanUtlis.getBean(PersonPropertiest.class);
    
    private final AnalysisFeignClient analysisFeignClient = BeanUtlis.getBean(AnalysisFeignClient.class);
    
    protected final SubArchiveService subArchiveService = BeanUtlis.getBean(SubArchiveService.class);
    
    private AbstractAnalysisCreateTaskHandler nextCreateTaskHandler;
    
    protected void setNextHandler(AbstractAnalysisCreateTaskHandler nextCreateTaskHandler) {
        this.nextCreateTaskHandler = nextCreateTaskHandler;
    }
    
    public String createTask(String type, JSONObject params) throws BusinessException {
        if (this.type.equals(type)) {
            return doCreate(params);
        }
        if (nextCreateTaskHandler != null) {
            nextCreateTaskHandler.createTask(type, params);
        }
        return null;
    }
    
    abstract protected String doCreate(JSONObject params) throws BusinessException;
    
    protected String xdataCreateTask(OffLineTaskDTO offLineTaskDTO) throws BusinessException {
        JSONObject result = JSONObject.parseObject(analysisFeignClient.addTask(offLineTaskDTO));
        
        if (SuccessRespUtil.isSuccess(result)) {
            JSONObject data = result.getJSONObject(ICommonConstant.ResultDataFormat.data);
            String execId = data.getString("taskId");
            if (Strings.isBlank(execId)) {
                throw new BusinessException(IResultCode.ERROR, "execId未知");
            }
            return execId;
        } else {
            throw new BusinessException(IResultCode.ERROR, result.getString(ICommonConstant.ResultDataFormat.respRemark));
        }
    }
    
}
