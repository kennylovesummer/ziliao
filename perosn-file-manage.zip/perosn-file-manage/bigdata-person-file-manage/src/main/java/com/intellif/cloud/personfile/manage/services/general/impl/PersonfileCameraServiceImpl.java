package com.intellif.cloud.personfile.manage.services.general.impl;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.model.dto.camera.PersonfileCameraReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.DeepPageUtil;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 设备接口类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月17日
 * @see PersonfileCameraServiceImpl
 * @since JDK1.8
 */
@Service
public class PersonfileCameraServiceImpl extends BaseServiceImpl implements IPersonfileCameraService {
    /**
     * 根据摄像头id查询详情
     *
     * @param devId
     * @return
     */
    @Override
    public PersonfileCamera findCameraByDevId(String devId) {
        QueryEvent queryEvent = new QueryEvent();
        Map<String, Object> paramMap = new HashMap<>(1);
        paramMap.put("devId", devId);
        queryEvent.setParameter(paramMap);
        queryEvent.setStatement("findCameraByDevId");
        return (PersonfileCamera) this.baseDao.findOneByCustom(queryEvent);
    }

    /**
     * 根据摄像头id集合查询详情
     *
     * @param devIdList
     * @return
     */
    @Override
    public List<PersonfileCamera> findCameraByDevIdList(List<String> devIdList) {
        QueryEvent queryEvent = new QueryEvent();
        Map<String, Object> paramMap = new HashMap<>(1);
        paramMap.put("devIdList", devIdList);
        queryEvent.setParameter(paramMap);
        queryEvent.setStatement("findCameraByDevIdList");
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    /**
     * 新增
     *
     * @param personfileCamera
     * @return
     */
    @Override
    public int insertPersonfileCamera(PersonfileCamera personfileCamera) {
        return this.baseDao.insert(personfileCamera);
    }

    /**
     * 批量新增
     *
     * @param personfileCameraList
     * @return
     */
    @Override
    public int insertPersonfileCameraBatch(List<PersonfileCamera> personfileCameraList) {
        return this.baseDao.batchInsert(new PersonfileCamera(), null, personfileCameraList);
    }

    /**
     * 设备列表分页查询
     *
     * @param personfileCameraReqDTO 设备对象
     * @return 设备列表
     */
    @Override
    public BasePageRespDTO queryPersonfileCamera(PersonfileCameraReqDTO personfileCameraReqDTO) {
        if (StringUtils.isBlank(personfileCameraReqDTO.getStartTime())) {
            personfileCameraReqDTO.setStartTime("");
        }
        if (StringUtils.isBlank(personfileCameraReqDTO.getEndTime())) {
            personfileCameraReqDTO.setEndTime("");
        }

        QueryEvent event = new QueryEvent();
        event.setStatement("findPersonfileCamera");
        event.setObj(personfileCameraReqDTO);
        // pageNum,pageSize,true 开启统计
        Page<PersonfileCameraReqDTO> page =
                PageHelper.startPage(personfileCameraReqDTO.getPage(), personfileCameraReqDTO.getPerpage(), true);

        this.baseDao.findAllIsPageByCustom(event);
        PageInfo<PersonfileCameraReqDTO> pageInfo = new PageInfo<>(page);
        int total = (int) pageInfo.getTotal();
        // Object data, int maxPage, int total,int respCode
        return new BasePageRespDTO(JSONArray.toJSONStringWithDateFormat(pageInfo.getList(), ICommonConstant.DateFormatType.Y_M_D_H_S),
                DeepPageUtil.getMaxPage(personfileCameraReqDTO.getPerpage(), total),
                total, IResultCode.SUCCESS);
    }
    
    @Override
    public void deletePersonfileCamera() {
        this.baseDao.updateStatement("deletePersonfileCamera", Maps.newHashMap());
    }
}
