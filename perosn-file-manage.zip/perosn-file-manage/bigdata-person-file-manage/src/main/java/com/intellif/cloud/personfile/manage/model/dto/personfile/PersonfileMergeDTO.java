package com.intellif.cloud.personfile.manage.model.dto.personfile;

import lombok.Data;

import java.util.List;

@Data
public class PersonfileMergeDTO {
    
    private List<String> fromAids;
    
    private String targetAid;
}
