package com.intellif.cloud.personfile.manage.feignclient;

import com.intellif.cloud.personfile.manage.feignclient.fallback.DeepEyeHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * @author 深目登录的feignClient
 * @version 1.0
 * @date 2018年10月22日
 * @see 
 * @since JDK1.8
 */
@FeignClient(name = "deepEyeClient", url = "${deepEye.url.prefix}",fallback = DeepEyeHystrix.class)
public interface DeepEyeClient {


    /**
     * 登录获取token
     *
     * @param username   账号
     * @param password   密码
     * @param grant_type 授权类型
     * @return
     */
    @PostMapping(value = "/api/oauth/token", headers = {"content-type=application/x-www-form-urlencoded", "Authorization=Basic Y2xpZW50YXBwOjEyMzQ1Ng=="})
    String login(@RequestParam("username") String username, @RequestParam("password") String password, @RequestParam("grant_type") String grant_type);
}
