package com.intellif.cloud.personfile.manage.controllers.sso;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.model.dto.account.AccountDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.account.BigdataAccountService;
import com.intellif.cloud.personfile.manage.utils.PersonHttpClientUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * 单点登录
 *
 * @author liuzj
 */
@Api(tags = "单点登录")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.SSO_LIU_ZHOU)
public class UserAuthenController {
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private BigdataAccountService bigdataAccountService;
    
    private static final String CONTENT_TYPE = "application/json; charset=UTF-8";
    
    @ApiOperation(httpMethod = "POST",value = "登录")
    @PostMapping("user/authen")
    public BaseDataRespDTO authen(@RequestBody JSONObject params){
        if (!params.containsKey("token")) {
            return new BaseDataRespDTO(IResultCode.ERROR,"请求异常!","参数token缺失!");
        }
        
        String token = params.getString("token");
    
        // 根据token获取用户信息
        Map<String, String> headers = new HashMap<>(1);
        headers.put(HttpHeaders.AUTHORIZATION, token);
        headers.put(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE);
        String url = personPropertiest.getSsoLoginUrl();
        String result = PersonHttpClientUtil.httpPostParamString(url,null,headers,CONTENT_TYPE);
        JSONObject jsonObject = JSONObject.parseObject(result);
        
        if (jsonObject == null) {
            return new BaseDataRespDTO(null,IResultCode.ERROR,"登录失败！");
        } else if (jsonObject.containsKey("success") && jsonObject.getBoolean("success")) {
            Map<String,Object> data = Maps.newHashMap();
            JSONObject dataJson = jsonObject.getJSONObject("data");
            String username = dataJson.getString("policeNo");
            
            // 验证用户是否在系统中存在，不存在则保存
            AccountDTO accountDTO = new AccountDTO();
            accountDTO.setAccount(username);
            BigdataAccount account = bigdataAccountService.findBigdataAccountByAccountAndPassword(accountDTO);
            if (account == null) {
                BigdataAccount bigdataAccount = new BigdataAccount();
                bigdataAccount.setName(username);
                bigdataAccount.setAccount(username);
                bigdataAccount.setPassword(token);
                bigdataAccountService.insertBigdataAccount(bigdataAccount);
            }
            
            data.put("username",username);
            data.put("avatarUrl",dataJson.getString("avatarUrl"));
            
            return new BaseDataRespDTO(data,IResultCode.SUCCESS,"登录成功！");
        } else {
            return new BaseDataRespDTO(null,IResultCode.ERROR,"登录失败！",jsonObject.getString("msg"));
        }
    }
    
    @RequestMapping(value = "auth/realms/{realm}/protocol/openid-connect/userinfo",method = RequestMethod.POST)
    public String tokenOathen(@PathVariable(value = "realm")String realm, HttpServletRequest request){
        String token = request.getHeader(HttpHeaders.AUTHORIZATION);
        String contentType = request.getContentType();
        return "验证token";
    }
    
    @RequestMapping(value = "/user/getCurrent",method = RequestMethod.POST)
    public JSONObject getUser(HttpServletRequest request){
        String token = request.getHeader(HttpHeaders.AUTHORIZATION);
        String contentType = request.getContentType();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 0);
        jsonObject.put("msg", "操作成功！");
        
        JSONObject data = new JSONObject();
        data.put("avatarUrl","http://192.168.11.100/store1165-2_3/FaceWareHouse/src_0_27/20180425/20180425T124353_88312_119580.jpg");
        data.put("username","tom");
        jsonObject.put("data", data);
        
        return jsonObject;
    }
    
}
