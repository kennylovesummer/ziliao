package com.intellif.cloud.personfile.manage.schedule.rubbish;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.kafka.producer.MqProducer;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 回收站定时
 *
 * @author liuzhijian
 * @date 2019-03-15
 */
@Component
public class RubbishClusterSchedule {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonfileRubbishService personfileRubbishService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    MqProducer mqProducer;

    /**
     * 将回收站照片推送到kafka，数据平台接收kafka并对照片进行二次聚类
     */
    @Scheduled(cron = "0 0 1 * * ?")
//    @Scheduled(cron = "0 */10 * * * ?")
    public void clusterAgain() {
        try {
            logger.info("回收站照片推送开始...");
            BasePageReqDTO basePageReqDTO = new BasePageReqDTO();
            basePageReqDTO.setPerpage(1000);
            List<Map<String, Object>> result = personfileRubbishService.findPersonfileRubbishToCluster(basePageReqDTO);
            for (int i = 2; CollectionUtils.isNotEmpty(result); i++) {
                // 推送至kafka
                for (Map item : result) {
                    logger.info("开始推送至数据平台进行二次归类:", item);
                    mqProducer.send(JSONObject.toJSONString(item), personPropertiest.getKafkaListenerPersonfileRubbishTopic());
                }
                // 推送完了立即删除
                logger.info("推送至数据平台进行二次归类结束后删除:", result);
                personfileRubbishService.deleteByIds(result.stream().map(dd -> dd.get("id")).collect(Collectors.toList()));
                basePageReqDTO.setPage(i);
                result = personfileRubbishService.findPersonfileRubbishToCluster(basePageReqDTO);
            }
            logger.info("回收站照片推送完成。");
        } catch (Exception e) {
            logger.info("回收站照片推送异常：", e.getMessage());
        }
    }

}
