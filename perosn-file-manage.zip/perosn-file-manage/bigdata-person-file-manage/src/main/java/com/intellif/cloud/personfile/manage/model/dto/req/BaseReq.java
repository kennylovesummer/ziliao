/*  
 * 文件名：BaseReq.java  
 * 版权：Copyright by 云天励飞 intellif.com  
 * 描述：  
 * 创建人：Administrator  
 * 创建时间：2018年8月10日    
 * 修改理由：  
 * 修改内容：  
 */  

package com.intellif.cloud.personfile.manage.model.dto.req;

import com.alibaba.fastjson.JSONObject;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

public class BaseReq implements Serializable {

	/**
	 * 序列化
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * 手持设备唯一标示
     */
    private String imei;
    
    /**
     *  操作来源 
     *  1.PC前台
     *  2.PC后台
     *  3.安卓
     *  4.苹果
     *  5.微信
     */
    @NotBlank
    private String opSource = "1";
    
    /**
     * 当前登录用户账号
     */
    private String currentUserId;
    
    
    private long depId;
    
    /**
     * 版本号
     */
    private String version = "0";
    
    public String getImei()
    {
        return imei;
    }
    
    public void setImei(String imei)
    {
        this.imei = imei;
    }
    
    public String getVersion()
    {
        return version;
    }
    
    public void setVersion(String version)
    {
        this.version = version;
    }
    
    public String getOpSource()
    {
        return opSource;
    }
    
    public void setOpSource(String opSource)
    {
        this.opSource = opSource;
    }
    
    public String getCurrentUserId()
    {
        return currentUserId;
    }
    
    public void setCurrentUserId(String currentUserId)
    {
        this.currentUserId = currentUserId;
    }
    
    public long getDepId() {
		return depId;
	}

	public void setDepId(long depId) {
		this.depId = depId;
	}

	/**
     * 得到属性字符串
     * @return String 属性字符串
     */
    @Override
    public String toString()
    {
        return JSONObject.toJSONString(this);
    }
    
}
