package com.intellif.cloud.personfile.manage.feignclient;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.feignclient.fallback.XdataFeignHystrix;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataRelationReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 一人一档的数据平台 feignClient
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月23日
 * @see XdataFeignClient
 * @since JDK1.8
 */
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.137:27001", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.63:27001", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.2:27002", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.204:27002", fallback = XdataFeignHystrix.class)
@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "${xdata.service.url}", fallback = XdataFeignHystrix.class)
public interface XdataFeignClient {
    
    /**
     * 获取抓拍图片
     *
     * @param xdataReqDTO
     * @return
     */
    @PostMapping("/xapi/archive/events")
    String eventList(@RequestBody XdataReqDTO xdataReqDTO);
    
    /**
     * 合并指定档案
     *
     * @param xdataReqDTO
     * @return
     */
    @PostMapping("/xapi/archive/merge")
    String merge(@RequestBody XdataReqDTO xdataReqDTO);
    
    /**
     * 删除档案
     *
     * @param xdataReqDTO
     * @return
     */
    @DeleteMapping("/xapi/archive")
    String delete(@RequestBody XdataReqDTO xdataReqDTO);
    
    /**
     * 查询单人人际关系
     *
     * @param xdataRelationReqDTO
     * @return
     */
    @PostMapping("/xapi/relation/query/single")
    String singlePersonRlation(@RequestBody XdataRelationReqDTO xdataRelationReqDTO);
    
    /**
     * 查询多人人际关系
     *
     * @param xdataRelationReqDTO
     * @return
     */
    @PostMapping("/xapi/relation/query/multi")
    String multiplePersonRlation(@RequestBody XdataRelationReqDTO xdataRelationReqDTO);
    
    /**
     * 添加人际关系
     *
     * @param xdataRelationDTO
     * @return String
     */
    @PostMapping(value = "/xapi/relation/create")
    String insertRelationship(@RequestBody XdataRelationReqDTO xdataRelationDTO);
    
    
    /**
     * 删除人际关系
     *
     * @param xdataRelationDTO
     * @return String
     */
    @DeleteMapping(value = "/xapi/relation/del")
    String deleteRelationship(@RequestBody XdataRelationReqDTO xdataRelationDTO);
    
    /**
     * 根据档案ID获取档案详情
     *
     * @param xdataReqDTO
     * @return String
     */
    @PostMapping(value = "/xapi/archive")
    String getPersonfileById(@RequestBody XdataReqDTO xdataReqDTO);
    
}
