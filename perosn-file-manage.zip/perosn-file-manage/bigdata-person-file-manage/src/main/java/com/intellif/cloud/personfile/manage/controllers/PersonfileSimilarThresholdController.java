package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author liuyu
 * @className PersonfileSimilarThresholdController
 * @date 2019/2/27 10:50
 * @description
 */
@Api(tags = "相似档案阈值设置")
@RestController
@RequestMapping(IPersonfilesManageConstant.BaseUrl.RESOURCE_BASE)
public class PersonfileSimilarThresholdController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final PersonPropertiest personPropertiest;
    
    private final BigdataCommonService bigdataCommonService;
    
    @Autowired
    public PersonfileSimilarThresholdController(PersonPropertiest personPropertiest
            , BigdataCommonService bigdataCommonService) {
        this.personPropertiest = personPropertiest;
        this.bigdataCommonService = bigdataCommonService;
    }
    
    /**
     * 推荐档案相似值设置（当相似度为 -1 时表示获取默认值）
     *
     * @param similarRate 相似度
     * @param version 版本
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "PUT",value = "推荐档案相似值设置")
    @PutMapping("/similarPersonFile/threshold/{similarRate}/{version}")
    public BaseDataRespDTO post(@PathVariable(name = "similarRate", required = false) Float similarRate,
                                @PathVariable(name = "version") String version) {
        try {
            BigdataCommon bigdataCommon;
            List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(IPersonfilesManageConstant.IRedisCacheKey.PERSONFILES_SIMILAR_RATE);
            if (similarRate == -1) {
                return IPersonFilesResultInfo.ok(CollectionUtils.isEmpty(bigdataCommons) ? personPropertiest.getSimilarRate() : bigdataCommons.get(0).getContent(), "档案推荐相似度设置成功！");
            }
            if (CollectionUtils.isNotEmpty(bigdataCommons)) {
                bigdataCommon = bigdataCommons.get(0);
                bigdataCommon.setContent(similarRate.toString());
                bigdataCommonService.updateBigdataCommon(bigdataCommon);
            } else {
                bigdataCommon = new BigdataCommon();
                bigdataCommon.setContentType(IPersonfilesManageConstant.IRedisCacheKey.PERSONFILES_SIMILAR_RATE);
                bigdataCommon.setContent(similarRate.toString());
                bigdataCommonService.insertBigdataCommon(bigdataCommon);
            }
            return IPersonFilesResultInfo.ok(bigdataCommon.getContent(), "档案推荐相似度设置成功！","档案推荐相似度设置成功！");
        } catch (Exception e) {
            logger.error("档案推荐相似度设置失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("档案推荐相似度设置失败", "异常：" + e.getMessage());
        }
    }
}
