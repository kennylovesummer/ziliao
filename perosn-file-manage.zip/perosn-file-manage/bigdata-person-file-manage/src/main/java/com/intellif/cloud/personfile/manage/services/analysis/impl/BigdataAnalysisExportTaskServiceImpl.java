package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.task.monitor.AnalysisDataDownloadMonitor;
import com.intellif.cloud.personfile.manage.utils.FileUtils;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class BigdataAnalysisExportTaskServiceImpl extends BaseServiceImpl implements BigdataAnalysisExportTaskService {
    
    @Autowired
    private AnalysisDataDownloadMonitor analysisDataDownloadMonitor;
    
    @Override
    public BigdataAnalysisExportTask selectAnalysisExportTaskById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryEvent.setParameter(parameters);
            queryEvent.setStatement("selectAnalysisExportTaskById");
            Object object = this.baseDao.findOneByCustom(queryEvent);
            return object == null ? null : (BigdataAnalysisExportTask) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisExportTaskById(Long id) {
        if (id != null) {
            BigdataAnalysisExportTask bigdataAnalysisExportTask = new BigdataAnalysisExportTask();
            bigdataAnalysisExportTask.setId(id);
            this.baseDao.delete(bigdataAnalysisExportTask);
        }
    }
    
    @Override
    public void deleteAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask) {
        deleteAnalysisExportTaskById(bigdataAnalysisExportTask.getId());
        
        analysisDataDownloadMonitor.stopOneThread(bigdataAnalysisExportTask.getId() + "");
        
        if (Strings.isNotBlank(bigdataAnalysisExportTask.getFileName()) && Strings.isNotBlank(bigdataAnalysisExportTask.getFilePath())) {
            ThreadPoolService.threadPool.execute(new DeleteFile(bigdataAnalysisExportTask.getFilePath() + bigdataAnalysisExportTask.getFileName() + ".zip"));
        }
    }
    
    private class DeleteFile implements Runnable{
        
        private String fileName;
        
        public DeleteFile(String fileName) {
            this.fileName = fileName;
        }
    
        @Override
        public void run() {
            try {
                Thread.currentThread().setName("文件删除任务-" + fileName);
                
                FileUtils.deleteFileByPath(fileName);
            } catch (Exception e){
                e.getMessage();
            } finally {
                try {
                    Thread.sleep(3000);
                    FileUtils.deleteFileByPath(fileName);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            
        }
    }
    
    @Override
    public Long insertAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask) {
        if (bigdataAnalysisExportTask != null) {
            bigdataAnalysisExportTask.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisExportTask.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisExportTask);
        return bigdataAnalysisExportTask.getId();
    }
    
    @Override
    public void updateAnalysisExportTask(BigdataAnalysisExportTask bigdataAnalysisExportTask) {
        this.baseDao.update(bigdataAnalysisExportTask);
    }
    
    @Override
    public Page<BigdataAnalysisExportTask> findAnalysisExportTaskByParams(AnalysisTaskDTO analysisTaskDTO) {
        QueryEvent<AnalysisTaskDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(analysisTaskDTO);
        queryEvent.setStatement("findAnalysisExportTaskByParams");
        Page<BigdataAnalysisExportTask> page = PageHelper.startPage(analysisTaskDTO.getPage(), analysisTaskDTO.getPerpage(), true);
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public void deleteDiedAnalysisExportTask() {
        this.baseDao.updateStatement("deleteDiedAnalysisExportTask", Maps.newHashMap());
    }
    
}
