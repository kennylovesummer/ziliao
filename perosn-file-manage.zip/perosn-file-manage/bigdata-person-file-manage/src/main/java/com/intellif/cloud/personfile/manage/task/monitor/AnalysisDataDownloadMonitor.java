package com.intellif.cloud.personfile.manage.task.monitor;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisExportTaskService;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisExportTask;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 数据分析下载任务监控
 *
 * @author liuzj
 * @date 2019-07-23
 */
@Component
public class AnalysisDataDownloadMonitor extends AbstractTaskMonitor{
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    private AtomicBoolean needRefresh = new AtomicBoolean(false);
    
    @Override
    public void addToMonitor(String taskId, Future<?> future) {
        aliveThreadRefreshTimeMap.putIfAbsent(taskId,System.currentTimeMillis());
        aliveThreadFutureMap.putIfAbsent(taskId, future);
    }
    
    @Override
    public void doMonitor() {
        if (personPropertiest.getDataAnalysisExportTimeOutMillis() != null) {
            timeOutMillis = personPropertiest.getDataAnalysisExportTimeOutMillis();
        }
        
        needRefresh.set(false);
        Set<String> taskIds = aliveThreadRefreshTimeMap.keySet();
        if (CollectionUtils.isNotEmpty(taskIds)) {
//            logger.info(taskIds.size() + "个任务被监控：" + Strings.join(taskIds,','));
            List<String> removeIdList = new ArrayList<>();
            for (String taskId : taskIds) {
                if (needRefresh.get()) {
                    break;
                }
                long currentTime = System.currentTimeMillis();
                long executeTime = currentTime - aliveThreadRefreshTimeMap.get(taskId);
                if (executeTime > timeOutMillis) {
                    logger.error("任务：" + taskId + "已超时");
                    Future<?> future = aliveThreadFutureMap.get(taskId);
                    if (future != null) {
                        future.cancel(true);
                    }
                    removeIdList.add(taskId);
                    updateTask(taskId,0);
                }
            }
            for (String taskId : removeIdList) {
                aliveThreadFutureMap.remove(taskId);
                aliveThreadRefreshTimeMap.remove(taskId);
            }
        }
    }
    
    /**
     * 停止某个线程
     *
     * @param taskId 任务ID
     */
    public void stopOneThread(String taskId){
        Future<?> future = aliveThreadFutureMap.get(taskId);
        if (future != null) {
            future.cancel(true);
        }
        aliveThreadFutureMap.remove(taskId);
        aliveThreadRefreshTimeMap.remove(taskId);
        needRefresh.set(true);
        logger.info("任务：" + taskId + "被移除，状态更新为失败");
        updateTask(taskId,1);
    }
    
    /**
     * 更新任务状态
     *
     * @param taskId 任务ID
     * @param failedCause 失败原因（0：超时；1：手动终止）
     */
    private void updateTask(String taskId,Integer failedCause){
        BigdataAnalysisExportTask bigdataAnalysisExportTask = bigdataAnalysisExportTaskService.selectAnalysisExportTaskById(Long.valueOf(taskId));
        if (bigdataAnalysisExportTask != null && bigdataAnalysisExportTask.getStatus() != 2 && bigdataAnalysisExportTask.getStatus() != -1) {
            bigdataAnalysisExportTask.setEndTime(new Date());
            bigdataAnalysisExportTask.setUseTime(bigdataAnalysisExportTask.getEndTime().getTime() - bigdataAnalysisExportTask.getStartTime().getTime());
            bigdataAnalysisExportTask.setDownloadMsg(failedCause == 0 ? "下载超时：用时" + bigdataAnalysisExportTask.getUseTime() + "ms,已超过超时时间" + timeOutMillis + "ms,任务已被移除" : "已被手动终止");
            bigdataAnalysisExportTask.setStatus(-1);
            bigdataAnalysisExportTaskService.updateAnalysisExportTask(bigdataAnalysisExportTask);
        }
    }
}
