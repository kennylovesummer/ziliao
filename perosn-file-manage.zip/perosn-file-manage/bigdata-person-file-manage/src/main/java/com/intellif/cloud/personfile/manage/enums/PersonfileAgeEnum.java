package com.intellif.cloud.personfile.manage.enums;

/**
 * @author liuzhijian
 * @version 1.0
 * @date 2019年08月13日
 * @see PersonfileAgeEnum
 * @since JDK1.8
 */
public enum PersonfileAgeEnum {
    
    /**
     * 未知
     */
    UN_KNOW(0, 0, 0),
    
    /**
     * 婴儿
     */
    BABY(0, 5, 1),
    
    /**
     * 小孩
     */
    CHILD(5, 10, 2),
    
    /**
     * 少年
     */
    YOUNG(10, 15, 3),
    
    /**
     * 青少年
     */
    TEENAGER(15, 20, 4),
    
    /**
     * 青年
     */
    YOUTH(20, 25, 5),
    
    /**
     * 中年
     */
    MIDDLE(25, 30, 6),
    
    /**
     * 壮年
     */
    NOON(30, 50, 7),
    
    /**
     * 中老年
     */
    MIDDLE_OLD(50, 60, 8),
    
    /**
     * 老年
     */
    OLD(60, 200, 9);
    
    private int startAge;
    
    private int endAge;
    
    private int ageId;
    
    PersonfileAgeEnum(int startAge, int endAge, int ageId) {
        this.startAge = startAge;
        this.endAge = endAge;
        this.ageId = ageId;
    }
    
    public static PersonfileAgeEnum getAgeByAgeId(int ageId) {
        for (PersonfileAgeEnum realNameArgEnum : PersonfileAgeEnum.values()) {
            if (realNameArgEnum.ageId == ageId) {
                return realNameArgEnum;
            }
        }
        return PersonfileAgeEnum.UN_KNOW;
    }
    
    public int getStartAge() {
        return startAge;
    }
    
    public void setStartAge(int startAge) {
        this.startAge = startAge;
    }
    
    public int getEndAge() {
        return endAge;
    }
    
    public void setEndAge(int endAge) {
        this.endAge = endAge;
    }
    
    public int getAgeId() {
        return ageId;
    }
    
    public void setAgeId(int ageId) {
        this.ageId = ageId;
    }
}

