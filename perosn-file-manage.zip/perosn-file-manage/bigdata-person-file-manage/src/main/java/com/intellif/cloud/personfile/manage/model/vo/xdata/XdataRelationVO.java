package com.intellif.cloud.personfile.manage.model.vo.xdata;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.vo.relationship.PersonfileRelationEdgeVO;
import com.intellif.cloud.personfile.manage.model.vo.relationship.PersonfileRelationVerticeVO;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author liuyu
 * @className XdataRelationVO
 * @date 2019/4/20 10:55
 * @description
 */
@Data
public class XdataRelationVO implements Serializable {

    private static final long serialVersionUID = -8550905156666190682L;

    List<PersonfileRelationEdgeVO> edges;

    List<PersonfileRelationVerticeVO> vertices;
    
    List<SimilarArchiveVO> similarsA;
    
    List<SimilarArchiveVO> similarsB;

    public XdataRelationVO() {
    }

    public XdataRelationVO(List<PersonfileRelationEdgeVO> edges, List<PersonfileRelationVerticeVO> vertices) {
        this.edges = edges == null ? Lists.newArrayList() : edges;
        this.vertices = vertices == null ? Lists.newArrayList() : vertices;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
