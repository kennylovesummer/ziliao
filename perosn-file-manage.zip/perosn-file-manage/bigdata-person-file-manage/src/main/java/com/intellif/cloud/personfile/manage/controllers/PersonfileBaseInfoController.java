package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.annotation.OperateLog;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfile;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.statistic.StatsticPersonfileAndImageVO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.AgeivisionUtil;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月16日
 * @see PersonfileBaseInfoController
 * @since JDK1.8
 */
@Api(tags = "档案中心")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.BaseUrl.RESOURCE_BASE)
public class PersonfileBaseInfoController {
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final SubArchiveService subArchiveService;
    
    private final StatisticPersonfileEventService statisticPersonfileEventService;
    
    private final StatisticPersonfileService statisticPersonfileService;
    
    private final StatisticPersonfileTypeService statisticPersonfileTypeService;
    
    @Autowired
    public PersonfileBaseInfoController(StatisticPersonfileEventService statisticPersonfileEventService,
                                        SubArchiveService subArchiveService,
                                        StatisticPersonfileService statisticPersonfileService,
                                        StatisticPersonfileTypeService statisticPersonfileTypeService) {
        this.subArchiveService = subArchiveService;
        this.statisticPersonfileEventService = statisticPersonfileEventService;
        this.statisticPersonfileService = statisticPersonfileService;
        this.statisticPersonfileTypeService = statisticPersonfileTypeService;
    }
    
    /**
     * 合并档案
     *
     * @param initiativPersonFileId 合并档案ID
     * @param passivePersonFileId   被合并档案ID
     * @param version               版本
     * @return Stringi
     */
    @ApiOperation(httpMethod = "POST",value = "档案合并")
    @OperateLog(value = true, remark = "合并档案")
    @PutMapping(value = "/merge/initiativeId/{initiativPersonFileId}/passiveId/{passivePersonFileId}/{version}")
    public BaseDataRespDTO mergePersonfile(@PathVariable(name = "initiativPersonFileId") String initiativPersonFileId,
                                           @PathVariable(name = "passivePersonFileId") String passivePersonFileId,
                                           @PathVariable(name = "version", required = false) String version) {
        try {
            if (initiativPersonFileId.equals(passivePersonFileId)) {
                return IPersonFilesResultInfo.unknownError("合并失败!", "档案编号异常");
            }
            subArchiveService.personfileHandle(passivePersonFileId, initiativPersonFileId);
            return new BaseDataRespDTO(null, IResultCode.SUCCESS, "档案合并成功！");
        } catch (Exception e) {
            logger.error("合并失败：" + e.getMessage());
            return IPersonFilesResultInfo.unknownError("合并失败!", e.getMessage());
        }
    }
    
    /**
     * 档案删除
     *
     * @param personFileId 档案ID
     * @param version      版本
     * @return String
     */
    @ApiOperation(httpMethod = "DELETE",value = "档案删除")
    @OperateLog(value = true, remark = "删除档案")
    @DeleteMapping(value = "/delete/{personFileId}/{version}")
    public BaseDataRespDTO deletePersonfile(@PathVariable(name = "personFileId") String personFileId, @PathVariable(name = "version", required = false) String version) {
        try {
            subArchiveService.personfileHandle(personFileId, null);
            return new BaseDataRespDTO(null, IResultCode.SUCCESS, "档案删除成功！");
        } catch (Exception e) {
            logger.error("删除失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("删除失败!", e.getMessage());
        }
    }
    
    
    /**
     * @author liuYu
     * @date 2018年10月18日
     * @see PersonfileBaseInfoController
     * @since JDK1.8
     */
    @ApiOperation(httpMethod = "GET",value = "获取档案详情")
    @GetMapping(value = "/detail/{personFileId}/{version}")
    public BaseDataRespDTO get(@PathVariable(name = "personFileId") @NotNull String personFileId) {
        try {
            PersonfileBasicsVO personfileBaseInfo = subArchiveService.findBaseInfoVOByPersonFileId(personFileId);
            return IPersonFilesResultInfo.ok(personfileBaseInfo, "查询人物基本信息成功！");
        } catch (Exception e) {
            logger.error("查询人物基本信息失败:" + e.getMessage());
            return IPersonFilesResultInfo.unknownError("查询人物基本信息失败!" + e.getMessage());
        }
    }
    
    @ApiOperation(httpMethod = "PUT",value = "档案添加标签")
    @PutMapping(value = "/personfilelabel/{version}")
    public BaseDataRespDTO put(@RequestParam("personFileId") @NotNull String personFileId, @RequestParam("labelId") Integer labelId) {
        try {
            if (labelId == null) {
                return IPersonFilesResultInfo.unknownError("请选择标签!");
            }
            int result = subArchiveService.insertPersonfileBasicsLabel(personFileId, labelId);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("档案添加标签失败!");
            }
            return IPersonFilesResultInfo.ok("档案添加标签成功!");
        } catch (Exception e) {
            logger.error("档案添加标签失败:" + e.getMessage());
            return IPersonFilesResultInfo.unknownError("档案添加标签失败!");
        }
    }
    
    @ApiOperation(httpMethod = "DELETE",value = "档案删除标签")
    @DeleteMapping(value = "/personfilelabel/{version}")
    public BaseDataRespDTO delete(@RequestParam("personFileId") @NotNull String personFileId, @RequestParam("labelId") Integer labelId) {
        try {
            if (labelId == null) {
                return IPersonFilesResultInfo.unknownError("请选择标签!");
            }
            int result = subArchiveService.deletePersonfileBasicsLabel(personFileId, labelId);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("档案删除标签失败!");
            }
            return IPersonFilesResultInfo.ok("档案删除标签成功!");
        } catch (Exception e) {
            logger.error("档案删除标签失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("档案删除标签失败!");
        }
    }
    
    @ApiOperation(httpMethod = "PUT",value = "编辑档案")
    @PutMapping(value = "/detail/{version}")
    public BaseDataRespDTO update(@RequestBody @Valid PersonfileBasics personfileBasics) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            if (personfileBasics.getCid() != null) {
                Map<String, Object> ageAndBirDate =  AgeivisionUtil.getBirAgeSex(personfileBasics.getCid());
                String birdate = (String)ageAndBirDate.get("birthday");
                Integer age = (Integer)ageAndBirDate.get("age");
                Integer sex = (Integer)ageAndBirDate.get("sex");
                if (Strings.isNotBlank(birdate)) {
                    personfileBasics.setBirthDate(simpleDateFormat.parse(birdate));
                }
                if (sex != null) {
                    personfileBasics.setSex(sex);
                }
               
                if (age != null) {
                    personfileBasics.setAge(age);
                }
            }
            
            personfileBasics.setUpdateFlag(true);
            personfileBasics.setPersonFilesId(personfileBasics.getBaseInfoId());
            int result = subArchiveService.updatePersonfileBasics(personfileBasics);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("档案基本信息编辑失败");
            }
            return IPersonFilesResultInfo.ok("档案基本信息编辑成功");
        } catch (Exception e) {
            logger.error("档案基本信息编辑失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("档案基本信息编辑失败");
        }
    }
    
    @Deprecated
    @ApiOperation(httpMethod = "GET",value = "获取档案总数和图片总数")
    @GetMapping(value = "/fileimage/{version}")
    public BaseDataRespDTO getFileImage() {
        try {
            StatisticPersonfile statisticPersonfile = statisticPersonfileService.findTopOne(DateFormatUtils.format(org.apache.commons.lang.time.DateUtils.addDays(new Date(), 1), ICommonConstant.DateFormatType.Y_M_D));
            Integer personfileNum = statisticPersonfile != null ? statisticPersonfile.getStatisticTotal() : 0;
            Integer snapNum = statisticPersonfileEventService.statisticEvent();
            
            StatsticPersonfileAndImageVO statsticPersonfileAndImageVO = new StatsticPersonfileAndImageVO(personfileNum, snapNum);
            return IPersonFilesResultInfo.ok(statsticPersonfileAndImageVO, "获取图片采集数和档案数");
        } catch (Exception e) {
            logger.error("获取图片采集数和档案数失败:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("获取图片采集数和档案数失败", "异常：" + e.getMessage());
        }
    }
}
