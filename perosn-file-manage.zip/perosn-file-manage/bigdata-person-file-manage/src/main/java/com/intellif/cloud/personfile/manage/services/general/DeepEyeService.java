package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.model.dto.camera.DeepEyeCameraDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;

import java.util.List;

/**
 * 调用深目的接口类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月22日
 * @see DeepEyeService
 * @since JDK1.8
 */
public interface DeepEyeService {
    /**
     * 获取所有摄像头
     *
     * @return
     */
    List<DeepEyeCameraDTO> getCameraList();

    /**
     * 根据小图查询大图
     *
     * @param id 小图id
     * @return
     */
    BaseDataRespDTO getBigImage(String id);

    /**
     * 根据大图查询小图
     *
     * @param id 大图id
     * @return
     */
    BaseDataRespDTO getSmallImage(String id);

    /**
     * 图片上传 获取特征值
     *
     * @param url     图片地址
     * @param isIfass 是否是Ifass
     * @return
     */
    BaseDataRespDTO imageUploadUrl(String url, Boolean isIfass);

    /**
     * 根据URL从结构化引擎获取特征值
     *
     * @param url URL
     * @return Base64编码的特征值
     */
    String getFeatureFromEngineByUrl(String url);
    
    /**
     * 获取摄像头树状列表
     *
     * @return BaseDataRespDTO
     */
    BaseDataRespDTO getTreeCameraInfo();
    
    /**
     * 搜索摄像头
     *
     * @param id id
     * @param name name
     * @return BaseDataRespDTO
     */
    BaseDataRespDTO searchCrmereByName(String id,String name,Integer page,Integer perpage);
}
