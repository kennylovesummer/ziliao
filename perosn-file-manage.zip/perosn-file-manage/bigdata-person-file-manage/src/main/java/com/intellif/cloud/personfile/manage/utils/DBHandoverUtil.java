package com.intellif.cloud.personfile.manage.utils;

import com.intellif.cloud.personfile.manage.enums.DBTypeEnum;

/**
 * 数据源切换
 *
 * @author liuzj
 * @date 2019-08-26
 */
public class DBHandoverUtil {
    
    private static final ThreadLocal<DBTypeEnum> contextHolder = new ThreadLocal<>();
    
    public static void set(DBTypeEnum dbType) {
        contextHolder.set(dbType);
    }
    
    public static DBTypeEnum get() {
        return contextHolder.get();
    }
    
    public static void master() {
        set(DBTypeEnum.master);
    }
    
    public static void slave() {
        set(DBTypeEnum.slave);
    }
    
    public static void init(){
        contextHolder.remove();
    }
}
