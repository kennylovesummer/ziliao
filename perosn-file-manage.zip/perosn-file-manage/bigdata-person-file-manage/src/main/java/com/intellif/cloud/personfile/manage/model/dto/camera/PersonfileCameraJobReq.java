package com.intellif.cloud.personfile.manage.model.dto.camera;


/**
 * 文件名：PersonfileCameraJobReq.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 人员档案的设备同步job调用
 *
 * @author ：tianhao
 * 创建时间：2018年8月18日
 * 修改理由：
 * 修改内容：
 */
public class PersonfileCameraJobReq implements java.io.Serializable {
    /**
     * 主键
     */
    private Long id;
    /**
     * 摄像头id
     */
    private String devId;
    /**
     * 操作类型:深目 1,深目3.0 2,基础服务
     */
    private Long opType;
    /**
     * 存放摄像头IP
     */
    private String ip;
    /**
     * 存放摄像头端口
     */
    private int port;
    /**
     * 摄像所属区域ID
     */
    private int areaId;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 更新时间
     */
    private String modifiedTime;
    /**
     * 经纬度
     */
    private String geoString;
    /**
     * 是否删除(0-未删除， 1-已删除)
     * 对应数据库的字段名: is_delete
     */
    private int deleteStatus;
    /**
     * 摄像头名字
     */
    private String name;
    /**
     * 设备类型
     */
    private String deviceType;
    /**
     * 创建人登录账号
     */
    private String creater;
    /**
     * 修改人账号
     */
    private String modifier;
    /**
     * 开始时间
     * 如果新增,为新增的开始时间,否则为修改的开始时间
     */
    private String startTime;
    /**
     * 结束时间
     * 如果为新增,为新增的结束时间,否则为修改的结束时间
     */
    private String endTime;
    /**
     * 是否新增,true 新增,false 修改,默认新增
     */
    private boolean add;

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDevId() {
        return devId;
    }

    public void setDevId(String devId) {
        this.devId = devId;
    }

    public Long getOpType() {
        return opType;
    }

    public void setOpType(Long opType) {
        this.opType = opType;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getAreaId() {
        return areaId;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getGeoString() {
        return geoString;
    }

    public void setGeoString(String geoString) {
        this.geoString = geoString;
    }

    public int getDeleteStatus() {
        return deleteStatus;
    }

    public void setDeleteStatus(int deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getCreater() {
        return creater;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public PersonfileCameraJobReq() {
    }

    public PersonfileCameraJobReq(String startTime, String endTime, boolean add) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.add = add;
    }
}
