package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.DownloadParam;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.PeerDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.DownloadVO;
import com.intellif.cloud.personfile.manage.services.analysis.*;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveAvatorService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.task.DownloadTask;
import com.intellif.cloud.personfile.manage.task.monitor.AnalysisDataDownloadMonitor;
import com.intellif.cloud.personfile.manage.utils.FileUtils;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @author liuzj
 * @see AnalysisExportTaskService
 */
@Service
public class AnalysisExportTaskServiceImpl implements AnalysisExportTaskService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private BigdataAnalysisTaskService bigdataAnalysisTaskService;
    
    @Autowired
    private SubEventService subEventService;
    
    @Autowired
    private BigdataAnalysisExportTaskService bigdataAnalysisExportTaskService;
    
    @Autowired
    private AnalysisExportTaskService analysisExportTaskService;
    
    @Autowired
    private SubArchiveAvatorService subArchiveAvatorService;
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    @Autowired
    private AnalysisDataDownloadMonitor analysisDataDownloadMonitor;
    
    @Autowired
    private BigdataAnalysisPeerService bigdataAnalysisPeerService;
    
    @Override
    public BaseDataRespDTO submit(DownloadParam downloadParam) {
        BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskById(downloadParam.getTaskId());
        if (bigdataAnalysisTask == null || Strings.isBlank(bigdataAnalysisTask.getExecId())) {
            return new BaseDataRespDTO(null, IResultCode.ERROR, "分析任务不存在");
        }
        Long id = null;
        BigdataAnalysisExportTask bigdataAnalysisExportTask = null;
        try {
            bigdataAnalysisExportTask = new BigdataAnalysisExportTask();
            bigdataAnalysisExportTask.setExecId(bigdataAnalysisTask.getExecId());
            bigdataAnalysisExportTask.setTaskId(downloadParam.getTaskId());
            bigdataAnalysisExportTask.setReqParams(downloadParam.toString());
            bigdataAnalysisExportTask.setTaskType(downloadParam.getReqParams().getString("type"));
            bigdataAnalysisExportTask.setTaskName(bigdataAnalysisTask.getName() + ICommonConstant.Symbol.UNDERLINE + System.currentTimeMillis());
            id = bigdataAnalysisExportTaskService.insertAnalysisExportTask(bigdataAnalysisExportTask);
            
            downloadParam.setDownLoadId(id);
            downloadParam.setExecId(bigdataAnalysisExportTask.getExecId());
            
            Future<Boolean> feature = ThreadPoolService.analysisExportThreadPool.submit(new DownloadTask(downloadParam, bigdataAnalysisExportTaskService, analysisExportTaskService, bigdataAnalysisExportTask));
            
            // 下载任务监控
            analysisDataDownloadMonitor.addToMonitor(id + "", feature);
            if (!analysisDataDownloadMonitor.isRunning()) {
                analysisDataDownloadMonitor.start();
            }
            return new BaseDataRespDTO(id, IResultCode.SUCCESS, "创建下载任务成功");
        } catch (Exception e) {
            if (id != null) {
                bigdataAnalysisExportTask.setStatus(-1);
                bigdataAnalysisExportTask.setDownloadMsg("下载异常：" + e.getMessage());
                bigdataAnalysisExportTaskService.updateAnalysisExportTask(bigdataAnalysisExportTask);
            }
            throw e;
        }
    }
    
    @Override
    public DownloadVO export(DownloadParam downloadParam) {
        switch (downloadParam.getReqParams().getString("type")) {
            case "peer":
                return peerAnalysisExport(downloadParam);
            case "crash":
                return clashAnalysisExport(downloadParam);
            case "trace":
                return traceAnalysisExport(downloadParam);
            default:
                return new DownloadVO(new Date(), -1, "未知异常，未知任务");
        }
    }
    
    @Override
    public DownloadVO peerAnalysisExport(DownloadParam downloadParam) {
        try {
            LinkedList<Future<Integer>> futures = new LinkedList<>();
            // 下载图片
            String basePath = personPropertiest.getDataAnalysisExportBasePath() + "同行人员结果/" + UUID.randomUUID() + "/";
            
            // 目标图片下载
            BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(downloadParam.getExecId());
            if (bigdataAnalysisTask == null) {
                return new DownloadVO(new Date(), -1, "任务不存在");
            }
            List<String> targetSnapUrls = subEventService.findSnapUrlsByPersonfileId(bigdataAnalysisTask.getAid());
            PersonfileHeadPicture targetHeadPicture = subArchiveAvatorService.findByPersonfileId(bigdataAnalysisTask.getAid());
            String basePath2 = FileUtils.dowloadPicture(futures, basePath, targetSnapUrls, targetHeadPicture.getSmallImageUrl(), null, false);
            
            // 同行人员图片下载
            String peerBasePath;
            AnalysisDTO analysisDTO = new AnalysisDTO();
            analysisDTO.setPerpage(0);
            analysisDTO.setPage(0);
            analysisDTO.setPeerNum(downloadParam.getReqParams().getInteger("peerNum"));
            analysisDTO.setTaskId(downloadParam.getTaskId());
            List<BigdataAnalysisArchive> analysisArchiveList = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(analysisDTO);
            PeerDTO peerDTO = new PeerDTO();
            peerDTO.setTaskId(downloadParam.getTaskId());
            peerDTO.setPerpage(0);
            EventDTO eventDTO = new EventDTO();
            eventDTO.setPerpage(0);
            for (BigdataAnalysisArchive analysisArchive : analysisArchiveList) {
                // 同行人员所有抓拍
                List<String> peerPersonUrls = subEventService.findSnapUrlsByPersonfileId(analysisArchive.getAid());
                PersonfileHeadPicture headPicture = subArchiveAvatorService.findByPersonfileId(analysisArchive.getAid());
                if (headPicture == null) {
                    logger.error("同行人员下载异常：档案" + analysisArchive.getAid() + "不存在");
                    continue;
                }
                peerBasePath = FileUtils.dowloadPicture(futures, basePath2, peerPersonUrls, headPicture.getSmallImageUrl(), null, false);
                
                // 目标和同行人抓拍
                peerDTO.setAid(analysisArchive.getAid());
                Page<BigdataAnalysisPeer> page = bigdataAnalysisPeerService.findAnalysisPeerByParams(peerDTO);
                
                if (CollectionUtils.isEmpty(page)) {
                    continue;
                }
                
                for (BigdataAnalysisPeer analysisPeer : page.getResult()) {
                    eventDTO.setTaskId(analysisArchive.getTaskId());
                    eventDTO.setAid(analysisArchive.getAid());
                    eventDTO.setStartTime(analysisPeer.getStartTime());
                    eventDTO.setEndTime(analysisPeer.getEndTime());
                    
                    List<BigdataAnalysisEvent> eventList = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
                    if (CollectionUtils.isEmpty(eventList)) {
                        continue;
                    }
                    
                    List<String> peerInfoUrls = eventList.stream().filter(event -> event.getAid().equals(analysisPeer.getAid())).map(BigdataAnalysisEvent::getFaceUrl).collect(Collectors.toList());
                    peerInfoUrls.add(analysisPeer.getFaceUrl());
                    
                    String peerFileName = FileUtils.getImageName(analysisPeer.getFaceUrl())
                            + ICommonConstant.Symbol.STRIKETHROUGH +
                            FileUtils.getImageName(peerInfoUrls.get(0));
                    
                    FileUtils.dowloadPicture(futures, peerBasePath, peerInfoUrls, peerFileName, null, true);
                }
            }
            
            // 压缩
            String zipBasePath = personPropertiest.getDataAnalysisExportBasePath();
            StringBuilder zipName = new StringBuilder();
            // 目标人员头像名
            zipName.append(FileUtils.getImageName(targetHeadPicture.getSmallImageUrl())).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH)
                    // 档案ID
                    .append(bigdataAnalysisTask.getAid()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 任务名
                            append(bigdataAnalysisTask.getName()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 时间戳
                            append(System.currentTimeMillis());
            toZip(futures, basePath, zipBasePath + zipName);
            
            return new DownloadVO(new Date(), zipName.toString(), zipBasePath, 2, "下载成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new DownloadVO(new Date(), -1, "下载异常：" + e.getMessage());
        }
    }
    
    @Override
    public DownloadVO clashAnalysisExport(DownloadParam downloadParam) {
        try {
            LinkedList<Future<Integer>> futures = new LinkedList<>();
            BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(downloadParam.getExecId());
            // 下载图片
            String basePath = personPropertiest.getDataAnalysisExportBasePath() + "时空碰撞结果/" + UUID.randomUUID() + "/";
            String eachBasePath;
            List<String> faceUrls;
            List<String> urls = Lists.newArrayList();
            
            AnalysisDTO analysisDTO = new AnalysisDTO();
            analysisDTO.setPage(0);
            analysisDTO.setPerpage(0);
            analysisDTO.setTaskId(downloadParam.getTaskId());
            List<BigdataAnalysisArchive> analysisArchiveList = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(analysisDTO);
            for (BigdataAnalysisArchive analysisArchive : analysisArchiveList) {
                // 碰撞人员
                PersonfileHeadPicture headPicture = subArchiveAvatorService.findByPersonfileId(analysisArchive.getAid());
                if (headPicture == null) {
                    logger.error("碰撞人员下载异常：档案" + analysisArchive.getAid() + "不存在");
                    continue;
                }
                FileUtils.dowloadPicture(futures, basePath, urls, headPicture.getSmallImageUrl(), null, false);
                
                EventDTO eventDTO = new EventDTO();
                eventDTO.setPage(0);
                eventDTO.setPerpage(0);
                eventDTO.setTaskId(downloadParam.getTaskId());
                eventDTO.setAid(analysisArchive.getAid());
                List<BigdataAnalysisEvent> eventList = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
                
                if (CollectionUtils.isEmpty(eventList)) {
                    continue;
                }
                
                faceUrls = eventList.stream().map(BigdataAnalysisEvent::getFaceUrl).collect(Collectors.toList());
                eachBasePath = FileUtils.dowloadPicture(futures, basePath, faceUrls, headPicture.getSmallImageUrl(), null, false);
                
                Map<String, List<BigdataAnalysisEvent>> groupByAreaCode = eventList.stream().collect(Collectors.groupingBy(BigdataAnalysisEvent::getAreaCode));
                for (String areaCode : groupByAreaCode.keySet()) {
                    List<BigdataAnalysisEvent> events = groupByAreaCode.get(areaCode);
                    if (CollectionUtils.isEmpty(events)) {
                        events = Lists.newArrayList();
                    }
                    FileUtils.dowloadPicture(futures, eachBasePath, events.stream().map(BigdataAnalysisEvent::getFaceUrl).collect(Collectors.toList()), areaCode, areaCode, true);
                }
            }
            
            if (CollectionUtils.isEmpty(analysisArchiveList)) {
                File file = new File(basePath);
                file.mkdirs();
            }
            // 压缩
            String zipBasePath = personPropertiest.getDataAnalysisExportBasePath();
            StringBuilder zipName = new StringBuilder();
            // 任务ID
            zipName.append(bigdataAnalysisTask.getId()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 任务名
                            append(bigdataAnalysisTask.getName()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 时间戳
                            append(System.currentTimeMillis());
            
            toZip(futures, basePath, zipBasePath + zipName);
            
            return new DownloadVO(new Date(), zipName.toString(), zipBasePath, 2, "下载成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new DownloadVO(new Date(), -1, "下载异常：" + e.getMessage());
        }
    }
    
    @Override
    public DownloadVO traceAnalysisExport(DownloadParam downloadParam) {
        try {
            LinkedList<Future<Integer>> futures = new LinkedList<>();
            
            BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskByExecId(downloadParam.getExecId());
            if (bigdataAnalysisTask == null) {
                return new DownloadVO(new Date(), -1, "任务异常，任务不存在");
            }
            
            // 创建文件夹（以目标抓拍照名字命名）以及下载目标代表图片到文件夹
            String basePath = personPropertiest.getDataAnalysisExportBasePath() + "路人轨迹结果/" + UUID.randomUUID() + "/";
            PersonfileHeadPicture targetHeadPicture = subArchiveAvatorService.findByPersonfileId(bigdataAnalysisTask.getAid());
            if (targetHeadPicture == null) {
                return new DownloadVO(new Date(), -1, "档案异常，无此档案");
            }
            List<String> targetUrls = Lists.newArrayList();
            targetUrls.add(targetHeadPicture.getSmallImageUrl());
            String basePath2 = FileUtils.dowloadPicture(futures, basePath, targetUrls, targetHeadPicture.getSmallImageUrl(), null, false);
            while (CollectionUtils.isNotEmpty(targetUrls)) {
                if (!futures.isEmpty()) {
                    futures.get(0).get();
                    futures.clear();
                    break;
                }
            }
            
            // 创建文件夹（以目标抓拍照数量命名）以及下载目标轨迹抓拍照到文件夹
            EventDTO eventDTO = new EventDTO();
            eventDTO.setPerpage(0);
            eventDTO.setPage(0);
            eventDTO.setTaskId(downloadParam.getTaskId());
            eventDTO.setAid(bigdataAnalysisTask.getAid());
            List<BigdataAnalysisEvent> eventList = bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO);
            
            if (CollectionUtils.isNotEmpty(eventList)) {
                List<String> traceUrls = eventList.stream().map(BigdataAnalysisEvent::getFaceUrl).collect(Collectors.toList());
                FileUtils.dowloadPicture(futures, basePath2, traceUrls, traceUrls.size() + "", null, true);
            }
            // 压缩
            String zipBasePath = personPropertiest.getDataAnalysisExportBasePath();
            StringBuilder zipName = new StringBuilder();
            // 目标人员头像名
            zipName.append(FileUtils.getImageName(targetHeadPicture.getSmallImageUrl()))
                    // 分隔符
                    .append(ICommonConstant.Symbol.STRIKETHROUGH)
                    // 档案ID
                    .append(bigdataAnalysisTask.getAid()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 任务名
                            append(bigdataAnalysisTask.getName()).
                    // 分隔符
                            append(ICommonConstant.Symbol.STRIKETHROUGH).
                    // 时间戳
                            append(System.currentTimeMillis());
            toZip(futures, basePath, zipBasePath + zipName);
            
            return new DownloadVO(new Date(), zipName.toString(), zipBasePath, 2, "下载成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new DownloadVO(new Date(), -1, "下载异常：" + e.getMessage());
        }
    }
    
    /**
     * 压缩文件
     *
     * @param futures  任务队列
     * @param basePath 待压缩的文件夹目录
     * @param zipPath  压缩包目录
     * @throws ExecutionException
     * @throws InterruptedException
     */
    private void toZip(LinkedList<Future<Integer>> futures, String basePath, String zipPath) throws ExecutionException, InterruptedException {
        while (true) {
            if (!futures.isEmpty()) {
                for (Future<Integer> future : futures) {
                    future.get();
                }
                // 压缩
                FileUtils.toZip(basePath, zipPath);
                break;
            } else {
                // 压缩
                FileUtils.toZip(basePath, zipPath);
                break;
            }
        }
    }
}
