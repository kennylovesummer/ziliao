package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.List;

@Data
public class LingerResultVO {

    private String aid;
    
    private String name;
    
    private String cid;
    
    private String gender;
    
    private String avatarUrl;
    
    private String imageId;
    
    private String imageUrl;
    
    private Integer imageCount;
    
    private String sysCode;
    
    private Long lingeredCount;
    
    private List<EventDetailVO> events;
}
