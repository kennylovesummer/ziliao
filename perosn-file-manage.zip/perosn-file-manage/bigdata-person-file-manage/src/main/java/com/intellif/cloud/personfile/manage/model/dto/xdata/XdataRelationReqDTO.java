package com.intellif.cloud.personfile.manage.model.dto.xdata;

import com.alibaba.fastjson.JSONObject;

import java.util.List;

/**
 * @author liuyu
 * @className XdataRelationReqDTO
 * @date 2019/4/19 14:27
 * @description
 */
public class XdataRelationReqDTO extends BaseReqDTO implements java.io.Serializable {

    private static final long serialVersionUID = -6415473257930015212L;

    /**
     * 档案ID
     */
    private String aid;

    /**
     * 身份证号
     */
    private String cid;

    /**
     * 起始人员身份证号（多人关系）
     */
    private String fromCid;

    /**
     * 被指向人员身份证号（多人关系）
     */
    private String targetCid;

    /**
     * 起始档案id
     */
    private String fromId;

    /**
     * 终止档案id
     */
    private String targetId;

    /**
     * 指向类型（SINGLE(单向)/BOTH(双向)/NONE(无向)）
     */
    private String direction;

    /**
     * 关系深度
     */
    private Integer maxDepth;

    /**
     * 关系标签
     */
    private String label;

    /**
     * 关系标签集合
     */
    private List<String> labels;

    /**
     * 同行次数
     */
    private Props props;

    /**
     * 业务编码 由天图平台分配给业务系统指定查询的库名
     */
    private String bizCode;

    public String getFromCid() {
        return fromCid;
    }

    public void setFromCid(String fromCid) {
        this.fromCid = fromCid;
    }

    public String getTargetCid() {
        return targetCid;
    }

    public void setTargetCid(String targetCid) {
        this.targetCid = targetCid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Integer getMaxDepth() {
        return maxDepth;
    }

    public void setMaxDepth(Integer maxDepth) {
        this.maxDepth = maxDepth;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public String getProps() {
        if (this.props != null) {
            return JSONObject.toJSONString(props);
        }
        return null;
    }

    public void setProps(Props props) {
        this.props = props;
    }

    public String getBizCode() {
        return bizCode;
    }

    public void setBizCode(String bizCode) {
        this.bizCode = bizCode;
    }

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
