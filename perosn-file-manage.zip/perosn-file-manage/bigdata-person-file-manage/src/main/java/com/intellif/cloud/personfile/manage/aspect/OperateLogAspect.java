//package com.intellif.deep.cloud.archive.manage.aspect;
//
//import com.google.gson.Gson;
//import com.intellif.log.LoggerUtilI;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.Signature;
//import org.aspectj.lang.annotation.AfterReturning;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.util.Arrays;
//
///**
// * @program ifaas-person-file-manage
// * @Author liuYu
// * @create 2018-11-16 11:34
// * @Version 1.0
// * @desc
// */
//
////@Aspect
////@Component
////@Order(1)
//public class OperateLogAspect {
//
//    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
//
//    private Gson gson = new Gson();
//
//    @Pointcut("execution(public * com.intellif.deep.cloud.archive.manage.controllers..*.*(..))")
////    @Pointcut("@annotation(org.springframework.web.bind.annotation.PostMapping) || @annotation(org.springframework.web.bind.annotation.DeleteMapping) || @annotation(org.springframework.web.bind.annotation.PutMapping)")
//    public void logPointCut() {
//        throw new UnsupportedOperationException();
//    }
//
//    @Before("logPointCut()")
//    public void beforeHandle(JoinPoint joinPoint) {
//        try {
//            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//            HttpServletRequest request = attributes.getRequest();
//            String url = request.getRequestURL().toString();
//            String method = request.getMethod();
//            Signature signature = joinPoint.getSignature();
//            String args = Arrays.toString(joinPoint.getArgs());
//            //打印请求内容
//            logger.info("===============请求内容===============");
//            logger.info("请求地址:", url);
//            logger.info("请求方式:", method);
//            logger.info("请求类方法:", signature);
//            logger.info("请求类方法参数:", args);
//            logger.info("===============请求内容===============");
//        } catch (Exception e) {
//            logger.error("获取日志异常：{}", e.getMessage());
//        }
//    }
//
//    @AfterReturning(pointcut = "logPointCut()", returning = "result")
//    public void afterHandle(Object result) {
//        try {
//            logger.info("--------------返回内容----------------");
//            logger.info("Response内容:", gson.toJson(result));
//            logger.info("--------------返回内容----------------");
//        } catch (Exception e) {
//            logger.error("返回内容异常：{}", e.getMessage());
//        }
//    }
//}
