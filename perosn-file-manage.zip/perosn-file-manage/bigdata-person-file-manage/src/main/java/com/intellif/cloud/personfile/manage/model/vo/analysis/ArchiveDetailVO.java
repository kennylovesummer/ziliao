package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

@Data
public class ArchiveDetailVO {
    
    private String aid;
    
    private String name;
    
    private String cid;
    
    private String gender;
    
    private String avatarUrl;
    
    private String imageId;
    
    private String imageUrl;
    
    private String sysCode;
    
    private Long imageCount;
}
