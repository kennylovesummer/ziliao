package com.intellif.cloud.personfile.manage.model.dto.personfile;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 档案中心搜索
 *
 * @author liuzhijian
 * @date 2019-03-14
 */
public class ListFilterDTO extends BasePageReqDTO implements java.io.Serializable {

    /**
     * 身份证号
     */
    private String personCid;

    /**
     * 姓名
     */
    private String personName;

    /**
     * 照片特征值
     */
    private String feature;

    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 结束时间
     */
    private String endTime;

    /**
     * 时间类型
     */
    private String timeType;

    /**
     * 相似档案
     */
    private List<Map<String,Object>> similars;

    /**
     * @0： 档案中心  @1：推荐功能
     */
    private int from;

    /**
     * 标签ID集合（多个以逗号隔开）
     */
    private List<String> labelIds;

    /**
     * 档案类型（0: 全部档案（默认）1：实名档案 2：未实名档案 3：我的关注）
     */
    private Integer personFileType = 0;

    /**
     * 档案ID集合
     */
    private List<String> personFileIds;
    
    /**
     * 不在此ID集合的数据
     */
    private List<String> personFileIdsNotIn;

    /**
     * 排序字段（0：创建时间；1：更新时间；2：汇集图片数量）
     */
    private Integer sortName;

    /**
     * 相似度
     */
    private Double similarRate;
    
    private Integer total;
    
    private List<String> tables;
    
    private Integer singlePage;
    
    private String lastCreateTime;
    
    private String lastRecentSnapTime;
    
    private Integer lastImageCount;
    
    private String lastAid;
    
    public String getLastCreateTime() {
        return lastCreateTime;
    }
    
    public void setLastCreateTime(String lastCreateTime) {
        this.lastCreateTime = lastCreateTime;
    }
    
    public String getLastRecentSnapTime() {
        return lastRecentSnapTime;
    }
    
    public void setLastRecentSnapTime(String lastRecentSnapTime) {
        this.lastRecentSnapTime = lastRecentSnapTime;
    }
    
    public Integer getLastImageCount() {
        return lastImageCount;
    }
    
    public void setLastImageCount(Integer lastImageCount) {
        this.lastImageCount = lastImageCount;
    }
    
    public String getLastAid() {
        return lastAid;
    }
    
    public void setLastAid(String lastAid) {
        this.lastAid = lastAid;
    }
    
    public Integer getSinglePage() {
        return singlePage;
    }
    
    public void setSinglePage(Integer singlePage) {
        this.singlePage = singlePage;
    }
    
    public List<String> getTables() {
        return tables;
    }
    
    public void setTables(List<String> tables) {
        this.tables = tables;
    }
    
    public Integer getTotal() {
        return total;
    }
    
    public void setTotal(Integer total) {
        this.total = total;
    }
    
    public Double getSimilarRate() {
        return similarRate;
    }

    public void setSimilarRate(Double similarRate) {
        this.similarRate = similarRate;
    }

    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public List<Map<String,Object>> getSimilars() {
        return similars;
    }

    public void setSimilars(List<Map<String,Object>> similars) {
        this.similars = similars;
    }

    public String getPersonCid() {
        return personCid;
    }

    public void setPersonCid(String personCid) {
        this.personCid = personCid;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getFeature() {
        return feature;
    }

    public void setFeature(String feature) {
        this.feature = feature;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public List<String> getLabelIds() {
        return this.labelIds;
    }

    public void setLabelIds(List<String> labelIds) {
        this.labelIds = labelIds;
    }

    public Integer getPersonFileType() {
        return personFileType;
    }

    public void setPersonFileType(Integer personFileType) {
        this.personFileType = personFileType;
    }

    public List<String> getPersonFileIds() {
        return personFileIds;
    }

    public void setPersonFileIds(List<String> personFileIds) {
        this.personFileIds = personFileIds;
    }

    public Integer getSortName() {
        return sortName;
    }

    public void setSortName(Integer sortName) {
        this.sortName = sortName;
    }
    
    public List<String> getPersonFileIdsNotIn() {
        return personFileIdsNotIn;
    }
    
    public void setPersonFileIdsNotIn(List<String> personFileIdsNotIn) {
        this.personFileIdsNotIn = personFileIdsNotIn;
    }
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
