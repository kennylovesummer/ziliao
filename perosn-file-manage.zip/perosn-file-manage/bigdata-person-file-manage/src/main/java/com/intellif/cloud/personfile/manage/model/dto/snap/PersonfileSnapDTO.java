package com.intellif.cloud.personfile.manage.model.dto.snap;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.Date;

public class PersonfileSnapDTO {

    @JSONField(name = "aid")
    private String personFilesId;

    @JSONField(name = "thumbnailId")
    private String faceId;

    @JSONField(name = "thumbnailUrl")
    private String faceUrl;

    private String imageId;

    private String imageUrl;

    private String sysCode;

    private String algoVersion;

    private String genderInfo;

    private String ageInfo;

    private String hairstyleInfo;

    private String hatInfo;

    private String glassesInfo;

    private String raceInfo;

    private String maskInfo;

    private String skinInfo;

    private String poseInfo;

    private Float qualityInfo;

    private String targetRect;

    private String targetRectFloat;

    private String landMarkInfo;

    private Float featureQuality;

    private Long sourceId;

    private String sourceType;

    private String site;

    private Date snapTime;

    private Date createTime;

    private String column1;

    private String column2;

    private String column3;

    public String getPersonFilesId() {
        return personFilesId;
    }

    public void setPersonFilesId(String personFilesId) {
        this.personFilesId = personFilesId;
    }

    public String getFaceId() {
        return faceId;
    }

    public void setFaceId(String faceId) {
        this.faceId = faceId;
    }

    public String getFaceUrl() {
        return faceUrl;
    }

    public void setFaceUrl(String faceUrl) {
        this.faceUrl = faceUrl;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getSysCode() {
        return sysCode;
    }

    public void setSysCode(String sysCode) {
        this.sysCode = sysCode;
    }

    public String getAlgoVersion() {
        return algoVersion;
    }

    public void setAlgoVersion(String algoVersion) {
        this.algoVersion = algoVersion;
    }

    public String getGenderInfo() {
        return genderInfo;
    }

    public void setGenderInfo(String genderInfo) {
        this.genderInfo = genderInfo;
    }

    public String getAgeInfo() {
        return ageInfo;
    }

    public void setAgeInfo(String ageInfo) {
        this.ageInfo = ageInfo;
    }

    public String getHairstyleInfo() {
        return hairstyleInfo;
    }

    public void setHairstyleInfo(String hairstyleInfo) {
        this.hairstyleInfo = hairstyleInfo;
    }

    public String getHatInfo() {
        return hatInfo;
    }

    public void setHatInfo(String hatInfo) {
        this.hatInfo = hatInfo;
    }

    public String getGlassesInfo() {
        return glassesInfo;
    }

    public void setGlassesInfo(String glassesInfo) {
        this.glassesInfo = glassesInfo;
    }

    public String getRaceInfo() {
        return raceInfo;
    }

    public void setRaceInfo(String raceInfo) {
        this.raceInfo = raceInfo;
    }

    public String getMaskInfo() {
        return maskInfo;
    }

    public void setMaskInfo(String maskInfo) {
        this.maskInfo = maskInfo;
    }

    public String getSkinInfo() {
        return skinInfo;
    }

    public void setSkinInfo(String skinInfo) {
        this.skinInfo = skinInfo;
    }

    public String getPoseInfo() {
        return poseInfo;
    }

    public void setPoseInfo(String poseInfo) {
        this.poseInfo = poseInfo;
    }

    public Float getQualityInfo() {
        return qualityInfo;
    }

    public void setQualityInfo(Float qualityInfo) {
        this.qualityInfo = qualityInfo;
    }

    public String getTargetRect() {
        return targetRect;
    }

    public void setTargetRect(String targetRect) {
        this.targetRect = targetRect;
    }

    public String getTargetRectFloat() {
        return targetRectFloat;
    }

    public void setTargetRectFloat(String targetRectFloat) {
        this.targetRectFloat = targetRectFloat;
    }

    public String getLandMarkInfo() {
        return landMarkInfo;
    }

    public void setLandMarkInfo(String landMarkInfo) {
        this.landMarkInfo = landMarkInfo;
    }

    public Float getFeatureQuality() {
        return featureQuality;
    }

    public void setFeatureQuality(Float featureQuality) {
        this.featureQuality = featureQuality;
    }

    public Long getSourceId() {
        return sourceId;
    }

    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Date getSnapTime() {
        return snapTime;
    }

    public void setSnapTime(Date snapTime) {
        this.snapTime = snapTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getColumn1() {
        return column1;
    }

    public void setColumn1(String column1) {
        this.column1 = column1;
    }

    public String getColumn2() {
        return column2;
    }

    public void setColumn2(String column2) {
        this.column2 = column2;
    }

    public String getColumn3() {
        return column3;
    }

    public void setColumn3(String column3) {
        this.column3 = column3;
    }
}
