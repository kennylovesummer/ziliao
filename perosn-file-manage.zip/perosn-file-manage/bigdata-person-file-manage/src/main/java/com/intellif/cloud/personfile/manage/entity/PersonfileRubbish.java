package com.intellif.cloud.personfile.manage.entity;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liuyu
 * @className PersonfileRubbish
 * @date 2019/3/15 14:01
 * @description
 */
@Data
public class PersonfileRubbish implements Serializable {

    private static final long serialVersionUID = -5521550554994691660L;

    private Long id;

    @JSONField(name = "aid")
    private String personFilesId;

    @JSONField(name = "thumbnailId")
    private String faceId;

    @JSONField(name = "thumbnailUrl")
    private String faceUrl;

    private String imageId;

    private String imageUrl;

    private String sysCode;

    private String featureInfo;

    private String algoVersion;

    private String genderInfo;

    private String ageInfo;

    private String hairstyleInfo;

    private String hatInfo;

    private String glassesInfo;

    private String raceInfo;

    private String maskInfo;

    private String skinInfo;

    private String poseInfo;

    private Float qualityInfo;

    private String targetRect;

    private String targetRectFloat;

    private String landMarkInfo;

    private Float featureQuality;

    private String sourceId;

    private String sourceType;

    private String site;

    @JSONField(name = "time")
    private Date snapTime;

    private Date createTime;

    private String column1;

    private String column2;

    private String column3;

    private Integer isDeleted;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
