package com.intellif.cloud.personfile.manage.contants;

/**
 * 深目返回值定义
 * @author tianhao
 * @version 1.0
 * @see DeepResultConstant
 * @since JDK1.8
 * @date 2018年11月06日
 */
public class DeepResultConstant {
    /**
     * token 失效
     */
    public static final String invalidToken ="invalid_token";
    /**
     * 错误
     */
    public static final String error = "error";
    /**
     * 错误的状态码
     */
    public static final String errCode = "errCode";

}
