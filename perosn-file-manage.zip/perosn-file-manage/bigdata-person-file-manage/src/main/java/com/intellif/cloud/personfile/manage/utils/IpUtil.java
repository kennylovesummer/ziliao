package com.intellif.cloud.personfile.manage.utils;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liuzj
 * @date 2018-11-14
 */
public class IpUtil {
    
    /**
     * 根据请求获取ip
     *
     * @param request 请求
     * @return String
     */
    public static String getIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || ICommonConstant.Exception.unknown.equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || ICommonConstant.Exception.unknown.equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || ICommonConstant.Exception.unknown.equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip.contains(ICommonConstant.Symbol.COMMA)) {
            return ip.split(ICommonConstant.Symbol.COMMA)[0];
        } else {
            return ip;
        }
    }
    
}
