package com.intellif.cloud.personfile.manage.contants;

/**
 * 服务返回的格式定义
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年8月8日
 * @see ServiceReturnConstant
 * @since JDK1.8
 */
public class ServiceReturnConstant {
    /**
     * 状态码
     */
    public static final String RESP_CODE = "respCode";
    /**
     * 消息提示
     */
    public static final String RESP_MESSAGE = "respMessage";
    /**
     * 解释性说明
     */
    public static final String RESP_REMARK = "respRemark";
    /**
     * 数据
     */
    public static final String DATA = "data";

    private ServiceReturnConstant() {
    }
}
