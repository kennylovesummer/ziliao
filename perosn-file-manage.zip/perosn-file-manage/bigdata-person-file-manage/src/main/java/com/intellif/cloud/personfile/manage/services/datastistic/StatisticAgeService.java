package com.intellif.cloud.personfile.manage.services.datastistic;

/**
 * 年龄统计
 * @author tianhao
 * @version 1.0
 * @date 2018年10月27日
 * @see StatisticAgeService
 * @since JDK1.8
 */
public interface StatisticAgeService {

    /**
     * 根据人员档案年龄id累加人员档案年龄数量
     * @param personFileAgeId   人员档案年龄
     * @param personFileAgeNum 人员档案年龄段统计数量
     * @return
     */
    int updateAgeNumByAgeId(int personFileAgeId, int personFileAgeNum);

    /**
     * 根据年龄ID查找年龄统计总数
     * @param personFileAgeId 年龄ID
     * @return int
     */
    int findAgeNumByAgeId(int personFileAgeId);
}
