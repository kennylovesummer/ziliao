package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;

/**
 * 轨迹创建参数
 *
 * @author liuzj
 * @date 2019-07-05
 */
@Data
public class TraceTaskCreateDTO extends BaseAnalysisCreateDTO implements java.io.Serializable{
    
    private List<String> aids;
    
    private String startTime;
    
    private String endTime;
    
    private List<String> sourceIds;
    
    private List<String> periods;
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
