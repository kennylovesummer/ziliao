package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 数据分析档案
 *
 * @author liuzj
 * @date 2019-07-18
 */
@Data
public class BigdataAnalysisArchive implements Serializable {
    private static final long serialVersionUID = 2342131002131442855L;
    private Long id;

    private Long taskId;

    private String aid;

    private String cid;
    
    private String personName;

    private String currAddr;

    private String faceUrl;

    private Integer eventTimes;

    private Integer imageCount;
    
    /**
     * 徘徊次數
     */
    private Long lingerdCount;
    
    private String imageId;
    
    private String imageUrl;
    
    private String gender;
    
    private String sysCode;
    
    private Long activeCount;
    

    private Date createTime;

    private String createBy;

    private Date modifyTime;

    private String modifyBy;
}