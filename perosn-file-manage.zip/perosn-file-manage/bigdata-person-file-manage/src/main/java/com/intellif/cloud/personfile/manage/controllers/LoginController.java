package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.model.dto.account.AccountDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.account.BigdataAccountService;
import com.intellif.cloud.personfile.manage.utils.IpUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * 登录接口
 *
 * @author liuzj
 * @date 2019-08-28
 */
@Api(tags = "登录")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.LOGIN)
public class LoginController {
    
    private final LoggerUtilI LOG = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAccountService bigdataAccountService;
    
    /**
     * 用户登录
     *
     * @param accountDTO 账号和密码
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "登录接口")
    @PostMapping
    public BaseDataRespDTO login(@RequestBody AccountDTO accountDTO, HttpServletRequest httpRequest) {
        try {
            // 参数校验
            if (Strings.isBlank(accountDTO.getAccount()) || Strings.isBlank(accountDTO.getPassword())) {
                LOG.error("账号密码错误");
                return new BaseDataRespDTO(IResultCode.ERROR,"【账号|密码】请填写完整！","【账号|密码】缺一不可");
            }
            
            // 账号登录
            BigdataAccount bigdataAccount = bigdataAccountService.findBigdataAccountByAccountAndPassword(accountDTO);
            if (bigdataAccount != null) {
                bigdataAccount.setIp(IpUtil.getIpAddress(httpRequest));
                bigdataAccount.setLoginTime(new Date());
                bigdataAccountService.updateBigdataAccount(bigdataAccount);
                return new BaseDataRespDTO(IResultCode.SUCCESS,"登录成功!");
            }
            
            // 账号存在性验证
            accountDTO.setPassword(null);
            BigdataAccount bigdataAccount1 = bigdataAccountService.findBigdataAccountByAccountAndPassword(accountDTO);
            if (bigdataAccount1 == null) {
                return new BaseDataRespDTO(IResultCode.ERROR,"账号不存在!","账号异常!");
            }
            
            return new BaseDataRespDTO(IResultCode.ERROR,"账号或密码错误!","登录异常!");
        } catch (Exception e){
            LOG.error("登录异常：" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR,"登录异常!",e.getMessage());
        }
    }
}
