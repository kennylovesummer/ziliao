package com.intellif.cloud.personfile.manage.model.dto.xdata;

import java.util.List;

/**
 * 数据平台查询请求封装对象
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月22日
 * @see XdataReqDTO
 * @since JDK1.8
 */
public class XdataReqDTO extends BaseReqDTO implements java.io.Serializable {
    /**
     * 摄像头id
     */
    private String sourceId;
    /**
     * 档案ID
     */
    private String aid;

    /**
     * 档案ID集合
     */
    private List<String> aids;

    /**
     * 人际关系code
     */
    private String code;
    
    /**
     * 档案类型 0:正常档案 1:黑名单档案
     */
    private Integer archiveType;
    
    public Integer getArchiveType() {
        return archiveType;
    }
    
    public void setArchiveType(Integer archiveType) {
        this.archiveType = archiveType;
    }
    
    /**
     * 待修改的关系code
     */
    private String oldCode;

    public String getOldCode() {
        return oldCode;
    }

    public void setOldCode(String oldCode) {
        this.oldCode = oldCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public List<String> getAids() {
        return aids;
    }

    public void setAids(List<String> aids) {
        this.aids = aids;
    }

    public XdataReqDTO() {
    }

    public XdataReqDTO(String sourceId, String aid, String dbName, String startTime, String endTime, int pageNo, int pageSize) {
        this.sourceId = sourceId;
        this.aid = aid;
        this.dbName = dbName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }

    public XdataReqDTO(String aid, String dbName, String startTime, String endTime, int pageNo, int pageSize) {
        this.aid = aid;
        this.dbName = dbName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }

    public XdataReqDTO(String aid, String dbName) {
        this.aid = aid;
        this.dbName = dbName;
    }

    public XdataReqDTO(String aid, String dbName, int pageNo, int pageSize) {
        this.aid = aid;
        this.dbName = dbName;
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }

    public XdataReqDTO(List<String> aids, String dbName){
        this.aids = aids;
        this.dbName = dbName;
    }

    public XdataReqDTO(List<String> aids, String dbName,String code,String oldCode){
        this.aids = aids;
        this.dbName = dbName;
        this.code = code;
        this.oldCode = oldCode;
    }
}
