package com.intellif.cloud.personfile.manage.model.dto.camera;

import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;

/**
 * 文件名：PersonfileCameraReqDTO
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 摄像头查询的请求封装对象
 *
 * @author ：tianhao
 * 创建时间：2018年10月20日
 * 修改理由：
 * 修改内容：
 */
public class PersonfileCameraReqDTO extends BasePageReqDTO implements java.io.Serializable {
    /**
     * 摄像头id
     */
    private String devId;
    /**
     * 区域id
     */
    private Long areaId;
    /**
     * 开始时间 根据创建时间条件查询
     */
    private String startTime;
    /**
     * 结束时间 根据创建时间条件查询
     */
    private String endTime;
    /**
     * 设备类型
     */
    private Long deviceType;
    /**
     * 设备名称 模糊查询
     */
    private String name;

    public String getDevId() {
        return devId;
    }

    public void setDevId(String devId) {
        this.devId = devId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Long getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Long deviceType) {
        this.deviceType = deviceType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() {
        return "PersonfileCameraReqDTO{" +
                "devId='" + devId + '\'' +
                ", areaId=" + areaId +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", deviceType=" + deviceType +
                ", name='" + name + '\'' +
                '}';
    }
}
