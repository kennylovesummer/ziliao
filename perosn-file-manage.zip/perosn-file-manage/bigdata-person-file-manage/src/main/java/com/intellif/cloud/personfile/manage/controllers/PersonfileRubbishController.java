package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.kafka.producer.MqProducer;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author liuyu
 * @className RubbishController
 * @date 2019/3/15 14:06
 * @description
 */
@Api(tags = "回收站")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.RequestUrl.RUBBISH)
public class PersonfileRubbishController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final PersonfileRubbishService personfileRubbishService;
    
    private final PersonPropertiest personPropertiest;
    
    private final MqProducer mqProducer;
    
    @Autowired
    public PersonfileRubbishController(PersonfileRubbishService personfileRubbishService, MqProducer mqProducer, PersonPropertiest personPropertiest) {
        this.personfileRubbishService = personfileRubbishService;
        this.mqProducer = mqProducer;
        this.personPropertiest = personPropertiest;
    }
    
    /**
     * 获取回收站列表
     *
     * @param page    页码
     * @param perpage 每页数据条数
     * @param version 版本
     * @return String
     */
    @ApiOperation(httpMethod = "GET",value = "获取回收站列表")
    @GetMapping(value = "/{version}")
    public BasePageRespDTO quaryRubbish(@RequestParam(required = false, defaultValue = "1") int page,
                                        @RequestParam(required = false, defaultValue = "90") int perpage,
                                        @PathVariable(name = "version") String version) {
        try {
            Page<PersonfileRubbish> personfileRubbishList = personfileRubbishService.findPersonfileRubbish(page, perpage);
            return IPersonFilesResultInfo.success(personfileRubbishList, personfileRubbishList.getPages(),
                    (int) personfileRubbishList.getTotal(), "回收站列表查询成功！");
        } catch (Exception e) {
            logger.error("获取回收站列表异常:" + e.getMessage());
            return new BasePageRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "回收站列表查询失败！");
        }
    }
    
    /**
     * 删除回收站照片
     *
     * @param rubbishId
     * @param version   版本
     * @return String
     */
    @ApiOperation(httpMethod = "DELETE",value = "删除回收站照片")
    @DeleteMapping(value = "/{rubbishId}/{version}")
    public BaseDataRespDTO deleteRubbish(@PathVariable(value = "rubbishId") Long rubbishId,
                                         @PathVariable(name = "version") String version) {
        try {
            PersonfileRubbish personfileRubbish = new PersonfileRubbish();
            personfileRubbish.setId(rubbishId);
            personfileRubbishService.deletePersonfileRubbish(personfileRubbish);
            return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.DELETE_SUCCESS.getMessage(), ResultMessageEnum.DELETE_SUCCESS.getMessage());
        } catch (Exception e) {
            logger.error("删除回收站照片异常:" + e.getMessage());
        }
        return new BaseDataRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, "删除回收站照片失败");
    }
    
    /**
     * 获取回收站聚类配置(此配置目前使用定时任务每天会将回收站照片推送一次至数据平台进行二次聚类)
     *
     * @param version 版本
     * @return String
     */
    @ApiOperation(httpMethod = "GET",value = "获取回收站聚类配置")
    @GetMapping(value = "/config/{version}")
    public BaseDataRespDTO quaryConfig(@PathVariable(name = "version") String version) {
        Map<String, Object> result = new HashMap<>(3);
        result.put("intervalDay", 1);
        result.put("clusterFlag", 1);
        result.put("clusterRule", "每1天聚类一次");
        return new BaseDataRespDTO(result, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(), ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        
    }
    
    
    /**
     * 回收站里的数据推送至kafak
     *
     * @return
     */
    @ApiOperation(httpMethod = "PUT",value = "回收站里的数据推送至kafak")
    @PutMapping(value = "push/to/kafka")
    public String rubishPushToKafka() {
        try {
            logger.info("回收站照片推送开始...");
            BasePageReqDTO basePageReqDTO = new BasePageReqDTO();
            List<Map<String, Object>> result = personfileRubbishService.findPersonfileRubbishToCluster(basePageReqDTO);
            for (int i = 2; CollectionUtils.isNotEmpty(result); i++) {
                // 推送至kafka
                for (Map item : result) {
                    logger.info("开始推送至数据平台进行二次归类:", item);
                    mqProducer.send(JSONObject.toJSONString(item), personPropertiest.getKafkaListenerPersonfileRubbishTopic());
                }
                // 推送完了立即删除
                logger.info("推送至数据平台进行二次归类结束后删除:", result);
                personfileRubbishService.deleteByIds(result.stream().map(dd -> dd.get("id")).collect(Collectors.toList()));
                basePageReqDTO.setPage(i);
                result = personfileRubbishService.findPersonfileRubbishToCluster(basePageReqDTO);
            }
            logger.info("回收站照片推送完成。");
            return "推送完成";
        } catch (Exception e) {
            logger.info("回收站照片推送异常：", e.getMessage());
        }
        return "推送失败";
    }
}
