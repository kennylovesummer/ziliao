package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesStatisticsConstant;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 人员类型统计
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月29日
 * @see PersonfileStatisticTypeController
 * @since JDK1.8
 */
@Api(tags = "人员类型统计")
@RestController
@RequestMapping(IPersonfilesStatisticsConstant.RequestUrl.PERSON_TYPE)
public class PersonfileStatisticTypeController {
    @Resource
    private StatisticPersonfileTypeService statisticPersonfileTypeService;
    
    /**
     * 根据人员类型id累加人员档案数量
     *
     * @param personFileTypeId 人员类型id
     * @param personFileNum    档案数量
     * @return
     */
    @ApiOperation(httpMethod = "PUT",value = "根据人员类型id累加人员档案数量")
    @PutMapping("/update/num/{version}")
    public String updateNumByPersonTypeId(@RequestParam String personFileTypeId, @RequestParam int personFileNum) {
        return JSONObject.toJSONString(statisticPersonfileTypeService.updateNumByPersonTypeId(personFileTypeId, personFileNum));
    }
    
    /**
     * 新增人员类型统计
     *
     * @param statisticPersonfileType
     * @return
     */
    @ApiOperation(httpMethod = "POST",value = "新增人员类型统计")
    @PostMapping("/insert/{version}")
    public String insertPersonfileType(@RequestBody StatisticPersonfileType statisticPersonfileType) {
        return JSONObject.toJSONString(statisticPersonfileTypeService.insertPersonfileType(statisticPersonfileType));
    }
    
    /**
     * 根据人员类型id修改人员类型名称
     *
     * @param personFileTypeId   人员类型id
     * @param personFileTypeName 人员类型名称
     * @return
     */
    @ApiOperation(httpMethod = "PUT",value = "根据人员类型id修改人员类型名称")
    @PutMapping("/update/typename/{version}")
    public String updatePersonfileTypeNameByTypeId(@RequestParam Integer personFileTypeId, @RequestParam String personFileTypeName) {
        return JSONObject.toJSONString(statisticPersonfileTypeService.updatePersonfileTypeNameByTypeId(personFileTypeId, personFileTypeName));
    }
    
    /**
     * 根据人员类型id删除类型统计
     *
     * @param personFileTypeId
     * @return
     */
    @ApiOperation(httpMethod = "DELETE",value = "根据人员类型id删除类型统计")
    @DeleteMapping("/{personFileTypeId}/{version}")
    public BaseDataRespDTO deletePersonfileTypeByTypeId(@PathVariable("personFileTypeId") Integer personFileTypeId) {
        return statisticPersonfileTypeService.deletePersonfileTypeByTypeId(personFileTypeId);
    }
}
