package com.intellif.cloud.personfile.manage.utils;

import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;

/**
 * @ClassName IPersonFilesResultInfo
 * @Author liuYu
 * @create 2018-10-17 18:00
 * @Version 1.0
 * @desc
 */

public class IPersonFilesResultInfo {

    public static BaseDataRespDTO ok(String description) {
        return new BaseDataRespDTO(IResultCode.SUCCESS, description);
    }

    public static BaseDataRespDTO ok() {
        return new BaseDataRespDTO(IResultCode.SUCCESS);
    }

    public static BaseDataRespDTO ok(Object data, String description) {
        return new BaseDataRespDTO(data, IResultCode.SUCCESS, description);
    }

    public static BaseDataRespDTO ok(String description, String respMark) {
        return new BaseDataRespDTO(IResultCode.SUCCESS, description, respMark);
    }

    public static BaseDataRespDTO ok(Object data, String description, String respMark) {
        return new BaseDataRespDTO(data, IResultCode.SUCCESS, description, respMark);
    }

    public static BaseDataRespDTO unknownError(String description) {
        return new BaseDataRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, description);
    }

    public static BaseDataRespDTO unknownError(String description, String respMark) {
        return new BaseDataRespDTO(IPersonFilesResultCode.IManageResultCode.ERROR, description, respMark);
    }

    public static BasePageRespDTO success(Object data, int maxPage, int total) {
        return new BasePageRespDTO(data, maxPage, total, IPersonFilesResultCode.IManageResultCode.ERROR);
    }

    public static BasePageRespDTO success(Object data, int maxPage, int total, String respMessage) {
        return new BasePageRespDTO(data, maxPage, total, IResultCode.SUCCESS, respMessage);
    }

    public static BasePageRespDTO success(Object data, int maxPage, int total, String respMessage, String respMark) {
        return new BasePageRespDTO(data, maxPage, total, IResultCode.SUCCESS, respMessage, respMark);
    }

    public static BasePageRespDTO error(Object data, int maxPage, int total, String respMessage) {
        return new BasePageRespDTO(data, maxPage, total, IResultCode.SUCCESS, respMessage);
    }
}