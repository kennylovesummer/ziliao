package com.intellif.cloud.personfile.manage.services.analysis;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.AnalysisTaskListDTO;
import com.intellif.cloud.personfile.manage.model.vo.crash.CrashVO;

import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * 任务
 *
 * @author liuzj
 * @date 2019-06-26
 */
public interface BigdataAnalysisTaskService {
    
    /**
     * 根据ID获取任务
     *
     * @return BigdataAnalysisArea
     */
    BigdataAnalysisTask findBigdataAnalysisTaskById(Long id);
    
    /**
     * 根据execId获取任务
     *
     * @return BigdataAnalysisArea
     */
    BigdataAnalysisTask findBigdataAnalysisTaskByExecId(String execId);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisTask 参数集
     */
    void insertBigdataAnalysisTask(BigdataAnalysisTask bigdataAnalysisTask);
    
    /**
     * 修改
     *
     * @param bigdataAnalysisTask 参数集
     */
    void updateBigdataAnalysisTask(BigdataAnalysisTask bigdataAnalysisTask);
    
    /**
     * 根据条件查询数据
     *
     * @param crashListDTO 参数集
     * @return List
     */
    Page<CrashVO> findBigdataAnalysisTaskByParams(AnalysisTaskListDTO crashListDTO);
    
    /**
     * 根据任务名获取任务
     *
     * @param name 任务名
     * @return BigdataAnalysisTask
     */
    BigdataAnalysisTask findBigdataAnalysisTaskByTaskName(String name);
    
    /**
     * 删除业务
     */
    void deleteTask(Long taskId);
    
    /**
     * 创建任务
     *
     * @param params 参数集
     * @return
     */
    BaseDataRespDTO createTask(JSONObject params);
    
    /**
     * 更新任务状态
     */
    void updateTaskStatus() throws ExecutionException, InterruptedException;
    
    /**
     * 根据旧的状态更新状态
     *
     * @param taskId 任务ID
     * @param newStatus 新的状态
     * @param oldStatus 旧的状态
     * @return 响应记录数
     */
    Integer updateStatusByOldStatus(Long taskId,Integer newStatus,Integer oldStatus);
    
    /**
     * 根据状态获取任务
     *
     * @param status 状态
     * @return List
     */
    List<BigdataAnalysisTask> findBigdataAnalysisTaskByStatus(Integer status);
    
    /**
     * 同步任务结果以及更新任务状态
     *
     * @param execId 执行job ID
     */
    boolean analysisTaskStatusHandler(String execId);
}
