package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.camera.DeepEyeCameraDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.services.general.DeepEyeService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 摄像头
 *
 * @author lzj
 * @version 1.0
 * @date 2019年06月25日
 * @see CameraController
 * @since JDK1.8
 */
@Api(tags = "摄像头")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.RequestUrl.CAMERA)
public class CameraController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private DeepEyeService deepEyeService;
    
    /**
     * 摄像头列表
     *
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "GET",value = "分页获取树状摄像头信息（调用深目API获取）")
    @GetMapping(value = "list")
    public BaseDataRespDTO list() {
        try {
            return deepEyeService.getTreeCameraInfo();
        } catch (Exception e) {
            logger.error("获取树状摄像头信息异常：" + e.getMessage());
            return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    
    /**
     * 搜索摄像头
     *
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取树状摄像头信息（调用深目API获取）- 根据名字搜索")
    @PostMapping(value = "search/page/{page}/perpage/{perpage}")
    public BaseDataRespDTO serchByName(@PathVariable(name = "page")Integer page,@PathVariable(name = "perpage")Integer perpage,@RequestBody DeepEyeCameraDTO deepEyeCameraDTO) {
        try {
            if (page == null || perpage == null || Strings.isBlank(deepEyeCameraDTO.getId())) {
                return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),"参数异常");
            }
            
            return deepEyeService.searchCrmereByName(deepEyeCameraDTO.getId(),deepEyeCameraDTO.getName(),page,perpage);
        } catch (Exception e) {
            logger.error("获取树状摄像头信息异常：" + e.getMessage());
            return new BaseDataRespDTO(null, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
}
