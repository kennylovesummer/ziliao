package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrashArea;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashAreaParam;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.CrashTaskCreateDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.cloud.personfile.manage.utils.StringsUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 碰撞分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisCrashCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    private final BigdataAnalysisCrashAreaService bigdataAnalysisCrashAreaService = BeanUtlis.getBean(BigdataAnalysisCrashAreaService.class);
    
    AnalysisCrashCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        CrashTaskCreateDTO multiCrashDTO = JSONObject.parseObject(params.toJSONString(), CrashTaskCreateDTO.class);
        
        // 参数校验
        if (CollectionUtils.isEmpty(multiCrashDTO.getSpatioTemps())) {
            throw new BusinessException(IResultCode.ERROR, "参数异常");
        }
        
        List<String> areaNames = multiCrashDTO.getSpatioTemps().stream().map(a -> a.getBlockCode()).collect(Collectors.toList());
        List<Integer> areaCodes = multiCrashDTO.getSpatioTemps().stream().map(a -> a.getAreaCode()).collect(Collectors.toList());
        if (areaNames.size() != Sets.newHashSet(areaNames).size() || areaCodes.size() != Sets.newHashSet(areaCodes).size()) {
            throw new BusinessException(IResultCode.ERROR, "区域名字或者区域标识不能重复");
        }
        
        List<String> devIds = Lists.newArrayList();
        multiCrashDTO.getSpatioTemps().stream().forEach(m -> devIds.addAll(m.getSourceIds()));
        if (CollectionUtils.isEmpty(devIds)) {
            throw new BusinessException(IResultCode.ERROR, "摄像头不能为空");
        }
        
        if (devIds.size() != Sets.newHashSet(devIds).size()) {
            throw new BusinessException(IResultCode.ERROR, "区域之间的摄像头不能有交集");
        }
    
        String rulesConfig = personPropertiest.getDataAnalysisCrashRules();
        if (Strings.isNotBlank(rulesConfig)) {
            multiCrashDTO.getSpatioTemps().forEach(rule-> {
                if (rule.getPeriods() == null) {
                    rule.setPeriods(Arrays.asList(rulesConfig.split(ICommonConstant.Symbol.COMMA)));
                }
            });
        }
        
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setParams(multiCrashDTO.toString());
        offLineTaskDTO.setTaskName(multiCrashDTO.getTaskName());
        offLineTaskDTO.setTaskType(DataStisticTypeEnum.CRASH.getName());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
        
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setName(multiCrashDTO.getTaskName());
        bigdataAnalysisTask.setType(DataStisticTypeEnum.CRASH.getName());
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        Long taskId = bigdataAnalysisTask.getId();
        
        List<BigdataAnalysisCrashArea> analysisCrashAreas = Lists.newArrayList();
        for (CrashAreaParam area : multiCrashDTO.getSpatioTemps()) {
            BigdataAnalysisCrashArea bigdataAnalysisCrashArea = new BigdataAnalysisCrashArea();
            bigdataAnalysisCrashArea.setCode(area.getBlockCode());
            bigdataAnalysisCrashArea.setAreaId(area.getAreaCode() + "");
            bigdataAnalysisCrashArea.setTaskId(taskId);
            bigdataAnalysisCrashArea.setDevs(StringsUtils.listToString(area.getSourceIds(), ICommonConstant.Symbol.COMMA));
            bigdataAnalysisCrashArea.setStartTime(area.getStartTime());
            bigdataAnalysisCrashArea.setEndTime(area.getEndTime());
            analysisCrashAreas.add(bigdataAnalysisCrashArea);
        }
        bigdataAnalysisCrashAreaService.batchInsert(analysisCrashAreas);
        
        return execId;
    }
}
