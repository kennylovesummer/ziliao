package com.intellif.cloud.personfile.manage.services.sub.impl;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileMergeDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapQueryDTO;
import com.intellif.cloud.personfile.manage.model.vo.activityRoutine.PersonfileActivityRoutinesVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSnapService;
import com.intellif.cloud.personfile.manage.services.sub.AbstractSubService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.services.sub.SubService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @see SubService
 */
@Service
@Transactional
public class SubEventServiceImpl extends AbstractSubService<PersonfileSnap> implements SubEventService {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    private static final String TABLE_NAME = "t_bigdata_event";
    
    public static final String CREATE_TABLE_SQL = "CREATE TABLE `t_bigdata_event` (\n" +
            "  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',\n" +
            "  `thumbnail_id` varchar(255) NOT NULL COMMENT '小图id',\n" +
            "  `thumbnail_url` varchar(1000) NOT NULL COMMENT '小图地址',\n" +
            "  `image_id` varchar(255) DEFAULT NULL COMMENT '大图ID',\n" +
            "  `image_url` varchar(1000) DEFAULT NULL COMMENT '大图URL',\n" +
            "  `sys_code` varchar(255) DEFAULT NULL COMMENT '系统编码',\n" +
            "  `algo_version` varchar(255) NOT NULL COMMENT '算法版本',\n" +
            "  `gender_info` varchar(255) DEFAULT NULL COMMENT '性别信息',\n" +
            "  `age_info` varchar(255) DEFAULT NULL COMMENT '年龄信息',\n" +
            "  `hairstyle_info` varchar(255) DEFAULT NULL COMMENT '发型信息',\n" +
            "  `hat_info` varchar(255) DEFAULT NULL COMMENT '帽子信息',\n" +
            "  `glasses_info` varchar(255) DEFAULT NULL COMMENT '眼镜信息',\n" +
            "  `race_info` varchar(255) DEFAULT NULL COMMENT '族别信息',\n" +
            "  `mask_info` varchar(255) DEFAULT NULL COMMENT '口罩信息',\n" +
            "  `skin_info` varchar(255) DEFAULT NULL COMMENT '皮肤信息',\n" +
            "  `pose_info` varchar(255) DEFAULT NULL COMMENT '角度信息',\n" +
            "  `quality_info` decimal(4,3) DEFAULT NULL COMMENT '图片质量评分',\n" +
            "  `target_rect` varchar(255) DEFAULT NULL COMMENT '人脸区域',\n" +
            "  `target_rect_float` varchar(255) DEFAULT NULL COMMENT '检测区域的浮点',\n" +
            "  `land_mark_info` varchar(255) DEFAULT NULL COMMENT '一些脸部轮廓信息',\n" +
            "  `feature_quality` decimal(2,1) DEFAULT NULL COMMENT '图片质量信息',\n" +
            "  `source_id` varchar(255) DEFAULT NULL COMMENT '摄像头ID',\n" +
            "  `source_type` varchar(255) NOT NULL COMMENT '数据源类型',\n" +
            "  `site` varchar(255) DEFAULT NULL COMMENT '抓拍地点',\n" +
            "  `time` datetime NOT NULL COMMENT '抓拍时间',\n" +
            "  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n" +
            "  `column1` varchar(255) DEFAULT NULL COMMENT '扩展字段',\n" +
            "  `column2` varchar(255) DEFAULT NULL COMMENT '扩展字段',\n" +
            "  `column3` varchar(255) DEFAULT NULL COMMENT '扩展字段',\n" +
            "  `dt` date DEFAULT NULL COMMENT '抓拍日期',\n" +
            "  KEY `thumbnailId` (`thumbnail_id`),\n" +
            "  KEY `aid` (`aid`,`dt`),\n" +
            "  KEY `createTime` (`create_time`)\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='抓拍照片表';";
    
    @Autowired
    private PersonfileSnapService personfileSnapService;
    
    @Autowired
    private PersonfileRubbishService personfileRubbishService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    @Override
    public Page<EventSnapDetailVO> getPersonfileSnap(SnapQueryDTO snapQueryDTO) {
        List<String> allTable = getAllTableFromDB(false,true);
        Integer startTime = Integer.parseInt(snapQueryDTO.getStartTime().replaceAll("-",""));
        Integer endTime = Integer.parseInt(snapQueryDTO.getEndTime().replaceAll("-",""));
        List<String> knowTable = Lists.newArrayList();
        selectKnowTable(allTable,knowTable,startTime,endTime);
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.getPersonfileSnap(snapQueryDTO);
    }
    
    @Override
    public Page<EventSnapDetailVO> getPersonfileSnapDetail(String personFilesId, String startDate,String endDate,int page, int perPage) throws ParseException {
        List<String> allTable = getAllTableFromDB(false,true);
        Integer startTime = Integer.parseInt(startDate.replaceAll("-",""));
        Integer endTime = Integer.parseInt(endDate.replaceAll("-",""));
        List<String> knowTables = Lists.newArrayList();
        selectKnowTable(allTable,knowTables,startTime,endTime);
        if (CollectionUtils.isEmpty(knowTables)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTables);
        return personfileSnapService.getPersonfileSnapDetail(personFilesId,page,perPage);
    }
    
    @Override
    public BaseDataRespDTO querySnapMapByPersonFilesId(SnapMapDTO snapMapDTO) {
        List<String> knowTable = getEventTables(snapMapDTO.getStartTime(),snapMapDTO.getEndTime());
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.querySnapMapByPersonFilesId(snapMapDTO);
    }
    
    @Override
    public Page<SnapMapVO> getSnapMapByPersonFilesId(SnapMapDTO snapMapDTO) {
        List<String> knowTable = getEventTables(snapMapDTO.getStartTime(),snapMapDTO.getEndTime());
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.getSnapMapByPersonFilesId(snapMapDTO);
    }
    
    @Override
    public Page<SnapMapVO> querySnapMapDetail(SnapQueryDTO snapQueryDTO) {
        List<String> knowTable = getEventTables(snapQueryDTO.getStartTime(),snapQueryDTO.getEndTime());
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.querySnapMapDetail(snapQueryDTO);
    }
    
    @Override
    public List<PersonfileRubbish> getByPersonfileId(String snapId, String personfileId,Integer page,Integer pageSize) {
        return personfileSnapService.getByPersonfileId(snapId,personfileId,page,pageSize);
    }
    
    @Override
    public int deletePersonfileSnap(PersonfileSnap personfileSnap) {
//        SubEventService subEventService = (SubEventService) AopContext.currentProxy();
//        List<PersonfileRubbish> snaps = subEventService.getByPersonfileId(personfileSnap.getFaceId(),null);
//        if (CollectionUtils.isEmpty(snaps)) {
//            return 0;
//        }
        if (personfileSnap.getSnapTime() != null) {
            List<String> knowTable = Lists.newArrayList();
            knowTable.add(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + DateFormatUtils.format(personfileSnap.getSnapTime(),"yyyyMMdd"));
            ThreadLocalUtil.setSubKnowTableName(knowTable);
        }
        return personfileSnapService.deletePersonfileSnap(personfileSnap);
    }
    
    @Override
    public void deleteEventSnapImg(String faceId, String personfileId) throws BusinessException {
        List<PersonfileRubbish> rubbishes = getByPersonfileId(faceId, personfileId,null,null);
        if (CollectionUtils.isEmpty(rubbishes)) {
            return;
        }
        PersonfileRubbish personfileRubbish = rubbishes.get(0);
        //删除的抓拍到回收站
        int result = personfileRubbishService.insertPersonfileRubbish(personfileRubbish);
        if (result == 1) {
            PersonfileSnap personfileSnap = new PersonfileSnap();
            BeanUtils.copyProperties(personfileRubbish,personfileSnap);
            //删除抓拍
            SubEventService subEventService = (SubEventService) AopContext.currentProxy();
            subEventService.deletePersonfileSnap(personfileSnap);
            //档案imageCount - 1
            PersonfileBasicsVO personfileBasicsVO = subArchiveService.findBaseInfoVOByPersonFileId(personfileId);
            if (personfileBasicsVO.getImageCount() > 0) {
                subArchiveService.updateImageCount(-1, personfileId);
            }
            // 更新事件统计
            try {
                statisticPersonfileEventService.updateStatisticEvent(-1, DateFormatUtils.format(personfileRubbish.getSnapTime(),ICommonConstant.DateFormatType.Y_M_D));
            } catch (Exception e) {
                logger.error("删除事件-更新事件统计异常：" + e.getMessage());
            }
            
        }
    }
    
    
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int batchInsert(List<PersonfileSnap> personfileSnaps) {
        this.baseDao.batchInsert(new PersonfileSnap(),null, personfileSnaps);
        return personfileSnaps.size();
    }
    
    @Override
    public void eventSync(List<PersonfileSnap> personfileSnaps){
        Map<String,List<PersonfileSnap>> groupByTable = personfileSnaps.stream().collect(Collectors.groupingBy(PersonfileSnap::getTableName));
        List<Map<String,Object>> params = Lists.newArrayList();
        for (String key: groupByTable.keySet()) {
            List<PersonfileSnap> snaps = groupByTable.get(key);
            Map<String,Object> param = Maps.newHashMap();
            param.put("personfileSnaps",snaps);
            param.put("tableName",createTableIfNotExist(key,key,CREATE_TABLE_SQL.replaceAll(TABLE_NAME,key),Long.valueOf(snaps.size() + ""),personPropertiest.getEventTableMaxRows()));
            params.add(param);
        }
        batchEventSync(params);
    }
    
    @Override
    public void batchEventSync(List<Map<String,Object>> params){
        this.baseDao.updateStatement("batchInsertPersonfileSnap", params);
    }
    
    @Override
    public Page<PersonfileActivityRoutinesVO> getSnapActivity(String personFilesId, String startTime, String endTime, Integer activityRoutineType, Integer page, Integer perpage) {
        List<String> allTable = getAllTableFromDB(false,true);
        String[] startTimes = startTime.split(" ");
        String[] endTimes = endTime.split(" ");
        Integer startTimeTemp = Integer.parseInt(startTimes[0].replaceAll("-",""));
        Integer endTimeTemp = Integer.parseInt(endTimes[0].replaceAll("-",""));
        List<String> knowTable = Lists.newArrayList();
        selectKnowTable(allTable,knowTable,startTimeTemp,endTimeTemp);
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.getSnapActivity(personFilesId,startTime,endTime,activityRoutineType,page,perpage);
    }
    
    /**
     * @deprecated
     */
    @Override
    public int getSnap(String startTime, String endTime) {
        return personfileSnapService.getSnap(startTime,endTime);
    }
    
    /**
     * @deprecated
     */
    @Override
    public String findByImageUrl(String imageUrl) {
        return personfileSnapService.findByImageUrl(imageUrl);
    }
    
    @Override
    public Integer statisticSnapByDate(String dt) {
        List<String> knowTable = getEventTables(dt,dt);
        if (CollectionUtils.isEmpty(knowTable)) {
            return null;
        }
        ThreadLocalUtil.setSubKnowTableName(knowTable);
        return personfileSnapService.statisticSnapByDate();
    }
    
    @Override
    public List<String> findSnapUrlsByPersonfileId(String personFileId) {
        return personfileSnapService.findSnapUrlsByPersonfileId(personFileId);
    }
    
    @Override
    public Date findFirstSnapTimeByPersonFileId(String personFileId) {
        return personfileSnapService.findFirstSnapTimeByPersonFileId(personFileId);
    }
    
    @Override
    public List<PersonfileBasics> findSnapTimeAndImageCount(String personFileId) {
        return personfileSnapService.findSnapTimeAndImageCount(personFileId);
    }
    
    @Override
    public List<PersonfileBasics> findSnapTimeAndImageCountByPersonfileId(List<String> personFileId) {
        return personfileSnapService.findSnapTimeAndImageCountByPersonfileId(personFileId);
    }
    
    @Override
    public void updateSnapAid(List<PersonfileMergeDTO> params) {
        personfileSnapService.updateSnapAid(params);
    }
    
    
    @Override
    public List<SnapMapVO> getSnapMapByPersonFilesId(List<String> personfilesIdList) {
        return personfileSnapService.getSnapMapByPersonFilesId(personfilesIdList);
    }
    
    @Override
    public List<String> getEventTables(String startTime, String endTime) {
        List<String> allTable = getAllTableFromDB(false,true);
        Integer startDate = Integer.parseInt(startTime.substring(0,10).replaceAll("-",""));
        Integer endDate = Integer.parseInt(endTime.substring(0,10).replaceAll("-",""));
        List<String> knowTable = Lists.newArrayList();
        selectKnowTable(allTable,knowTable,startDate,endDate);
        return knowTable;
    }
    
    @Override
    public List<String> getEventAllTables(){
        return getAllTableFromDB(true,true);
    }
    
    private void selectKnowTable(List<String> allTable,List<String> knowTable, Integer startTime,Integer endTime){
        for (String table: allTable) {
            if (!table.contains(TABLE_NAME)) {
                continue;
            }
            if (table.equals(TABLE_NAME)) {
                knowTable.add(table);
                continue;
            }
            String[] tableSplit = table.split(ICommonConstant.Symbol.UNDERLINE);
            Integer date;
            try {
                date = Integer.parseInt(tableSplit[3]);
            } catch (Exception e){
                continue;
            }
            if (date >= startTime && date <= endTime) {
                knowTable.add(table);
            }
        }
    }
}
