package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.xdata.Props;
import lombok.Data;

import java.util.List;

@Data
public class NocturnalTaskCreateDTO extends BaseAnalysisCreateDTO{

    private List<String> sourceIds;
    
    private String startTime;
    
    private String endTime;
    
    private Props rules;
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
