package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisCrashArea;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @see BigdataAnalysisCrashAreaService
 */
@Service
public class BigdataAnalysisCrashAreaServiceImpl extends BaseServiceImpl implements BigdataAnalysisCrashAreaService {
    private static final BigdataAnalysisCrashArea ANALYSIS_CRASH_AREA = new BigdataAnalysisCrashArea();
    
    @Override
    public BigdataAnalysisCrashArea findAnalysisCrashAreaById(Long id) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("id", id);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findAnalysisCrashAreaById");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (BigdataAnalysisCrashArea) object;
    }
    
    @Override
    public Integer insertAnalysisCrashArea(BigdataAnalysisCrashArea bigdataAnalysisCrashArea) {
        return this.baseDao.insert(bigdataAnalysisCrashArea);
    }
    
    @Override
    public void batchInsert(List<BigdataAnalysisCrashArea> analysisCrashAreas) {
        this.baseDao.batchInsert(ANALYSIS_CRASH_AREA, null, analysisCrashAreas);
    }
    
    @Override
    public void updateAnalysisCrashArea(BigdataAnalysisCrashArea bigdataAnalysisCrashArea) {
        this.baseDao.update(bigdataAnalysisCrashArea);
    }
    
    @Override
    public List<BigdataAnalysisCrashArea> findAnalysisCrashAreaByTaskId(Long taskId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findAnalysisCrashAreaByTaskId");
        Object object = this.baseDao.findAllIsPageByCustom(queryEvent);
        return object == null ? null : (List<BigdataAnalysisCrashArea>) object;
    }
    
    @Override
    public List<BigdataAnalysisCrashArea> findAnalysisCrashAreaByTaskIds(List<Long> taskIds) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskIds", taskIds);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findAnalysisCrashAreaByTaskIds");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (List<BigdataAnalysisCrashArea>) object;
    }
    
    @Override
    public void deleteByTaskId(Long taskId) {
        Map<String,Object> params = Maps.newHashMap();
        params.put("taskId",taskId);
        this.baseDao.updateStatement("deleteByTaskId",params);
    }
}
