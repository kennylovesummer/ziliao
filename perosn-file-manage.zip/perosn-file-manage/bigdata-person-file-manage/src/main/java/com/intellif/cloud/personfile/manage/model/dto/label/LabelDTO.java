package com.intellif.cloud.personfile.manage.model.dto.label;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author liuyu
 * @className LabelDTO
 * @date 2019/3/23 17:17
 * @description
 */
@Data
public class LabelDTO implements Serializable {

    private static final long serialVersionUID = 8675288793161554211L;

    private List<String> lableIds;
}
