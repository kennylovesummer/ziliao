package com.intellif.cloud.personfile.manage.enums;

public enum DBTypeEnum {
    master, slave
}