package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisPeer;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.PeerDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisPeerService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * 同行分析
 *
 * @author lzj
 * @version 1.0
 * @date 2019年06月20日
 * @see PeerAnalysisController
 * @since JDK1.8
 */
@Api(tags = "数据分析-同行分析")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.PEER)
public class PeerAnalysisController implements Serializable {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAnalysisPeerService bigdataAnalysisPeerService;
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    /**
     * 获取同行分析列表
     *
     * @param peerDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取同行人员")
    @PostMapping(value = "list")
    public BasePageRespDTO list(@RequestBody PeerDTO peerDTO) {
        try {
            // 参数校验
            if (peerDTO.getTaskId() == null) {
                return new BasePageRespDTO(null, 0,0, IResultCode.ERROR, "参数异常");
            }
    
            peerDTO.setOrderBy("a.event_times desc");
            Page<BigdataAnalysisArchive> page = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(peerDTO);
            List<BigdataAnalysisArchive> bigdataAnalysisArchiveList = page.getResult();
    
            if (CollectionUtils.isNotEmpty(bigdataAnalysisArchiveList)) {
//                List<Map<String, Object>> personfileBasicsList = subArchiveService.findByPersonfileIds(bigdataAnalysisArchiveList.stream().map(BigdataAnalysisArchive::getAid).collect(Collectors.toList()));
                for (BigdataAnalysisArchive item: bigdataAnalysisArchiveList) {
                    PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(item.getAid());
                    item.setImageCount(personfileBasics != null ? personfileBasics.getImageCount() : null);
                    item.setPersonName(personfileBasics != null ? personfileBasics.getName() : null);
                    item.setCid(personfileBasics != null ? personfileBasics.getCid() : null);
//                    item.setImageCount((Integer) personfileBasicsList.stream().filter(m -> item.getAid().equals(m.get("personFileId"))).findAny().orElse(Maps.newHashMap()).get("imageCount"));
                }
            }
            
            return new BasePageRespDTO(bigdataAnalysisArchiveList, page.getPages(),Integer.parseInt(page.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e){
            logger.error("同行档案结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR,ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    /**
     * 获取同行分析详情
     *
     * @param peerDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取同行详情")
    @PostMapping(value = "detail")
    public BasePageRespDTO detail(@RequestBody PeerDTO peerDTO) {
        try {
            // 参数校验
            if (peerDTO.getTaskId() == null || Strings.isBlank(peerDTO.getAid())) {
                return new BasePageRespDTO(null, 0,0, IResultCode.ERROR, "参数异常");
            }
    
            Page<BigdataAnalysisPeer> page = bigdataAnalysisPeerService.findAnalysisPeerByParams(peerDTO);
            List<BigdataAnalysisPeer> peerList = page.getResult();
    
            if (CollectionUtils.isEmpty(peerList)) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
    
            EventDTO eventDTO = new EventDTO();
            BeanUtils.copyProperties(peerDTO,eventDTO);
            eventDTO.setPerpage(0);
            for (BigdataAnalysisPeer peer: peerList) {
//                eventDTO.setDate(peer.getDate().getTime());
                eventDTO.setStartTime(peer.getStartTime());
                eventDTO.setEndTime(peer.getEndTime());
//                eventDTO.setCameraId(peer.getCameraId());
                peer.setFaces(bigdataAnalysisEventService.findAnalysisEventByParams(eventDTO));
            }
    
            return new BasePageRespDTO(peerList, page.getPages(),Integer.parseInt(page.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e){
            logger.error("同行事件结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR,ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
}
