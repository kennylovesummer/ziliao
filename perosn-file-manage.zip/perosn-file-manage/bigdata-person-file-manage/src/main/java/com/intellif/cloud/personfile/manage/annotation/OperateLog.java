package com.intellif.cloud.personfile.manage.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target(value = {TYPE, METHOD, ANNOTATION_TYPE})
@Retention(RUNTIME)
public @interface OperateLog {

    boolean value() default false;

    String remark() default "";
}
