package com.intellif.cloud.personfile.manage.model.dto.req;

import com.alibaba.fastjson.JSONObject;

public class BasePageRespDTO extends BaseResp {

	/**
	 *
	 */
	private static final long serialVersionUID = -7485993417216651750L;

	private Object data;
	private int maxPage;
	private int total;
	private String respMark;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public int getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public BasePageRespDTO() {
	}

	public BasePageRespDTO(Object data, int maxPage, int total, int respCode) {
		this.data = data;
		this.maxPage = maxPage;
		this.total = total;
		super.setRespCode(respCode);
	}

	public BasePageRespDTO(Object data, int maxPage, int total, int respCode, String respMessage) {
		this.data = data;
		this.maxPage = maxPage;
		this.total = total;
		super.setRespCode(respCode);
		super.setRespMessage(respMessage);
	}

	public BasePageRespDTO(Object data, int maxPage, int total, int respCode, String respMessage, String respMark) {
		this.data = data;
		this.maxPage = maxPage;
		this.total = total;
		super.setRespCode(respCode);
		super.setRespMessage(respMessage);
		this.respMark = respMark;
	}

	public BasePageRespDTO(int respCode, String respMessage, String respMark) {
		super.setRespCode(respCode);
		super.setRespMessage(respMessage);
		this.respMark = respMark;
	}

	public BasePageRespDTO(int respCode, String description) {
		super.setRespMessage(description);
		super.setRespCode(respCode);
	}

	public String getRespMark() {
		return respMark;
	}

	public void setRespMark(String respMark) {
		this.respMark = respMark;
	}

	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}
}
