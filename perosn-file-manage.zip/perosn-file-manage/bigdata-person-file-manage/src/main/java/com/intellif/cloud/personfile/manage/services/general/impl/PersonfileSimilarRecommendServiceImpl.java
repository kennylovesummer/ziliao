package com.intellif.cloud.personfile.manage.services.general.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSimilarRecommendService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileSimilarRecommendServiceImpl
 * @date 2019/2/25 14:14
 * @description
 */
@Service
public class PersonfileSimilarRecommendServiceImpl implements PersonfileSimilarRecommendService {
    
    @Autowired
    private PersonfileSolrService personfileSolrService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    @Autowired
    private XdataFeignClient xdataFeignClient;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Override
    public List<Map<String, Object>> getPersonfileSimilarRecommend(String personFileId) throws Exception {
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        listFilterDTO.setFrom(1);
        XdataReqDTO xdataReqDTO = new XdataReqDTO();
        xdataReqDTO.setAid(personFileId);
        xdataReqDTO.setDbName(personPropertiest.getPersonFileDBName2());
        xdataReqDTO.setSysCode("person-file-manage");
        xdataReqDTO.setCode(System.currentTimeMillis() + "");
        xdataReqDTO.setArchiveType(0);
        JSONObject personFileJson = JSONObject.parseObject(xdataFeignClient.getPersonfileById(xdataReqDTO));
        if (SuccessRespUtil.isSuccess(personFileJson)) {
            //将byte[]转换为base64
            JSONObject personFile = personFileJson.getJSONObject(ICommonConstant.ResultDataFormat.data);
            listFilterDTO.setFeature(personFile.getString("featureInfo"));
            personfileSolrService.findByFeature(listFilterDTO);
        }
    
        List<Map<String, Object>> similars = listFilterDTO.getSimilars();
        List<Map<String, Object>> result = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(similars)) {
            similars.forEach(similar -> {
                ListFilterDTO filterDTO = new ListFilterDTO();
                filterDTO.setPersonFileIds(Collections.singletonList(similar.get("personfileId").toString()));
                BasePageRespDTO basePageRespDTO = subArchiveService.findByFilterParams(filterDTO);
                List<PersonfileVO> page = (List<PersonfileVO>) basePageRespDTO.getData();
                if (!page.isEmpty()) {
                    Map<String, Object> item = new HashMap<>(5);
                    
                    PersonfileVO personfileVO = page.get(0);
                    item.put("personName", personfileVO.getPersonName());
                    item.put("imageUrl", personfileVO.getImageUrl());
                    item.put("imageCount", personfileVO.getImageCount());
                    item.put("personfileId", similar.get("personfileId"));
                    item.put("score", similar.get("score"));
                    
                    result.add(item);
                }
            });
        }
        return result;
    }
}
