package com.intellif.cloud.personfile.manage.aspect;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.task.SubWork;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import com.intellif.cloud.personfile.manage.services.sub.AbstractSubService;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@Aspect
@Component
@Order(2)
public class SubTableAspect {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Pointcut("execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl.*(..)) && " +
            "!execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl.batchInsertPersonfileBasics(..)) &&" +
            "!execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveServiceImpl.batchUpdatePersonfileBasics(..))")
    public void subSnap() {
    }
    
    @Pointcut("execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl.*(..)) && " +
            "!execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl.batchInsert(..))")
    public void subArchive() {
    }
    
    @Pointcut("execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveAvatorServiceImpl.*(..)) &&" +
            "!execution(* com.intellif.cloud.personfile.manage.services.sub.impl.SubArchiveAvatorServiceImpl.batchInsert(..))")
    public void subArchiveAvator() {
    }
    
    @Before("subArchive() || subSnap() || subArchiveAvator()")
    public void beforeHandle(JoinPoint joinPoint) {
        try {
            setTableName(joinPoint.getTarget());
        } catch (Exception e) {
            logger.error("分表参数设置异常：" + e.getMessage());
            e.printStackTrace();
        }
    }
    
    @Around("@annotation(com.intellif.cloud.personfile.manage.annotation.SubSelectOne)")
    public Object subSelectOne(ProceedingJoinPoint pjp) throws Throwable {
        try {
            ThreadLocalUtil.setneedClear(false);
            List<String> tables = AbstractSubService.SLAVE_TABLE_CACHE.get("tables");
            tables.stream().sorted(Comparator.comparing(String::trim).reversed());
            for (String tableName: tables) {
                
                if (!tableName.contains(ThreadLocalUtil.getTableName()) || tableName.contains("t_bigdata_archive_label_record")) {
                    continue;
                }
                ThreadLocalUtil.setSubTableName(tableName);
                Object result = pjp.proceed();
                if (result != null) {
                    return result;
                }
            }
            return null;
        } catch (Throwable throwable) {
            logger.error("分表数据查询异常：" + throwable.getMessage());
            throw throwable;
        } finally {
            ThreadLocalUtil.removeSubTableName();
            ThreadLocalUtil.remove();
            ThreadLocalUtil.removeNeedClearMap();
        }
    }
    
    @Around("@annotation(com.intellif.cloud.personfile.manage.annotation.SubSelectMore)")
    public Object subSelectMore(ProceedingJoinPoint pjp) throws ExecutionException, InterruptedException {
        try {
            List result = Lists.newLinkedList();
            Integer statisSum = 0;
            Long personFileTotal = 0L;
            Page page = new Page();
            ThreadLocalUtil.setneedClear(false);
            
            List<String> tables = ThreadLocalUtil.getSubKnowTableName() != null ? ThreadLocalUtil.getSubKnowTableName() : AbstractSubService.SLAVE_TABLE_CACHE.get("tables");
            Object resultItem = Lists.newArrayList();
            if (CollectionUtils.isEmpty(tables)) {
                return result;
            }
            LinkedList<Future<Object>> futures = new LinkedList<>();
            for (String tableName: tables) {
                if (!tableName.contains(ThreadLocalUtil.getTableName()) || tableName.contains("t_bigdata_archive_label_record")) {
                    continue;
                }
                futures.add(ThreadPoolService.subThreadPool.submit(new SubWork(pjp, tableName,ThreadLocalUtil.getTableName())));
            }
            boolean isAllNull = true;
            for (Future<Object> future : futures) {
                resultItem = future.get();
                if (resultItem != null) {
                    isAllNull = false;
                    if (resultItem instanceof List) {
                        result.addAll((List)resultItem);
                    }
                    if (resultItem instanceof Integer) {
                        statisSum+=(Integer) resultItem;
                    }
                    if (resultItem instanceof Long) {
                        personFileTotal+=(Long) resultItem;
                    }
                    if (resultItem instanceof Page) {
                        page.addAll((Page)resultItem);
                    }
                }
            }
            
            if (resultItem instanceof Integer) {
                return statisSum;
            }
            if (resultItem instanceof Long) {
                return personFileTotal;
            }
            if (resultItem instanceof Page) {
                return page;
            }
            if (isAllNull) {
                return null;
            }
            return result;
        } catch (Exception e) {
            logger.error("分表数据查询异常：" + e.getMessage());
//            e.printStackTrace();
            throw e;
        } finally {
            ThreadLocalUtil.removeSubTableName();
            ThreadLocalUtil.remove();
            ThreadLocalUtil.removeSubKnowTableName();
            ThreadLocalUtil.removeNeedClearMap();
        }
    }
    
    private void setTableName(Object target) throws NoSuchFieldException, IllegalAccessException {
        Field tableNameFiled = target.getClass().getDeclaredField("TABLE_NAME");
        tableNameFiled.setAccessible(true);
        ThreadLocalUtil.setTableName((String) tableNameFiled.get(target));
    }
}
