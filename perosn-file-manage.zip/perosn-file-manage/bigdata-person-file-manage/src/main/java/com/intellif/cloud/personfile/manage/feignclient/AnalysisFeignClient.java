package com.intellif.cloud.personfile.manage.feignclient;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.feignclient.fallback.AnalysisFeignHystrix;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.online.OnlineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.SimilarArchiveDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 数据分析服务
 */
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.137:27001", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.63:27001", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.2:27002", fallback = XdataFeignHystrix.class)
//@FeignClient(name = ICommonConstant.ServiceName.X_DATA_XAPI, url = "192.168.31.204:27002", fallback = XdataFeignHystrix.class)
@FeignClient(name = ICommonConstant.ServiceName.ANALYSIS_SERVICE, url = "${analysis.service.url}", fallback = AnalysisFeignHystrix.class)
public interface AnalysisFeignClient {
    
    /**
     * 新建任务
     *
     * @param offLineTaskDTO
     * @return String
     */
    @PostMapping(value = "/xapi/analysis/offline/v1.0")
    String addTask(@RequestBody OffLineTaskDTO offLineTaskDTO);
    
    /**
     * 删除任务
     *
     * @param offLineTaskDTO
     * @return String
     */
    @PostMapping(value = "/xapi/analysis/offline/v1.0")
    String delTask(@RequestBody OffLineTaskDTO offLineTaskDTO);
    
    /**
     * 获取任务状态
     *
     * @param offLineTaskDTO
     * @return String
     */
    @PostMapping(value = "/xapi/analysis/offline/v1.0")
    String getTaskStatus(@RequestBody OffLineTaskDTO offLineTaskDTO);
    
    /**
     * 获取任务结果
     *
     * @param analysisTaskResultDTO 参数集
     * @return String
     */
    @PostMapping(value = "/xapi/analysis/offline/v1.0")
    String getTaskResult(@RequestBody AnalysisTaskResultDTO analysisTaskResultDTO);
    
    /**
     * 删除任务结果
     *
     * @param analysisTaskResultDTO 参数集
     * @return String
     */
    @DeleteMapping(value = "/xapi/analysis/data/detail")
    String delTaskResult(@RequestBody AnalysisTaskResultDTO analysisTaskResultDTO);
    
    /**
     * 在线任务创建
     *
     * @param onlineTaskDTO 参数集
     * @return String
     */
    @PostMapping(value = "/xapi/online/analysis/v1.0")
    String analysisOnlineTaskCreate(OnlineTaskDTO onlineTaskDTO);
    
    /**
     * 相似档案推荐
     *
     * @return String
     */
    @PostMapping(value = "/xapi/base/archive/recommendation/v1.0")
    String getSimilarArchives(@RequestBody SimilarArchiveDTO similarArchiveDTO);
}
