/*
 * 文 件 名:  QueryEvent.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2014-11-27
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.intellif.cloud.personfile.manage.utils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * 查询事件封装
 * 提供查询条件的自定义，分页查询
 *
 * @param <T>
 * @author wangyi
 * @version [版本号, 2014-11-27]
 */
public class QueryEvent<T> {
    // private final static Log log = LogFactory.getLog(QueryEvent.class);

    /**
     * 要查询的表对象
     */
    private T obj;

    /**
     * 自定义的SQL语句id
     */
    private String statement;

    /**
     * 要传入的参数
     */
    private Map<String, Object> parameter = new HashMap<String, Object>();

    /**
     * 自己定义要拼接的语句
     */
    private String appendSql;

    /**
     * @return 返回 statement
     */
    public String getStatement() {
        return statement;
    }

    /**
     * @param statement 对statement进行赋值
     */
    public void setStatement(String statement) {
        this.statement = statement;
    }

    /**
     * @return 返回 parameter
     */
    public Map<String, Object> getParameter() {
        return parameter;
    }

    /**
     * @param parameter 对parameter进行赋值
     */
    public void setParameter(Map<String, Object> parameter) {
        this.parameter = parameter;
    }

    /**
     * @return 返回 obj
     */
    public T getObj() {
        return obj;
    }

    /**
     * @param obj 对obj进行赋值
     */
    public void setObj(T obj) {
        this.obj = obj;
    }

    /**
     * @return 返回 appendSql
     */
    public String getAppendSql() {
        return appendSql;
    }

    /**
     * @param appendSql 对appendSql进行赋值
     */
    public void setAppendSql(String appendSql) {
        this.appendSql = appendSql;
    }

    /**
     * 把传入的对象转到Map中
     * <功能详细描述>
     *
     * @param obj
     * @see [类、类#方法、类#成员]
     */
    @SuppressWarnings("rawtypes")
    private void converObjectToParameter(Object obj) {
        if (obj == null) {
            return;
        }
        Field[] fields;
        Class supers = obj.getClass().getSuperclass();
        if (null != supers) {
            fields = supers.getDeclaredFields();
            if (fields.length > 0) {
                setMap(fields, obj);
            }
            supers = supers.getSuperclass();
            if (null != supers) {
                fields = supers.getDeclaredFields();
                if (fields.length > 0) {
                    setMap(fields, obj);
                }
            }

        }
        fields = obj.getClass().getDeclaredFields();
        if (fields.length > 0) {
            setMap(fields, obj);
        }
    }

    /**
     * 把对象中的字段转到MAP中
     * <功能详细描述>
     *
     * @param fields
     * @param obj
     * @see [类、类#方法、类#成员]
     */
    private void setMap(Field[] fields, Object obj) {
        for (Field field : fields) {
            try {
                field.setAccessible(true);
                this.parameter.put(field.getName(), field.get(obj));
            } catch (ExceptionInInitializerError e) {
                this.parameter.put(field.getName(), null);
            } catch (NullPointerException e) {
                this.parameter.put(field.getName(), null);
            } catch (IllegalArgumentException e) {
                this.parameter.put(field.getName(), null);
            } catch (IllegalAccessException e) {
                this.parameter.put(field.getName(), null);
            }
        }

    }

    /**
     * 执行前做一次参数转换
     * <功能详细描述>
     *
     * @see [类、类#方法、类#成员]
     */
    public void initParameter() {
        //转换成参数
        converObjectToParameter(obj);
        if (null != this.appendSql && !"".equals(this.appendSql)) {
            this.parameter.put("appendSql", this.appendSql);
        }
    }

    /**
     * 设置要传入的参数到Map中
     * <功能详细描述>
     *
     * @see [类、类#方法、类#成员]
     */
    public void putParameter(String key, Object value) {
        this.parameter.put(key, value);
    }

    /**
     * 删除Map中
     * <功能详细描述>
     *
     * @see [类、类#方法、类#成员]
     */
    public void removeParameter(String key) {
        this.parameter.remove(key);
    }

    /**
     * 得到属性字符串
     * @return String 属性字符串
     */
    //    @Override
    //    public String toString()
    //    {
    //        return JSONObject.fromObject(this).toString();
    //    }
    //    
    //    public static void main(String[] args)
    //    {
    //        B p = new B();
    //        p.setUserId("111");
    //        //        p.setAge("19");
    //        p.setName("tiger");
    //        QueryEvent e = new QueryEvent();
    //        e.setObj(p);
    //        e.initParameter();
    //        Map map = e.getParameter();
    //    }
}
