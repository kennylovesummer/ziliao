package com.intellif.cloud.personfile.manage.aspect;

import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.utils.DBHandoverUtil;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 数据源切面
 *
 * @author liuzj
 * @date 2019-08-26
 */
@Aspect
@Component
@Order(1)
public class DataSourceAspect {
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Before("execution(* com.intellif.cloud.personfile.manage.services.*.*.*(..))")
    public void before(JoinPoint jp) {
        String methodName = jp.getSignature().getName();
        
        if (methodName.contains("getSessionFactory")) {
            return;
        }

        if (personPropertiest.getSlaveDBEnable() && StringUtils.startsWithAny(methodName, "get", "select", "find","query","statis")) {
            DBHandoverUtil.slave();
        } else {
            DBHandoverUtil.master();
        }
    }
    
//    @AfterReturning("execution(* com.intellif.cloud.personfile.manage.services.*.*.*(..))")
//    public void after() {
//        DBHandoverUtil.init();
//    }
    
}

