/*
 * 文件名：ICommonConstants.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：wangyi
 * 创建时间：2018年10月11日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.contants;

/**
 * 公共常量定义
 *
 * @author wangyi
 * @version 1.0
 * @date 2018年10月11日
 * @see ICommonConstant
 * @since JDK1.8
 */

public interface ICommonConstant {

    /**
     * 符号
     */
    interface Symbol {
        
        String AND = "&";
        
        /**
         * 逗号
         */
        String COMMA = ",";
        /**
         * 英文句号
         */
        String POINT = ".";

        /**
         * 冒号
         */
        String COLON = ":";

        /**
         * 链接符号 Connective symbol ~
         */
        String CONNECTIVE_SYMBOL = "~";

        /**
         * 链接符号 strikethrough -
         */
        String STRIKETHROUGH = "-";
        
        String UNDERLINE = "_";

        /**
         * 链接符号 Space ' '
         */
        String SPACE = " ";
        /**
         * 中括号
         */
        String BRACKET = "[]";

    }
    
    interface  Letter {
        String A = "A";
    
        String B = "B";
    }

    interface RequestHeaderInter {
        /**
         * 内容类型key
         */
        String CONTENT_TYPE = "Content-Type";

        /**
         * 内容json类型 包含utf-8
         */
        String CONTENT_TYPE_JSON = "application/json;charset=utf-8";

        /**
         * 内容json类型 包含utf-8
         */
        String CONTENT_TYPE_JSON_NO_UTF = "application/json";

        String HTTP_MOTHED_POST = "POST";
    }

    interface Day {
        int DAY = 1;
        int WEEK_DAY = 7;
    }

    interface BeforeDay {
        int BEFORE_DAY_HORE = -24;
        int BEFORE_DAY = -1;
    }

    interface BeforeWeek {
        int BEFORE_DAY = -7;
    }

    interface BeforeMonth {
        int BEFORE_DAY = -30;
    }

    interface TokenKey {
        String AUTHORIZATION = "Authorization";

        String TOKEN = "token";

        String LOG_ID = "logId";

        String BEARER = "Bearer ";
    }

    interface DateFormatType {
        
        String[] DATE_TIME_FORMAT_ARRAY = {"yyyy-MM-dd HH:mm:ss"};
    
        String[] DATE_FORMAT_ARRAY = {"yyyy-MM-dd"};
        
        /**
         * 全日期类型
         */
        String Y_M_S_ALL = "yyyy-MM-dd HH:mm:ss";

        /**
         * 全日期类型yyyyMMddHHmmss 带十分秒
         */
        String YMSALL = "yyyyMMddHHmmss";

        /**
         * 全日期类型yyyyMMdd
         */
        String YMS = "yyyyMMdd";

        /**
         * 全日期类型 HH为24小时制
         */
        String Y_M_D_H_S = "yyyy-MM-dd HH:mm:ss";

        /**
         * 时 分 秒
         */
        String H_M_S = "HH:mm:ss";

        /**
         * 年 月 日
         */
        String Y_M_D = "yyyy-MM-dd";

        /**
         * 年
         */
        String Y = "yyyy";
    }

    /**
     * 时间字符串
     */
    interface DateStr {
        /**
         * 开始时间
         */
        String START_TIME = " 00:00:00";

        /**
         * 结束时间
         */
        String END_TIME = " 23:59:59";
    }

    /**
     * 调用的服务名
     */
    interface ServiceName {
        /**
         * 基础服务(目前走深目，此服务暂时不用)
         */
        String IFAAS_BASICINFO = "ifaas-basicinfo";
        /**
         * 采集服务(弃用)
         */
        String IFAAS_COLLECTION = "ifaas-collection";
        /**
         * 文件服务(弃用)
         */
        String IFAAS_FILE = "ifaas-file";
        /**
         * 权限服务（未用）
         */
        String IFAAS_AUTHORITY = "ifaas-authority";
        /**
         * 一人一档的人员档案库
         */
        String PERSON_FILE_MANGAGE = "person-file-manage";

        /**
         * 数据平台服务
         */
        String X_DATA_XAPI = "x-data-xapi";
    
        /**
         * 数据平台服务
         */
        String ANALYSIS_SERVICE = "analysis-service";

        /**
         * 一人一档数据统计服务
         */
        String PERSON_FILE_DATASTATISTICS = "person-file-datastatistics";

    }

    /**
     * 返回的格式定义
     */
    interface ResultDataFormat {
        /**
         * 状态码
         */
        String respCode = "respCode";
        /**
         * 消息说明
         */
        String respMessage = "respMessage";
        /**
         * 说明
         */
        String data = "data";
        /**
         * 解释性说明
         */
        String respRemark = "respRemark";
        /**
         * 总数
         */
        String total = "total";
        /**
         * 最大页码
         */
        String maxPage = "maxPage";
        /**
         * 数量
         */
        String size = "size";
    }

    /**
     * 字典表的key
     * sys_dict
     */
    interface DictDataKey {
        /**
         * 事件类型
         */
        String eventType = "event_type";
    
        /**
         * 同行关系
         */
        String relationShipPeer = "PEER";
    }

    /**
     * 网络
     */
    interface Internet {
        String HTTP = "http";
        String WWW = "www";
        String HTTPS = "https";
        /**
         * http 前缀 带斜杠
         */
        String HTTP_SLASH = "http://";
    }

    /**
     * 未知异常
     */
    interface Exception {
        String unknown = "unknown";
    }
    
}
