package com.intellif.cloud.personfile.manage.services.general.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.annotation.SubSelectMore;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import com.intellif.cloud.personfile.manage.services.general.*;
import com.intellif.cloud.personfile.manage.utils.DeepPageUtil;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName PersonfileBaseInfoServiceImpl
 * @Author liuYu
 * @create 2018-10-18 16:19
 * @Version 1.0
 * @desc
 */
@Service
public class PersonfileBaseInfoServiceImpl extends BaseServiceImpl implements PersonfileBaseInfoService {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonfileLabelService personfileLabelService;
    
    @Autowired
    private PersonfileConcernServiceImpl personfileConcernServiceImpl;
    
    @Resource
    private StatisticPersonfileTypeService statisticPersonfileTypeService;
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    @Autowired
    private StatisticPersonfileService statisticPersonfileService;
    
    @Autowired
    private XdataFeignClient xdataFeignClient;
    
    @Autowired
    private PersonfileRubbishService personfileRubbishService;
    
    @Autowired
    private PersonfileSnapService personfileSnapService;
    
    @Autowired
    private PersonfileSolrService personfileSolrService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private IPersonfileConcernService iPersonfileConcernService;
    
    public static final PersonfileBasics PERSONFILE_BASICS = new PersonfileBasics();
    
    @Override
    public PersonfileBasics findBaseInfoByPersonFileId(String personFilesId) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("personFilesId", personFilesId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBaseInfoByPersonFileId");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (PersonfileBasics) object;
    }
    
    @Override
    public List<String> findBaseInfoByLabels(List<Integer> lableIdList) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("lableIdList", lableIdList);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findBaseInfoByLabels");
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }
    
    @Override
    public PersonfileBasicsVO findBaseInfoVOByPersonFileId(String personFilesId) {
        PersonfileBasicsVO personfileBasicsVO = new PersonfileBasicsVO();
        PersonfileBasics personfileBasics = this.findBaseInfoByPersonFileId(personFilesId);
        
        if (personfileBasics != null) {
            BeanUtils.copyProperties(personfileBasics, personfileBasicsVO);
            personfileBasicsVO.setAppearTime(personfileBasics.getRecentSnapTime());
            List<String> personfileIds = Lists.newArrayList();
            personfileIds.add(personFilesId);
            List<PersonfileLabelVO> personfileLabelVOS = personfileLabelService.findPersonfileLabelRecordByPersonfileIds(personfileIds);
            Map<String, List<PersonfileLabelVO>> personfileLabelMap = personfileLabelVOS.stream().collect(Collectors.groupingBy(PersonfileLabelVO::getAid));
            List<PersonfileLabelVO> personfileLabelVOList = personfileLabelMap.get(personFilesId);
            if (CollectionUtils.isNotEmpty(personfileLabelVOList)) {
                personfileBasicsVO.setLabelName(personfileLabelVOList.stream().map(PersonfileLabelVO::getLabelName).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
                personfileBasicsVO.setLabelId(personfileLabelVOList.stream().sorted(Comparator.comparingInt(s -> Integer.parseInt(s.getLabelId()))).map(PersonfileLabelVO::getLabelId).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
            }
            return personfileBasicsVO;
        }
        return personfileBasicsVO;
    }
    
    @Override
    public int insertPersonfileBasicsLabel(String personFileId, Integer labelId) throws BusinessException {
        PersonfileLabel personfileLabel = personfileLabelService.queryPersonfileLabelById(labelId);
        if (personfileLabel != null) {
            PersonfileLabelRecord personfileLabelRecord = new PersonfileLabelRecord();
            personfileLabelRecord.setLabelId(Long.valueOf(labelId));
            personfileLabelRecord.setLabelName(personfileLabel.getLabelName());
            personfileLabelRecord.setAid(personFileId);
            int result = this.baseDao.updateStatement("insertPersonfilelabelRecord", personfileLabelRecord);
            if (result == 1) {
                statisticPersonfileTypeService.updateNumByPersonTypeId(labelId + "", 1);
                return 1;
            }
        }
        return 0;
    }
    
    @Override
    public int deletePersonfileBasicsLabel(String personFileId, Integer labelId) {
        PersonfileBasicsVO personfileBasicsVO = findBaseInfoVOByPersonFileId(personFileId);
        String labeldIds = personfileBasicsVO.getLabelId();
        if (Strings.isNotBlank(labeldIds) && labeldIds.indexOf(labelId + "") != -1) {
            PersonfileLabelRecord personfileLabelRecord = new PersonfileLabelRecord();
            personfileLabelRecord.setLabelId(Long.valueOf(labelId));
            personfileLabelRecord.setAid(personFileId);
            int result = this.baseDao.updateStatement("deletePersonfilelabelRecord", personfileLabelRecord);
            if (result == 1) {
                statisticPersonfileTypeService.updateNumByPersonTypeId(labelId + "", -1);
                return 1;
            }
        }
        return 0;
    }
    
    @Override
    public int updatePersonfileBasics(PersonfileBasics personfileBasics) {
        return this.baseDao.update(personfileBasics);
    }
    
    @Override
    public int deleteByPersonfileIdPersonfileBasics(String personfileId) {
        PersonfileBasics personfileBasics = new PersonfileBasics();
        personfileBasics.setPersonFilesId(personfileId);
        personfileBasics.setIsDeleted(IPersonfilesManageConstant.BaseByte.IS_DELETE);
        return this.baseDao.updateStatement("deleteByPersonfileIdPersonfileBasics", personfileBasics);
    }
    
    @Override
    public int batchInsertPersonfileBasics(List<PersonfileBasics> personfileBasics) {
        return this.baseDao.batchInsert(PERSONFILE_BASICS, null, personfileBasics);
    }
    
    @Override
    public int batchUpdatePersonfileBasics(List<PersonfileBasics> personfileBasics) {
        Map<String, Object> params = Maps.newHashMap();
        params.put("personFileList", personfileBasics);
        params.put("tableName", "t_bigdata_archive");
        return this.baseDao.batchUpdate(PERSONFILE_BASICS, params);
    }
    
    @Override
    public int batchUpdatePersonfileStatistic(List<PersonfileBasics> personfileBasics) {
        return this.baseDao.batchUpdate("updatePersonfileStatistic", personfileBasics);
    }
    
    /**
     * 档案合并/删除成功之后处理
     *
     * @param personFileId          被合并的档案ID
     * @param initiativPersonFileId 合并的档案ID
     * @throws BusinessException 异常
     */
    @Override
    public void personfileHandle(String personFileId, String initiativPersonFileId) throws BusinessException {
        if (Strings.isBlank(personFileId)) {
            throw new BusinessException(IResultCode.ERROR, "参数异常");
        }
        
        PersonfileBasics personfileBasics = findBaseInfoByPersonFileId(personFileId);
        
        if (personfileBasics == null) {
            throw new BusinessException(IResultCode.ERROR, "档案不存在");
        }
        
        boolean isReal = Strings.isNotBlank(personfileBasics.getCid());
        
        // 删除关注
        personfileConcernServiceImpl.deleteByIdPersonfileConcern(personFileId);
        logger.info("删除关注成功！");
        
        // 删除基本信息
        int existFlag = deleteByPersonfileIdPersonfileBasics(personFileId);
        if (existFlag == 0) {
            throw new BusinessException(IResultCode.ERROR, "档案不存在");
        }
        logger.info("删除基本信息成功！");
        
        // 合并档案
        if (StringUtils.isNotEmpty(initiativPersonFileId)) {
            // 更新档案
            PersonfileBasics initiativPersonFile = findBaseInfoByPersonFileId(initiativPersonFileId);
            if (initiativPersonFile == null) {
                throw new BusinessException(IResultCode.ERROR, "档案不存在");
            }
            
            if (isReal && Strings.isBlank(initiativPersonFile.getCid())) {
                isReal = false;
            }
            
            if (Strings.isBlank(initiativPersonFile.getCid())) {
                initiativPersonFile.setCid(personfileBasics.getCid());
                initiativPersonFile.setSex(personfileBasics.getSex());
                initiativPersonFile.setAge(personfileBasics.getAge());
                initiativPersonFile.setBirthDate(personfileBasics.getBirthDate());
                initiativPersonFile.setName(personfileBasics.getName());
            }
            
            updatePersonfileBasics(initiativPersonFile);
            
            logger.info("合并档案成功！");
            // 数据平台处理: 调用数据平台接口(档案id列表，第一个为主合入档案id，第二个为被合入档案id（被删除），目前限制列表长度为2)
            List<String> aids = new LinkedList<>();
            aids.add(initiativPersonFileId);
            aids.add(personFileId);
            Long startTime = System.currentTimeMillis();
            xdataFeignClient.merge(new XdataReqDTO(aids, personPropertiest.getPersonfileRelationshipAddDBName()));
            logger.info("数据平台合并成功！耗时：" + (System.currentTimeMillis() - startTime));
            // 删除档案
        } else {
            // 数据平台处理
            Long startTime = System.currentTimeMillis();
            xdataFeignClient.delete(new XdataReqDTO(personFileId, personPropertiest.getPersonfileRelationshipAddDBName()));
            logger.info("数据删除成功！耗时：" + (System.currentTimeMillis() - startTime));
        }
        
        // 删除档案和合并档案都将抓拍放入回收站
        PersonfileSnap personfileSnap = new PersonfileSnap();
        personfileSnap.setPersonFilesId(personFileId);
        List<PersonfileRubbish> personfileRubbishes = personfileSnapService.getByPersonfileId(null, personFileId,null,null);
        if (CollectionUtils.isNotEmpty(personfileRubbishes)) {
            personfileRubbishService.insertBatchPersonfileRubbish(personfileRubbishes);
        }
        personfileSnapService.deletePersonfileSnap(personfileSnap);
        logger.info("抓拍放入回收站成功！");
        try {
            // 从solr中删除档案
            personfileSolrService.deleteByPersonfileId(personFileId);
            logger.info("从solr中删除档案成功！");
            
            // 更新人员类型统计
            if (personfileBasics.getLabelId() != null) {
                statisticPersonfileTypeService.updateNumByPersonTypeId(personfileBasics.getLabelId() + "", -1);
            }
            
            // 更新事件统计
            if (CollectionUtils.isNotEmpty(personfileRubbishes)) {
                Map<String, List<PersonfileRubbish>> personRubishs = personfileRubbishes.stream().collect(Collectors.groupingBy(personfileRubbish -> DateFormatUtils.format(personfileRubbish.getCreateTime(), ICommonConstant.DateFormatType.Y_M_D)));
                personRubishs.entrySet().forEach(e -> statisticPersonfileEventService.updateStatisticEvent(-e.getValue().size(), e.getKey()));
            }
            
            // 更新档案统计
            statisticPersonfileService.updateStatistic(-1, isReal ? -1 : 0);
            
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("统计数据更新异常：" + e);
        }
        
    }
    
    @Override
    @SubSelectMore
    public List<PersonfileBasics> findAutoByParam(Map<String, Object> params) {
        QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
        queryEvent.setParameter(params);
        queryEvent.setStatement("findAutoByParam");
        return (List<PersonfileBasics>) this.baseDao.findAllIsPageByCustom(queryEvent);
    }
    
    @Override
    @SubSelectMore
    public Integer statisticNewPersonfile(String clusterStartTime, String clusterEndTime, Boolean isRealName) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(2);
        parameters.put("clusterStartTime", clusterStartTime);
        parameters.put("clusterEndTime", clusterEndTime);
        parameters.put("isRealName", isRealName);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("statisticNewPersonfile");
        return (Integer) this.baseDao.findOneByCustom(queryEvent);
    }
    
    @Override
    @SubSelectMore
    public List<Map<String, Object>> findByPersonfileIds(List<String> personFileIds) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("personFileIds", personFileIds);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findByPersonfileIds");
        return (List<Map<String, Object>>) this.baseDao.findAllIsPageByCustom(queryEvent);
    }
    
    @Override
    public BasePageRespDTO findByFilterParams(ListFilterDTO listFilterDTO) {
        // 标签参数特殊处理-----start--------------------------------
        if (CollectionUtils.isNotEmpty(listFilterDTO.getLabelIds())) {
            List<PersonfileLabelVO> personfileLabelTemp = personfileLabelService.findLabelRecordByLabelId(listFilterDTO.getLabelIds());
            List<String> personfileIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(personfileLabelTemp)) {
                personfileIds = personfileLabelTemp.stream().map(PersonfileLabelVO::getAid).collect(Collectors.toList());
            }
            if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds()) && CollectionUtils.isNotEmpty(personfileIds)) {
                listFilterDTO.getPersonFileIds().addAll(personfileIds);
            } else if (CollectionUtils.isNotEmpty(personfileIds)) {
                listFilterDTO.setPersonFileIds(personfileIds);
            } else {
                personfileIds.add("archive");
                listFilterDTO.setPersonFileIds(personfileIds);
            }
        }
        // 标签参数特殊处理-----end--------------------------------
        
        // 我的关注-----start--------------------------------
        List<PersonfileConcern> personfileConcernList = iPersonfileConcernService.findByConcerner(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        if (listFilterDTO.getPersonFileType() == 3) {
            List<String> exitIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(personfileConcernList)) {
                List<String> personfileIds = personfileConcernList.stream().map(PersonfileConcern::getPersonFilesId).collect(Collectors.toList());
                if (CollectionUtils.isEmpty(listFilterDTO.getPersonFileIds())) {
                    listFilterDTO.setPersonFileIds(personfileIds);
                } else {
                    for (String id : listFilterDTO.getPersonFileIds()) {
                        if (personfileIds.contains(id)) {
                            exitIds.add(id);
                        }
                    }
                    if (CollectionUtils.isEmpty(exitIds)) {
                        exitIds.add("archive");
                    }
                    listFilterDTO.setPersonFileIds(exitIds);
                }
            } else {
                exitIds.add("archive");
                listFilterDTO.setPersonFileIds(exitIds);
            }
        }
        // 我的关注-----end--------------------------------
        
        List<PersonfileVO> personfileVOS = findByParams(listFilterDTO);
        
        // 标签返回特殊处理-----start------------------------------
        if (CollectionUtils.isNotEmpty(personfileVOS)) {
            List<String> personfileIds = personfileVOS.stream().map(PersonfileVO::getPersonFileId).collect(Collectors.toList());
            List<PersonfileLabelVO> personfileLabelVOS = personfileLabelService.findPersonfileLabelRecordByPersonfileIds(personfileIds);
            Map<String, List<PersonfileLabelVO>> personfileLabelMap = personfileLabelVOS.stream().collect(Collectors.groupingBy(PersonfileLabelVO::getAid));
            for (PersonfileVO personfileVO : personfileVOS) {
                List<PersonfileLabelVO> personfileLabelVOList = personfileLabelMap.get(personfileVO.getPersonFileId());
                if (CollectionUtils.isNotEmpty(personfileLabelVOList)) {
                    personfileVO.setLabelNames(personfileLabelVOList.stream().sorted(Comparator.comparingInt(s -> Integer.parseInt(s.getLabelId()))).map(PersonfileLabelVO::getLabelName).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
                }
            }
            personfileVOS = personfileVOS.stream().distinct().collect(Collectors.toList());
        } else {
            personfileVOS = Lists.newArrayList();
        }
        // 标签返回特殊处理-----end------------------------------
        
        // 注入关注
        if (CollectionUtils.isNotEmpty(personfileConcernList)) {
            personfileVOS.forEach(personfileVO -> {
                if (personfileConcernList.stream().anyMatch(personfileConcern -> personfileConcern.getPersonFilesId().equalsIgnoreCase(personfileVO.getPersonFileId()))) {
                    personfileVO.setFocused(1);
                }
            });
        }
        
        // 注入相似度----------start----------------------------
        if (CollectionUtils.isNotEmpty(listFilterDTO.getSimilars())) {
            personfileVOS.forEach(personfileVO -> {
                List<Map<String, Object>> similarTemps = listFilterDTO.getSimilars().stream().filter(v -> v.get("personfileId").equals(personfileVO.getPersonFileId())).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(similarTemps)) {
                    personfileVO.setSimilar((Float) similarTemps.get(0).get("score"));
                }
            });
            personfileVOS = personfileVOS.stream().sorted(Comparator.comparingDouble(PersonfileVO::getSimilar).reversed()).collect(Collectors.toList());
        }
        // 注入相似度----------end----------------------------
        
        // 获取最近抓拍时间和抓拍数量
//        for (PersonfileVO personfileVO: personfileVOS) {
//            PersonfileBasics personfileBasics = findSnapTimeAndImageCountByPersonfileId(personfileVO.getPersonFileId());
//            personfileVO.setImageCount(personfileBasics.getImageCount());
//            personfileVO.setAppearTime(personfileBasics.getRecentSnapTime());
//        }
        
        // 结果返回
        return new BasePageRespDTO(personfileVOS,
                DeepPageUtil.getMaxPage(listFilterDTO.getPerpage(), listFilterDTO.getTotal()),
                listFilterDTO.getTotal(), IResultCode.SUCCESS);
        
    }
    
    @Override
//    @SubSelectMore
    public List<PersonfileVO> findByParams(ListFilterDTO listFilterDTO) {
        // 档案数据查询--------start------------------------------
        QueryEvent<ListFilterDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(listFilterDTO);
        queryEvent.setStatement("findByFilterParams");
        Page<PersonfileVO> page = PageHelper.startPage(1, listFilterDTO.getPerpage(), false);
        this.baseDao.findAllIsPageByCustom(queryEvent);
        PageInfo<PersonfileVO> pageInfo = new PageInfo<>(page);
        // 档案数据查询--------end------------------------------
        listFilterDTO.setTotal((int) pageInfo.getTotal());
        return pageInfo.getList();
    }
    
    @Override
    @SubSelectMore
    public Long findPersonfilePageTotal(ListFilterDTO listFilterDTO) {
        QueryEvent<ListFilterDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(listFilterDTO);
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("page", listFilterDTO.getPage());
        parameters.put("perpage", listFilterDTO.getPerpage());
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findPersonfilePageTotal");
        Object num = this.baseDao.findOneByCustom(queryEvent);
        return num != null ? (Long) num : 0;
    }
    
    @Override
    @SubSelectMore
    public List<PersonfileClusterFinishDTO> findByPage(int pageNo, int perpage) {
        QueryEvent<PersonfileClusterFinishDTO> queryEvent = new QueryEvent<>();
        queryEvent.setStatement("findByPage");
        
        Page<PersonfileClusterFinishDTO> page = PageHelper.startPage(pageNo, perpage, false);
        this.baseDao.findAllIsPageByCustom(queryEvent);
        PageInfo<PersonfileClusterFinishDTO> pageInfo = new PageInfo<>(page);
        
        return pageInfo.getList();
    }
    
    @Override
    @SubSelectMore
    public List<String> findDeletedPersonfilesId(List<String> personfilesIdList) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("personfilesIdList", personfilesIdList);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findDeletedPersonfilesId");
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }
    
    @Override
    public int updateImageCount(int addImageCount, String personfileId) {
        Map map = new HashMap(2);
        map.put("addImageCount", addImageCount);
        map.put("personfileId", personfileId);
        try {
            return this.baseDao.updateStatement("updateImageCount", map);
            
        } catch (Exception e) {
            logger.error("更新档案imageCount异常:" + e.getMessage());
            return 0;
        }
    }
    
    @Override
    @SubSelectMore
    public Integer statisticAge(Integer startAge, Integer endAge, Boolean isEqual) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        queryEvent.setStatement("statisticAge");
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("startAge", startAge);
        parameters.put("endAge", endAge);
        parameters.put("isEqual", isEqual);
        queryEvent.setParameter(parameters);
        Object obj = this.baseDao.findOneByCustom(queryEvent);
        return obj != null ? (Integer) obj : 0;
    }
    
    @Override
    public List<PersonfileBasics> findAidAndPersonFileCreateTime(Integer page, Integer perpage, String table) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        queryEvent.setStatement("findAidAndPersonFileCreateTime");
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("page", page);
        parameters.put("perpage", perpage);
        parameters.put("table", table);
        queryEvent.setParameter(parameters);
        Object obj = this.baseDao.findAllIsPageByCustom(queryEvent);
        return obj != null ? (List<PersonfileBasics>) obj : Lists.newArrayList();
    }
    
}
