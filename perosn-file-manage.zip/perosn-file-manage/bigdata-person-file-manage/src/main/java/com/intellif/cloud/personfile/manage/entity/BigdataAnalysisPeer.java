package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 数据分析同行结果
 *
 * @author liuzj
 * @date 2019-07-18
 */
@Data
public class BigdataAnalysisPeer implements Serializable {
    private static final long serialVersionUID = -3124544320240305318L;
    private Long id;

    private Long taskId;

    private String aid;

    private String cameraId;

    private String cameraName;

    private String geoString;

    private Date date;

    private String faceId;

    private String faceUrl;

    private Long imageCount;

    private Double score;
    
    private Long timeSpan;

    private Long time;
    
    private List<BigdataAnalysisEvent> faces;

    private Long startTime;

    private Long endTime;

    private Date createTime;

    private String createBy;

    private Date modifyTime;

    private String modifyBy;

}