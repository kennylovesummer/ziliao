package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @see BigdataAnalysisEventService
 * @author liuzj
 */
@Service
public class BigdataAnalysisEventServiceImpl extends BaseServiceImpl implements BigdataAnalysisEventService {
    
    private static final BigdataAnalysisEvent BIGDATA_ANALYSIS_EVENT = new BigdataAnalysisEvent();
    
    
    @Override
    public BigdataAnalysisEvent findAnalysisEventById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryEvent.setParameter(parameters);
            queryEvent.setStatement("findAnalysisEventById");
            Object object = this.baseDao.findOneByCustom(queryEvent);
            return object == null ? null : (BigdataAnalysisEvent) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent) {
        if (bigdataAnalysisEvent != null && bigdataAnalysisEvent.getId() != null) {
            this.baseDao.delete(bigdataAnalysisEvent);
        }
    }
    
    @Override
    public Long insertAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent) {
        if (bigdataAnalysisEvent != null) {
            bigdataAnalysisEvent.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisEvent.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisEvent);
        return bigdataAnalysisEvent.getId();
    }
    
    @Override
    public void batchInsertAnalysisEvent(List<BigdataAnalysisEvent> eventList) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_EVENT,null,eventList);
    }
    
    @Override
    public void updateAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent) {
        this.baseDao.update(bigdataAnalysisEvent);
    }
    
    @Override
    public Page<BigdataAnalysisEvent> findAnalysisEventByParams(AnalysisDTO eventDTO) {
        QueryEvent<AnalysisDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(eventDTO);
        queryEvent.setStatement("findAnalysisEventByParams");
    
        Page<BigdataAnalysisEvent> page = PageHelper.startPage(eventDTO.getPage(), eventDTO.getPerpage());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public Map<String, Long> findMaxTimeAndMinTimeByParams(AnalysisDTO eventDTO) {
        QueryEvent<AnalysisDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(eventDTO);
        queryEvent.setStatement("findMaxTimeAndMinTimeByParams");
        return (Map<String, Long>)this.baseDao.findOneByCustom(queryEvent);
    }
    
    @Override
    public void deleteBigdataAnalysisEventByTaskId(Long taskId) {
        if (taskId == null) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        this.baseDao.updateStatement("deleteBigdataAnalysisEventByTaskId",parameters);
    }
    
    @Override
    public Long findCountByParams(EventDTO eventDTO) {
        QueryEvent<EventDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(eventDTO);
        queryEvent.setStatement("findCountByParams");
        Object num = this.baseDao.findOneByCustom(queryEvent);
        return num != null ? (Long)num : 0L;
    }
    
    @Override
    public Map<String, Long> findMaxMinDateByPage(AnalysisDTO eventDTO) {
        QueryEvent<AnalysisDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(eventDTO);
        queryEvent.setStatement("findMaxMinDateByPage");
        Object result = this.baseDao.findOneByCustom(queryEvent);
        return result != null ? (Map<String, Long>)result : null;
    }
    
}
