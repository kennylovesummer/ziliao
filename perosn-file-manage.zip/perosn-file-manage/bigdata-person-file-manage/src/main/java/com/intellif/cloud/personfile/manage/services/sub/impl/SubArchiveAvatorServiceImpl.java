package com.intellif.cloud.personfile.manage.services.sub.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileHeadPicture;
import com.intellif.cloud.personfile.manage.services.general.PersonfileHeadPictureService;
import com.intellif.cloud.personfile.manage.services.sub.AbstractSubService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveAvatorService;
import com.intellif.cloud.personfile.manage.services.sub.SubService;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @see SubService
 */
@Service
public class SubArchiveAvatorServiceImpl extends AbstractSubService<PersonfileHeadPicture> implements SubArchiveAvatorService {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    private static final String TABLE_NAME = "t_bigdata_avatar_info";
    
    private static final String CREATE_TABLE_NAME_SQL = "CREATE TABLE `t_bigdata_avatar_info` (\n" +
            "  `aid` varchar(255) NOT NULL COMMENT '档案ID',\n" +
            "  `feature_info` blob COMMENT '特征值',\n" +
            "  `big_image_url` varchar(255) DEFAULT NULL COMMENT '大图地址',\n" +
            "  `small_image_url` varchar(255) DEFAULT '0' COMMENT '小图地址',\n" +
            "  `target_rect` varchar(255) DEFAULT NULL COMMENT '人脸框',\n" +
            "  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n" +
            "  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',\n" +
            "  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n" +
            "  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',\n" +
            "  UNIQUE KEY `aid` (`aid`) USING BTREE COMMENT '人员档案id唯一索引'\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;";
    
    
    @Autowired
    private PersonfileHeadPictureService personfileHeadPictureService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    private static final PersonfileHeadPicture PERSON_FILE_HEAD = new PersonfileHeadPicture();
    
    @Override
    public int batchInsert(List<PersonfileHeadPicture> personfileHeadPictureList){
        return this.baseDao.batchInsert(PERSON_FILE_HEAD,null, personfileHeadPictureList);
    }
    
    @Override
    public void archiveImageSync(List<PersonfileHeadPicture> personfileHeadPictureList){
        Map<String,List<PersonfileHeadPicture>> groupByCreateDate = personfileHeadPictureList.stream().collect(Collectors.groupingBy(PersonfileHeadPicture::getTableName));
        List<Map<String,Object>> params = Lists.newArrayList();
        for (String key: groupByCreateDate.keySet()) {
            Map<String,Object> param = Maps.newHashMap();
            param.put("personfileHeadPictures",groupByCreateDate.get(key));
            param.put("tableName",key);
            params.add(param);
        }
//        this.baseDao.updateStatement("batchInsertPersonfileHeadPicture", params);
        this.baseDao.batchInsert("batchInsertPersonfileHeadPicture", params);
    }
    
    @Override
    public PersonfileHeadPicture findByPersonfileId(String personfilesId){
        ThreadLocalUtil.setSubTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfilesId,personPropertiest.getArchiveTableMaxTables()));
        return personfileHeadPictureService.findByPersonfileId(personfilesId);
    }
    
    /**
     * 初始化分表
     *
     * @param num 表数量
     */
    public void initSubTable(Integer num){
        for (int i = 0; i < num; i++) {
            String tableName = TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + i;
            if (!isExist(tableName,false)) {
                createTable(CREATE_TABLE_NAME_SQL.replaceAll(TABLE_NAME,tableName));
            }
        }
    }
}
