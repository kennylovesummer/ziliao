package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 数据分析碰撞结果
 *
 * @author liuzj
 * @date 2019-07-18
 */
@Data
public class BigdataAnalysisCrash implements Serializable {
    
    private static final long serialVersionUID = -4746024772756235279L;
    
    private Long id;
    
    private Long taskId;
    
    private String aid;

    private String cameraId;

    private String cameraName;

    private Long endTime;

    private Long startTime;
    
    private Long date;

    private Integer imageCount;

    private String geoString;

    private String areaCode;
    
    private List<BigdataAnalysisEvent> faces;

    private Date createTime;

    private String createBy;

    private Date modifyTime;

    private String modifyBy;
}