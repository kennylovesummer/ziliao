package com.intellif.cloud.personfile.manage.enums;

/**
 * 引擎选择的枚举
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月16日
 * @see ProjectTypeEnum
 * @since JDK1.8
 */
public enum ProjectTypeEnum {

    SM("deepEye", "深目"),

    IFAAS("ifaas", "ifaas3.0");

    ProjectTypeEnum(String value, String name) {
        this.value = value;
        this.name = name;
    }

    private String value;
    private String name;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
