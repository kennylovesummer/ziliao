package com.intellif.cloud.personfile.manage.task.monitor;

import com.intellif.log.LoggerUtilI;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 任务监控抽象层
 *
 * @author liuzj
 * @date 2019-07-23
 */
public abstract class AbstractTaskMonitor implements TaskMonitor{
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    protected Long initialDelay = 0L;
    
    protected Long period = 10L;
    
    protected Long timeOutMillis = 3 * 60 * 1000L;
    
    protected static final ConcurrentMap<String, Long> aliveThreadRefreshTimeMap = new ConcurrentHashMap<>();
    
    protected static final ConcurrentMap<String, Future<?>> aliveThreadFutureMap = new ConcurrentHashMap<>();
    
    private AtomicBoolean isRunning = new AtomicBoolean(false);
    
    private static final ScheduledExecutorService monitorExecutor = Executors.newScheduledThreadPool(1);
    
    public AbstractTaskMonitor(Long initialDelay, Long period,Long timeOutMillis) {
        this.initialDelay = initialDelay;
        this.period = period;
        this.timeOutMillis = timeOutMillis;
    }
    
    public AbstractTaskMonitor() {
    }
    
    @Override
    public Boolean start() {
        if (!isRunning()) {
            logger.info("Task monitor thread start...");
            Runnable monitorWorker = () -> {
                Thread.currentThread().setName("监控线程");
                try {
                    doMonitor();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            
            };
            monitorExecutor.scheduleAtFixedRate(monitorWorker, initialDelay, period, TimeUnit.SECONDS);
            isRunning.set(true);
            logger.info("Task monitor thread start success!");
        }
        return true;
    }
    
    @Override
    public Boolean isRunning() {
        return isRunning.get();
    }
    
    @Override
    public Boolean stop() {
        try {
            monitorExecutor.shutdown();
            
            isRunning.set(false);
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
 
}
