package com.intellif.cloud.personfile.manage.services.datastistic;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileEvent;

import java.util.List;

/**
 * 抓拍日統接口
 *
 * @author liuzj
 * @version 1.0
 * @date 2019年05月24日
 * @see StatisticPersonfileEventService
 * @since JDK1.8
 */
public interface StatisticPersonfileEventService {
    
    /**
     * 新增
     *
     * @param statisticPersonfileEvent 实体
     * @return int
     */
    int insertStatisticPersonfileEvent(StatisticPersonfileEvent statisticPersonfileEvent);
    
    /**
     * 根据时间获取事件的统计数据
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return List
     */
    List<StatisticPersonfileEvent> findStatisticEventDailyByDate(String startTime, String endTime);
    
    /**
     * 获取抓拍统计结果
     *
     * @return Integer
     */
    Integer statisticEvent();
    
    /**
     * 更新统计
     *
     * @param incNum 新增数
     * @param dt     时间
     */
    void updateStatisticEvent(Integer incNum, String dt);
}
