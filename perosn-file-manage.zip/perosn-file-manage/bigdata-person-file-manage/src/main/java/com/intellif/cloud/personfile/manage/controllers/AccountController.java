package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAccount;
import com.intellif.cloud.personfile.manage.model.dto.account.AccountDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.account.BigdataAccountService;
import com.intellif.cloud.personfile.manage.utils.IpUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 登录接口
 *
 * @author liuzj
 * @date 2019-08-28
 */
@Api(tags = "用户管理-用户")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.ACCOUNT)
public class AccountController {
    
    private final LoggerUtilI LOG = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private BigdataAccountService bigdataAccountService;
    
    /**
     * 新增
     *
     * @param accountDTO 新增信息集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "新增用户")
    @PostMapping("save")
    public BaseDataRespDTO save(@RequestBody AccountDTO accountDTO) {
        try {
            if (Strings.isBlank(accountDTO.getAccount()) || Strings.isBlank(accountDTO.getName()) || Strings.isBlank(accountDTO.getPassword())) {
                return new BaseDataRespDTO(IResultCode.ERROR,"信息不完整!","【账号|密码|用户名】须填写完整!");
            }
            
            BigdataAccount bigdataAccount = new BigdataAccount();
            BeanUtils.copyProperties(accountDTO,bigdataAccount);
            bigdataAccountService.insertBigdataAccount(bigdataAccount);
            return new BaseDataRespDTO(IResultCode.SUCCESS,"新增成功!");
        } catch (Exception e){
            LOG.error("账号新增异常：" + e.getMessage());
            if (e.getMessage().contains("Duplicate entry")) {
                return new BaseDataRespDTO(IResultCode.ERROR,"账号已存在!");
            }
            return new BaseDataRespDTO(IResultCode.ERROR,"账号新增异常!",e.getMessage());
        }
    }
    
    /**
     * 删除
     *
     * @param id ID
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "DELETE", value = "删除用户")
    @DeleteMapping("del/{id}")
    public BaseDataRespDTO del(@PathVariable(name = "id") Long id) {
        try {
            if (id == null) {
                return new BaseDataRespDTO(IResultCode.ERROR,"账号删除失败!","参数缺失");
            }
            bigdataAccountService.deleteBigdataAccountById(id);
            return new BaseDataRespDTO(IResultCode.SUCCESS,"账号删除成功!");
        } catch (Exception e) {
            LOG.error("账号删除异常：" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR,"账号删除异常!",e.getMessage());
        }
        
    }
    
    /**
     * 更新
     *
     * @param accountDTO 更新信息集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "更新用户")
    @PostMapping("update")
    public BaseDataRespDTO update(@RequestBody AccountDTO accountDTO) {
        try {
            if (accountDTO.getId() == null) {
                return new BaseDataRespDTO(IResultCode.ERROR,"更新失败!","唯一ID缺失!");
            }
        
            BigdataAccount bigdataAccount = new BigdataAccount();
            BeanUtils.copyProperties(accountDTO,bigdataAccount);
            bigdataAccountService.updateBigdataAccount(bigdataAccount);
            return new BaseDataRespDTO(IResultCode.SUCCESS,"账号更新成功!");
        } catch (Exception e){
            LOG.error("账号更新异常：" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR,"账号更新异常!",e.getMessage());
        }
    }
    
    /**
     * 分页查询
     *
     * @param accountDTO 参数集
     * @return BasePageRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "分页查询用户信息")
    @PostMapping("list")
    public BasePageRespDTO list(@RequestBody AccountDTO accountDTO) {
        try {
            Page<BigdataAccount> page = bigdataAccountService.findBigdataAccountByPage(accountDTO);
            return new BasePageRespDTO(page.getResult(),page.getPages(),Integer.parseInt(page.getTotal() + ""), IResultCode.SUCCESS, "查询成功!");
        } catch (Exception e) {
            LOG.error("账号分页查询异常：" + e.getMessage());
            return new BasePageRespDTO(IResultCode.ERROR,"账号分页查询异常!",e.getMessage());
        }
    }
    
    /**
     * 根据账号查询用户信息
     *
     * @param params params 账号
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "根据账号获取用户")
    @PostMapping("findByAccount")
    public BaseDataRespDTO findById(@RequestBody JSONObject params, HttpServletRequest httpRequest) {
        try {
            
            if (!params.containsKey("account")) {
                return new BaseDataRespDTO(IResultCode.ERROR,"账户查询失败!","参数缺失!");
            }
            
            String account = params.getString("account");
            
            AccountDTO accountDTO = new AccountDTO();
            accountDTO.setAccount(account);
            BigdataAccount bigdataAccount = bigdataAccountService.findBigdataAccountByAccountAndPassword(accountDTO);
            if (bigdataAccount == null) {
                return new BaseDataRespDTO(null,IResultCode.ERROR,"账号不存在!");
            }
            
            String ip = IpUtil.getIpAddress(httpRequest);
            if (Strings.isNotBlank(ip) && Strings.isNotBlank(bigdataAccount.getIp())) {
                Map<String,Object> result = Maps.newHashMap();
                result.put("account",bigdataAccount.getAccount());
                result.put("name",bigdataAccount.getName());
                result.put("isOut",!ip.equals(bigdataAccount.getIp()));
                return new BaseDataRespDTO(result,IResultCode.SUCCESS,ip.equals(bigdataAccount.getIp()) ? "查询成功!" : "此账号已在异地登录！被迫下线");
            }
            
            return new BaseDataRespDTO(null,IResultCode.ERROR,"查询异常!");
        } catch (Exception e) {
            LOG.error("账号查询异常：" + e.getMessage());
            return new BaseDataRespDTO(IResultCode.ERROR,"账号查询异常!",e.getMessage());
        }
    }
}
