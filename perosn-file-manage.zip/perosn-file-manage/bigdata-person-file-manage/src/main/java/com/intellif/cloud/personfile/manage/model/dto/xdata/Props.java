package com.intellif.cloud.personfile.manage.model.dto.xdata;

import java.io.Serializable;
import java.util.List;

/**
 * @author liuyu
 * @className Props
 * @date 2019/4/19 11:40
 * @description
 */
public class Props implements Serializable {

    private static final long serialVersionUID = -3009435214905743310L;

    private Integer peerNum;

    private String avatarUrl;
    
    private String startTime;
    
    private String endTime;
    
    /**
     * 过滤出现多少次；大于0
     */
    private Integer filterTimes;
    
    /**
     * 多长间隔算一次记录
     */
    private Integer interval;
    
    private List<String> sourceIds;
    
    /**
     * 包含黑夜时间段
     */
    private String includePeriods;
    
    /**
     * 排除白天时间段
     */
    private String excludePeriods;
 
    private List<String> periods;
    
    
    public void setPeriods(List<String> periods) {
        this.periods = periods;
    }
    
    public String getIncludePeriods() {
        return includePeriods;
    }
    
    public void setIncludePeriods(String includePeriods) {
        this.includePeriods = includePeriods;
    }
    
    public String getExcludePeriods() {
        return excludePeriods;
    }
    
    public void setExcludePeriods(String excludePeriods) {
        this.excludePeriods = excludePeriods;
    }
    
    public List<String> getPeriods() {
        return periods;
    }
    
    public String getStartTime() {
        return startTime;
    }
    
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    
    public String getEndTime() {
        return endTime;
    }
    
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    
    public Integer getFilterTimes() {
        return filterTimes;
    }
    
    public void setFilterTimes(Integer filterTimes) {
        this.filterTimes = filterTimes;
    }
    
    public Integer getInterval() {
        return interval;
    }
    
    public void setInterval(Integer interval) {
        this.interval = interval;
    }
    
    public List<String> getSourceIds() {
        return sourceIds;
    }
    
    public void setSourceIds(List<String> sourceIds) {
        this.sourceIds = sourceIds;
    }
    
    public Integer getPeerNum() {
        return peerNum;
    }

    public void setPeerNum(Integer peerNum) {
        this.peerNum = peerNum;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
}