package com.intellif.cloud.personfile.manage.services.sub.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataReqDTO;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileTypeService;
import com.intellif.cloud.personfile.manage.services.datastistic.impl.ThreadPoolService;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileConcernService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileBaseInfoService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileLabelService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.services.general.impl.PersonfileBaseInfoServiceImpl;
import com.intellif.cloud.personfile.manage.services.general.impl.PersonfileConcernServiceImpl;
import com.intellif.cloud.personfile.manage.services.sub.AbstractSubService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.services.sub.SubService;
import com.intellif.cloud.personfile.manage.task.ArchiveImageCountAndSnapTimeUpdateWork;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @see SubService
 */
@Service
public class SubArchiveServiceImpl extends AbstractSubService<PersonfileBasics> implements SubArchiveService {
    
    private static final String TABLE_NAME = "t_bigdata_archive";
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    public static final String CREATE_TABLE_SQL = "CREATE TABLE `t_bigdata_archive` (\n" +
            "  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',\n" +
            "  `name` varchar(255) DEFAULT NULL COMMENT '姓名',\n" +
            "  `cid` varchar(255) DEFAULT NULL COMMENT '身份证',\n" +
            "  `residence_addr` varchar(64) NOT NULL DEFAULT '-' COMMENT '档案户籍所在地',\n" +
            "  `phone_number` varchar(32) NOT NULL DEFAULT '' COMMENT '手机号码',\n" +
            "  `curr_addr` varchar(255) NOT NULL DEFAULT '-' COMMENT '居住地',\n" +
            "  `gender` int(3) NOT NULL DEFAULT '0' COMMENT '性别(1-男， 2-女, 0-未知)',\n" +
            "  `age` int(4) NOT NULL DEFAULT '0' COMMENT '年龄: 0 未知 （备注：只是作为一种参考值）',\n" +
            "  `phone_mac` varchar(64) NOT NULL DEFAULT '-' COMMENT '手机mac地址',\n" +
            "  `transportation_card` varchar(64) NOT NULL DEFAULT '-' COMMENT '交通卡',\n" +
            "  `transportation` varchar(64) NOT NULL DEFAULT '-' COMMENT '交通工具',\n" +
            "  `birthday` date DEFAULT NULL COMMENT '出生年月',\n" +
            "  `recent_snap_time` datetime DEFAULT '1970-01-01 00:00:00' COMMENT '最近抓拍时间',\n" +
            "  `person_file_create_time` datetime DEFAULT NULL COMMENT '档案创建时间',\n" +
            "  `image_count` int(11) DEFAULT '0' COMMENT '抓拍照片数',\n" +
            "  `avatar_url` varchar(255) DEFAULT NULL COMMENT '头像地址',\n" +
            "  `algo_version` varchar(255) DEFAULT NULL COMMENT '算法版本',\n" +
            "  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',\n" +
            "  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',\n" +
            "  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',\n" +
            "  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',\n" +
            "  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',\n" +
            "  UNIQUE KEY `aid` (`aid`) USING BTREE COMMENT '档案ID唯一索引',\n" +
            "  KEY `modifyTime` (`modify_time`),\n" +
            "  KEY `imageCount` (`image_count`),\n" +
            "  KEY `personFileCreateTime` (`person_file_create_time`),\n" +
            "  KEY `cid` (`cid`),\n" +
            "  KEY `name` (`name`),\n" +
            "  KEY `isDeletedAndCid` (`is_deleted`,`cid`),\n" +
            "  KEY `recentSnapTime` (`recent_snap_time`)\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案中心人员基础信息表';";
    
    @Autowired
    private PersonfileBaseInfoService personfileBaseInfoService;
    
    @Autowired
    private PersonfileLabelService personfileLabelService;
    
    @Autowired
    private PersonfileConcernServiceImpl personfileConcernServiceImpl;
    
    @Autowired
    private XdataFeignClient xdataFeignClient;
    
    @Autowired
    private PersonfileRubbishService personfileRubbishService;
    
    @Resource
    private StatisticPersonfileTypeService statisticPersonfileTypeService;
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    @Autowired
    private IPersonfileConcernService iPersonfileConcernService;
    
    @Autowired
    private SubEventService subEventService;
    
    private static final PersonfileBasics PERSONFILE = new PersonfileBasics();
    
    private static final String[] dateFormat = {"yyyy-MM-dd HH:mm:ss"};
    
    @Override
    public PersonfileBasics findBaseInfoByPersonFileId(String personFileId) {
        ThreadLocalUtil.setSubTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personFileId, personPropertiest.getArchiveTableMaxTables()));
        return personfileBaseInfoService.findBaseInfoByPersonFileId(personFileId);
    }
    
    @Override
    public List<String> findBaseInfoByLabels(List<Integer> lableIdList) {
        return personfileBaseInfoService.findBaseInfoByLabels(lableIdList);
    }
    
    @Override
    public PersonfileBasicsVO findBaseInfoVOByPersonFileId(String personFileId) {
        PersonfileBasicsVO personfileBasicsVO = new PersonfileBasicsVO();
        PersonfileBasics personfileBasics = findBaseInfoByPersonFileId(personFileId);
        if (personfileBasics != null) {
            BeanUtils.copyProperties(personfileBasics, personfileBasicsVO);
            personfileBasicsVO.setAppearTime(personfileBasics.getRecentSnapTime());
            List<String> personfileIds = Lists.newArrayList();
            personfileIds.add(personFileId);
            List<PersonfileLabelVO> personfileLabelVOS = personfileLabelService.findPersonfileLabelRecordByPersonfileIds(personfileIds);
            Map<String, List<PersonfileLabelVO>> personfileLabelMap = personfileLabelVOS.stream().collect(Collectors.groupingBy(PersonfileLabelVO::getAid));
            List<PersonfileLabelVO> personfileLabelVOList = personfileLabelMap.get(personFileId);
            if (CollectionUtils.isNotEmpty(personfileLabelVOList)) {
                personfileBasicsVO.setLabelName(personfileLabelVOList.stream().map(PersonfileLabelVO::getLabelName).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
                personfileBasicsVO.setLabelId(personfileLabelVOList.stream().sorted(Comparator.comparingInt(s -> Integer.parseInt(s.getLabelId()))).map(PersonfileLabelVO::getLabelId).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
            }
            return personfileBasicsVO;
        }
        return personfileBasicsVO;
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int insertPersonfileBasicsLabel(String personFileId, Integer labelId) throws BusinessException {
        return personfileBaseInfoService.insertPersonfileBasicsLabel(personFileId, labelId);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int deletePersonfileBasicsLabel(String personFileId, Integer labelId) {
        PersonfileBasicsVO personfileBasicsVO = findBaseInfoVOByPersonFileId(personFileId);
        if (personfileBasicsVO == null) {
            return 0;
        }
        String labeldIds = personfileBasicsVO.getLabelId();
        if (Strings.isNotBlank(labeldIds) && labeldIds.contains(labelId + "")) {
            PersonfileLabelRecord personfileLabelRecord = new PersonfileLabelRecord();
            personfileLabelRecord.setLabelId(Long.valueOf(labelId));
            personfileLabelRecord.setAid(personFileId);
            int result = this.baseDao.updateStatement("deletePersonfilelabelRecord", personfileLabelRecord);
            if (result == 1) {
                statisticPersonfileTypeService.updateNumByPersonTypeId(labelId + "", -1);
            }
        }
        return 1;
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int updatePersonfileBasics(PersonfileBasics personfileBasics) {
        ThreadLocalUtil.setSubTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileBasics.getPersonFilesId(), personPropertiest.getArchiveTableMaxTables()));
        return personfileBaseInfoService.updatePersonfileBasics(personfileBasics);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int batchUpdatePersonfileBasics(List<PersonfileBasics> personfileBasics) {
        Map<String, Object> params = Maps.newHashMap();
        if (CollectionUtils.isEmpty(personfileBasics)) {
            return 0;
        }
        params.put("personFileList", personfileBasics);
        return this.baseDao.batchUpdate(PersonfileBaseInfoServiceImpl.PERSONFILE_BASICS, params);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int deleteByPersonfileIdPersonfileBasics(String personfileId) {
        ThreadLocalUtil.setSubTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables()));
        return personfileBaseInfoService.deleteByPersonfileIdPersonfileBasics(personfileId);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public void archiveSync(List<PersonfileBasics> personfileBasics) {
        Map<String, List<PersonfileBasics>> groupByCreateDate = personfileBasics.stream().collect(Collectors.groupingBy(PersonfileBasics::getTableName));
        List<Map<String, Object>> params = Lists.newArrayList();
        for (String key : groupByCreateDate.keySet()) {
            Map<String, Object> param = Maps.newHashMap();
            param.put("personfileBasics", groupByCreateDate.get(key));
            param.put("tableName", key);
            params.add(param);
        }
//        this.baseDao.updateStatement("batchInsertPersonfileBasics", params);
        this.baseDao.batchInsert("batchInsertPersonfileBasics", params);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public int batchInsertPersonfileBasics(List<PersonfileBasics> personfileBasics) {
        return this.baseDao.batchInsert(PERSONFILE, null, personfileBasics);
    }
    
    @Override
    public List<PersonfileBasics> findAutoByParam(Map<String, Object> params) {
        return personfileBaseInfoService.findAutoByParam(params);
    }
    
    @Override
    public Integer statisticNewPersonfile(String clusterStartTime, String clusterEndTime, Boolean isRealName) {
        return personfileBaseInfoService.statisticNewPersonfile(clusterStartTime, clusterEndTime, isRealName);
    }
    
    @Override
//    @CacheEvict(value="archiveCache", allEntries=true)
    public void personfileHandle(String personFileId, String initiativPersonFileId) throws BusinessException, IllegalAccessException {
        if (Strings.isBlank(personFileId)) {
            throw new BusinessException(IResultCode.ERROR, "参数异常");
        }
        
        PersonfileBasics personfileBasics = findBaseInfoByPersonFileId(personFileId);
        
        if (personfileBasics == null) {
            throw new BusinessException(IResultCode.ERROR, "档案不存在");
        }
        
        boolean isReal = Strings.isNotBlank(personfileBasics.getCid());
        
        // 删除关注
        personfileConcernServiceImpl.deleteByIdPersonfileConcern(personFileId);
        logger.info("删除关注成功！");
        
        // 删除基本信息
        SubArchiveService subArchiveService = (SubArchiveService) AopContext.currentProxy();
        int existFlag = subArchiveService.deleteByPersonfileIdPersonfileBasics(personFileId);
        if (existFlag == 0) {
            throw new BusinessException(IResultCode.ERROR, "档案不存在");
        }
        logger.info("删除基本信息成功！");
        
        // 合并档案
        if (StringUtils.isNotEmpty(initiativPersonFileId)) {
            // 更新档案
            PersonfileBasics initiativPersonFile = subArchiveService.findBaseInfoByPersonFileId(initiativPersonFileId);
            if (initiativPersonFile == null) {
                throw new BusinessException(IResultCode.ERROR, "档案不存在");
            }
            
            if (isReal && Strings.isBlank(initiativPersonFile.getCid())) {
                isReal = false;
            }
            
            if (Strings.isBlank(initiativPersonFile.getCid())) {
                initiativPersonFile.setCid(personfileBasics.getCid());
                initiativPersonFile.setSex(personfileBasics.getSex());
                initiativPersonFile.setAge(personfileBasics.getAge());
                initiativPersonFile.setBirthDate(personfileBasics.getBirthDate());
                initiativPersonFile.setName(personfileBasics.getName());
                subArchiveService.updatePersonfileBasics(initiativPersonFile);
            }
            
            logger.info("合并档案成功！");
            // 数据平台处理: 调用数据平台接口(档案id列表，第一个为主合入档案id，第二个为被合入档案id（被删除），目前限制列表长度为2)
            List<String> aids = new LinkedList<>();
            aids.add(initiativPersonFileId);
            aids.add(personFileId);
            Long startTime = System.currentTimeMillis();
            xdataFeignClient.merge(new XdataReqDTO(aids, personPropertiest.getPersonFileDBName()));
            logger.info("数据平台合并成功！耗时：" + (System.currentTimeMillis() - startTime));
            // 删除档案
        } else {
            // 数据平台处理
            Long startTime = System.currentTimeMillis();
            xdataFeignClient.delete(new XdataReqDTO(personFileId, personPropertiest.getPersonFileDBName()));
            logger.info("数据删除成功！耗时：" + (System.currentTimeMillis() - startTime));
        }
        
        // 删除档案和合并档案都将抓拍放入回收站
        PersonfileSnap personfileSnap = new PersonfileSnap();
        personfileSnap.setPersonFilesId(personFileId);
        
        List<PersonfileRubbish> personfileRubbishes = subEventService.getByPersonfileId(null, personFileId, 0, 1000);
        int page = 1;
        while (CollectionUtils.isNotEmpty(personfileRubbishes)) {
            personfileRubbishService.insertBatchPersonfileRubbish(personfileRubbishes);
            personfileRubbishes = subEventService.getByPersonfileId(null, personFileId, page * 1000, 1000);
            page++;
        }
        subEventService.deletePersonfileSnap(personfileSnap);
        logger.info("抓拍放入回收站成功！");
        try {
            // 从solr中删除档案
//            personfileSolrService.deleteByPersonfileId(personFileId);
            logger.info("从solr中删除档案成功！");
            
            // 更新人员类型统计
            List<String> aids = Lists.newArrayList();
            aids.add(personfileBasics.getPersonFilesId());
            List<PersonfileLabelVO> personfileLabelVOS = personfileLabelService.findPersonfileLabelRecordByPersonfileIds(aids);
            if (CollectionUtils.isNotEmpty(personfileLabelVOS)) {
                statisticPersonfileTypeService.updateNumByPersonTypeId(personfileLabelVOS.get(0).getLabelId(), -1);
            }
            
            // 更新事件统计
            if (CollectionUtils.isNotEmpty(personfileRubbishes)) {
                Map<String, List<PersonfileRubbish>> personRubishs = personfileRubbishes.stream().collect(Collectors.groupingBy(personfileRubbish -> DateFormatUtils.format(personfileRubbish.getCreateTime(), ICommonConstant.DateFormatType.Y_M_D)));
                personRubishs.forEach((key, value) -> {
                    List<StatisticPersonfileEvent> events = statisticPersonfileEventService.findStatisticEventDailyByDate(key + ICommonConstant.DateStr.START_TIME, key + ICommonConstant.DateStr.END_TIME);
                    if (CollectionUtils.isNotEmpty(events)) {
                        if (events.get(0).getIncNum() > value.size()) {
                            statisticPersonfileEventService.updateStatisticEvent(-value.size(), key);
                        }
                    }
                });
            }

//            // 更新档案统计
//            StatisticPersonfile statisticPersonfile = statisticPersonfileService.findTopOne(DateFormatUtils.format(DateUtils.addDays(new Date(),1),"yyyy-MM-dd"));
//            if (statisticPersonfile.getStatisticTotal() > 0) {
//                statisticPersonfile.setStatisticTotal(statisticPersonfile.getStatisticTotal() - 1);
//                if (isReal && statisticPersonfile.getStatisticRealNameTotal() > 0) {
//                    statisticPersonfile.setStatisticRealNameTotal(statisticPersonfile.getStatisticRealNameTotal() - 1);
//                }
//                statisticPersonfileService.updateStatisticPersonfile(statisticPersonfile);
//            }
//
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("统计数据更新异常：" + e);
        }
    }
    
    @Override
    public List<Map<String, Object>> findByPersonfileIds(List<String> personFileIds) {
        List<String> knowTables = Lists.newArrayList();
        for (String personfileId : personFileIds) {
            knowTables.add(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables()));
        }
        ThreadLocalUtil.setSubKnowTableName(knowTables);
        return personfileBaseInfoService.findByPersonfileIds(personFileIds);
    }
    
    @Override
    public BasePageRespDTO findByFilterParams(ListFilterDTO listFilterDTO) {
        // 标签参数特殊处理-----start--------------------------------
        if (CollectionUtils.isNotEmpty(listFilterDTO.getLabelIds())) {
            List<PersonfileLabelVO> personfileLabelTemp = personfileLabelService.findLabelRecordByLabelId(listFilterDTO.getLabelIds());
            List<String> personfileIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(personfileLabelTemp)) {
                personfileIds = personfileLabelTemp.stream().map(PersonfileLabelVO::getAid).collect(Collectors.toList());
            }
            if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds()) && CollectionUtils.isNotEmpty(personfileIds)) {
                listFilterDTO.getPersonFileIds().addAll(personfileIds);
            } else if (CollectionUtils.isNotEmpty(personfileIds)) {
                listFilterDTO.setPersonFileIds(personfileIds);
            } else {
                personfileIds.add("archive");
                listFilterDTO.setPersonFileIds(personfileIds);
            }
        }
        // 标签参数特殊处理-----end--------------------------------
        
        // 我的关注-----start--------------------------------
        List<PersonfileConcern> personfileConcernList = iPersonfileConcernService.findByConcerner(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        if (listFilterDTO.getPersonFileType() == 3) {
            List<String> exitIds = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(personfileConcernList)) {
                List<String> personfileIds = personfileConcernList.stream().map(PersonfileConcern::getPersonFilesId).collect(Collectors.toList());
                if (CollectionUtils.isEmpty(listFilterDTO.getPersonFileIds())) {
                    listFilterDTO.setPersonFileIds(personfileIds);
                } else {
                    for (String id : listFilterDTO.getPersonFileIds()) {
                        if (personfileIds.contains(id)) {
                            exitIds.add(id);
                        }
                    }
                    if (CollectionUtils.isEmpty(exitIds)) {
                        exitIds.add("archive");
                    }
                    listFilterDTO.setPersonFileIds(exitIds);
                }
            } else {
                exitIds.add("archive");
                listFilterDTO.setPersonFileIds(exitIds);
            }
        }
        // 我的关注-----end--------------------------------
        
        
        if (listFilterDTO.getPage() != 1) {
            if (Strings.isBlank(listFilterDTO.getLastRecentSnapTime())) {
                listFilterDTO.setLastRecentSnapTime("1970-01-01 00:00:00");
            }
        }
        if (listFilterDTO.getSortName() != null && listFilterDTO.getSortName() == 2 && listFilterDTO.getPage() == 1) {
            listFilterDTO.setLastImageCount(Integer.MAX_VALUE);
        }
        
        SubArchiveService subArchiveService = (SubArchiveService) AopContext.currentProxy();
        List<PersonfileVO> personfileVOS = subArchiveService.findByParams(listFilterDTO);
        for (PersonfileVO personfileVO: personfileVOS) {
            if (personfileVO.getAppearTime().getTime() <= 0) {
                personfileVO.setAppearTime(null);
            }
        }
        
        // 标签返回特殊处理-----start------------------------------
        if (CollectionUtils.isNotEmpty(personfileVOS)) {
            List<String> personfileIds = personfileVOS.stream().map(PersonfileVO::getPersonFileId).collect(Collectors.toList());
            List<PersonfileLabelVO> personfileLabelVOS = personfileLabelService.findPersonfileLabelRecordByPersonfileIds(personfileIds);
            Map<String, List<PersonfileLabelVO>> personfileLabelMap = personfileLabelVOS.stream().collect(Collectors.groupingBy(PersonfileLabelVO::getAid));
            for (PersonfileVO personfileVO : personfileVOS) {
                List<PersonfileLabelVO> personfileLabelVOList = personfileLabelMap.get(personfileVO.getPersonFileId());
                if (CollectionUtils.isNotEmpty(personfileLabelVOList)) {
                    personfileVO.setLabelNames(personfileLabelVOList.stream().sorted(Comparator.comparingInt(s -> Integer.parseInt(s.getLabelId()))).map(PersonfileLabelVO::getLabelName).collect(Collectors.joining(ICommonConstant.Symbol.COMMA)));
                }
            }
            personfileVOS = personfileVOS.stream().distinct().collect(Collectors.toList());
        } else {
            personfileVOS = Lists.newArrayList();
        }
        // 标签返回特殊处理-----end------------------------------
        
        // 注入关注
        if (CollectionUtils.isNotEmpty(personfileConcernList)) {
            personfileVOS.forEach(personfileVO -> {
                if (personfileConcernList.stream().anyMatch(personfileConcern -> personfileConcern.getPersonFilesId().equalsIgnoreCase(personfileVO.getPersonFileId()))) {
                    personfileVO.setFocused(1);
                }
            });
        }
        
        // 注入相似度----------start----------------------------
        if (CollectionUtils.isNotEmpty(listFilterDTO.getSimilars())) {
            personfileVOS.forEach(personfileVO -> {
                List<Map<String, Object>> similarTemps = listFilterDTO.getSimilars().stream().filter(v -> v.get("personfileId").equals(personfileVO.getPersonFileId())).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(similarTemps)) {
                    personfileVO.setSimilar((Float) similarTemps.get(0).get("score"));
                }
            });
            personfileVOS = personfileVOS.stream().sorted(Comparator.comparingDouble(PersonfileVO::getSimilar).reversed()).collect(Collectors.toList());
        }
        // 注入相似度----------end----------------------------
        
        // 结果返回
        return new BasePageRespDTO(personfileVOS, 0, CollectionUtils.isNotEmpty(personfileVOS) ? personfileVOS.size() : 0, IResultCode.SUCCESS);
    }
    
    @Override
    public List<PersonfileVO> findByParams(ListFilterDTO listFilterDTO) {
        List<String> knowTables = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds())) {
            for (String personfileId : listFilterDTO.getPersonFileIds()) {
                String knowTable = TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables());
                if (knowTables.contains(knowTable)) {
                    continue;
                }
                knowTables.add(knowTable);
            }
        } else {
            for (String table : getAllTableFromDB(false, true)) {
                if (table.contains(TABLE_NAME) && !table.contains("t_bigdata_archive_label_record")) {
                    knowTables.add(table);
                }
            }
        }
//        listFilterDTO.setSinglePage(((listFilterDTO.getPage() / 10) + 1) * 15);
        listFilterDTO.setSinglePage(15);
//        ThreadLocalUtil.setSubKnowTableName(knowTables);
        listFilterDTO.setTables(knowTables);
        return personfileBaseInfoService.findByParams(listFilterDTO);
    }
    
    @Override
    public Long findPersonfilePageTotal(ListFilterDTO listFilterDTO) {
        if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds())) {
            List<String> knowTables = Lists.newArrayList();
            for (String personfileId : listFilterDTO.getPersonFileIds()) {
                String knowTable = TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables());
                if (knowTables.contains(knowTable)) {
                    continue;
                }
                knowTables.add(knowTable);
            }
            ThreadLocalUtil.setSubKnowTableName(knowTables);
        }
        Long num = personfileBaseInfoService.findPersonfilePageTotal(listFilterDTO);
        return num == null ? 0 : num;
    }
    
    @Override
    public List<PersonfileClusterFinishDTO> findByPage(int pageNo, int perpage) {
        return personfileBaseInfoService.findByPage(pageNo, perpage);
    }
    
    @Override
    public List<String> findDeletedPersonfilesId(List<String> personfilesIdList) {
        if (CollectionUtils.isNotEmpty(personfilesIdList)) {
            List<String> knowTables = Lists.newArrayList();
            for (String personfileId : personfilesIdList) {
                knowTables.add(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables()));
            }
            ThreadLocalUtil.setSubKnowTableName(knowTables);
        }
        return personfileBaseInfoService.findDeletedPersonfilesId(personfilesIdList);
    }
    
    @Override
    public int updateImageCount(int addImageCount, String personfileId) {
        ThreadLocalUtil.setSubTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(personfileId, personPropertiest.getArchiveTableMaxTables()));
        return personfileBaseInfoService.updateImageCount(addImageCount, personfileId);
    }
    
    @Override
    public Integer statisticAge(Integer startAge, Integer endAge, Boolean isEqual) {
        return personfileBaseInfoService.statisticAge(startAge, endAge, isEqual);
    }
    
    
    @Override
    public void statisticImageCountAndGetRecentSnapTime() {
        List<String> tables = getAllTableFromDB(false, true);
        for (String table : tables) {
            if (!table.contains(TABLE_NAME) || table.equals("t_bigdata_archive_label_record")) {
                continue;
            }
//            ThreadPoolService.threadPool.execute(new ArchiveImageCountAndSnapTimeUpdateWork(this,table,personPropertiest.getArchiveImageCountAndRecentSnapTimeUpdateBatch(),personPropertiest.getArchiveImageCountAndRecentSnapTimeUpdateSnapBatch()));
            try {
                statisticImageCountAndRecentSnapTimeHandle(table,personPropertiest.getArchiveImageCountAndRecentSnapTimeUpdateBatch(),personPropertiest.getArchiveImageCountAndRecentSnapTimeUpdateSnapBatch());
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void statisticImageCountAndRecentSnapTimeHandle(String table, Integer archiveBatch,Integer archiveSnapBatch) throws ParseException {
        List<PersonfileBasics> personFileList = Lists.newArrayList();
        int page = 0;
        int perpage = archiveBatch;
        int num = archiveBatch;
        logger.info(Thread.currentThread().getName() + "----------------正在更新表:" + table);
        long startTime = System.currentTimeMillis();
        while (num == perpage) {
            List<PersonfileBasics> personfileBasicsList = personfileBaseInfoService.findAidAndPersonFileCreateTime(page * perpage, perpage,table);
            logger.info(Thread.currentThread().getName() + "---------------------------查询档案耗时：" + (System.currentTimeMillis() - startTime));
            
            if (CollectionUtils.isEmpty(personfileBasicsList)) {
                break;
            }
            
            num = personfileBasicsList.size();
            logger.info(Thread.currentThread().getName() + "---------------------更新档案数：" + num);
            
            List<String> aids = personfileBasicsList.stream().map(PersonfileBasics::getPersonFilesId).collect(Collectors.toList());
            int batchNum = ((aids.size() % archiveSnapBatch) == 0) ?  (aids.size() / archiveSnapBatch) : ((aids.size() / archiveSnapBatch) + 1);
            for (int i =0;i < batchNum;i++) {
                startTime = System.currentTimeMillis();
                List<PersonfileBasics> personfileBasicsList1 = subEventService.findSnapTimeAndImageCountByPersonfileId(aids.subList(i * archiveSnapBatch,(((i + 1) == batchNum) ? aids.size() : ((i + 1) * archiveSnapBatch))));
                if (CollectionUtils.isEmpty(personfileBasicsList1)) {
                    continue;
                }
                Map<String,List<PersonfileBasics>> groupByAid = personfileBasicsList1.stream().collect(Collectors.groupingBy(PersonfileBasics::getPersonFilesId));
                groupByAid.forEach((key,value)->{
                    PersonfileBasics personfileBasics2 = new PersonfileBasics();
                    personfileBasics2.setPersonFilesId(key);
                    personfileBasics2.setImageCount(value.stream().mapToInt(PersonfileBasics::getImageCount).sum());
                    Date recentSnapTime = value.stream().filter(file -> file.getRecentSnapTime() != null).max(Comparator.comparing(PersonfileBasics::getRecentSnapTime)).orElse(new PersonfileBasics()).getRecentSnapTime();
                    try {
                        personfileBasics2.setRecentSnapTime(recentSnapTime == null ? DateUtils.parseDate("1970-01-01 00:00:00",dateFormat)  : recentSnapTime);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    personfileBasics2.setTableName(TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + AbstractSubService.hash(key, personPropertiest.getArchiveTableMaxTables()));
                    personFileList.add(personfileBasics2);
                });
            }
            if (CollectionUtils.isNotEmpty(personFileList)) {
                startTime = System.currentTimeMillis();
                personfileBaseInfoService.batchUpdatePersonfileStatistic(personFileList);
                logger.info(Thread.currentThread().getName() + "---------------------------更新档案" + personFileList.size() + "耗时：" + (System.currentTimeMillis() - startTime));
                personFileList.clear();
            }
            page++;
        }
        logger.info(Thread.currentThread().getName() + "----------------更新完毕表:" + table);
    }
    
    /**
     * 初始化分表
     *
     * @param num 表数量
     */
    public void initSubTable(Integer num) {
        for (int i = 0; i < num; i++) {
            String tableName = TABLE_NAME + ICommonConstant.Symbol.UNDERLINE + i;
            if (!isExist(tableName, false)) {
                createTable(CREATE_TABLE_SQL.replaceAll(TABLE_NAME, tableName));
            }
        }
    }
}
