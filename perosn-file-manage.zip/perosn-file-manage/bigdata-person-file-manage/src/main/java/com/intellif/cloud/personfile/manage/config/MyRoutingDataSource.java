package com.intellif.cloud.personfile.manage.config;

import com.intellif.cloud.personfile.manage.utils.DBHandoverUtil;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.annotation.Nullable;


/**
 * @author admin
 * @date 2019-02-27
 */
public class MyRoutingDataSource extends AbstractRoutingDataSource {
    
    @Nullable
    @Override
    protected Object determineCurrentLookupKey() {
        return DBHandoverUtil.get();
    }
    
}
