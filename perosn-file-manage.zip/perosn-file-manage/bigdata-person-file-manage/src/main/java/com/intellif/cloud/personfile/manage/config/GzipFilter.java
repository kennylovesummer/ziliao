package com.intellif.cloud.personfile.manage.config;

import com.google.common.net.HttpHeaders;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//@Component
public class GzipFilter implements Filter {
    
    @Override
    public void destroy() {
    }
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String requestUrl = httpRequest.getRequestURL().toString();
        if (Strings.isNotBlank(requestUrl) && requestUrl.contains("camera")) {
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            String acceptEncoding = httpRequest.getHeader(HttpHeaders.ACCEPT_ENCODING);
            if (acceptEncoding != null) {
                if (acceptEncoding.indexOf("gzip") >= 0) {
                    GZipResponseWrapper gZipResponseWrapper = new GZipResponseWrapper(httpResponse);
                    chain.doFilter(request, gZipResponseWrapper);
                    gZipResponseWrapper.finish();
                    return;
                }
            }
        }
        chain.doFilter(request, response);
    }
}
