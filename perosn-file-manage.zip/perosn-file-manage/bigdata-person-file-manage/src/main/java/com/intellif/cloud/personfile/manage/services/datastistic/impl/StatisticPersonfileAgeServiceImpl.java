package com.intellif.cloud.personfile.manage.services.datastistic.impl;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfile;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticAgeService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.log.LoggerUtilI;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 年龄统计
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月27日
 * @see StatisticPersonfileAgeServiceImpl
 * @since JDK1.8
 */
@Service
public class StatisticPersonfileAgeServiceImpl extends BaseServiceImpl implements StatisticAgeService {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    /**
     * 根据人员档案年龄id累加人员档案年龄数量
     *
     * @param personFileAgeId  人员档案年龄
     * @param personFileAgeNum 人员档案年龄段统计数量
     * @return
     */
    @Override
    public int updateAgeNumByAgeId(int personFileAgeId, int personFileAgeNum) {
        int ageNum = findAgeNumByAgeId(personFileAgeId);
        if (ageNum == 0 && personFileAgeNum <= 0) {
            return 1;
        }
        Map map = new HashMap(2);
        map.put("personFileAgeNum", personFileAgeNum);
        map.put("personFileAgeId", personFileAgeId);
        try {
            return this.baseDao.updateStatement("updateAgeNumByAgeId", map);

        } catch (Exception e) {
            logger.error("根据人员档案年龄id累加人员档案年龄数量 接口异常:" + e.getMessage());
            return 0;
        }
    }

    @Override
    public int findAgeNumByAgeId(int personFileAgeId) {
        QueryEvent<StatisticPersonfile> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("ageId", personFileAgeId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findAgeNumByAgeId");
        Object ageNum = this.baseDao.findOneByCustom(queryEvent);
        return ageNum != null ? (int) ageNum : 0;
    }
}
