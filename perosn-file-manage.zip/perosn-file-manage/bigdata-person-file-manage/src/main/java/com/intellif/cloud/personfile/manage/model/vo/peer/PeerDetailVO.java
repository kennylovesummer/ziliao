package com.intellif.cloud.personfile.manage.model.vo.peer;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * 同行详情
 *
 * @author liuzj
 * @date 2019-07-01
 */
@Data
public class PeerDetailVO {
    
    private Long taskId;
    
    private String aid;
    
    private String cameraId;
    
    private String cameraName;
    
    private String geoString;
    
    private Long date;
    
    private String faceId;
    
    private String faceUrl;
    
    private Integer imageCount;
    
    private Long startTime;
    
    private Long endTime;
    
    private Float score;
    
    private Long time;
    
    private List<Map<String, Object>> faces;
    
}
