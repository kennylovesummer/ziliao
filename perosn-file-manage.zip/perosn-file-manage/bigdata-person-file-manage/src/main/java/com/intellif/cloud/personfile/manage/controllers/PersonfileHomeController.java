package com.intellif.cloud.personfile.manage.controllers;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.enums.PersonfileTypeEnum;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileVO;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileConcernService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileLabelService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月16日
 * @see PersonfileHomeController
 * @since JDK1.8
 */
@Api(tags = "档案中心-档案列表")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.BaseUrl.RESOURCE_BASE)
public class PersonfileHomeController {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    @Autowired
    private SubEventService subEventService;
    
    @Autowired
    private PersonfileSolrService personfileSolrService;
    
    @Autowired
    private IPersonfileConcernService iPersonfileConcernService;
    
    @Autowired
    private PersonfileLabelService personfileLabelService;
    
    /**
     * 档案搜索
     *
     * @param listFilterDTO 参数集合
     * @return BasePageRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取档案列表")
    @PostMapping(value = "/list/{version}")
//    @Cacheable(key = "#listFilterDTO.toString()+'-'+'list'",value="archiveCache")
    public BasePageRespDTO preciseList(@RequestBody ListFilterDTO listFilterDTO,
                                       @PathVariable(name = "version") String version){
        try {
            listFilterDTO.setFrom(0);
            personfileSolrService.findByFeature(listFilterDTO);
    
            // 未出现时间搜索处理
            if ("2".equals(listFilterDTO.getTimeType()) && Strings.isNotBlank(listFilterDTO.getStartTime()) && Strings.isNotBlank(listFilterDTO.getEndTime())) {
                List<String> tables = subEventService.getEventTables(listFilterDTO.getStartTime(),listFilterDTO.getEndTime());
                if (CollectionUtils.isEmpty(tables)) {
                    tables.add("t_bigdata_event");
                }
                listFilterDTO.setPersonFileIdsNotIn(tables);
            }
            
            return subArchiveService.findByFilterParams(listFilterDTO);
        } catch (Exception e) {
            logger.error("档案搜索异常：" + e.getMessage());
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, e.getMessage());
        }
        
    }
    
    /**
     * 获取各个类型档案总数
     *
     * @param listFilterDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取各类档案总数")
    @PostMapping(value = "/getEachTotal/{version}")
//    @Cacheable(key = "#listFilterDTO.toString()+'-'+'total'",value="archiveCache")
    public BaseDataRespDTO getEachTotal(@RequestBody ListFilterDTO listFilterDTO) throws Exception {
        Map<String, Object> result = Maps.newHashMap();
        try {
            listFilterDTO.setFrom(0);
            personfileSolrService.findByFeature(listFilterDTO);
    
            // 未出现时间搜索处理
            if ("2".equals(listFilterDTO.getTimeType()) && Strings.isNotBlank(listFilterDTO.getStartTime()) && Strings.isNotBlank(listFilterDTO.getEndTime())) {
                List<String> tables = subEventService.getEventTables(listFilterDTO.getStartTime(),listFilterDTO.getEndTime());
                if (CollectionUtils.isEmpty(tables)) {
                    tables.add("t_bigdata_event");
                }
                listFilterDTO.setPersonFileIdsNotIn(tables);
            }
            
            // 标签参数特殊处理-----start--------------------------------
            if (CollectionUtils.isNotEmpty(listFilterDTO.getLabelIds())) {
                List<PersonfileLabelVO> personfileLabelTemp = personfileLabelService.findLabelRecordByLabelId(listFilterDTO.getLabelIds());
                List<String> personfileIds = Lists.newArrayList();
                if (CollectionUtils.isNotEmpty(personfileLabelTemp)) {
                    personfileIds = personfileLabelTemp.stream().map(PersonfileLabelVO::getAid).collect(Collectors.toList());
                }
                if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds()) && CollectionUtils.isNotEmpty(personfileIds)) {
                    listFilterDTO.getPersonFileIds().addAll(personfileIds);
                } else if (CollectionUtils.isNotEmpty(personfileIds)) {
                    listFilterDTO.setPersonFileIds(personfileIds);
                } else {
                    personfileIds.add("archive");
                    listFilterDTO.setPersonFileIds(personfileIds);
                }
            }
            
            LinkedList<Future<Integer>> futures = new LinkedList<>();
            // 总未实名档案数
            listFilterDTO.setPersonFileType(2);
            ListFilterDTO listFilterDTO1 = new ListFilterDTO();
            BeanUtils.copyProperties(listFilterDTO, listFilterDTO1);
            futures.add(ThreadPoolService.threadPool.submit(new GetTotalWork(listFilterDTO1, subArchiveService)));
            
            
            // 总关注档案数
            listFilterDTO.setPersonFileType(3);
            List<PersonfileConcern> personfileConcernList = iPersonfileConcernService.findByConcerner(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            boolean hasFocous = true;
            if (CollectionUtils.isNotEmpty(personfileConcernList)) {
                ListFilterDTO listFilterDTO2 = new ListFilterDTO();
                BeanUtils.copyProperties(listFilterDTO, listFilterDTO2);
                List<String> exitIds = Lists.newArrayList();
                List<String> personfileIds = personfileConcernList.stream().map(PersonfileConcern::getPersonFilesId).collect(Collectors.toList());
                if (CollectionUtils.isEmpty(listFilterDTO2.getPersonFileIds())) {
                    listFilterDTO2.setPersonFileIds(personfileIds);
                } else {
                    for (String id : listFilterDTO2.getPersonFileIds()) {
                        if (personfileIds.contains(id)) {
                            exitIds.add(id);
                        }
                    }
                    if (CollectionUtils.isEmpty(exitIds)) {
                        exitIds.add("archive");
                    }
                    listFilterDTO2.setPersonFileIds(exitIds);
                }
                futures.add(ThreadPoolService.threadPool.submit(new GetTotalWork(listFilterDTO2, subArchiveService)));
            } else {
                hasFocous = false;
            }
            
            // 总档案数
            listFilterDTO.setPersonFileType(null);
            ListFilterDTO listFilterDTO3 = new ListFilterDTO();
            BeanUtils.copyProperties(listFilterDTO, listFilterDTO3);
            futures.add(ThreadPoolService.threadPool.submit(new GetTotalWork(listFilterDTO3, subArchiveService)));
    
            result.put(PersonfileTypeEnum.FOCUS.getTotalName(), hasFocous ? futures.get(1).get() : 0);
            Integer total  =  hasFocous ? futures.get(2).get() : futures.get(1).get();
            result.put(PersonfileTypeEnum.ALL.getTotalName(),total);
            Integer noReal = futures.get(0).get();
            if (total != null && noReal != null && total >= noReal) {
                result.put(PersonfileTypeEnum.REAL.getTotalName(), total - noReal);
            } else {
                result.put(PersonfileTypeEnum.REAL.getTotalName(), 0);
            }
            
            return new BaseDataRespDTO(result, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e) {
            throw e;
//            logger.error("档案数量搜索异常：" + e.getMessage());
//            return new BaseDataRespDTO(result, IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), e.getMessage());
        }
    }
    
    
    class GetTotalWork implements Callable<Integer> {
        
        private ListFilterDTO listFilterDTO;
        
        private SubArchiveService subArchiveService;
        
        public GetTotalWork(ListFilterDTO listFilterDTO, SubArchiveService subArchiveService) {
            this.listFilterDTO = listFilterDTO;
            this.subArchiveService = subArchiveService;
        }
        
        @Override
        public Integer call() {
            return Integer.parseInt(subArchiveService.findPersonfilePageTotal(listFilterDTO) + "");
        }
    }
    
    /**
     * 根据ID获取档案
     *
     * @param personFileId 档案ID
     * @param version      版本
     * @return String
     */
    @ApiOperation(httpMethod = "GET",value = "根据档案ID获取档案")
    @GetMapping(value = "/{personFileId}/{version}")
    public BasePageRespDTO getPersonfile(@PathVariable(name = "personFileId") String personFileId, @PathVariable(name = "version", required = false) String version) {
        ListFilterDTO listFilterDTO = new ListFilterDTO();
        List<String> personfileIds = Lists.newArrayList();
        personfileIds.add(personFileId);
        listFilterDTO.setPersonFileIds(personfileIds);
        listFilterDTO.setSortName(1);
        BasePageRespDTO basePageRespDTO = subArchiveService.findByFilterParams(listFilterDTO);
        // 查找该档案第一张抓拍照片时间
        Date snapTime = subEventService.findFirstSnapTimeByPersonFileId(personFileId);
        List<PersonfileVO> personfileVOS = (List<PersonfileVO>) basePageRespDTO.getData();
        if (CollectionUtils.isNotEmpty(personfileVOS)) {
            personfileVOS.get(0).setFirstSnapTime(snapTime != null ? snapTime.getTime() : null);
            basePageRespDTO.setData(personfileVOS.get(0));
        }
        return basePageRespDTO;
    }
    
    /**
     * 将数据导入到solr
     *
     * @return
     */
    @Deprecated
    @PostMapping(value = "personfileToSolr")
    public BaseDataRespDTO personfileToSolr() {
//        ListFilterDTO listFilterDTO = new ListFilterDTO();
//        listFilterDTO.setPerpage(1000);
//        List<PersonfileClusterFinishDTO> personfileBasicsList = subArchiveService.findByPage(1, 1000);
//        for (int i = 2; CollectionUtils.isNotEmpty(personfileBasicsList); i++) {
//            listFilterDTO.setPage(i);
//            personfileSolrService.insert(personfileBasicsList);
//            personfileBasicsList = subArchiveService.findByPage(i, 1000);
//        }
        try {
            subArchiveService.statisticImageCountAndGetRecentSnapTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new BaseDataRespDTO(1000000);
    }
    
}
