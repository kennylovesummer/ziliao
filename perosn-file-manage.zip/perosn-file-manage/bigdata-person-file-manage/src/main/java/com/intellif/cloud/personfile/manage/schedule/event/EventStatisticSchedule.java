package com.intellif.cloud.personfile.manage.schedule.event;

import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileEvent;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileEventService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 事件日统
 *
 * @author liuzhijian
 * @date 2019-05-24
 */
@Component
public class EventStatisticSchedule {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private StatisticPersonfileEventService statisticPersonfileEventService;
    
    @Autowired
    private SubEventService subEventService;
    
    private static final String[] format = {"yyyyMMdd"};
    
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    /**
     * 根据时间获取抓拍数量
     *
     * @return 数量
     */
    @Scheduled(cron = "0 */30 * * * ?")
    public void statisticSnapByDate() {
        try {
            List<String> allTables = subEventService.getEventAllTables();
            List<String> events = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(allTables)) {
                for (String table: allTables) {
                    if (table.startsWith("t_bigdata_event")) {
                        events.add(table);
                    }
                }
                events = events.stream().sorted(Comparator.comparing(String::trim)).collect(Collectors.toList());
            }
            if (CollectionUtils.isEmpty(events)) {
                return;
            }
            String startDate = events.get(0);
            if (Strings.isBlank(startDate)) {
                return;
            }
            int i = 1;
            while (startDate.length() < 24) {
                startDate = events.get(i);
                i++;
            }
            if (Strings.isBlank(startDate)) {
                return;
            }
            String firstDateStr = startDate.substring(16,24);
            
            Date firstDate = DateUtils.parseDate(firstDateStr,format);

            while (firstDate.compareTo(new Date()) < 1){
                Integer incNum = subEventService.statisticSnapByDate(dateFormat.format(firstDate));
                StatisticPersonfileEvent statisticPersonfileEvent = new StatisticPersonfileEvent();
                statisticPersonfileEvent.setIncNum(incNum != null ? incNum : 0);
                statisticPersonfileEvent.setDt(firstDate);
                statisticPersonfileEventService.insertStatisticPersonfileEvent(statisticPersonfileEvent);
                firstDate = DateUtils.addDays(firstDate,1);
            }
        } catch (Exception e) {
            e.printStackTrace();
//            logger.error("事件日统异常：" + e.getMessage());
        }
    }
    
}
