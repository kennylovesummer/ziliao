package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @see BigdataAnalysisArchiveService
 * @author liuzj
 */
@Service
public class BigdataAnalysisArchiveServiceImpl extends BaseServiceImpl implements BigdataAnalysisArchiveService {
    
    private static final BigdataAnalysisArchive BIGDATA_ANALYSIS_ARCHIVE = new BigdataAnalysisArchive();
    
    @Override
    public BigdataAnalysisArchive findAnalysisArchiveById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryEvent = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryEvent.setParameter(parameters);
            queryEvent.setStatement("findAnalysisArchiveById");
            Object object = this.baseDao.findOneByCustom(queryEvent);
            return object == null ? null : (BigdataAnalysisArchive) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive) {
        if (bigdataAnalysisArchive != null && bigdataAnalysisArchive.getId() != null) {
            this.baseDao.delete(bigdataAnalysisArchive);
        }
    }
    
    @Override
    public Long insertAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive) {
        if (bigdataAnalysisArchive != null) {
            bigdataAnalysisArchive.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisArchive.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisArchive);
        return bigdataAnalysisArchive.getId();
    }
    
    @Override
    public void batchInsertAnalysisArchive(List<BigdataAnalysisArchive> analysisArchiveList) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_ARCHIVE,null,analysisArchiveList);
    }
    
    @Override
    public void updateAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive) {
        this.baseDao.update(bigdataAnalysisArchive);
    }
    
    @Override
    public Page<BigdataAnalysisArchive> findAnalysisArchiveByParams(AnalysisDTO analysisDTO) {
        QueryEvent<AnalysisDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(analysisDTO);
        queryEvent.setStatement("findAnalysisArchiveByParams");
    
        Page<BigdataAnalysisArchive> page = PageHelper.startPage(analysisDTO.getPage(), analysisDTO.getPerpage(),analysisDTO.getOrderBy());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public void deleteBigdataAnalysisArchiveByTaskId(Long taskId) {
        if (taskId == null) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        this.baseDao.updateStatement("deleteBigdataAnalysisArchiveByTaskId",parameters);
    }
    
}
