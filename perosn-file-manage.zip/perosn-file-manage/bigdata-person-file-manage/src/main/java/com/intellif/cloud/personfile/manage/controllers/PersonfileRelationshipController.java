package com.intellif.cloud.personfile.manage.controllers;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileRelationShip;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.feignclient.AnalysisFeignClient;
import com.intellif.cloud.personfile.manage.feignclient.XdataFeignClient;
import com.intellif.cloud.personfile.manage.model.dto.relationship.PersonfileRelationshipDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.SimilarArchiveDTO;
import com.intellif.cloud.personfile.manage.model.dto.xdata.XdataRelationReqDTO;
import com.intellif.cloud.personfile.manage.model.vo.personfile.PersonfileBasicsVO;
import com.intellif.cloud.personfile.manage.model.vo.relationship.PersonfileRelationEdgeVO;
import com.intellif.cloud.personfile.manage.model.vo.relationship.PersonfileRelationVerticeVO;
import com.intellif.cloud.personfile.manage.model.vo.relationship.RelationshipDefaultFilterVO;
import com.intellif.cloud.personfile.manage.model.vo.xdata.SimilarArchiveVO;
import com.intellif.cloud.personfile.manage.model.vo.xdata.XdataRelationVO;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRelationShipService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.solr.common.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author liuzhijian
 * @version 1.0
 * @date 2019年04月13日
 * @see PersonfileRelationshipController
 * @since JDK1.8
 */
@Api(tags = "关系图谱")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.RequestUrl.RELATIONSHIPS)
public class PersonfileRelationshipController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final PersonfileRelationShipService personfileRelationShipService;

    private final XdataFeignClient xdataFeignClient;

    private final PersonPropertiest personPropertiest;

    private final SubArchiveService subArchiveService;

    private final BigdataCommonService bigdataCommonService;
    
    private final AnalysisFeignClient analysisFeignClient;

    @Autowired
    public PersonfileRelationshipController(PersonfileRelationShipService personfileRelationShipService,
                                            XdataFeignClient xdataFeignClient,
                                            PersonPropertiest personPropertiest,
                                            SubArchiveService subArchiveService,
                                            BigdataCommonService bigdataCommonService,
                                            AnalysisFeignClient analysisFeignClient) {
        this.personfileRelationShipService = personfileRelationShipService;
        this.xdataFeignClient = xdataFeignClient;
        this.personPropertiest = personPropertiest;
        this.subArchiveService = subArchiveService;
        this.bigdataCommonService = bigdataCommonService;
        this.analysisFeignClient = analysisFeignClient;
    }

    /**
     * 查询单人人际关系
     *
     * @param xdataRelationReqDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取单人关系")
    @PostMapping("single/relation/{version}")
    BaseDataRespDTO singlePersonRelation(@RequestBody XdataRelationReqDTO xdataRelationReqDTO) {
        try {
            if (Strings.isNotBlank(xdataRelationReqDTO.getCid()) && Strings.isBlank(xdataRelationReqDTO.getAid())) {
                Map<String,Object> params = Maps.newHashMap();
                params.put("cid",xdataRelationReqDTO.getCid());
                List<PersonfileBasics> personfileBasics = subArchiveService.findAutoByParam(params);
                if (CollectionUtils.isNotEmpty(personfileBasics)) {
                    xdataRelationReqDTO.setAid(personfileBasics.get(0).getPersonFilesId());
                }
            }
            xdataRelationReqDTO.setBizCode(personPropertiest.getPersonFileRelationshipDBName());
            JSONObject jsonObject = JSONObject.parseObject(xdataFeignClient.singlePersonRlation(xdataRelationReqDTO));
            if (SuccessRespUtil.isSuccess(jsonObject)) {
                return new BaseDataRespDTO(getRelationResult(true,jsonObject,xdataRelationReqDTO), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "单人关系查询失败",jsonObject != null ? jsonObject.getString("respMessage") : null);
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "单人关系查询失败", e.getMessage());
        }
    }


    /**
     * 查询多人人际关系
     *
     * @param xdataRelationReqDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "获取多人关系")
    @PostMapping("multiple/relation/{version}")
    BaseDataRespDTO multiplePersonRelation(@RequestBody XdataRelationReqDTO xdataRelationReqDTO) {
        try {
            boolean isTrue =
                    ((Strings.isBlank(xdataRelationReqDTO.getFromId()) || Strings.isBlank(xdataRelationReqDTO.getTargetId())) && (Strings.isBlank(xdataRelationReqDTO.getTargetCid()) || Strings.isBlank(xdataRelationReqDTO.getFromCid())))
                    ||
                    (Strings.isNotBlank(xdataRelationReqDTO.getFromId()) && Strings.isNotBlank(xdataRelationReqDTO.getTargetId()) && xdataRelationReqDTO.getFromId().equals(xdataRelationReqDTO.getTargetId()))
                    ||
                    (Strings.isNotBlank(xdataRelationReqDTO.getTargetCid()) && Strings.isNotBlank(xdataRelationReqDTO.getFromCid()) && Strings.isBlank(xdataRelationReqDTO.getTargetCid()) && Strings.isBlank(xdataRelationReqDTO.getFromCid()));
            
            if (isTrue) {
                return new BaseDataRespDTO("参数异常", IPersonFilesResultCode.IManageResultCode.ERROR, "参数缺失或参数异常", "参数缺失或参数异常");
            }
            
            if ((Strings.isNotBlank(xdataRelationReqDTO.getFromCid()) && Strings.isNotBlank(xdataRelationReqDTO.getTargetCid()))
                && (Strings.isBlank(xdataRelationReqDTO.getFromId()) || Strings.isBlank(xdataRelationReqDTO.getTargetId()))) {
                Map<String,Object> params = Maps.newHashMap();
                params.put("cid",xdataRelationReqDTO.getFromCid());
                List<PersonfileBasics> personfileBasics = subArchiveService.findAutoByParam(params);
                if (CollectionUtils.isNotEmpty(personfileBasics)) {
                    xdataRelationReqDTO.setFromId(personfileBasics.get(0).getPersonFilesId());
                }
                params.put("cid",xdataRelationReqDTO.getTargetCid());
                personfileBasics = subArchiveService.findAutoByParam(params);
                if (CollectionUtils.isNotEmpty(personfileBasics) && CollectionUtils.isNotEmpty(personfileBasics)) {
                    xdataRelationReqDTO.setTargetId(personfileBasics.get(0).getPersonFilesId());
                }
            }
            xdataRelationReqDTO.setBizCode(personPropertiest.getPersonFileRelationshipDBName());
            JSONObject jsonObject = JSONObject.parseObject(xdataFeignClient.multiplePersonRlation(xdataRelationReqDTO));
            if (SuccessRespUtil.isSuccess(jsonObject)) {
                return new BaseDataRespDTO(getRelationResult(false,jsonObject,xdataRelationReqDTO), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "多人关系查询失败",jsonObject != null ? jsonObject.getString("respMessage") : null);
        } catch (Exception e) {
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR,"多人关系查询失败", e.getMessage());
        }
    }

    /**
     * 编辑/添加人际关系
     *
     * @param status          编辑、添加标识（0：添加；1：编辑）
     * @param version         版本
     * @param relationshipDTO 参数集
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST",value = "编辑/添加人际关系（status = 0：添加；status = 1：编辑）")
    @PostMapping(value = "/save/{status}/{version}")
    public BaseDataRespDTO insertRelationship(@PathVariable(name = "status") Integer status,
                                              @PathVariable(name = "version") String version,
                                              @RequestBody PersonfileRelationshipDTO relationshipDTO) {

        try {
            boolean isTrue = relationshipDTO.getRelatePersonFileId() == null || relationshipDTO.getRelatedPersonFileId() == null || relationshipDTO.getRelatePersonFileId().equals(relationshipDTO.getRelatedPersonFileId());
            if (isTrue) {
                return new BaseDataRespDTO("参数异常", IPersonFilesResultCode.IManageResultCode.ERROR, "参数缺失或参数异常", "参数缺失或参数异常");
            }
            XdataRelationReqDTO xdataRelationDTO = new XdataRelationReqDTO();
            xdataRelationDTO.setFromId(relationshipDTO.getRelatePersonFileId());
            xdataRelationDTO.setTargetId(relationshipDTO.getRelatedPersonFileId());
            xdataRelationDTO.setLabel(relationshipDTO.getRelationCode());
            xdataRelationDTO.setDirection("BOTH");
            if (status == 0) {
                xdataRelationDTO.setBizCode(personPropertiest.getPersonfileRelationshipAddDBName());
                JSONObject result = JSONObject.parseObject(xdataFeignClient.insertRelationship(xdataRelationDTO));
                if (SuccessRespUtil.isSuccess(result)) {
                    return new BaseDataRespDTO(result.get("data"), IResultCode.SUCCESS, "添加档案关系成功");
                } else {
                    return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR,  "添加档案关系失败",result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : "无返回结果");
                }
            }

            if (status == 1) {
                xdataRelationDTO.setBizCode(personPropertiest.getPersonFileRelationshipDBName());
                xdataRelationDTO.setLabel(relationshipDTO.getOldRelationCode());
                JSONObject result = JSONObject.parseObject(xdataFeignClient.deleteRelationship(xdataRelationDTO));
                if (SuccessRespUtil.isSuccess(result)) {
                    xdataRelationDTO.setBizCode(personPropertiest.getPersonfileRelationshipAddDBName());
                    xdataRelationDTO.setLabel(relationshipDTO.getRelationCode());
                    result = JSONObject.parseObject(xdataFeignClient.insertRelationship(xdataRelationDTO));
                    if (SuccessRespUtil.isSuccess(result)) {
                        return new BaseDataRespDTO(result.get("data"), IResultCode.SUCCESS, "修改档案关系成功");
                    } else {
                        return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR,"修改档案关系失败", result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : "无返回结果");
                    }
                }
            }
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "操作档案关系失败");
        } catch (Exception e) {
            logger.error("添加档案关系失败", e.getMessage());
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "操作档案关系失败", e.getMessage());
        }
    }

    /**
     * 删除人际关系
     *
     * @param relatedPersonFileId 被关联档案ID
     * @param relatePersonFileId  关联档案ID
     * @param relationCode        关系
     * @param version             版本
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "DELETE",value = "删除人际关系")
    @DeleteMapping(value = "/delete/relatePersonFileId/{relatePersonFileId}/relatedPersonFileId/{relatedPersonFileId}/relationCode/{relationCode}/{version}")
    public BaseDataRespDTO deleteRelationship(@PathVariable(name = "relatedPersonFileId") String relatedPersonFileId,
                                              @PathVariable(name = "relatePersonFileId") String relatePersonFileId,
                                              @PathVariable(name = "relationCode") String relationCode,
                                              @PathVariable(name = "version") String version) {
        try {
            // 同行不让删除
            if (ICommonConstant.DictDataKey.relationShipPeer.equalsIgnoreCase(relationCode)) {
                return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "此关系不能删除");
            }
            
            XdataRelationReqDTO xdataRelationDTO = new XdataRelationReqDTO();
            xdataRelationDTO.setFromId(relatePersonFileId);
            xdataRelationDTO.setTargetId(relatedPersonFileId);
            xdataRelationDTO.setLabel(relationCode);
            xdataRelationDTO.setDirection("BOTH");
            xdataRelationDTO.setBizCode(personPropertiest.getPersonFileRelationshipDBName());
           
            JSONObject result = JSONObject.parseObject(xdataFeignClient.deleteRelationship(xdataRelationDTO));
            if (SuccessRespUtil.isSuccess(result)) {
                return new BaseDataRespDTO(result.get("data"), IResultCode.SUCCESS, "删除档案关系成功");
            } else {
                return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR,"删除档案关系失败", result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : "无返回结果");
            }
        } catch (Exception e) {
            logger.error("删除档案关系失败", e.getMessage());
            return new BaseDataRespDTO(null, IPersonFilesResultCode.IManageResultCode.ERROR, "删除档案关系失败", e.getMessage());
        }
    }


    /**
     * 获取所有关系名
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "GET",value = "获取所有关系标签")
    @GetMapping(value = "/{version}")
    public BaseDataRespDTO findAllPersonfileRelationShip(@RequestParam(name = "relationShipName", required = false) String relationShipName) {
        try {
            List<PersonfileRelationShip> personfileRelationShips = personfileRelationShipService.findAllPersonfileRelationShip(relationShipName);
            return IPersonFilesResultInfo.ok(personfileRelationShips, "查询所有关系成功！");
        } catch (Exception e) {
            logger.error("查询所有关系异常:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("查询所有关系失败!");
        }
    }

    /**
     * 添加关系
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "POST",value = "添加关系标签")
    @PostMapping(value = "/{version}")
    public BaseDataRespDTO insertPersonfileRelationShip(@RequestBody @Valid PersonfileRelationShip personfileRelationShip, BindingResult bindingResult) {
        try {
            if (bindingResult.hasErrors()) {
                Map<String, Object> result = Maps.newHashMap();
                if (bindingResult.hasErrors()) {
                    FieldError error = (FieldError) bindingResult.getAllErrors().get(0);
                    result.put("code", "400");
                    result.put("message", error.getDefaultMessage());
                }
                return new BaseDataRespDTO(39000004, "添加的关系名或者code不可为空！");
            }
            if (StringUtils.isEmpty(codeCheck(personfileRelationShip.getLabel()))) {
                return new BaseDataRespDTO(39000002, "请输入英文字符串的code!");
            }
            String label = personfileRelationShip.getLabel().toUpperCase();
            PersonfileRelationShip relationShip = personfileRelationShipService.findPersonfileRelationShipByName(
                    null, personfileRelationShip.getRelationShipName(), label);
            if (relationShip != null) {
                return new BaseDataRespDTO(39000001, "添加的关系名或者code已存在！");
            }
            personfileRelationShip.setLabel(label);
            int result = personfileRelationShipService.insertPersonfileRelationShip(personfileRelationShip);
            if (result == 0) {
                return new BaseDataRespDTO(39000003, "添加关系失败！");
            }
            return IPersonFilesResultInfo.ok(39000003, "添加关系成功！");
        } catch (Exception e) {
            logger.error("添加关系异常:", e.getMessage());
            return new BaseDataRespDTO(39000003,"添加关系失败!");
        }
    }

    /**
     * 删除指定id关系
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "DELETE",value = "删除关系标签")
    @DeleteMapping(value = "/{relationShipId}/{version}")
    public BaseDataRespDTO findPersonfileRelationShipById(@PathVariable("relationShipId") Integer relationShipId) {
        try {
            int result = personfileRelationShipService.deletePersonfileRelationShip(relationShipId);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError("删除指定的关系失败！", "数据库执行失败！");
            }
            return IPersonFilesResultInfo.ok(null, "删除关系成功！");
        } catch (Exception e) {
            logger.error("删除关系异常:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("删除关系失败!");
        }
    }

    /**
     * 更新指定关系的信息
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "PUT",value = "更新关系标签")
    @PutMapping(value = "/{relationShipId}/{version}")
    public BaseDataRespDTO findAllPersonfileRelationShip(@PathVariable("relationShipId") Integer relationShipId, @RequestBody @Valid PersonfileRelationShip personfileRelationShip) {
        try {
            PersonfileRelationShip relationShip = personfileRelationShipService.findPersonfileRelationShipByName(relationShipId, personfileRelationShip.getRelationShipName(), null);
            if (relationShip != null) {
                return new BaseDataRespDTO(39000001, "修改的关系名已存在！");
            }
            personfileRelationShip.setId(relationShipId);
            int result = personfileRelationShipService.updatePersonfileRelationShip(personfileRelationShip);
            if (result == 0) {
                return IPersonFilesResultInfo.unknownError(null, "更新关系失败！");
            }
            return IPersonFilesResultInfo.ok(null, "更新关系成功！");
        } catch (Exception e) {
            logger.error("更新指定关系的信息:", e.getMessage());
            return IPersonFilesResultInfo.unknownError("更新关系失败!");
        }
    }

    /**
     * 新增/修改关系图谱默认查询条件(0：新增；1：修改)
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "POST",value = "新增/修改关系图谱默认查询条件(type = 0：新增；type = 1：修改)")
    @PostMapping(value = "defaultFilter/{type}")
    public BaseDataRespDTO defaultFilterInsert(@RequestBody @Valid RelationshipDefaultFilterVO relationshipDefaultFilterVO,@PathVariable(name = "type") Integer type) {
        try {
            if (type == 0) {
                BigdataCommon bigdataCommon = new BigdataCommon();
                bigdataCommon.setRemark("关系图谱默认搜索条件");
                bigdataCommon.setContentType(RelationshipDefaultFilterVO.class.getSimpleName());
                bigdataCommon.setContent(relationshipDefaultFilterVO.toString());
                bigdataCommonService.insertBigdataCommon(bigdataCommon);
                return new BaseDataRespDTO("关系图谱默认条件新增成功", IResultCode.SUCCESS, ResultMessageEnum.EXECUTE_SUCCESS.getMessage());
            }
            if (type == 1) {
                List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(RelationshipDefaultFilterVO.class.getSimpleName());
                if (CollectionUtils.isNotEmpty(bigdataCommons)) {
                    BigdataCommon bigdataCommon = bigdataCommons.get(0);
                    bigdataCommon.setContent(relationshipDefaultFilterVO.toString());
                    bigdataCommonService.updateBigdataCommon(bigdataCommon);
                } else {
                    return new BaseDataRespDTO(null, IResultCode.ERROR, "无关系图谱默认条件，无法修改");
                }
                return new BaseDataRespDTO("关系图谱默认条件修改成功", IResultCode.SUCCESS, ResultMessageEnum.EXECUTE_SUCCESS.getMessage());
            }
        }catch (Exception e){
            logger.error("关系图谱默认条件操作失败：" + e.getMessage());
        }
        return new BaseDataRespDTO(null, IResultCode.ERROR, "关系图谱默认条件操作失败");
    }

    /**
     * 查询关系图谱默认查询条件
     *
     * @return BaseDataRespDTO 参数集
     */
    @ApiOperation(httpMethod = "GET",value = "查询关系图谱默认查询条件")
    @GetMapping(value = "defaultFilter/list")
    public BaseDataRespDTO defaultFilterList() {
        try {
            List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(RelationshipDefaultFilterVO.class.getSimpleName());
            if (CollectionUtils.isNotEmpty(bigdataCommons)) {
                BigdataCommon bigdataCommon = bigdataCommons.get(0);
                return new BaseDataRespDTO(JSONObject.parseObject(bigdataCommon.getContent()), IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            } else {
                return new BaseDataRespDTO(null, IResultCode.ERROR, "关系图谱默认条件查询失败");
            }
        }catch (Exception e){
            logger.error("关系图谱默认条件查询失败：" + e.getMessage());
        }
        return new BaseDataRespDTO(null, IResultCode.ERROR, "关系图谱默认条件查询失败");
    }

    /**
     * 获取关系结果集通用数据封装方法
     *
     * @param jsonObject 数据平台结果集
     * @return XdataRelationVO
     */
    private XdataRelationVO getRelationResult(boolean isSingle,JSONObject jsonObject,XdataRelationReqDTO xdataRelationReqDTO) {
        JSONObject data = jsonObject.getJSONObject("data");
        if (data == null || data.isEmpty()) {
            return new XdataRelationVO();
        }
        String edges = data.getString("edges");
        String vertieces = data.getString("vertices");
        List<PersonfileRelationEdgeVO> personfileRelationEdgeVOList = Strings.isNotBlank(edges) ? JSONObject.parseArray(edges, PersonfileRelationEdgeVO.class) : Lists.newArrayList();
        List<PersonfileRelationVerticeVO> personfileRelationVerticeVOList = Strings.isNotBlank(vertieces) ? JSONObject.parseArray(vertieces, PersonfileRelationVerticeVO.class) : Lists.newArrayList();
        List<PersonfileRelationShip> personfileRelationShips = null;
        try {
            personfileRelationShips = personfileRelationShipService.findAllPersonfileRelationShip(null);
        } catch (BusinessException e) {
            logger.error("查询所有关系异常：" + e.getMessage());
        }
        
        Map<String,List<SimilarArchiveVO>> similarMap = null;
        if (isSingle) {
            List<PersonfileRelationVerticeVO> filtedList = singleToFilterBySimilarAndTopNum(isSingle,xdataRelationReqDTO,personfileRelationVerticeVOList);
            if (CollectionUtils.isNotEmpty(filtedList)) {
                personfileRelationVerticeVOList = filtedList;
            }
        } else {
            similarMap = toFilterBySimilarAndTopNum(isSingle,xdataRelationReqDTO,personfileRelationVerticeVOList);
        }
        
        if (CollectionUtils.isNotEmpty(personfileRelationShips)) {
            Map<String, String> labelNameMap = personfileRelationShips.stream().collect(Collectors.toMap(PersonfileRelationShip::getLabel, PersonfileRelationShip::getRelationShipName, (key1, key2) -> key2));
            personfileRelationEdgeVOList.forEach(e -> {
                if (e != null) {
                    if (labelNameMap.containsKey(e.getLabel())) {
                        String labelName = labelNameMap.get(e.getLabel());
                        e.setLabelName(Strings.isNotBlank(labelName) ? labelName : e.getLabel());
                    } else {
                        e.setLabelName(e.getLabel());
                    }
                }
            });
            personfileRelationVerticeVOList.forEach(e -> {
                try {
                    if (e != null) {
                        PersonfileBasicsVO personfileBaseInfo = subArchiveService.findBaseInfoVOByPersonFileId(e.getAid());
                        e.setLabelManage(personfileBaseInfo.getLabelName());
                        e.setImageCount(personfileBaseInfo.getImageCount());
                        e.setAppearTime(personfileBaseInfo.getAppearTime());
                        e.setName(personfileBaseInfo.getName());
                        if (xdataRelationReqDTO != null &&
                                (e.getAid().equalsIgnoreCase(xdataRelationReqDTO.getFromId()) || e.getAid().equalsIgnoreCase(xdataRelationReqDTO.getTargetId())
                                    || e.getAid().equalsIgnoreCase(xdataRelationReqDTO.getAid()))) {
                            e.setModifyTime("self");
                        }
                        for (PersonfileRelationEdgeVO personfileRelationEdgeVO : personfileRelationEdgeVOList) {
                            if (e.getAid().equalsIgnoreCase(personfileRelationEdgeVO.getFromId())
                                    || e.getAid().equalsIgnoreCase(personfileRelationEdgeVO.getTargetId())) {
                                if (labelNameMap.containsKey(personfileRelationEdgeVO.getLabel())) {
                                    String labelName = labelNameMap.get(personfileRelationEdgeVO.getLabel());
                                    e.setLabelName(Strings.isNotBlank(labelName) ? labelName : personfileRelationEdgeVO.getLabel());
                                    e.setLabel(personfileRelationEdgeVO.getLabel());
                                } else {
                                    e.setLabelName(e.getLabel());
                                }
                            }
                        }
                    }
                } catch (Exception e1) {
                    logger.error(e1.getMessage());
                }
            });
        }
        personfileRelationVerticeVOList.removeIf(Objects::isNull);
        personfileRelationEdgeVOList.removeIf(Objects::isNull);
    
        XdataRelationVO xdataRelationVO = new XdataRelationVO(personfileRelationEdgeVOList, personfileRelationVerticeVOList);
        
        xdataRelationVO.setSimilarsA(similarMap != null ? similarMap.get("fromSimilarList") : null);
        xdataRelationVO.setSimilarsB(similarMap != null ? similarMap.get("targetSimilarList") : null);
        return xdataRelationVO;
    }

    /**
     * 匹配英文
     *
     * @param paramValue
     * @return
     */
    private String codeCheck(String paramValue) {
        String regex = "^[A-Za-z]+$";
        Matcher matcher = Pattern.compile(regex).matcher(paramValue.trim());
        if (matcher.find()) {
            return matcher.group(0);
        }
        return null;
    }
    
    /**
     * 根据相似度和topNum过滤
     *
     * @param xdataRelationReqDTO 参数
     * @param personfileRelationVerticeVOList 结果集
     * @param isSingle 是否是单人图谱
     */
    private Map<String,List<SimilarArchiveVO>> toFilterBySimilarAndTopNum(boolean isSingle,XdataRelationReqDTO xdataRelationReqDTO,List<PersonfileRelationVerticeVO> personfileRelationVerticeVOList){
        // 获取高级管理配置
        List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(RelationshipDefaultFilterVO.class.getSimpleName());
        if (CollectionUtils.isNotEmpty(bigdataCommons)) {
            Map<String,List<SimilarArchiveVO>> similars = Maps.newHashMap();
            BigdataCommon bigdataCommon = bigdataCommons.get(0);
            JSONObject params = JSONObject.parseObject(bigdataCommon.getContent());
            
            Float similarScore = params.getFloat("similarScore");
    
            SimilarArchiveDTO similarArchiveDTO = new SimilarArchiveDTO();
            SimilarArchiveDTO.Params similarParams = similarArchiveDTO.new Params();
            similarParams.setThreshold((double)similarScore);
            similarParams.setNum(personPropertiest.getSimilarPersonFileMaxNum());
            similarArchiveDTO.setParams(similarParams);
            similarArchiveDTO.setBizCode(personPropertiest.getBizCode());
            if (isSingle) {
                similarParams.setFromId(xdataRelationReqDTO.getAid());
            } else {
                similarParams.setFromId(xdataRelationReqDTO.getFromId());
                JSONObject result = JSONObject.parseObject(analysisFeignClient.getSimilarArchives(similarArchiveDTO));
                List<SimilarArchiveVO> fromSimilarArchiveVOList = Lists.newArrayList();
                if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
                    fromSimilarArchiveVOList = JSONObject.parseArray(result.getString(ICommonConstant.ResultDataFormat.data), SimilarArchiveVO.class);
                }
    
                similarParams.setFromId(xdataRelationReqDTO.getTargetId());
                JSONObject result2 = JSONObject.parseObject(analysisFeignClient.getSimilarArchives(similarArchiveDTO));
                List<SimilarArchiveVO> targetSimilarArchiveVOList = Lists.newArrayList();
                if (SuccessRespUtil.isSuccess(result2) && result2.get(ICommonConstant.ResultDataFormat.data) != null) {
                    targetSimilarArchiveVOList = JSONObject.parseArray(result2.getString(ICommonConstant.ResultDataFormat.data), SimilarArchiveVO.class);
                }
    
                similars.put("fromSimilarList",fromSimilarArchiveVOList);
                similars.put("targetSimilarList",targetSimilarArchiveVOList);
                return similars;
            }
        }
        return null;
    }
    
    private List<PersonfileRelationVerticeVO> singleToFilterBySimilarAndTopNum(boolean isSingle,XdataRelationReqDTO xdataRelationReqDTO,List<PersonfileRelationVerticeVO> personfileRelationVerticeVOList){
        // 获取高级管理配置
        List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(RelationshipDefaultFilterVO.class.getSimpleName());
        if (CollectionUtils.isNotEmpty(bigdataCommons)) {
            BigdataCommon bigdataCommon = bigdataCommons.get(0);
            JSONObject params = JSONObject.parseObject(bigdataCommon.getContent());
            
            Integer topNum = params.getInteger("topNum");
            Float similarScore = params.getFloat("similarScore");
            
            SimilarArchiveDTO similarArchiveDTO = new SimilarArchiveDTO();
            SimilarArchiveDTO.Params similarParams = similarArchiveDTO.new Params();
            similarParams.setThreshold((double)similarScore);
            similarParams.setNum(personPropertiest.getSimilarPersonFileMaxNum());
            similarArchiveDTO.setParams(similarParams);
            similarArchiveDTO.setBizCode(personPropertiest.getBizCode());
            similarParams.setFromId(xdataRelationReqDTO.getAid());
            
            JSONObject result = JSONObject.parseObject(analysisFeignClient.getSimilarArchives(similarArchiveDTO));
            if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
                List<SimilarArchiveVO> similarArchiveVOList = JSONObject.parseArray(result.getString(ICommonConstant.ResultDataFormat.data), SimilarArchiveVO.class);
                List<PersonfileRelationVerticeVO> personfileRelationVerticeVOS = Lists.newLinkedList();
    
                List<PersonfileRelationVerticeVO> self = personfileRelationVerticeVOList.stream().filter(s -> s != null && s.getAid().equals(xdataRelationReqDTO.getAid())).collect(Collectors.toList());
                List<PersonfileRelationVerticeVO> others = personfileRelationVerticeVOList.stream().filter(s -> s != null && !s.getAid().equals(xdataRelationReqDTO.getAid())).collect(Collectors.toList());
                if (CollectionUtils.isEmpty(others)) {
                    return self;
                }
                for (PersonfileRelationVerticeVO verticeVO: others) {
                    if (CollectionUtils.isNotEmpty(similarArchiveVOList)) {
                        if (similarArchiveVOList.stream().anyMatch(s -> s.getArchiveId().equals(verticeVO.getAid()))) {
                            continue;
                        }
                    }
                    if (personfileRelationVerticeVOS.size() == topNum) {
                        break;
                    }
                    personfileRelationVerticeVOS.add(verticeVO);
                }
                personfileRelationVerticeVOS.addAll(self);
                return personfileRelationVerticeVOS;
            }
        }
        logger.error("单人关系去重异常");
        return null;
    }
    
}
