package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.entity.*;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.AnalysisTaskResultDTO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.ArchiveDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.BlockTrceMetaVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.EventDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.ResBlockInfoVO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashAreaService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisCrashService;
import com.intellif.cloud.personfile.manage.utils.BeanUtlis;
import com.intellif.cloud.personfile.manage.utils.DateUtils;
import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

/**
 * 数据分析碰撞结果处理器
 *
 * @author liuzj
 * @date 2019-07-19
 */
public class AnalysisMutiCrashResultHandler extends AbstractAnalysisSyncResultHandler {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private final BigdataAnalysisCrashService bigdataAnalysisCrashService = BeanUtlis.getBean(BigdataAnalysisCrashService.class);
    
    private final BigdataAnalysisCrashAreaService bigdataAnalysisCrashAreaService = BeanUtlis.getBean(BigdataAnalysisCrashAreaService.class);
    
    public AnalysisMutiCrashResultHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected void syncData(AnalysisTaskResultDTO analysisTaskResultDTO) {
        // 清除数据
        clearHistoryData(analysisTaskResultDTO);
        bigdataAnalysisCrashService.deleteBigdataAnalysisCrashByTaskId(analysisTaskResultDTO.getTaskId2());
        
        JSONObject result = getResult(analysisTaskResultDTO);
        
        Long taskId = analysisTaskResultDTO.getTaskId2();
        if (SuccessRespUtil.isSuccess(result) && result.get(ICommonConstant.ResultDataFormat.data) != null) {
            // 碰撞结果列表处理
            List<ArchiveDetailVO> crashResultVOList = JSONObject.parseArray(result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("targetInfos"), ArchiveDetailVO.class);
            String listResult = listHandle(crashResultVOList, taskId);
            
            // 碰撞详情处理
            List<ResBlockInfoVO> xdataCrashVOList = JSONObject.parseArray(result.getJSONObject(ICommonConstant.ResultDataFormat.data).getString("resBlockInfos"), ResBlockInfoVO.class);
            List<String> detailResult = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(xdataCrashVOList)) {
                List<BigdataAnalysisCrashArea> analysisCrashAreas = bigdataAnalysisCrashAreaService.findAnalysisCrashAreaByTaskId(analysisTaskResultDTO.getTaskId2());
                
                xdataCrashVOList.forEach((item) -> detailResult.add(detailHaldle(item.getTargetTraceInfos(), taskId, analysisCrashAreas.stream().filter(area -> area.getCode().equals(item.getBlockCode())).findAny().orElse(new BigdataAnalysisCrashArea()).getCode())));
            } else {
                detailResult.add("碰撞详情无数据。");
            }
           
            analysisTaskResultDTO.setRemark(listResult + Strings.join(detailResult,','));
            updateTaskStatus(analysisTaskResultDTO, true);
        } else {
            analysisTaskResultDTO.setRemark("多区域碰撞数据同步结束，" + (result != null ? result.getString(ICommonConstant.ResultDataFormat.respRemark) : ""));
            updateTaskStatus(analysisTaskResultDTO, false);
        }
    }
    
    /**
     * 碰撞结果处理
     *
     * @param crashResultVOList 数据集
     * @param taskId            后台任务ID
     */
    private String listHandle(List<ArchiveDetailVO> crashResultVOList, Long taskId) {
        
        if (CollectionUtils.isEmpty(crashResultVOList)) {
            logger.error("任务：" + taskId + " 碰撞结果无数据");
            return "碰撞结果无数据。";
        }
        
        List<String> personfileIds = crashResultVOList.stream().map(ArchiveDetailVO::getAid).collect(Collectors.toList());
        
        Map<String, Object> params = Maps.newHashMap();
        params.put("personFilesIds", personfileIds);
        List<PersonfileBasics> personfileBasicsList = subArchiveService.findAutoByParam(params);
        
        if (CollectionUtils.isEmpty(personfileBasicsList)) {
            logger.error("任务：" + taskId + " 碰撞结果导入，档案异常");
            return "碰撞结果导入，档案异常。";
        }
        
        PersonfileBasics personfileBasics;
        List<BigdataAnalysisArchive> analysisArchiveList = Lists.newArrayList();
        List<String> faceResult = Lists.newArrayList();
        for (ArchiveDetailVO crashResultVO : crashResultVOList) {
            personfileBasics = personfileBasicsList.stream().filter(personfile -> personfile.getPersonFilesId().equals(crashResultVO.getAid())).findAny().orElse(new PersonfileBasics());
            
            if (Strings.isBlank(personfileBasics.getPersonFilesId())) {
                continue;
            }
            
            BigdataAnalysisArchive bigdataAnalysisArchive = new BigdataAnalysisArchive();
            bigdataAnalysisArchive.setAid(crashResultVO.getAid());
            bigdataAnalysisArchive.setTaskId(taskId);
            bigdataAnalysisArchive.setCid(personfileBasics.getCid());
            bigdataAnalysisArchive.setPersonName(personfileBasics.getName());
            bigdataAnalysisArchive.setCurrAddr(personfileBasics.getDomicilePlace());
            bigdataAnalysisArchive.setFaceUrl(personfileBasics.getHeadImageUrl());
            bigdataAnalysisArchive.setImageCount(0);
            
            analysisArchiveList.add(bigdataAnalysisArchive);
            
            if (analysisArchiveList.size() == BATCH_INSERT_NUM) {
                bigdataAnalysisArchiveService.batchInsertAnalysisArchive(analysisArchiveList);
                analysisArchiveList.clear();
            }
            
            if (faceResult.size() < 4) {
                faceResult.add(personfileBasics.getHeadImageUrl());
            }
        }
        
        bigdataAnalysisArchiveService.batchInsertAnalysisArchive(analysisArchiveList);
        
        // 存入四张结果图片
        BigdataAnalysisTask bigdataAnalysisTask = bigdataAnalysisTaskService.findBigdataAnalysisTaskById(taskId);
        bigdataAnalysisTask.setResult(Strings.join(faceResult, ','));
        bigdataAnalysisTaskService.updateBigdataAnalysisTask(bigdataAnalysisTask);
        
        return "多区域碰撞列表结果同步成功！";
    }
    
    /**
     * 碰撞详情处理
     *
     * @param xdataCrashVOList 碰撞详情数据
     * @param taskId           后台任务ID
     */
    private String detailHaldle(List<BlockTrceMetaVO> xdataCrashVOList, Long taskId, String areaCode) {
        if (Strings.isBlank(areaCode)) {
            return areaCode + " areaCode 参数异常。";
        }

        if (CollectionUtils.isEmpty(xdataCrashVOList)) {
            logger.error("任务：" + taskId + " 碰撞结果详情无数据");
            return areaCode + " 碰撞结果详情无数据。";
        }

        // 按档案ID分组
        Map<String, List<BlockTrceMetaVO>> resultGroupByAid = xdataCrashVOList.stream().collect(Collectors.groupingBy(BlockTrceMetaVO::getAid));

        // 构造返回数据
        List<BigdataAnalysisCrash> crashList = Lists.newArrayList();
        List<BigdataAnalysisEvent> faces = Lists.newLinkedList();
        resultGroupByAid.forEach((key1, value1) -> {
            
            List<EventDetailVO> events = Lists.newArrayList();
            for (BlockTrceMetaVO blockTrceMetaVO: value1) {
                events.addAll(blockTrceMetaVO.getEvents());
            }
    
            // 去重
            events = events.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(EventDetailVO::getFaceId))), ArrayList::new));
    
            // 按时间分组
            Map<Long, List<EventDetailVO>> resultGroupByDate = events.stream().collect(Collectors.groupingBy(e -> e.getDate().getTime()));

            // 按摄像头分组
            List<Map<String, List<EventDetailVO>>> hadGroupByResult = Lists.newArrayList();
            resultGroupByDate.forEach((key2, value2) -> {
                if (CollectionUtils.isNotEmpty(value2)) {
                    Map<String, List<EventDetailVO>> resultGroupByCamera = value2.stream().collect(Collectors.groupingBy(EventDetailVO::getCameraId));
                    hadGroupByResult.add(resultGroupByCamera);
                }
            });

            Set<String> devIds = events.stream().map(xdataCrashVO -> xdataCrashVO.getCameraId()).collect(Collectors.toSet());
            List<PersonfileCamera> devs = iPersonfileCameraService.findCameraByDevIdList(new ArrayList<>(devIds));

            if (CollectionUtils.isNotEmpty(devs)) {
                for (Map<String, List<EventDetailVO>> hadGroupByResultItem : hadGroupByResult) {
                    hadGroupByResultItem.forEach((key, value) -> {
                        BigdataAnalysisCrash bigdataAnalysisCrash = new BigdataAnalysisCrash();
                        bigdataAnalysisCrash.setTaskId(taskId);
                        bigdataAnalysisCrash.setAid(key1);
                        PersonfileCamera dev = devs.stream().filter(d -> d.getDevId().equals(key)).findAny().orElse(new PersonfileCamera());
                        if (Strings.isNotBlank(dev.getDevId())) {
                            bigdataAnalysisCrash.setCameraId(dev.getDevId());
                            bigdataAnalysisCrash.setCameraName(dev.getName());
                            bigdataAnalysisCrash.setGeoString(dev.getGeoString());
                            try {
                                bigdataAnalysisCrash.setStartTime(org.apache.commons.lang3.time.DateUtils.parseDate(value.stream().min(comparing(EventDetailVO::getTime)).orElse(new EventDetailVO()).getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                                bigdataAnalysisCrash.setEndTime(org.apache.commons.lang3.time.DateUtils.parseDate(value.stream().max(comparing(EventDetailVO::getTime)).orElse(new EventDetailVO()).getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            bigdataAnalysisCrash.setDate(DateUtils.getDate(bigdataAnalysisCrash.getStartTime()));
                            bigdataAnalysisCrash.setAreaCode(areaCode);
                            if (CollectionUtils.isNotEmpty(value)) {
                                crashList.add(bigdataAnalysisCrash);

                                if (crashList.size() == BATCH_INSERT_NUM) {
                                    bigdataAnalysisCrashService.batchInsertAnalysisCrash(crashList);
                                    crashList.clear();
                                }

                                value.forEach(v -> {
                                    BigdataAnalysisEvent bigdataAnalysisEvent = new BigdataAnalysisEvent();
                                    bigdataAnalysisEvent.setFaceId(v.getFaceId());
                                    bigdataAnalysisEvent.setFaceUrl(v.getFaceUrl());
                                    try {
                                        bigdataAnalysisEvent.setTime(org.apache.commons.lang3.time.DateUtils.parseDate(v.getTime(),ICommonConstant.DateFormatType.Y_M_D_H_S).getTime());
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                    bigdataAnalysisEvent.setTaskId(taskId);
                                    bigdataAnalysisEvent.setCameraId(v.getCameraId());
                                    bigdataAnalysisEvent.setAid(key1);
                                    bigdataAnalysisEvent.setAreaCode(areaCode);
                                    bigdataAnalysisEvent.setDate(DateUtils.getDate(v.getDate().getTime()));
                                    bigdataAnalysisEvent.setImageUrl(v.getImageUrl());
                                    bigdataAnalysisEvent.setImageId(v.getImageId());
                                    bigdataAnalysisEvent.setTargetRect(v.getTargetRect());
                                    faces.add(bigdataAnalysisEvent);

                                    if (faces.size() == BATCH_INSERT_NUM) {
                                        bigdataAnalysisEventService.batchInsertAnalysisEvent(faces);
                                        faces.clear();
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });

        if (CollectionUtils.isNotEmpty(faces)) {
            bigdataAnalysisEventService.batchInsertAnalysisEvent(faces);
        }
        
        if (CollectionUtils.isNotEmpty(crashList)) {
            bigdataAnalysisCrashService.batchInsertAnalysisCrash(crashList);
        }

        return areaCode + " 多区域详情结果同步成功！";
    }
    
}
