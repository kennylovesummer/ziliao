/*
 * 文件名：IPersonFilesConstant.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年10月11日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.contants;

/**
 * 〈一句话简述该类/接口的功能〉
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @version 1.0
 * @date 2018年10月11日
 * @see IPersonFilesConstant
 * @since JDK1.8
 */

public interface IPersonFilesConstant extends ICommonConstant {
    /**
     * 删除标识
     */
    interface BaseByte {
        /**
         * 已删除
         */
        Byte IS_DELETE = 1;
        /**
         * 未删除
         */
        Byte IS_NOT_DELETE = 0;

    }

    /**
     * kafka
     */
    interface KafkaVar {

        /**
         * 档案id-use
         */
        String ARCHIVE_ID = "aid";

        /**
         * 档案身份证ID-use
         */
        String ARCHIVE_CID = "identityNo";

        /**
         * 年龄
         */
        String AGE = "age";
    }
}
