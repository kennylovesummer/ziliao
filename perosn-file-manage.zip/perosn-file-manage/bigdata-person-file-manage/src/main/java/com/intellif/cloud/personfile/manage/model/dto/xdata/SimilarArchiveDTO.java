package com.intellif.cloud.personfile.manage.model.dto.xdata;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

@Data
public class SimilarArchiveDTO {
    
    private String bizCode;
    
    private Object params;
    
    @Data
    public class Params {
        /**
         * 档案ID
         */
        private String fromId;
    
        /**
         * 相似度
         */
        private Double threshold;
    
        /**
         * 相似档案数量
         */
        private Integer num;
    
        @Override
        public String toString() {
            return JSONObject.toJSONString(this);
        }
    }
    
}
