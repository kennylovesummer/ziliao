package com.intellif.cloud.personfile.manage.services.general.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileRubbishService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileRubbishServiceImpl
 * @date 2019/3/15 14:25
 * @description
 */

@Service
public class PersonfileRubbishServiceImpl extends BaseServiceImpl implements PersonfileRubbishService {

    @Override
    public Page<PersonfileRubbish> findPersonfileRubbish(int pageNo, int pageSize) {
        QueryEvent event = new QueryEvent<>();
        event.setStatement("findPersonfileRubbish");
        PageHelper.startPage(pageNo, pageSize);
        List<PersonfileRubbish> personfileRubbishList = this.baseDao.findAllIsPageByCustom(event);
        return (Page<PersonfileRubbish>) personfileRubbishList;
    }

    @Override
    public int insertPersonfileRubbish(PersonfileRubbish personfileRubbish) {
        return this.baseDao.insert(personfileRubbish);
    }

    @Override
    public int deletePersonfileRubbish(PersonfileRubbish personfileRubbish) {
        return this.baseDao.update(personfileRubbish);
    }

    @Override
    public int insertBatchPersonfileRubbish(List<PersonfileRubbish> personfileRubbishes) {
        return this.baseDao.updateStatement("insertBatchPersonfileRubbish", personfileRubbishes);
    }

    @Override
    public List<Map<String, Object>> findPersonfileRubbishToCluster(BasePageReqDTO basePageReqDTO) {
        QueryEvent<BasePageReqDTO> event = new QueryEvent<>();
        event.setStatement("findPersonfileRubbishToCluster");
        event.setObj(basePageReqDTO);
        PageHelper.startPage(basePageReqDTO.getPage(), basePageReqDTO.getPerpage(),false);
        List<Map<String, Object>>  personfileRubbishList = this.baseDao.findAllIsPageByCustom(event);
        return personfileRubbishList;
    }

    @Override
    public void deleteByIds(List<Object> ids) {
        if (CollectionUtils.isNotEmpty(ids)) {
            this.baseDao.delete(ids);
        }
    }
}
