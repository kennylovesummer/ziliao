package com.intellif.cloud.personfile.manage.enums;

/**
 * 事件枚举类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月26日
 * @see EventTypeEnum
 * @since JDK1.8
 */
public enum EventTypeEnum {
    // 事件类型(0,全部, 1-抓拍，2-乘车，3-住宿)
    ALL(0, "全部"),

    CAPTURE(1, "抓拍"),

    RIDE(2, "乘车"),

    HOSTEL(3, "住宿");

    private int id;

    private String name;

    EventTypeEnum(int id, String name) {
        this.name = name;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static EventTypeEnum getById(int id) {
        for (EventTypeEnum c : EventTypeEnum.values()) {
            if (c.getId() == id) {
                return c;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return name;
    }

}
