package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.entity.PersonfileRelationShip;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;

import java.text.ParseException;
import java.util.List;

/**
 * @author liuyu
 * @className PersonfileRelationShipServiceImpl
 * @date 2019/4/15 10:49
 * @description
 */
public interface PersonfileRelationShipService {

    /**
     * 查询指定id的关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    PersonfileRelationShip findPersonfileRelationShipById(Integer id) throws BusinessException;

    /**
     * 添加关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    int insertPersonfileRelationShip(PersonfileRelationShip personfileRelationShip) throws BusinessException, ParseException;

    /**
     * 查询所有的关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    List<PersonfileRelationShip> findAllPersonfileRelationShip(String relationShipName) throws BusinessException;

    /**
     * 查询指定名称的关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    PersonfileRelationShip findPersonfileRelationShipByName(Integer id, String labelName, String label) throws BusinessException;

    /**
     * 修改关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    int updatePersonfileRelationShip(PersonfileRelationShip personfileRelationShip) throws BusinessException, ParseException;

    /**
     * 根据id删除关系
     *
     * @return
     * @throws BusinessException
     * @see
     */
    int deletePersonfileRelationShip(Integer id) throws BusinessException;
}
