package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileCamera;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.LingerDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.PeerDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisArchiveService;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisEventService;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileBaseInfoService;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * 活动规律分析
 *
 * @author lzj
 * @version v1.3.0
 * @date 2019年10月24日
 * @see ActivityAnalysisController
 * @since JDK1.8
 */
@Api(tags = "数据分析-活动规律分析")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.ACTIVITY)
public class ActivityAnalysisController implements Serializable {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    private PersonfileBaseInfoService personfileBaseInfoService;
    
    @Autowired
    private IPersonfileCameraService iPersonfileCameraService;
    
    @Autowired
    private BigdataAnalysisArchiveService bigdataAnalysisArchiveService;
    
    @Autowired
    private BigdataAnalysisEventService bigdataAnalysisEventService;
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    /**
     * 获取活动规律分析列表
     *
     * @param peerDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "分页获取活动人员列表")
    @PostMapping(value = "list")
    public BasePageRespDTO list(@RequestBody PeerDTO peerDTO) {
        try {
            // 参数校验
            if (peerDTO.getTaskId() == null) {
                return new BasePageRespDTO(null, 0,0, IResultCode.ERROR, "参数异常");
            }
    
            Page<BigdataAnalysisArchive> page = bigdataAnalysisArchiveService.findAnalysisArchiveByParams(peerDTO);
            List<BigdataAnalysisArchive> bigdataAnalysisArchiveList = page.getResult();
    
            if (CollectionUtils.isNotEmpty(bigdataAnalysisArchiveList)) {
//                List<Map<String, Object>> personfileBasicsList = subArchiveService.findByPersonfileIds(bigdataAnalysisArchiveList.stream().map(BigdataAnalysisArchive::getAid).collect(Collectors.toList()));
                for (BigdataAnalysisArchive item: bigdataAnalysisArchiveList) {
                    PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(item.getAid());
                    item.setImageCount(personfileBasics != null ? personfileBasics.getImageCount() : null);
                    item.setPersonName(personfileBasics != null ? personfileBasics.getName() : null);
                    item.setCid(personfileBasics != null ? personfileBasics.getCid() : null);
//                    item.setImageCount((Integer) personfileBasicsList.stream().filter(m -> item.getAid().equals(m.get("personFileId"))).findAny().orElse(Maps.newHashMap()).get("imageCount"));
                }
            }
            
            return new BasePageRespDTO(bigdataAnalysisArchiveList, page.getPages(),Integer.parseInt(page.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e){
            logger.error("徘徊档案结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR,ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
    /**
     * 获取活动规律分析详情
     *
     * @param lingerDTO
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "POST", value = "分页获取活动人员活动详情")
    @PostMapping(value = "detail")
    public BasePageRespDTO detail(@RequestBody LingerDTO lingerDTO) {
        try {
            // 参数校验
            if (lingerDTO.getTaskId() == null || Strings.isBlank(lingerDTO.getAid())) {
                return new BasePageRespDTO(null, 0,0, IResultCode.ERROR, "参数异常");
            }
    
            Page<BigdataAnalysisEvent> page = bigdataAnalysisEventService.findAnalysisEventByParams(lingerDTO);
            List<BigdataAnalysisEvent> eventList = page.getResult();
    
            if (CollectionUtils.isEmpty(eventList)) {
                return new BasePageRespDTO(null, 0, 0, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
    
            // 按时间分组
            Map<Long, List<BigdataAnalysisEvent>> resultGroupByDate = eventList.stream().collect(Collectors.groupingBy(e -> e.getDate()));
    
            // 按摄像头分组
            List<Map<String, List<BigdataAnalysisEvent>>> hadGroupByResult = Lists.newArrayList();
            resultGroupByDate.forEach((key2, value2) -> {
                if (CollectionUtils.isNotEmpty(value2)) {
                    Map<String, List<BigdataAnalysisEvent>> resultGroupByCamera = value2.stream().collect(Collectors.groupingBy(BigdataAnalysisEvent::getCameraId));
                    hadGroupByResult.add(resultGroupByCamera);
                }
            });
    
            Set<String> devIds = eventList.stream().map(xdataCrashVO -> xdataCrashVO.getCameraId()).collect(Collectors.toSet());
            List<PersonfileCamera> devs = iPersonfileCameraService.findCameraByDevIdList(new ArrayList<>(devIds));
            List<Map<String,Object>> result = Lists.newArrayList();
            for (Map<String, List<BigdataAnalysisEvent>> resultGroupByDateAndDevId: hadGroupByResult) {
                resultGroupByDateAndDevId.forEach((key, value) -> {
                    Map<String,Object> item = Maps.newHashMap();
                    if (CollectionUtils.isNotEmpty(value)) {
                        item.put("date",value.get(0).getDate());
                        item.put("cameraId",key);
                        item.put("cameraName",devs.stream().filter(d -> d.getDevId().equals(key)).findAny().orElse(new PersonfileCamera()).getName());
                        item.put("faces",value);
                        result.add(item);
                    }
                });
                
            }
            
            return new BasePageRespDTO(result, page.getPages(),Integer.parseInt(page.getTotal() + ""),IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage());
        } catch (Exception e){
            logger.error("徘徊事件结果查询异常：" + e.getMessage());
            return new BasePageRespDTO(null,0,0,IResultCode.ERROR,ResultMessageEnum.SEARCH_FAILED.getMessage(),e.getMessage());
        }
    }
    
}
