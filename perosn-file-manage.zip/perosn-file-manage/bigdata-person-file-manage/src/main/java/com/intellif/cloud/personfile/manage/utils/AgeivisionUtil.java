package com.intellif.cloud.personfile.manage.utils;

import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.Map;

/**
 * 年龄分布工具类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月27日
 * @see IdcardUtil
 * @since JDK1.8
 */
public class AgeivisionUtil {

    /**
     * 根据年龄返回年龄划分id和名称
     * 年龄划分id: 0-unknown，1-baby， 2-child，3-teenager，4-pre-adult，5-yong，6-mature，7-midlift，8-middle-aged，9-old man
     *
     * @param age 年龄
     * @return 年龄划分id
     */
    public static int getAgeivisionByAge(int age) {
        // baby、child、teenager、pre-adult、yong、mature、midlift、middle-aged、old man
        if (age == 0) {
            return 0;
        } else if (age > 0 && age <= 5) {
            return 1;
        } else if (age > 5 && age <= 10) {
            return 2;
        } else if (age > 10 && age <= 15) {
            return 3;
        } else if (age > 15 && age <= 20) {
            return 4;
        } else if (age > 20 && age <= 25) {
            return 5;
        } else if (age > 25 && age <= 30) {
            return 6;
        } else if (age > 30 && age <= 50) {
            return 7;
        } else if (age > 50 && age <= 60) {
            return 8;
        } else {
            return 9;
        }
    }

    /**
     * 根据年龄ID获取该年龄对应的类型
     *
     * @param ageId 年龄ID
     * @return String
     */
    public static String getAgeType(int ageId){
        switch (ageId){
            case 0:
                return "未知";
            case 1:
                return "婴儿";
            case 2:
                return "小孩";
            case 3:
                return "少年";
            case 4:
                return "青少年";
            case 5:
                return "青年";
            case 6:
                return "中年";
            case 7:
                return "壮年";
            case 8:
                return "中老年";
            case 9:
                return "老年";
            default:
                return "未知";

        }
    }

    /**
     * 根据身份证,返回年龄划分id
     *
     * @param idCard
     * @return
     */
    public static int getAgeivisionByIDCard(String idCard) {
        return getAgeivisionByAge(IdcardUtil.idNOToAge(idCard));
    }

    /**
     * 将从搜索引擎那边传过来的数据进行转换（如果是0、1、2则不进行转换）
     *
     * @param param     待转换的int类型参数
     * @param fromIndex 从后几位开始截取
     * @return int
     */
    public static int changeFromBinToInt(Integer param, Integer fromIndex) {
        if (param == null) {
            return 0;
        }

        String binParam = Integer.toBinaryString(param);

        if (param == 0 || param == 1 || param == 2 || fromIndex == null || fromIndex == binParam.length()) {
            return param;
        }

        if (StringUtils.isNotBlank(binParam) && binParam.length() > fromIndex) {
            try {
                BigInteger newParam = new BigInteger(binParam.substring(binParam.length() - fromIndex), 2);
                return Integer.parseInt(newParam.toString());
            } catch (Exception e) {
                return 0;
            }
        }

        return 0;
    }

    /**
     * 从身份证获取年龄
     *
     * @param cid 身份证
     * @return int
     */
    public static Map<String, Object> getBirAgeSex(String cid) {
        String birthday = "";
        Integer age = 0;
        Integer sex = 0;

        int year = Calendar.getInstance().get(Calendar.YEAR);
        if (StringUtils.isBlank(cid)) {
            Map<String, Object> map = Maps.newHashMap();
            map.put("birthday", "");
            map.put("age", age);
            map.put("sex", sex);
            return map;
        }
        char[] number = cid.toCharArray();
        boolean flag = true;
        if (number.length == 15) {
            for (int x = 0; x < number.length; x++) {
                if (!flag) {
                    return Maps.newHashMap();
                }
                flag = Character.isDigit(number[x]);
            }
        } else if (number.length == 18) {
            for (int x = 0; x < number.length - 1; x++) {
                if (!flag) {
                    return Maps.newHashMap();
                }
                flag = Character.isDigit(number[x]);
            }
        }
        if (flag && cid.length() == 15) {
            birthday = "19" + cid.substring(6, 8) + "-"
                    + cid.substring(8, 10) + "-"
                    + cid.substring(10, 12);
            sex = Integer.parseInt(cid.substring(cid.length() - 3)) % 2 == 0 ? 1 : 2;
            age = (year - Integer.parseInt("19" + cid.substring(6, 8)));
        } else if (flag && cid.length() == 18) {
            birthday = cid.substring(6, 10) + "-"
                    + cid.substring(10, 12) + "-"
                    + cid.substring(12, 14);
            sex = Integer.parseInt(cid.substring(cid.length() - 4, cid.length() - 1)) % 2 == 0 ? 2 : 1;
            age = (year - Integer.parseInt(cid.substring(6, 10)));
        }

        // 异常年龄和性别处理
        if (age < 0) {
            age = 0;
        }

        Map<String, Object> map = Maps.newHashMap();
        map.put("birthday", StringUtils.isBlank(birthday) ? null : birthday);
        map.put("age", age);
        map.put("sex", sex);
        return map;
    }

}
