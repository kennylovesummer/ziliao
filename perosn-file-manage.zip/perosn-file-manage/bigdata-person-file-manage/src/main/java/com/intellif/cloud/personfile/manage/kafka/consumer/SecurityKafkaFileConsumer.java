package com.intellif.cloud.personfile.manage.kafka.consumer;

import com.bigdata.mq.kafka.consumer.AbstractSecurityKafkaConsumer;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;

import java.util.Collection;
import java.util.Properties;

/**
 * 档案消费者类AbstractSecurityKafkaConsumer
 */
public class SecurityKafkaFileConsumer extends AbstractSecurityKafkaConsumer {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private MqMessageHandle mqMessageHandle;

    public SecurityKafkaFileConsumer(final MqMessageHandle mqMessageHandle, Properties props, String... topic) {
        super(props, topic);
        this.mqMessageHandle = mqMessageHandle;
    }

    @Override
    public void receive(String s) {

    }

    @Override
    public void receive(Collection<String> list) {
        try {
            if (CollectionUtils.isNotEmpty(list)) {
                mqMessageHandle.archiveHandle(list);
            }
        } catch (Exception e){
            logger.error("档案kafka同步异常：" + e.getMessage());
            throw e;
        }
    }
}
