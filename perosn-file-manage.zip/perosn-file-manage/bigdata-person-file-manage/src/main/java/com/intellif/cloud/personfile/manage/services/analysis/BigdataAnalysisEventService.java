package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisEvent;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.EventDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;

import java.util.List;
import java.util.Map;

/**
 * 数据分析事件
 *
 * @author liuzj
 * @date 2019-07-18
 */
public interface BigdataAnalysisEventService {
    
    /**
     * 根据ID查找
     *
     * @param id ID
     * @return entity
     */
    BigdataAnalysisEvent findAnalysisEventById(Long id);
    
    /**
     * 根据ID删除对象
     *
     * @param bigdataAnalysisEvent 要删除的对象
     */
    void deleteAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisEvent 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent);
    
    /**
     * 批量插入事件
     *
     * @param eventList 事件集合
     */
    void batchInsertAnalysisEvent(List<BigdataAnalysisEvent> eventList);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisEvent 待更新的对象
     */
    void updateAnalysisEvent(BigdataAnalysisEvent bigdataAnalysisEvent);
    
    /**
     * 分页查找
     *
     * @param eventDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisEvent> findAnalysisEventByParams(AnalysisDTO eventDTO);
    
    /**
     * 查找开始时间和结束时间
     *
     * @param eventDTO 参数集合
     * @return map(startTime,endTime,imageCount)
     */
    Map<String,Long> findMaxTimeAndMinTimeByParams(AnalysisDTO eventDTO);
    
    /**
     * 根据任务ID删除
     *
     * @param taskId 任务ID
     */
    void deleteBigdataAnalysisEventByTaskId(Long taskId);
    
    /**
     * 根据条件统计数量
     *
     * @param eventDTO 参数集
     * @return Long
     */
    Long findCountByParams(EventDTO eventDTO);
    
    /**
     * 根据任务ID和档案ID分页查找最大时间和最小时间
     *
     * @param eventDTO
     * @return min( date ) & max( date )
     */
    Map<String,Long> findMaxMinDateByPage(AnalysisDTO eventDTO);
}
