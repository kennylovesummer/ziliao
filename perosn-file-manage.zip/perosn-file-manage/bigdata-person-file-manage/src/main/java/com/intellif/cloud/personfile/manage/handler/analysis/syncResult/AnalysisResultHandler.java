package com.intellif.cloud.personfile.manage.handler.analysis.syncResult;

import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;

/**
 * 数据分析结果导入
 *
 * @author liuzj
 * @date 2019-07-19
 */
public class AnalysisResultHandler {
    
    
    private static final AbstractAnalysisSyncResultHandler peerResultHandler = new AnalysisPeerResultHandler(DataStisticTypeEnum.PEER.getResultName());
    
    private static final AbstractAnalysisSyncResultHandler traceResultHandler = new AnalysisTraceResultHandler(DataStisticTypeEnum.TRACE.getResultName());
    
    private static final AbstractAnalysisSyncResultHandler mutiCrashResultHandler = new AnalysisMutiCrashResultHandler(DataStisticTypeEnum.CRASH.getResultName());
    
    private static final AbstractAnalysisSyncResultHandler lingerResultHandler = new AnalysisLingerResultHandler(DataStisticTypeEnum.LINGER.getResultName());
    
    private static final AbstractAnalysisSyncResultHandler activityResultHandler = new AnalysisActivityResultHandler(DataStisticTypeEnum.ACTIVITY.getResultName());
    
    private static final AbstractAnalysisSyncResultHandler nocturnalResultHandler = new AnalysisNocturnalResultHandler(DataStisticTypeEnum.NOCTURNAL.getResultName());
    
    static {
        peerResultHandler.setNextHandler(traceResultHandler);
        traceResultHandler.setNextHandler(mutiCrashResultHandler);
        mutiCrashResultHandler.setNextHandler(lingerResultHandler);
        lingerResultHandler.setNextHandler(activityResultHandler);
        activityResultHandler.setNextHandler(nocturnalResultHandler);
    }
    
    
    /**
     * 获取结果导入处理链
     *
     * @return AbstractAnalysisSyncResultHandler
     */
    public static AbstractAnalysisSyncResultHandler getHandlerChain(){
        return peerResultHandler;
    }
}
