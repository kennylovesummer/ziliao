package com.intellif.cloud.personfile.manage.services.sub;

import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.DBHandoverUtil;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.log.LoggerUtilI;
import org.apache.ibatis.session.SqlSession;

import java.math.BigInteger;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 分表基础操作
 *
 * @param <T>
 * @author liuzj
 * @date 2019-08-22
 */
public abstract class AbstractSubService<T> extends BaseServiceImpl implements SubService<T> {
    
    private final LoggerUtilI LOG = LoggerUtilI.getLogger(this.getClass().getName());
    
    public static final ConcurrentHashMap<String, List<String>> TABLE_CACHE = new ConcurrentHashMap();
    
    public static final ConcurrentHashMap<String, List<String>> SLAVE_TABLE_CACHE = new ConcurrentHashMap();
    
    protected static final ConcurrentHashMap<String, Long> CURRENT_TABLE_COUNT = new ConcurrentHashMap();
    
    private final Map<String, Object> PARAMS = new HashMap<>();
    
    private final QueryEvent QUERYE_VENT = new QueryEvent();
    
    private static final Object LOCK = new Object();
    
    public List<String> getAllTableFromDB(Boolean ignoreCache, Boolean isSlave) {
        
        if (isSlave) {
            if (!SLAVE_TABLE_CACHE.isEmpty() && !ignoreCache) {
                return SLAVE_TABLE_CACHE.get("tables");
            }
        } else {
            if (!TABLE_CACHE.isEmpty() && !ignoreCache) {
                return TABLE_CACHE.get("tables");
            }
        }
        
        if (isSlave) {
            DBHandoverUtil.slave();
        } else {
            DBHandoverUtil.master();
        }
        
        List<String> tableNames = new ArrayList<>();
        ResultSet rs = null;
        SqlSession sqlSession = null;
        try {
            sqlSession = this.baseDao.getSessionFactory().openSession(true);
            DatabaseMetaData db = sqlSession.getConnection().getMetaData();
            rs = db.getTables(null, null, null, new String[]{"TABLE"});
            while (rs.next()) {
                String tableName = rs.getString(3);
                if ("t_bigdata_archive".equals(tableName) || "t_bigdata_avatar_info".equals(tableName) || "t_bigdata_event".equals(tableName)) {
                    continue;
                }
                tableNames.add(tableName);
            }
        } catch (Exception e) {
            e.printStackTrace();
//            LOG.error("Get all table failed", e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (sqlSession != null) {
                    sqlSession.close();
                }
            } catch (SQLException e) {
                LOG.error("Close ResultSet failed", e);
            }
        }
        
        if (isSlave) {
            SLAVE_TABLE_CACHE.put("tables", tableNames);
        } else {
            TABLE_CACHE.put("tables", tableNames);
        }
        
        initTableCount("t_bigdata_");
        return tableNames;
    }
    
    public String createTableIfNotExist(String originTable, String tableName, String createSQL, Long incCount, Long maxCount) {
        synchronized (LOCK) {
            Long currentCount = CURRENT_TABLE_COUNT.get(tableName);
            CURRENT_TABLE_COUNT.put(tableName, currentCount != null ? (currentCount + incCount) : incCount);
            String newTableName = tableName;
            if (!isExist(tableName, false)) {
                boolean exist = (createTable(createSQL) == 0);
                if (exist) {
                    getAllTableFromDB(true, false);
                    getAllTableFromDB(true, true);
                }
            } else {
                if (CURRENT_TABLE_COUNT.get(tableName) > maxCount) {
                    String[] tns = tableName.split(ICommonConstant.Symbol.UNDERLINE);
                    if (tableName.contains("extend")) {
                        tns[tns.length - 1] = System.currentTimeMillis() + "";
                        newTableName = String.join(ICommonConstant.Symbol.UNDERLINE, tns);
                    } else {
                        newTableName = tableName + "_extend_" + System.currentTimeMillis();
                    }
                    
                    for (String tn : CURRENT_TABLE_COUNT.keySet()) {
                        if (tn.contains(originTable) && CURRENT_TABLE_COUNT.get(tn) < maxCount) {
                            newTableName = tn;
                            break;
                        }
                    }
                    createSQL = createSQL.replaceAll(tableName, newTableName);
                    createTableIfNotExist(originTable, newTableName, createSQL, incCount, maxCount);
                }
            }
            return newTableName;
        }
    }
    
    protected Long createTable(String creatsql) {
        Statement statement = null;
        SqlSession sqlSession = null;
        try {
            DBHandoverUtil.master();
            sqlSession = this.baseDao.getSessionFactory().openSession(true);
            statement = sqlSession.getConnection().createStatement();
            
            return statement.executeLargeUpdate(creatsql);
        } catch (Exception e) {
            LOG.error("Create table failed", e);
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
                if (sqlSession != null) {
                    sqlSession.close();
                }
            } catch (SQLException e) {
                LOG.error("Close connection failed", e);
            }
        }
        return 0L;
    }
    
    /**
     * 判断表是否存在
     *
     * @param tableName 表名
     * @return boolean
     */
    protected boolean isExist(String tableName, Boolean isSlave) {
        List<String> tableNames = getAllTableFromDB(false, isSlave);
        return tableNames.contains(tableName);
    }
    
    public void initTableCount(String tableName) {
        PARAMS.put("tableName", tableName);
        PARAMS.put("dbName", "person_file_manage");
        QUERYE_VENT.setStatement("findTablesInfoByName");
        QUERYE_VENT.setParameter(PARAMS);
        List<Map<String, Object>> tableInfos = (List<Map<String, Object>>) this.baseDao.findAllIsPageByCustom(QUERYE_VENT);
        BigInteger tableRows;
        for (Map<String, Object> info : tableInfos) {
            if ("t_bigdata_archive_label_record".equals(info.get("TABLE_NAME"))) {
                continue;
            }
            tableRows = (BigInteger) info.get("TABLE_ROWS");
            CURRENT_TABLE_COUNT.put((String) info.get("TABLE_NAME"), tableRows.longValue());
        }
    }
    
    public static int hash(String aid, Integer tableNum) {
        return Math.abs(aid.hashCode()) % tableNum;
    }
    
}
