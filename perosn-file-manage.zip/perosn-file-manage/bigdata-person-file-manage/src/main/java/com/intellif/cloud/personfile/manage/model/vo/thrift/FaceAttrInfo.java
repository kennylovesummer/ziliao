package com.intellif.cloud.personfile.manage.model.vo.thrift;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @Description :
 * @Author dyl
 * @Date 15:18 2018/12/28
 */
public class FaceAttrInfo {


    // 质量分值
    private String attributes;

    // pose json
    private String faceRect;

    @JSONField(name = "attributes")
    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    @JSONField(name = "face_rect")
    public String getFaceRect() {
        return faceRect;
    }

    public void setFaceRect(String faceRect) {
        this.faceRect = faceRect;
    }
}
