package com.intellif.cloud.personfile.manage.utils;


import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.*;
import java.util.*;

/**
 * 日期的工具类
 *
 * @author wangyi
 */
public class DeepDateUtil {
    
    /**
     * 时间戳转时间字符串
     * 154100160
     *
     * @param time 时间戳 yyyy-MM-dd
     * @return
     */
    public static String timeStampYMDToString(String time) {
        Long timeLong = Long.parseLong(time);
        //要转换的时间格式
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        return sdf.format(timeLong);
    }
    
    /**
     * 时间戳转时间字符串
     * 1539850141000
     *
     * @param time 时间戳 yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static String timeStampToString(String time) {
        Long timeLong = Long.parseLong(time);
        //要转换的时间格式
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Date date;
        try {
            date = sdf.parse(sdf.format(timeLong));
            return sdf.format(date);
        } catch (ParseException e) {
            return null;
        }
    }
    
    
    /**
     * 时间戳获取前一天时间字符串
     * 1539850141000
     *
     * @param time 时间戳 yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static String timeStampToPreString(String time) {
        Long timeLong = Long.parseLong(time);
        //要转换的时间格式
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Date date;
        try {
            date = sdf.parse(sdf.format(timeLong));
            date = DateUtils.addDays(date, -1);
            return sdf.format(date);
        } catch (ParseException e) {
            return null;
        }
    }
    
    /**
     * 时间戳转Date
     *
     * @param time 时间戳
     * @return
     */
    public static Date timeStampToDate(String time) {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        try {
            return format.parse(format.format(new Long(time)));
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * 返回当前的时间前或后的n分钟的时间
     *
     * @param minutes 负数 为前,例如-10，代表前10分钟 整数 为后,例如10,代表10分钟后
     * @return
     */
    public static String firstMinutes(int minutes) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + minutes);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S).format(calendar.getTime());
    }
    
    /**
     * 返回当前的时间前或后的n小时的时间
     *
     * @param hour 负数 为前,例如-10，代表前10小时 整数 为后,例如10,代表10小时
     * @return
     */
    public static String firstHours(int hour) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + hour);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S).format(calendar.getTime());
    }
    
    /**
     * 返回当前的时间前或后的n小时的时间
     *
     * @param hour 负数 为前,例如-10，代表前10小时 整数 为后,例如10,代表10小时
     * @return
     */
    public static String firstHours(int hour, String DateFormatType) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + hour);
        return new SimpleDateFormat(DateFormatType).format(calendar.getTime());
    }
    
    /**
     * 返回当前的时间前或后的n天的时间
     *
     * @param day 负数 为前,例如-10，代表前10天 整数 为后,例如10,代表10天
     * @return
     */
    public static String firstDay(int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + day);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S).format(calendar.getTime());
    }
    
    /**
     * 返回当前时间
     *
     * @return
     */
    public static String nowDate() {
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S).format(new Date());
    }
    
    /**
     * 返回当前时间 localDate
     *
     * @return
     */
    public static String getLocalDate() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(ICommonConstant.DateFormatType.Y_M_D_H_S));
    }
    
    /**
     * 返回当前时间 localDate的yyyy-MM-dd格式
     *
     * @return
     */
    public static String getLocalDateYMD() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(ICommonConstant.DateFormatType.Y_M_D));
    }
    
    /**
     * String转Date yyyy-MM-dd HH:mm:ss
     *
     * @param datetime 时间
     * @return
     */
    public static Date stringToDateYMDHS(String datetime) {
        if (StringUtils.isBlank(datetime)) {
            return null;
        }
        SimpleDateFormat f = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        try {
            return f.parse(datetime);
        } catch (ParseException e) {
            return null;
        }
    }
    
    /**
     * 获取本月的第一天的时间,格式 yyyy-MM-dd HH:mm:ss
     *
     * @return
     */
    public static String getFirstMonth() {
        Calendar ca = Calendar.getInstance();
        SimpleDateFormat f = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        int minmum = ca.getActualMinimum(Calendar.DAY_OF_MONTH);
        int day = ca.get(Calendar.DAY_OF_MONTH);
        Calendar cal = (Calendar) ca.clone();
        cal.add(Calendar.DATE, minmum - day);
        return f.format(cal.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取本月的最后一天的时间,格式 yyyy-MM-dd HH:mm:ss
     *
     * @return
     */
    public static String getLastMonth() {
        Calendar ca = Calendar.getInstance();
        SimpleDateFormat f = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        int maximum = ca.getActualMaximum(Calendar.DAY_OF_MONTH);
        int day = ca.get(Calendar.DAY_OF_MONTH);
        Calendar cal = (Calendar) ca.clone();
        cal.add(Calendar.DATE, maximum - day);
        return f.format(cal.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取本周一的时间
     *
     * @return
     */
    public static String getFirstWeek() {
        Calendar cal = Calendar.getInstance();
        // 获得当前日期是一个星期的第几天
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (1 == dayWeek) {
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        // 设置一个星期的第一天，按中国的习惯一个星期的第一天是星期一
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        // 获得当前日期是一个星期的第几天
        int day = cal.get(Calendar.DAY_OF_WEEK);
        // 根据日历的规则，给当前日期减去星期几与一个星期第一天的差值
        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - day);
        SimpleDateFormat f = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        return f.format(cal.getTime()) + " 00:00:00";
    }
    
    /**
     * 判断该日期是否是该月的第一天
     *
     * @param date 需要判断的日期
     * @return
     */
    public static boolean isFirstDayOfMonth(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH) == 1;
    }
    
    /**
     * 判断该日期是否是周一
     *
     * @param date 需要判断的日期
     * @return
     */
    public static boolean isFirstDayOfWeek(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_WEEK) == 1;
    }
    
    /**
     * 获取时间是当年的第几周
     *
     * @param date
     * @return
     */
    public static Integer getDayWeekOfYear(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setTime(date);
        return calendar.get(Calendar.WEEK_OF_YEAR);
    }
    
    /**
     * 获取时间是当年的第几周
     *
     * @param time 时间,string类型,格式yyyy-MM-dd
     * @return
     */
    public static Integer getDayWeekOfYear(String time) {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        try {
            getDayWeekOfYear(format.parse(time));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 获取时间是当年的第几月
     *
     * @param date
     * @return
     */
    public static Integer getMonth(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MONDAY) + 1;
    }
    
    /**
     * 获取年
     *
     * @param date
     * @return
     */
    public static Integer getYear(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.YEAR);
    }
    
    /**
     * 当年第一天
     *
     * @param date 日期
     * @return yyyy-MM-dd 00:00:00
     */
    public static String getYearFirstDay(Date date) {
        return getYear(date) + "-01-01 00:00:00";
    }
    
    /**
     * 获取某年最后一天日期
     *
     * @param date
     * @return Date
     */
    public static String getYearLastDay(Date date) {
        return getYear(date) + "-12-31 59:59:59";
    }
    
    /**
     * 获取这个月的第一天
     *
     * @param date
     * @return yyyy-MM-dd 00:00:00
     */
    public static String getMonthFirstDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, 0);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取这个月的最后一天
     *
     * @param date
     * @return yyyy-MM-dd 59:59:59
     */
    public static String getMonthLastDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 59:59:59";
    }
    
    /**
     * 获取周一的时间
     *
     * @param date
     * @return yyyy-MM-dd 00:00:00
     */
    public static String getWeekMonday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        // 获得当前日期是一个星期的第几天
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (1 == dayWeek) {
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        // 设置一个星期的第一天，按中国的习惯一个星期的第一天是星期一
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        // 获得当前日期是一个星期的第几天
        int day = cal.get(Calendar.DAY_OF_WEEK);
        // 根据日历的规则，给当前日期减去星期几与一个星期第一天的差值
        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - day);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(cal.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取周日时间
     *
     * @return yyyy-MM-dd 59:59:59
     */
    public static String getWeekSunday(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int day_of_week = c.get(Calendar.DAY_OF_WEEK) - 1;
        if (day_of_week == 0) {
            day_of_week = 7;
        }
        c.add(Calendar.DATE, -day_of_week + 7);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(c.getTime()) + " 59:59:59";
    }
    
    /**
     * 获取当前时间的小时
     *
     * @param date
     * @return
     */
    public static Integer getHour(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        // HOUR_OF_DAY:24小时制
        return calendar.get(Calendar.HOUR_OF_DAY);
    }
    
    /**
     * 获取 当年的第几天
     *
     * @param date
     * @return
     */
    public static Integer getDayOfYear(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_YEAR);
    }
    
    /**
     * 获得当天零时零分零秒
     *
     * @return
     */
    public static String getFirstDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取当前时间的年月日
     *
     * @return
     */
    public static String getNowDateYMD() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime());
    }
    
    /**
     * 获得当天零时零分零秒
     *
     * @return
     */
    public static String getFirstDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 00:00:00";
    }
    
    /**
     * 获取前n天的时间
     * param  day   前n天
     *
     * @param time 时间字符串
     * @return
     */
    public static String getBeforeDay(int day, String time) {
        if (0 == day) {
            return time;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(sdf.parse(time));
            cal.add(Calendar.DATE, day);
            return sdf.format(cal.getTime());
        } catch (ParseException e) {
            return time;
        }
    }
    
    /**
     * 获得当天23时23分23
     *
     * @return
     */
    public static String getLastDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 23:59:59";
    }
    
    /**
     * 获得当前小时的0分0秒
     *
     * @return
     */
    public static String getHourStart(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int hour = getHour(date);
        if (hour < 10) {
            return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 0" + hour
                    + ":00:00";
        }
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " " + hour
                + ":00:00";
    }
    
    /**
     * 获得当前小时的59分59秒
     *
     * @return
     */
    public static String getHourEnd(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int hour = getHour(date);
        if (hour < 10) {
            return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " 0" + hour
                    + ":59:59";
        }
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(calendar.getTime()) + " " + hour
                + ":59:59";
    }
    
    /**
     * 计算本周第一天
     *
     * @param dataStr
     * @return
     * @throws ParseException
     * @see
     */
    public static String getFirstAndLastOfWeek(String dataStr) throws ParseException {
        // 设置时间格式
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar cal = Calendar.getInstance();
        Date time = sdf.parse(dataStr);
        cal.setTime(time);
        
        // 判断要计算的日期是否是周日，如果是则减一天计算周六的，否则会出问题，计算到下一周去了
        // 获得当前日期是一个星期的第几天
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (1 == dayWeek) {
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        // 设置一个星期的第一天，第一天为周日
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        // 获得当前日期是一个星期的第几天
        int day = cal.get(Calendar.DAY_OF_WEEK);
        // 根据日历的规则，给当前日期减去星期几与一个星期第一天的差值
        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - day);
        
        return sdf.format(cal.getTime());
    }
    
    /**
     * 计算本周是本年第几周
     *
     * @param
     * @return
     * @throws ParseException
     * @see
     */
    public static Integer getWeekIndex(String dateString) {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Date date = null;
        try {
            date = format.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setTime(date);
        Integer weekIndex = calendar.get(Calendar.WEEK_OF_YEAR);
        return weekIndex;
    }
    
    /**
     * 计算上一周同期的日期
     *
     * @param date
     * @return
     * @throws Exception
     * @see
     */
    public static String getLastDayByWeek(String date) throws ParseException {
        
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Calendar c = Calendar.getInstance();
        
        // 过去七天
        c.setTime(format.parse(date));
        c.add(Calendar.DATE, -7);
        Date d = c.getTime();
        String day = format.format(d);
        
        return day;
    }
    
    /**
     * 计算昨天相同的日期
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String frontDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar cal = Calendar.getInstance();
        cal.setTime(format.parse(today));
        cal.add(Calendar.DATE, -1);
        Date time = cal.getTime();
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(time);
    }
    
    /**
     * 计算上个月同一天
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String getLastMonthSameDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Calendar c = Calendar.getInstance();
        c.setTime(format.parse(today));
        
        c.add(Calendar.MONTH, -1);
        
        Date m = c.getTime();
        
        String mon = format.format(m);
        return mon;
    }
    
    /**
     * 计算上个月同一天日期
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String getLastDateMonthSameDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar c = Calendar.getInstance();
        c.setTime(format.parse(today));
        
        c.add(Calendar.MONTH, -1);
        
        Date m = c.getTime();
        
        String mon = format.format(m);
        return mon;
    }
    
    /**
     * 计算上半年同一天
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String getLasthalfYearSameDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Calendar c = Calendar.getInstance();
        c.setTime(format.parse(today));
        
        c.add(Calendar.MONTH, -6);
        
        Date m = c.getTime();
        
        String mon = format.format(m);
        return mon;
    }
    
    /**
     * 计算去年同一天
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String getLastYearSameDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        Calendar c = Calendar.getInstance();
        c.setTime(format.parse(today));
        
        c.add(Calendar.YEAR, -1);
        
        Date m = c.getTime();
        
        String mon = format.format(m);
        return mon;
    }
    
    /**
     * 计算当月第一天
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String getFirstDayForMonth(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        
        // 获取当月的第一天
        Calendar c = Calendar.getInstance();// 获取当前日期
        c.setTime(format.parse(today));
        c.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号,当前日期既为本月第一天
        return format.format(c.getTime());
        
    }
    
    /**
     * 计算几天前的日期的日期
     *
     * @param
     * @return
     * @throws Exception
     * @see
     */
    public static String getPastDate(String today, int n) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(format.parse(today));
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - n);
        Date d = calendar.getTime();
        String result = format.format(d);
        return result;
    }
    
    public static int differentDays(String date1, String date2) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(format.parse(date1));
        
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(format.parse(date2));
        int day1 = cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);
        
        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if (year1 != year2) // 同一年
        {
            int timeDistance = 0;
            for (int i = year1; i < year2; i++) {
                if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) // 闰年
                {
                    timeDistance += 366;
                } else // 不是闰年
                {
                    timeDistance += 365;
                }
            }
            
            return timeDistance + (day2 - day1);
        } else // 不同年
        {
            // System.out.println("判断day2 - day1 : " + (day2-day1));
            return day2 - day1;
        }
    }
    
    public static String dateToWeek(String datetime) {
        SimpleDateFormat f = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar cal = Calendar.getInstance(); // 获得一个日历
        Date datet = null;
        try {
            datet = f.parse(datetime);
            cal.setTime(datet);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1; // 指示一个星期中的某天。
        if (w < 0) {
            w = 0;
        }
        
        return weekDays[w];
    }
    
    public static String lastMonthFirstDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        // 获取前月的第一天
        Calendar calendar = Calendar.getInstance();// 获取当前日期
        calendar.setTime(format.parse(today));
        calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号,当前日期既为本月第一天
        String firstDay = format.format(calendar.getTime());
        return firstDay;
    }
    
    public static String currentMonthLastDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(format.parse(today));
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        String last = format.format(calendar.getTime());
        return last;
    }
    
    public static String currentWeekLastDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar cal = Calendar.getInstance();
        cal.setTime(format.parse(today));
        int d = 0;
        if (cal.get(Calendar.DAY_OF_WEEK) == 1) {
            d = -6;
        } else {
            d = 2 - cal.get(Calendar.DAY_OF_WEEK);
        }
        cal.add(Calendar.DAY_OF_WEEK, d);
        // 所在周结束日期
        String data2 = format.format(cal.getTime());
        return data2;
    }
    
    /**
     * 字符串转时间Date Y_M_D_H_S
     *
     * @param str
     * @return
     * @throws ParseException
     * @see
     */
    public static Date strToDateTime(String str) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S);
        return formatter.parse(str);
    }
    
    /**
     * 字符串转日期Date Y_M_D
     *
     * @param str
     * @return
     * @throws ParseException
     * @see
     */
    public static Date strToDate(String str) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        return formatter.parse(str);
    }
    
    /**
     * date转字符串 yyyy-MM-dd HH:mm:ss
     *
     * @param date
     * @return
     */
    public static String dateToStr(Date date) {
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D_H_S).format(date);
    }
    
    /**
     * date转字符串 yyyy-MM-dd
     *
     * @param date
     * @return
     */
    public static String dateToString(Date date) {
        return new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D).format(date);
    }
    
    /**
     * date2比date1多的天数
     *
     * @param date1 小的日期
     * @param date2 大的日期
     * @return
     */
    public static int differentDays(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        int day1 = cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);
        
        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if (year1 != year2) // 同一年
        {
            int timeDistance = 0;
            for (int i = year1; i < year2; i++) {
                if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) // 闰年
                {
                    timeDistance += 366;
                } else // 不是闰年
                {
                    timeDistance += 365;
                }
            }
            
            return timeDistance + (day2 - day1);
        } else // 不同年
        {
            return day2 - day1;
        }
    }
    
    /**
     * 两个日期的小时差
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int differentHour(Date startTime, Date endTime) {
        long from = startTime.getTime();
        long to = endTime.getTime();
        // 1000 * 60 * 60　
        return (int) ((to - from) / (3600000));
    }
    
    /**
     * date2比date1多的周数
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int differentWeeks(Date startTime, Date endTime) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startTime);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        dayOfWeek = dayOfWeek - 1;
        if (dayOfWeek == 0) {
            dayOfWeek = 7;
        }
        int dayOffset = differentDays(startTime, endTime);
        int weekOffset = dayOffset / 7;
        int a;
        if (dayOffset > 0) {
            a = (dayOffset % 7 + dayOfWeek > 7) ? 1 : 0;
        } else {
            a = (dayOfWeek + dayOffset % 7 < 1) ? -1 : 0;
        }
        weekOffset = weekOffset + a;
        return weekOffset;
    }
    
    /**
     * 获取两个日期相差的月数
     *
     * @param d1 较大的日期
     * @param d2 较小的日期
     * @return 如果d1>d2返回 月数差 否则返回0
     */
    public static int differentMonths(Date d1, Date d2) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(d1);
        c2.setTime(d2);
        if (c1.getTimeInMillis() < c2.getTimeInMillis()) {
            return 0;
        }
        int year1 = c1.get(Calendar.YEAR);
        int year2 = c2.get(Calendar.YEAR);
        int month1 = c1.get(Calendar.MONTH);
        int month2 = c2.get(Calendar.MONTH);
        int day1 = c1.get(Calendar.DAY_OF_MONTH);
        int day2 = c2.get(Calendar.DAY_OF_MONTH);
        // 获取年的差值 假设 d1 = 2015-8-16 d2 = 2011-9-30
        int yearInterval = year1 - year2;
        // 如果 d1的 月-日 小于 d2的 月-日 那么 yearInterval-- 这样就得到了相差的年数
        if (month1 < month2 || month1 == month2 && day1 < day2) {
            yearInterval--;
        }
        // 获取月数差值
        int monthInterval = (month1 + 12) - month2;
        if (day1 < day2) {
            monthInterval--;
        }
        monthInterval %= 12;
        return yearInterval * 12 + monthInterval;
    }
    
    /**
     * 获取日期参数所在周的第一天 （日期格式：周一到 周日） date=2018-09-30() return 2018-09-24
     *
     * @return
     * @see
     */
    public static String getWeekFristDay(String date) {
        LocalDate inputDate = LocalDate.parse(date);
        TemporalAdjuster FIRST_OF_WEEK = TemporalAdjusters.ofDateAdjuster(
                localDate -> localDate.minusDays(localDate.getDayOfWeek().getValue() - DayOfWeek.SUNDAY.getValue()));
        return (inputDate.with(FIRST_OF_WEEK)).toString();
    }
    
    /**
     * 获取日期参数所在周的最后一天 （日期格式：周一到 周日）
     *
     * @return
     * @see
     */
    public static String getWeekLastDay(String date) {
        LocalDate inputDate = LocalDate.parse(date);
        TemporalAdjuster LAST_OF_WEEK = TemporalAdjusters.ofDateAdjuster(
                localDate -> localDate.plusDays(DayOfWeek.SATURDAY.getValue() - localDate.getDayOfWeek().getValue()));
        return (inputDate.with(LAST_OF_WEEK)).toString();
    }
    
    /**
     * 两个时间段天相差的时间段 根据开始时间和结束时间返回时间段内的时间集合
     *
     * @param beginDate
     * @param endDate
     * @return List
     */
    public static Map<String, Object> getDaysBetweenTwoDate(Date beginDate, Date endDate) {
        Map<String, Object> lDate = new HashMap<>(16);
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        // 把开始时间加入集合
        lDate.put(sdf.format(beginDate), null);
        Calendar cal = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        cal.setTime(beginDate);
        boolean bContinue = true;
        while (bContinue) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            cal.add(Calendar.DAY_OF_MONTH, 1);
            // 测试此日期是否在指定日期之后
            if (endDate.after(cal.getTime())) {
                lDate.put(sdf.format(cal.getTime()), null);
            } else {
                break;
            }
        }
        // 把结束时间加入集合
        lDate.put(sdf.format(endDate), null);
        return lDate;
    }
    
    /**
     * 计算上一周同期的日期
     *
     * @param date
     * @return
     * @throws Exception
     * @see
     */
    public static String frontWeek(String date) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar c = Calendar.getInstance();
        // 过去七天
        c.setTime(format.parse(date));
        c.add(Calendar.DATE, -7);
        Date d = c.getTime();
        String day = format.format(d);
        return day;
    }
    
    /**
     * 获取日期参数所在月的 开始日期 ~结束日期 （YYYY-MM-DD~YYYY-MM-DD）
     *
     * @return
     * @throws ParseException
     * @see
     */
    public static String getFontMonth(String date) throws ParseException {
        return FontMonthFirstDay(date) + ICommonConstant.Symbol.CONNECTIVE_SYMBOL + FontMonthLastDay(date);
    }
    
    /**
     * 获取月的第一天日期 （2018-01-01）
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String FontMonthFirstDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        // 获取前月的第一天
        Calendar calendar = Calendar.getInstance();// 获取当前日期
        calendar.setTime(format.parse(today));
        calendar.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号,当前日期既为本月第一天
        String firstDay = format.format(calendar.getTime());
        return firstDay;
    }
    
    /**
     * 获取月的最后一天日期 （2018-01-31）
     *
     * @param today
     * @return
     * @throws ParseException
     * @see
     */
    public static String FontMonthLastDay(String today) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(format.parse(today));
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        String last = format.format(calendar.getTime());
        return last;
    }
    
    /**
     * 获取日期参数所在周的 开始日期 ~结束日期 （YYYY-MM-DD~YYYY-MM-DD）
     *
     * @return
     * @throws ParseException
     * @see
     */
    public static String getFontWeek(String date) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        // 计算周日时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(df.parse(date));
        int indexOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        calendar.add(Calendar.DATE, 1 - indexOfWeek);
        Calendar calendar1 = Calendar.getInstance();
        // 计算周六时间
        calendar1.setTime(df.parse(date));
        int indexOfWeek1 = calendar1.get(Calendar.DAY_OF_WEEK);
        calendar1.add(Calendar.DATE, 7 - indexOfWeek1);
        return df.format(calendar.getTime()) + ICommonConstant.Symbol.CONNECTIVE_SYMBOL
                + df.format(calendar1.getTime());
    }
    
    /**
     * localDate转Date
     */
    public static Date localDate2Date(LocalDate localDate) {
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
        Instant instant1 = zonedDateTime.toInstant();
        Date from = Date.from(instant1);
        return from;
    }
    
    /**
     * Date 转 localDate
     */
    public static LocalDate date2LocalDate(Date date) {
        Instant instant = date.toInstant();
        ZonedDateTime zdt = instant.atZone(ZoneId.systemDefault());
        LocalDate localDate = zdt.toLocalDate();
        return localDate;
    }
    
    /**
     * 获取月第一天
     *
     * @param date
     * @return
     */
    public static Date getStartDayOfMonth(String date) {
        LocalDate now = LocalDate.parse(date);
        return getStartDayOfMonth(now);
    }
    
    public static Date getStartDayOfMonth(LocalDate date) {
        LocalDate now = date.with(TemporalAdjusters.firstDayOfMonth());
        return localDate2Date(now);
    }
    
    /**
     * 获取月最后一天
     *
     * @param date
     * @return
     */
    public static Date getEndDayOfMonth(String date) {
        LocalDate localDate = LocalDate.parse(date);
        return getEndDayOfMonth(localDate);
    }
    
    public static Date getEndDayOfMonth(LocalDate date) {
        LocalDate now = date.with(TemporalAdjusters.lastDayOfMonth());
        
        Date.from(now.atStartOfDay(ZoneId.systemDefault()).plusDays(1L).minusNanos(1L).toInstant());
        return localDate2Date(now);
    }
    
    /**
     * 获取周第一天
     *
     * @param date
     * @return
     */
    public static Date getStartDayOfWeek(String date) {
        LocalDate now = LocalDate.parse(date);
        return getStartDayOfWeek(now);
    }
    
    public static Date getStartDayOfWeek(TemporalAccessor date) {
        TemporalField fieldISO = WeekFields.of(Locale.CHINA).dayOfWeek();
        LocalDate localDate = LocalDate.from(date);
        localDate = localDate.with(fieldISO, 1);
        return localDate2Date(localDate);
    }
    
    /**
     * 获取周最后一天
     *
     * @param date
     * @return
     */
    public static Date getEndDayOfWeek(String date) {
        LocalDate localDate = LocalDate.parse(date);
        return getEndDayOfWeek(localDate);
    }
    
    public static Date getEndDayOfWeek(TemporalAccessor date) {
        TemporalField fieldISO = WeekFields.of(Locale.CHINA).dayOfWeek();
        LocalDate localDate = LocalDate.from(date);
        localDate = localDate.with(fieldISO, 7);
        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).plusDays(1L).minusNanos(1L).toInstant());
    }
    
    /**
     * 一天的开始
     *
     * @param date
     * @return
     */
    public static Date getStartOfDay(String date) {
        LocalDate localDate = LocalDate.parse(date);
        return getStartOfDay(localDate);
    }
    
    public static Date getStartOfDay(TemporalAccessor date) {
        LocalDate localDate = LocalDate.from(date);
        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }
    
    /**
     * 一天的结束
     *
     * @param date
     * @return
     */
    public static Date getEndOfDay(String date) {
        LocalDate localDate = LocalDate.parse(date);
        return getEndOfDay(localDate);
    }
    
    public static Date getEndOfDay(TemporalAccessor date) {
        LocalDate localDate = LocalDate.from(date);
        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).plusDays(1L).minusNanos(1L).toInstant());
    }
    
    /**
     * 获取周第一天和最后一天
     *
     * @param datetime
     * @return
     */
    public static String getStartAndEndDayOfWeek(String datetime) {
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        return sdf.format(getStartDayOfWeek(datetime)) + "~" + sdf.format(getEndDayOfWeek(datetime));
    }
    
    /**
     * 获取月第一天和最后一天
     *
     * @param datetime
     * @return
     */
    public static String getStartAndEndDayOfMonth(String datetime) {
        SimpleDateFormat sdf = new SimpleDateFormat(ICommonConstant.DateFormatType.Y_M_D);
        return sdf.format(getStartDayOfMonth(datetime)) + "~" + sdf.format(getEndDayOfMonth(datetime));
    }
    
    /**
     * 获取上个周第一天
     *
     * @return
     */
    public static LocalDate getStartDayOfWeek() {
        LocalDate startDate = LocalDate.now();
        LocalDate localDate1 = startDate.plusWeeks(ICommonConstant.BeforeDay.BEFORE_DAY);
        DayOfWeek dayOfWeek = localDate1.getDayOfWeek();
        return localDate1.minusDays(dayOfWeek.getValue() - ICommonConstant.Day.DAY);
    }
    
    /**
     * 获取昨天
     *
     * @return
     */
    public static LocalDate getSameDayOfYesterday() {
        return DeepDateUtil.date2LocalDate(DateUtils.addDays(new Date(), ICommonConstant.BeforeDay.BEFORE_DAY));
    }
    
    /**
     * 获取上个周同一天
     *
     * @return
     */
    public static LocalDate getSameDayOfWeek() {
        return DeepDateUtil.date2LocalDate(DateUtils.addDays(new Date(), ICommonConstant.BeforeWeek.BEFORE_DAY));
    }
    
    /**
     * 获取上个周最后一天
     *
     * @return
     */
    public static LocalDate getEndDayOfWeek() {
        LocalDate startDate = LocalDate.now();
        LocalDate localDate1 = startDate.plusWeeks(ICommonConstant.BeforeDay.BEFORE_DAY);
        DayOfWeek dayOfWeek = localDate1.getDayOfWeek();
        return localDate1.plusDays(ICommonConstant.Day.WEEK_DAY - dayOfWeek.getValue());
    }
    
    /**
     * 获取上个月第一天
     *
     * @return
     */
    public static LocalDate getStartDayOfMonth() {
        LocalDate startDate = LocalDate.now();
        LocalDate lastMonthDate = startDate.plusMonths(ICommonConstant.BeforeDay.BEFORE_DAY);
        return lastMonthDate.with(TemporalAdjusters.firstDayOfMonth());
    }
    
    /**
     * 获取上个月最后一天
     *
     * @return
     */
    public static LocalDate getEndDayOfMonth() {
        LocalDate startDate = LocalDate.now();
        LocalDate lastMonthDate = startDate.plusMonths(ICommonConstant.BeforeDay.BEFORE_DAY);
        return lastMonthDate.with(TemporalAdjusters.lastDayOfMonth());
    }
    
    /**
     * 获取两个日期之间的日期
     *
     * @param start 开始日期
     * @param end   结束日期
     * @return 日期集合
     */
    public static List<Date> getBetweenDates(LocalDate start, LocalDate end) {
        List<Date> result = Lists.newArrayList();
        Calendar tempStart = Calendar.getInstance();
        tempStart.setTime(localDate2Date(start));
        tempStart.add(Calendar.DAY_OF_YEAR, 1);
        Calendar tempEnd = Calendar.getInstance();
        tempEnd.setTime(localDate2Date(end));
        while (tempStart.before(tempEnd)) {
            result.add(tempStart.getTime());
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
        }
        return result;
    }
}
