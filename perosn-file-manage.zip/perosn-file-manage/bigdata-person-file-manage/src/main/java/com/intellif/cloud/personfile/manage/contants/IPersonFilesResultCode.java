/*
 * 文件名：IPersonFilesResultCode.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述：
 * 创建人：Administrator
 * 创建时间：2018年10月11日
 * 修改理由：
 * 修改内容：
 */

package com.intellif.cloud.personfile.manage.contants;

/**
 * 〈一句话简述该类/接口的功能〉
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @version 1.0
 * @date 2018年10月11日
 * @see IPersonFilesResultCode
 * @since JDK1.8
 */

public interface IPersonFilesResultCode extends IResultCode {
    
    /**
     * 档案中心返回状态码接口
     * 开头33
     * 〈功能详细描述〉
     *
     * @author admin
     * @version 1.0
     * @date 2018年10月16日
     * @see IManageResultCode
     * @since JDK1.8
     */
    interface IManageResultCode {
        int SUCCESS = 33000000;
        
        int ERROR = 33000001;
    }
    
    
    /**
     * 档案分析返回状态码接口
     * 开头34
     *
     * @author admin
     * @version 1.0
     * @date 2018年10月16日
     * @see IManageResultCode
     * @since JDK1.8
     */
    interface IDatastatisticResultCode {
        int SUCCESS = 34000000;
        
        int ERROR = 34000001;
    }
    
    
    /**
     * 档案统计返回状态码接口
     * 开头35
     *
     * @author admin
     * @version 1.0
     * @date 2018年10月16日
     * @see IManageResultCode
     * @since JDK1.8
     */
    interface IJobResultCode {
        int SUCCESS = 35000000;
        
        int ERROR = 35000001;
    }
    
    /**
     * 一人一档的数据平台的返回状态码
     */
    interface XDataResultCode {
        /**
         * 成功
         */
        int SUCCESS = 10000000;
        int HIT_SUCCESS = 1001;
    }
}
