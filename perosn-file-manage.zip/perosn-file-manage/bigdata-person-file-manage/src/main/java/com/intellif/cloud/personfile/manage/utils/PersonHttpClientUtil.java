package com.intellif.cloud.personfile.manage.utils;
/*
 *文件名： HttpClientUtils.java
 *版权： Copyright by 云天励飞 intellif.com
 *描述： HttpClient4.3工具类
 *创建人：tianhao
 *创建时间： 2018/11/06 16:07
 *修改理由：
 *修改内容：
 */

import com.alibaba.fastjson.JSONObject;
import com.intellif.log.LoggerUtilI;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpHeaders;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;


/**
 * HttpClient4.3工具类
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年11月16日
 * @see PersonHttpClientUtil
 * @since JDK1.8
 */
public class PersonHttpClientUtil {

    private static final LoggerUtilI logger = LoggerUtilI.getLogger(PersonHttpClientUtil.class.getName());

    private static RequestConfig requestConfig;
    
    /**
     * httpClient的读取超时时间,默认10秒,httpClient使用该属性
     */
    public static final int HTTP_CLIENT_READ_TIMEOUT = 1000000;
    
    /**
     * httpClient的连接超时时间,默认5秒,httpClient使用该属性
     */
    public static final int HTTP_CLIENT_CONNECT_TIMEOUT = 1000000;

    static {
        // 设置请求和传输超时时间
        requestConfig = RequestConfig.custom().
                setSocketTimeout(HTTP_CLIENT_READ_TIMEOUT).
                setConnectTimeout(HTTP_CLIENT_CONNECT_TIMEOUT).
                build();
    }

    /**
     * post请求传输json参数
     *
     * @param url       url地址
     * @param jsonParam 参数
     * @param tokenMap  请求头
     * @return
     */
    public static String httpPost(String url, JSONObject jsonParam, Map<String, String> tokenMap) {
        return httpPostExec(url, jsonParam, tokenMap, "application/json");
    }

    /**
     * post请求
     *
     * @param url
     * @param jsonParam
     * @param tokenMap
     * @param contentType
     * @return
     */
    public static String httpPost(String url, JSONObject jsonParam, Map<String, String> tokenMap, String contentType) {
        return httpPostExec(url, jsonParam, tokenMap, contentType);
    }

    /**
     * post请求,参数为string
     *
     * @param url
     * @param jsonParam
     * @param tokenMap
     * @param contentType
     * @return
     */
    public static String httpPostParamString(String url, String jsonParam, Map<String, String> tokenMap, String contentType) {
        return httpPostParamStringExec(url, jsonParam, tokenMap, contentType);
    }

    /**
     * post请求传输String参数 例如：name=Jack&sex=1&type=2
     * Content-type:application/x-www-form-urlencoded
     *
     * @param url      url地址
     * @param strParam 参数
     * @param tokenMap 请求头
     * @return
     */
    public static String httpPost(String url, String strParam, Map<String, String> tokenMap) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);
        setHeader(httpPost, tokenMap);
        try {
            if (null != strParam) {
                // 解决中文乱码问题
                StringEntity entity = new StringEntity(strParam, "utf-8");
                entity.setContentEncoding("UTF-8");
                entity.setContentType("application/x-www-form-urlencoded");
                httpPost.setEntity(entity);
            }
            CloseableHttpResponse result = httpClient.execute(httpPost);
            // 请求发送成功，并得到响应
            if (result.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                try {
                    // 读取服务器返回过来的json字符串数据
                    return EntityUtils.toString(result.getEntity(), "utf-8");
                } catch (Exception e) {
                    logger.error("post请求提交失败:" + url, e);
                }
            }
        } catch (IOException e) {
            logger.error("httpClient post请求提交失败:" + url, e);
        } finally {
            httpPost.releaseConnection();
        }
        return null;
    }

    /**
     * 发送get请求
     *
     * @param url      路径
     * @param tokenMap token
     * @return
     */
    public static String httpGet(String url, Map<String, String> tokenMap) {
        CloseableHttpClient client = HttpClients.createDefault();
        // 发送get请求
        HttpGet request = new HttpGet(url);
        request.setConfig(requestConfig);
        // 设置header
        setHeader(request, tokenMap);
        try {
            CloseableHttpResponse response = client.execute(request);
            return EntityUtils.toString(response.getEntity(), "utf-8");
        } catch (IOException e) {
            logger.error("get请求提交失败:" + url, e);
        } finally {
            request.releaseConnection();
        }
        return null;
    }


    /**
     * 设置请求头
     *
     * @param httpRequestBase
     * @param tokenMap
     */
    private static void setHeader(HttpRequestBase httpRequestBase, Map<String, String> tokenMap) {
        if (tokenMap.isEmpty()) {
            return;
        }
        // 迭代器 遍历map
        Iterator iter = tokenMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            httpRequestBase.setHeader(entry.getKey().toString(), entry.getValue().toString());
        }
    }

    /**
     * @param url
     * @param jsonParam   string类型的参数
     * @param tokenMap
     * @param contentType
     * @return
     */
    private static String httpPostParamStringExec(String url, String jsonParam, Map<String, String> tokenMap, String contentType) {
        // post请求返回结果
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        // 设置请求和传输超时时间
        httpPost.setConfig(requestConfig);
        setHeader(httpPost, tokenMap);
        try {
            if (null != jsonParam) {
                // 解决中文乱码问题
                StringEntity entity = new StringEntity(jsonParam, "utf-8");
                entity.setContentEncoding("UTF-8");
                entity.setContentType(contentType);
                httpPost.setEntity(entity);
            }
            CloseableHttpResponse result = httpClient.execute(httpPost);
            // 请求发送成功，并得到响应
            return EntityUtils.toString(result.getEntity(), "utf-8");
        } catch (IOException e) {
            logger.error("post请求提交失败:" + url, e);
        } finally {
            httpPost.releaseConnection();
        }
        return null;
    }

    /**
     * @param url
     * @param jsonParam
     * @param tokenMap
     * @param contentType
     * @return
     */
    private static String httpPostExec(String url, JSONObject jsonParam, Map<String, String> tokenMap, String contentType) {
        // post请求返回结果
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        // 设置请求和传输超时时间
        httpPost.setConfig(requestConfig);
        setHeader(httpPost, tokenMap);
        try {
            if (null != jsonParam) {
                // 解决中文乱码问题
                StringEntity entity = new StringEntity(jsonParam.toString(), "utf-8");
                entity.setContentEncoding("UTF-8");
                entity.setContentType(contentType);
                httpPost.setEntity(entity);
            }
            CloseableHttpResponse result = httpClient.execute(httpPost);
            // 请求发送成功，并得到响应
            return EntityUtils.toString(result.getEntity(), "utf-8");
        } catch (IOException e) {
            logger.error("post请求提交失败:" + url, e);
        } finally {
            httpPost.releaseConnection();
        }
        return null;
    }
}