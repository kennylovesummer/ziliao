package com.intellif.cloud.personfile.manage.enums;

/**
 * 数据分析模块
 *
 * @author liuzj
 * @version 1.0
 * @date 2019年07月01日
 * @see DataStisticTypeEnum
 * @since JDK1.8
 */
public enum DataStisticTypeEnum {

    CRASH(0, "azkaban_collision","碰撞","Collision"),
    
    PEER(1, "azkaban_peer","同行","Peer"),
    
    TRACE(2, "azkaban_track","轨迹","Track"),
    
    LINGER(3, "azkaban_lingered","徘徊","Lingered"),
    
    ACTIVITY(4, "azkaban_activity","活动规律","ActivityRule"),
    
    NOCTURNAL(5, "azkaban_nocturnal","昼伏夜出","Nocturnal");

    private int id;

    private String name;
    
    private String chName;
    
    private String resultName;
    
    
    public String getChName() {
        return chName;
    }
    
    public void setChName(String chName) {
        this.chName = chName;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getResultName() {
        return resultName;
    }
    
    public void setResultName(String resultName) {
        this.resultName = resultName;
    }
    
    DataStisticTypeEnum(int id, String name, String chName, String resultName) {
        this.name = name;
        this.id = id;
        this.chName = chName;
        this.resultName = resultName;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static DataStisticTypeEnum getById(int id) {
        for (DataStisticTypeEnum c : DataStisticTypeEnum.values()) {
            if (c.getId() == id) {
                return c;
            }
        }
        return null;
    }
    
    public static DataStisticTypeEnum getByName(String name) {
        for (DataStisticTypeEnum c : DataStisticTypeEnum.values()) {
            if (c.name.equalsIgnoreCase(name)) {
                return c;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return name;
    }

}
