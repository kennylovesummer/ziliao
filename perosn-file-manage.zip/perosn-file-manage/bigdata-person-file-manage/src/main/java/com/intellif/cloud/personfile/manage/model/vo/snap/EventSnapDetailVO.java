package com.intellif.cloud.personfile.manage.model.vo.snap;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author liuyu
 * @className EventSnapDetailVO
 * @date 2019/3/19 15:32
 * @description
 */
@Data
public class EventSnapDetailVO implements Serializable {

    private static final long serialVersionUID = 1073106924434578294L;

    private Long id;

    private String personFilesId;

    private String faceId;

    private String faceUrl;

    private String imageId;

    private String imageUrl;

    private String sourceType;

    private String targetRect;

    private String snapTime;
    
    private Date st;

    private String snapDate;

    private Integer imageCount;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
