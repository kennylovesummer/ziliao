package com.intellif.cloud.personfile.manage.controllers;

import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.model.dto.camera.PersonfileCameraReqDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.services.general.IDevSynchronizeService;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileCameraService;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 设备控制层
 *
 * @author tianhao
 * @version 1.0
 * @date 2018年10月17日
 * @see PersonfileCameraController
 * @since JDK1.8
 */
@Deprecated
@Api(tags = "摄像头")
@RestController
@RequestMapping(value = IPersonfilesManageConstant.RequestUrl.CAMERA_BASE_URL)
public class PersonfileCameraController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final IDevSynchronizeService devSynchronizeService;

    private final IPersonfileCameraService personfileCameraService;

    @Autowired
    public PersonfileCameraController(IDevSynchronizeService devSynchronizeService, IPersonfileCameraService personfileCameraService) {
        this.devSynchronizeService = devSynchronizeService;
        this.personfileCameraService = personfileCameraService;
    }

    /**
     * 设备列表分页查询
     *
     * @param personfileCameraReqDTO
     * @return
     */
    @ApiOperation(httpMethod = "POST",value = "分页获取摄像头")
    @PostMapping(value = "{version}")
    public BasePageRespDTO queryDevList(@RequestBody PersonfileCameraReqDTO personfileCameraReqDTO) {
        try {
            return personfileCameraService.queryPersonfileCamera(personfileCameraReqDTO);
        } catch (Exception e) {
            logger.error("一人一档设备列表分页查询异常:" + e.getMessage());
            return new BasePageRespDTO(null, 0, 0, IResultCode.ERROR, "设备列表查询异常", e.getMessage());
        }
    }


}
