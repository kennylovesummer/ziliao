package com.intellif.cloud.personfile.manage.utils;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonFilesResultCode;
import com.intellif.cloud.personfile.manage.contants.IResultCode;

public class SuccessRespUtil {

    /**
     * 返回状态判断
     *
     * @param result
     * @return boolean
     */
    public static boolean isSuccess(JSONObject result) {
        return result != null && result.getInteger(IPersonFilesConstant.ResultDataFormat.respCode) == IResultCode.SUCCESS;
    }

    /**
     * 返回状态判断
     *
     * @param resultCode 状态码
     * @return boolean
     */
    public static boolean isSuccess(Integer resultCode) {
        return resultCode != null && resultCode == IResultCode.SUCCESS;
    }

    /**
     * 返回比中状态判断
     *
     * @param resultCode 状态码
     * @return boolean
     */
    public static boolean isHitSuccess(Integer resultCode) {
        return resultCode != null && resultCode == IPersonFilesResultCode.XDataResultCode.HIT_SUCCESS;
    }

    private SuccessRespUtil() {
    }
}
