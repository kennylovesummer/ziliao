package com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.CrashAreaParam;
import lombok.Data;

import java.util.List;

@Data
public class CrashTaskCreateDTO extends BaseAnalysisCreateDTO implements java.io.Serializable {
    
    public List<CrashAreaParam> spatioTemps;
    
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
