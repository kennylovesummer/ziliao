package com.intellif.cloud.personfile.manage.services.general;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabel;
import com.intellif.cloud.personfile.manage.model.vo.label.PersonfileLabelVO;

import java.text.ParseException;
import java.util.List;

/**
 * @ClassName PersonfileLabelService
 * @Author liuYu
 * @create 2018-10-16 17:32
 * @Version 1.0
 * @desc 标签
 */
public interface PersonfileLabelService {
    /**
     * 查询指定id的标签
     * @return
     * @throws BusinessException
     * @see
     */
    PersonfileLabel queryPersonfileLabelById(Integer id)throws BusinessException;

    /**
     * 添加标签
     * @return
     * @throws BusinessException
     * @see
     */
    int insertPersonfileLabel(PersonfileLabel personfileLabel) throws BusinessException, ParseException;

    /**
     * 分页查询所有的标签
     * @return
     * @throws BusinessException
     * @see
     */
    Page<PersonfileLabel> queryPersonfileLabelList(int pageNum, int pageSize)throws BusinessException;

    /**
     * 查询所有的标签
     * @return
     * @throws BusinessException
     * @see
     */
    List<PersonfileLabel> findAllPersonfileLabel()throws BusinessException;

    /**
     * 查询指定名称的标签
     * @return
     * @throws BusinessException
     * @see
     */
    PersonfileLabel queryPersonfileLabelByName(Integer id, String labelName) throws BusinessException;

    /**
     * 修改标签
     * @return
     * @throws BusinessException
     * @see
     */
    int updatePersonfileLabel(PersonfileLabel personfileLabel) throws BusinessException, ParseException;

    /**
     * 根据id删除标签
     * @return
     * @throws BusinessException
     * @see
     */
    int deletePersonfileLabel(Integer id)throws BusinessException;

    /**
     * 根据档案ID集合查询标签档案中间表记录
     *
     * @param ids 档案ID集合
     * @return List
     */
    List<PersonfileLabelVO> findPersonfileLabelRecordByPersonfileIds(List<String> ids);

    /**
     * 根据标签ID集合查询标签档案中间表记录
     *
     * @param ids 标签ID集合
     * @return List
     */
    List<PersonfileLabelVO> findLabelRecordByLabelId(List<String> ids);
}
