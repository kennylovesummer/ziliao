package com.intellif.cloud.personfile.manage.config;

import lombok.Data;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * kafka消费者配置
 *
 * @author liuzj
 * @date 2019-01-08
 */
@Configuration
@Data
public class KafkaConsumerConfig {

    @Value("${kafka.consumer.bootstrap.servers}")
    private String servers;

    @Value("${kafka.consumer.session.timout.ms}")
    private String sessionTimeout;

    @Value("${kafka.consumer.max.poll.interval.ms}")
    private String pollInterval;

    @Value("${kafka.consumer.max.poll.records}")
    private String pollRecords;

    @Value("${kafka.consumer.heartbeat.interval.ms}")
    private String heartbeatInterval;
    
    @Value("${kafka.consumer.max.partition.fetch.bytes}")
    private String maxPartitionFetchBytes;

    @Value("${kafka.consumer.group.id}")
    private String groupId;

    @Value("${security.conf.path}")
    private String path;
    
    @Value("${user.keytab.file}")
    private String keyTabFile;
    
    @Value("${user.principal}")
    private String userPrincipal;
    
    @Value("${kafka.auto.offset.reset:latest}")
    private String autoOffsetReset;
    
    @Value("${kafka.auto.commit:false}")
    private String autoCommit;

    @Value("${security.mode:false}")
    private boolean isSecurityMode;
    
    
    
    private static final String SECURITY_CONF_PATH = "security.conf.path";

    private static final String USER_KEYTAB_FILE = "user.keytab.file";

    private static final String USER_PRINCIPAL = "user.principal";

    public Properties getPorps(){
        Properties properties = new Properties();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
        properties.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeout);
        properties.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, pollInterval);
        properties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, pollRecords);
        properties.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, heartbeatInterval);
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        properties.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG,30000);
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,autoOffsetReset);
        properties.put(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG,maxPartitionFetchBytes);
        if (isSecurityMode) {
            properties.put(SECURITY_CONF_PATH, path);
            properties.put(USER_KEYTAB_FILE, keyTabFile);
            properties.put(USER_PRINCIPAL, userPrincipal);
        }
        return properties;
    }
}
