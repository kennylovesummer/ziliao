package com.intellif.cloud.personfile.manage.task.monitor;

import java.util.concurrent.Future;

/**
 * 任务监控
 *
 * @author liuzj
 * @date 2019-07-23
 */
public interface TaskMonitor {
    
    /**
     * 启动
     *
     * @return
     */
    Boolean start();
    
    /**
     * 是否在运行
     *
     * @return
     */
    Boolean isRunning();
    
    /**
     * 停止
     *
     * @return
     */
    Boolean stop();
    
    /**
     * 将线程加入监控
     *
     * @param threadId 线程ID
     * @param future 线程存放集合
     */
    void addToMonitor(String threadId,Future<?> future);
    
    /**
     * 监控逻辑
     */
    void doMonitor();
}
