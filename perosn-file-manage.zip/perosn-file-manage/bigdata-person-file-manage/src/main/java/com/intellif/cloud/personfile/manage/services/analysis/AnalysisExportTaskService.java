package com.intellif.cloud.personfile.manage.services.analysis;

import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.DownloadParam;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.vo.analysis.DownloadVO;

/**
 * 任务下载
 *
 * @author luzj
 * @date 2019-07-14
 */
public interface AnalysisExportTaskService {
    
    /**
     * 同行下载
     *
     * @param downloadParam 参数集合
     * @return DownloadVO
     */
    DownloadVO peerAnalysisExport(DownloadParam downloadParam);
    
    /**
     * 碰撞下载
     *
     * @param downloadParam 参数集合
     * @return DownloadVO
     */
    DownloadVO clashAnalysisExport(DownloadParam downloadParam);
    
    /**
     * 轨迹下载
     *
     * @param downloadParam 参数集合
     * @return DownloadVO
     */
    DownloadVO traceAnalysisExport(DownloadParam downloadParam);
    
    /**
     * 任务下载
     *
     * @param downloadParam 参数集合
     * @return DownloadVO
     */
    DownloadVO export(DownloadParam downloadParam);
    
    /**
     * 任务提交
     *
     * @param downloadParam 参数集合
     * @return BaseDataRespDTO
     */
    BaseDataRespDTO submit(DownloadParam downloadParam) throws BusinessException;
}
