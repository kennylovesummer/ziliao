/*
 * 文 件 名:  MySqlHelper.java
 * 版    权:  慧眼云
 * 描    述:  <描述>
 * 修 改 人:  wangyi
 * 修改时间:  2012-11-26
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.intellif.cloud.personfile.manage.utils;

/**
 * 根据对象和调用的接口确定sql
 * <功能详细描述>
 *
 * @author 005818
 * @version [版本号, 2012-11-26]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class MySqlHelper {
    public static <T> String getSQLName(String order, T obj) {
        StringBuffer sql = new StringBuffer();
        sql.append(order);
        sql.append(obj.getClass().getSimpleName());
        return sql.toString();
    }
}
