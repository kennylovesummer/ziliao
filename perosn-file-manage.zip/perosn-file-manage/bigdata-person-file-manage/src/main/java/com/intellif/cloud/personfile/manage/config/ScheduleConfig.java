package com.intellif.cloud.personfile.manage.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

/**
 * 定时任务线程数配置
 *
 * @author liuzj
 * @date 2019-12-11
 */
@Configuration
public class ScheduleConfig {
     
     @Bean
     public TaskScheduler taskScheduler() {
          ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
          taskScheduler.setPoolSize(6);
          return taskScheduler;
     }
}
