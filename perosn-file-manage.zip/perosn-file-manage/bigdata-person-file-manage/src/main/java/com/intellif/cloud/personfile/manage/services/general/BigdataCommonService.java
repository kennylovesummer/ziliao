package com.intellif.cloud.personfile.manage.services.general;

import com.intellif.cloud.personfile.manage.entity.BigdataCommon;

import java.util.List;

/**
 * 通用业务处理
 *
 * @author liuzj
 * @date 2019-05-22
 */
public interface BigdataCommonService {

    /**
     * 新增
     *
     * @param bigdataCommon 通用业务实体
     * @return int
     */
    int insertBigdataCommon(BigdataCommon bigdataCommon);

    /**
     * 修改
     *
     * @param bigdataCommon 通用业务实体
     * @return int
     */
    int updateBigdataCommon(BigdataCommon bigdataCommon);

    /**
     * 根据contentType查找数据
     *
     * @param contentType 业务类型（不同业务具有不同的类型）
     * @return List
     */
    List<BigdataCommon> findBigdataCommonByContentType(String contentType);
}
