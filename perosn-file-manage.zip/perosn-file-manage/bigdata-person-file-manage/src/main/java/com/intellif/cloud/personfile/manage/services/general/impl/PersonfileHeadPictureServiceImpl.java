package com.intellif.cloud.personfile.manage.services.general.impl;

import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.entity.PersonfileHeadPicture;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.general.PersonfileHeadPictureService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 档案最近抓拍时间和活动更新时间
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月26日
 * @see PersonfileHeadPictureService
 * @since JDK1.8
 */
@Service
public class PersonfileHeadPictureServiceImpl extends BaseServiceImpl implements PersonfileHeadPictureService {

    @Override
    public int batchInsert(List<PersonfileHeadPicture> personfileHeadPictures) {
        return this.baseDao.batchInsert(new PersonfileHeadPicture(),null,personfileHeadPictures);
    }

    @Override
    public PersonfileHeadPicture findByPersonfileId(String personfilesId) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("personFilesId", personfilesId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findByPersonfileIdPersonfileHeadPicture");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object == null ? null : (PersonfileHeadPicture) object;
    }

    @Override
    public int update(PersonfileHeadPicture PersonfileHeadPicture) {
        return this.baseDao.update(PersonfileHeadPicture);
    }
}
