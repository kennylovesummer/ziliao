package com.intellif.cloud.personfile.manage.model.dto.snap;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageReqDTO;
import lombok.Data;

import java.io.Serializable;

/**
 * @author liuyu
 * @className SnapQueryDTO
 * @date 2019/3/19 15:48
 * @description
 */
@Data
public class SnapQueryDTO extends BasePageReqDTO implements Serializable {

    private static final long serialVersionUID = -6816984079695808361L;

    /**
     * 档案ID
     */
    private String personFileId;
    /**
     * 设备id
     */
    private String devId;
    /**
     * 创建开始日期
     */
    private String startTime;
    /**
     * 创建结束日期
     */
    private String endTime;
    /**
     * 事件类型(0-全部,1-抓拍，2-乘车，3-住宿)
     */
    private String eventType;

    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
