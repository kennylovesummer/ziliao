package com.intellif.cloud.personfile.manage.services.analysis;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisArchive;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.base.AnalysisDTO;

import java.util.List;

/**
 * 数据分析档案
 *
 * @author liuzj
 * @date 2019-07-18
 */
public interface BigdataAnalysisArchiveService {
    
    /**
     * 根据ID查找
     *
     * @param id ID
     * @return entity
     */
    BigdataAnalysisArchive findAnalysisArchiveById(Long id);
    
    /**
     * 根据ID删除对象
     *
     * @param bigdataAnalysisArchive 要删除的对象
     */
    void deleteAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive);
    
    /**
     * 新增
     *
     * @param bigdataAnalysisArchive 待插入的对象
     * @return Long 档案ID
     */
    Long insertAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive);
    
    /**
     * 批量插入
     *
     * @param analysisArchiveList 数据集
     */
    void batchInsertAnalysisArchive(List<BigdataAnalysisArchive> analysisArchiveList);
    
    /**
     * 更新
     *
     * @param bigdataAnalysisArchive 待更新的对象
     */
    void updateAnalysisArchive(BigdataAnalysisArchive bigdataAnalysisArchive);
    
    /**
     * 分页查找
     *
     * @param analysisDTO 参数集合
     * @return Page 分页数据
     */
    Page<BigdataAnalysisArchive> findAnalysisArchiveByParams(AnalysisDTO analysisDTO);
    
    /**
     * 根据任务ID删除
     *
     * @param taskId 任务ID
     */
    void deleteBigdataAnalysisArchiveByTaskId(Long taskId);
}
