package com.intellif.cloud.personfile.manage.model.vo.analysis;

import lombok.Data;

import java.util.List;

@Data
public class LocationInfo {
    
    private String sourceId;
    
    private String site;
    
    private Long imageCount;
    
    private List<EventDetailVO> events;
}
