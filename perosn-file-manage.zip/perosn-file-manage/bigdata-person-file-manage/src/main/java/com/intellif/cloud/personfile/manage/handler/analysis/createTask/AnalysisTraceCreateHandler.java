package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisTask;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.base.OffLineTaskDTO;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.in.TraceTaskCreateDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;

import java.util.Arrays;

/**
 * 轨迹分析任务创建
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisTraceCreateHandler extends AbstractAnalysisCreateTaskHandler {
    
    AnalysisTraceCreateHandler(String type) {
        this.type = type;
    }
    
    @Override
    protected String doCreate(JSONObject params) throws BusinessException {
        TraceTaskCreateDTO traceTaskCreateDTO = JSONObject.parseObject(params.toJSONString(), TraceTaskCreateDTO.class);
        
        // 参数校验
        if (CollectionUtils.isEmpty(traceTaskCreateDTO.getAids())
                || Strings.isBlank(traceTaskCreateDTO.getStartTime())
                || Strings.isBlank(traceTaskCreateDTO.getEndTime())) {
            throw new BusinessException(IResultCode.ERROR,"参数异常");
        }
        
        // 人员是否存在校验
        PersonfileBasics personfileBasics = subArchiveService.findBaseInfoByPersonFileId(traceTaskCreateDTO.getAids().get(0));
        if (personfileBasics == null) {
            throw new BusinessException(IResultCode.ERROR,"分析档案不存在");
        }
    
        String rulesConfig = personPropertiest.getDataAnalysisCrashRules();
        if (Strings.isNotBlank(rulesConfig)) {
            traceTaskCreateDTO.setPeriods(Arrays.asList(rulesConfig.split(ICommonConstant.Symbol.COMMA)));
        }
    
        OffLineTaskDTO offLineTaskDTO = new OffLineTaskDTO();
        offLineTaskDTO.setOpCode("create");
        offLineTaskDTO.setParams(traceTaskCreateDTO.toString());
        offLineTaskDTO.setTaskName(traceTaskCreateDTO.getTaskName());
        offLineTaskDTO.setTaskType(traceTaskCreateDTO.getTaskType());
        offLineTaskDTO.setBizCode(personPropertiest.getBizCode());
        String execId = xdataCreateTask(offLineTaskDTO);
    
        BigdataAnalysisTask bigdataAnalysisTask = new BigdataAnalysisTask();
        bigdataAnalysisTask.setType(DataStisticTypeEnum.TRACE.getName());
        bigdataAnalysisTask.setName(traceTaskCreateDTO.getTaskName());
        bigdataAnalysisTask.setAid(traceTaskCreateDTO.getAids().get(0));
        bigdataAnalysisTask.setParams(params.toJSONString());
        bigdataAnalysisTask.setExecId(execId);
        bigdataAnalysisTaskService.insertBigdataAnalysisTask(bigdataAnalysisTask);
        
        return execId;
    }
}
