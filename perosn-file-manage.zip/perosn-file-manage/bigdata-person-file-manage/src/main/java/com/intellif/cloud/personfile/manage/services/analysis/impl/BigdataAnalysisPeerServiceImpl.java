package com.intellif.cloud.personfile.manage.services.analysis.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataAnalysisPeer;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.model.dto.analysis.offLine.out.PeerDTO;
import com.intellif.cloud.personfile.manage.services.analysis.BigdataAnalysisPeerService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuzj
 * @see BigdataAnalysisPeerService
 */
@Service
public class BigdataAnalysisPeerServiceImpl extends BaseServiceImpl implements BigdataAnalysisPeerService {
    
    private static final BigdataAnalysisPeer BIGDATA_ANALYSIS_PEER = new BigdataAnalysisPeer();
    
    @Override
    public BigdataAnalysisPeer findAnalysisPeerById(Long id) {
        if (id != null) {
            QueryEvent<PersonfileBasics> queryPeer = new QueryEvent<>();
            Map<String, Object> parameters = new HashMap<>(1);
            parameters.put("id", id);
            queryPeer.setParameter(parameters);
            queryPeer.setStatement("findAnalysisPeerById");
            Object object = this.baseDao.findOneByCustom(queryPeer);
            return object == null ? null : (BigdataAnalysisPeer) object;
        }
        return null;
    }
    
    @Override
    public void deleteAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer) {
        if (bigdataAnalysisPeer != null && bigdataAnalysisPeer.getId() != null) {
            this.baseDao.delete(bigdataAnalysisPeer);
        }
    }
    
    @Override
    public Long insertAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer) {
        if (bigdataAnalysisPeer != null) {
            bigdataAnalysisPeer.setCreateBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
            bigdataAnalysisPeer.setModifyBy(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        }
        this.baseDao.insert(bigdataAnalysisPeer);
        return bigdataAnalysisPeer.getId();
    }
    
    @Override
    public void batchInsertAnalysisPeer(List<BigdataAnalysisPeer> peerList) {
        this.baseDao.batchInsert(BIGDATA_ANALYSIS_PEER, null, peerList);
    }
    
    @Override
    public void updateAnalysisPeer(BigdataAnalysisPeer bigdataAnalysisPeer) {
        this.baseDao.update(bigdataAnalysisPeer);
    }
    
    @Override
    public Page<BigdataAnalysisPeer> findAnalysisPeerByParams(PeerDTO peerDTO) {
        QueryEvent<PeerDTO> queryEvent = new QueryEvent<>();
        queryEvent.setObj(peerDTO);
        queryEvent.setStatement("findAnalysisPeerByParams");
        
        Page<BigdataAnalysisPeer> page = PageHelper.startPage(peerDTO.getPage(), peerDTO.getPerpage());
        this.baseDao.findAllIsPageByCustom(queryEvent);
        return page;
    }
    
    @Override
    public void deleteBigdataAnalysisPeerByTaskId(Long taskId) {
        if (taskId == null) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("taskId", taskId);
        this.baseDao.updateStatement("deleteBigdataAnalysisPeerByTaskId",parameters);
    }
    
}
