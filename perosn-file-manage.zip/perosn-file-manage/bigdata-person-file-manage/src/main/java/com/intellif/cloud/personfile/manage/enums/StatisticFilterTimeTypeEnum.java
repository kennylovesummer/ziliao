package com.intellif.cloud.personfile.manage.enums;

/**
 * @author liuzhijian
 * @version 1.0
 * @see StatisticFilterTimeTypeEnum
 * @since JDK1.8
 * @date 2018年10月20日
 */
public enum StatisticFilterTimeTypeEnum {

	WEEK(0, "按周统计"),

	MONTH(1, "按天统计");

	private int id;

	private String name;

	StatisticFilterTimeTypeEnum(int id, String name) {
		this.name = name;
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public static StatisticFilterTimeTypeEnum getById(int id) {
		for (StatisticFilterTimeTypeEnum c : StatisticFilterTimeTypeEnum.values()) {
			if (c.getId() == id) {
				return c;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return name;
	}

}
