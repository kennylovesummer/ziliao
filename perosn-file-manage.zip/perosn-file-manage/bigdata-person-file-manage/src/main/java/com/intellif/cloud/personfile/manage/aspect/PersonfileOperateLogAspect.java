//package com.intellif.cloud.personfile.manage.aspect;
//
//import com.alibaba.fastjson.JSONObject;
//import com.google.common.collect.Maps;
//import com.intellif.cloud.personfile.manage.annotation.OperateLog;
//import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
//import com.intellif.cloud.personfile.manage.services.general.PersonfileOperateLogService;
//import com.intellif.cloud.personfile.manage.utils.IpUtil;
//import com.intellif.cloud.personfile.manage.entity.PersonfileOperateLog;
//import com.intellif.cloud.personfile.manage.utils.SuccessRespUtil;
//import com.intellif.log.LoggerUtilI;
//import org.apache.commons.lang.StringUtils;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.AfterReturning;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.DefaultParameterNameDiscoverer;
//import org.springframework.core.ParameterNameDiscoverer;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.lang.reflect.Method;
//import java.util.Date;
//import java.util.Map;
//import java.util.stream.Collectors;
//import java.util.stream.IntStream;
//
///**
// * 操作日志的切面类
// *
// * @author liuzhijian
// * @version 1.0
// * @date 2018年11月15日
// * @see PersonfileOperateLogAspect
// * @since JDK1.8
// */
//@Aspect
//@Component
//@Order(2)
//public class PersonfileOperateLogAspect {
//
//    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
//
//    private PersonfileOperateLog personfileOperateLog;
//
//    @Autowired
//    private PersonfileOperateLogService personfileOperateLogService;
//
//    @Pointcut("@annotation(com.intellif.cloud.personfile.manage.annotation.OperateLog)")
//    public void logPointCut() {
//        throw new UnsupportedOperationException();
//    }
//
//    @Before("logPointCut()")
//    public void beforeHandle(JoinPoint joinPoint) {
//        try {
//            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
//                    .getRequestAttributes()).getRequest();
//            String ip = IpUtil.getIpAddress(request);
//            MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
//            Method method = methodSignature.getMethod();
//            Map fieldsName = getFieldsName(joinPoint);
//            String personFileId = (String) fieldsName.get("personFileId");
//            OperateLog annotation = method.getAnnotation(OperateLog.class);
//            personfileOperateLog = new PersonfileOperateLog();
//            personfileOperateLog.setOperateTime(new Date())
//                    .setOperateUserIp(ip)
//                    .setOperateUserName(IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
//            if (StringUtils.isBlank(personFileId)) {
//                String initiativPersonFileId = (String) fieldsName.get("initiativPersonFileId");
//                String passivePersonFileId = (String) fieldsName.get("passivePersonFileId");
//                personfileOperateLog.setOperateName(initiativPersonFileId + annotation.remark() + passivePersonFileId);
//            } else {
//                personfileOperateLog.setOperateName(annotation.remark() + personFileId);
//            }
//        } catch (Exception e) {
//            logger.error("获取日志异常：{}", e.getMessage());
//        }
//    }
//
//    @AfterReturning(pointcut = "logPointCut()", returning = "result")
//    public void afterHandle(Object result) {
//        try {
//            JSONObject jsonResult = JSONObject.parseObject(result.toString());
//            personfileOperateLog.setRemark(SuccessRespUtil.isSuccess(jsonResult) ? "操作成功" : "操作失败");
//            personfileOperateLogService.insert(personfileOperateLog);
//        } catch (Exception e) {
//            logger.error("保存日志异常：{}", e.getMessage());
//        }
//    }
//
//    private static Map getFieldsName(JoinPoint joinPoint) throws ClassNotFoundException, NoSuchMethodException {
//        Map<String, Class> map = Maps.newHashMap();
//        String classType = joinPoint.getTarget().getClass().getName();
//        String methodName = joinPoint.getSignature().getName();
//        // 参数值
//        Object[] args = joinPoint.getArgs();
//        Class<?>[] classes = new Class[args.length];
//        // 获取的是封装类型而不是基础类型
//        IntStream.range(0, args.length).filter(k -> !args[k].getClass().isPrimitive()).forEach(k -> {
//            String result = args[k].getClass().getName();
//            Class s = map.get(result);
//            classes[k] = s == null ? args[k].getClass() : s;
//        });
//        ParameterNameDiscoverer pnd = new DefaultParameterNameDiscoverer();
//        // 获取指定的方法，第二个参数可以不传，但是为了防止有重载的现象，还是需要传入参数的类型
//        Method method = Class.forName(classType).getMethod(methodName, classes);
//        // 参数名
//        String[] parameterNames = pnd.getParameterNames(method);
//        // 通过map封装参数和参数值
//        return IntStream.range(0, parameterNames.length).boxed().collect(Collectors.toMap(i -> parameterNames[i], i -> args[i], (a, b) -> b, Maps::newHashMap));
//    }
//}
