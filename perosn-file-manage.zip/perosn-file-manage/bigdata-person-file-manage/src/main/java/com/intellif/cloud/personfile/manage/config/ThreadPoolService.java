package com.intellif.cloud.personfile.manage.config;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.intellif.cloud.personfile.manage.contants.ThreadPoolConstant;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 文件名：ThreadPoolService.java
 * 版权：Copyright by 云天励飞 intellif.com
 * 描述： 线程池 初始化
 *
 * @author ：tianhao
 * 创建时间：2018年10月29日
 * 修改理由：
 * 修改内容：
 */
public class ThreadPoolService {
    /**
     * 基础线程池
     */
    public static final ThreadPoolExecutor threadPool;
    
    static {
        threadPool = new ThreadPoolExecutor(
                ThreadPoolConstant.COREPOOL_SIZE,
                ThreadPoolConstant.MAXIMUM_POOL_SIZE,
                ThreadPoolConstant.KEEP_ALIVE_TIME,
                TimeUnit.SECONDS,
                ThreadPoolConstant.WORKQUEUE,
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build(),
                new ThreadPoolExecutor.CallerRunsPolicy());
    }
    
    /**
     * 分表线程池
     */
    public static final ThreadPoolExecutor subThreadPool;
    
    static {
        subThreadPool = new ThreadPoolExecutor(
                5,
                8,
                ThreadPoolConstant.KEEP_ALIVE_TIME,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue(),
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build());
    }
    
    /**
     * 档案线程池
     */
    public static final ThreadPoolExecutor archiveThreadPool;
    
    static {
        archiveThreadPool = new ThreadPoolExecutor(
                4,
                4,
                ThreadPoolConstant.KEEP_ALIVE_TIME,
                TimeUnit.SECONDS,
                new ArrayBlockingQueue(1),
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build(),
                new ThreadPoolExecutor.CallerRunsPolicy());
    }
    
    /**
     * 数据分析线程池
     */
    public static final ThreadPoolExecutor analysisExportThreadPool;
    
    static {
        analysisExportThreadPool = new ThreadPoolExecutor(
                3,
                5,
                1,
                TimeUnit.SECONDS,
                new ArrayBlockingQueue(2),
                new ThreadFactoryBuilder().setNameFormat("XX-task-%d").build());
    }
    
    private ThreadPoolService() {
    }
}
