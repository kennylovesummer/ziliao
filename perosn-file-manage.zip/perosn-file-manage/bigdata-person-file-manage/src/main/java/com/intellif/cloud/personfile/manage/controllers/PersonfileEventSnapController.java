package com.intellif.cloud.personfile.manage.controllers;

import com.github.pagehelper.Page;
import com.google.common.collect.Lists;
import com.intellif.cloud.personfile.manage.contants.ICommonConstant;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.contants.IResultCode;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;
import com.intellif.cloud.personfile.manage.enums.EventTypeEnum;
import com.intellif.cloud.personfile.manage.enums.ResultMessageEnum;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BasePageRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.EventSnapDetailResp;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapResp;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapQueryDTO;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.utils.IPersonFilesResultInfo;
import com.intellif.log.LoggerUtilI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

/**
 * @author liuyu
 * @className EventSnapController
 * @date 2019/3/19 14:05
 * @description
 */
@Api(tags = "事件流")
@RestController
@RequestMapping(IPersonfilesManageConstant.RequestUrl.EVENTFLOW)
public class PersonfileEventSnapController {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final SubEventService subEventService;
    
    private final SubArchiveService subArchiveService;

    @Autowired
    public PersonfileEventSnapController(SubEventService subEventService,SubArchiveService subArchiveService) {
        this.subEventService = subEventService;
        this.subArchiveService = subArchiveService;
    }

    /**
     * 查询事件和事件详情-2018-12-18
     * 档案详情->个人事件流->事件流列表
     *
     * @return
     */
    @ApiOperation(httpMethod = "POST",value = "事件流-获取事件流")
    @PostMapping(value = "/listdetail/{version}")
    public BasePageRespDTO listDetail(@RequestBody SnapQueryDTO snapQueryDTO) {
        try {
            if (StringUtils.isBlank(snapQueryDTO.getPersonFileId())) {
                return new BasePageRespDTO(IResultCode.ERROR, "查询失败", "参数为空");
            }
            List<EventSnapDetailResp> eventSnapDetailRespList = Lists.newLinkedList();
    
            List<EventSnapDetailVO>  personfileSnapDetailList = subEventService.getPersonfileSnapDetail(snapQueryDTO.getPersonFileId(), snapQueryDTO.getStartTime(),snapQueryDTO.getEndTime(),1, 20);
            if (CollectionUtils.isEmpty(personfileSnapDetailList)) {
                return IPersonFilesResultInfo.success(eventSnapDetailRespList, 0, 0, "查询事件和事件详情成功！");
            }
    
            Map<String,List<EventSnapDetailVO>> groupByDt = personfileSnapDetailList.stream().collect(Collectors.groupingBy(EventSnapDetailVO::getSnapDate));
    
            groupByDt.forEach((key,value) ->{
                EventSnapDetailResp eventSnapDetailResp = new EventSnapDetailResp();
                eventSnapDetailResp.setEventType(1);
                eventSnapDetailResp.setOccurrenceDate(key);
                eventSnapDetailResp.setImageCount(0);
                eventSnapDetailResp.setSnap(value);
                eventSnapDetailRespList.add(eventSnapDetailResp);
            });
            
            return IPersonFilesResultInfo.success(eventSnapDetailRespList.stream().sorted(Comparator.comparing(EventSnapDetailResp::getOccurrenceDate).reversed()).collect(Collectors.toList()), 0, 0, "查询事件和事件详情成功！");
                
        } catch (Exception e) {
            logger.error("查询事件和事件详情异常：" + e.getMessage());
        }
        return IPersonFilesResultInfo.error(null, 0, 0, "查询事件和事件详情失败!");
    }
    
    /**
     * 获取更多抓拍照
     *
     * @return
     */
    @ApiOperation(httpMethod = "POST",value = "事件流-获取更多抓拍")
    @PostMapping(value = "/snapmore/{version}")
    public BasePageRespDTO getSnapmore(@RequestParam("personFileId") @NotNull String personFileId,
                                       @RequestParam("snapDate") @NotNull String snapDate,
                                       @RequestParam("page") Integer page,
                                       @RequestParam("perpage") Integer perpage) {
        try {
            Page<EventSnapDetailVO> personfileSnapDetail = subEventService.getPersonfileSnapDetail(personFileId, snapDate,snapDate, page, perpage);
            List<EventSnapDetailVO> result = personfileSnapDetail.getResult();
            result = result.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(EventSnapDetailVO::getFaceId))), ArrayList::new))
                    .stream().sorted(Comparator.comparing(EventSnapDetailVO::getSt).reversed()).collect(Collectors.toList());
            return IPersonFilesResultInfo.success(result, personfileSnapDetail.getPages(),
                    (int) personfileSnapDetail.getTotal(), "查询更多抓拍事件详情成功！");
        } catch (Exception e) {
            logger.error("查询事件和事件详情异常：", e.getMessage());
            return IPersonFilesResultInfo.error(null, 0, 0, "查询更多抓拍事件详情失败!");
        }
    }

    /**
     * 获取有捕获照片的设备(地图)
     *
     * @param snapMapDTO personFilesId	String	档案ID（必填）
     *                   startTime	String	创建开始日期
     *                   endTime	    String	创建结束日期
     *                   eventType	String	事件类型(0-全部,1-抓拍，2-乘车，3-住宿)
     */
    @ApiOperation(httpMethod = "POST",value = "事件流-事件地图")
    @PostMapping("/map/{personFileId}/{version}")
    public BaseDataRespDTO queryMapPictureDevByPersonFileId(@RequestBody SnapMapDTO snapMapDTO, @PathVariable String personFileId) {
        try {
            // 事件类型 全部
            if (String.valueOf(EventTypeEnum.ALL.getId()).equals(snapMapDTO.getEventType())) {
                snapMapDTO.setEventType("");
                // 事件类型不为抓拍,全部返回为空(暂时只有抓拍事件)
            } else if (!String.valueOf(EventTypeEnum.CAPTURE.getId()).equals(snapMapDTO.getEventType())) {
                return new BaseDataRespDTO(null, IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(), ResultMessageEnum.SEARCH_SUCCESS.getMessage());
            }
            snapMapDTO.setPersonFileId(personFileId);
            // 1).先根据档案id、开始和结束时间查询事件id
            // 2).根据事件id查询事件详情
            snapMapDTO.setPerpage(0);
            BaseDataRespDTO result = subEventService.querySnapMapByPersonFilesId(snapMapDTO);
            return result != null ? result : new BaseDataRespDTO(null,IResultCode.SUCCESS, ResultMessageEnum.SEARCH_SUCCESS.getMessage(), "无数据");
        } catch (Exception e){
            logger.error("事件地图获取异常：" + e.getMessage());
        }
        return new BaseDataRespDTO(IResultCode.ERROR, ResultMessageEnum.SEARCH_FAILED.getMessage(), "获取所有设备(地图)异常");
    }

    /**
     * 获取事件详情（地图）
     * personFileId	String	    档案ID（必填）
     * devId	    String	    设备ID（必填）
     * startTime	String	    创建开始日期
     * endTime	    String	    创建结束日期
     * reqPageNum
     * maxResults
     *
     * @return
     */
    @ApiOperation(httpMethod = "POST",value = "事件流-事件地图详情")
    @PostMapping("/map/detail/{version}")
    public BasePageRespDTO mapDetail(@RequestBody SnapQueryDTO snapQueryDTO) {
        try {
            Page<SnapMapVO> snapMapVOList = subEventService.querySnapMapDetail(snapQueryDTO);
            List<SnapMapVO> snapMapVOS = snapMapVOList.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(SnapMapVO::getFaceId))), ArrayList::new));
            Collections.reverse(snapMapVOS);
            Map<String, List<SnapMapVO>> map = snapMapVOS.stream().collect(Collectors.groupingBy(SnapMapVO::getSnapDate));
            List<SnapMapResp> snapMapRespList = Lists.newArrayList();
            map.forEach((k, v) -> {
                SnapMapResp snapMapResp = new SnapMapResp();
                snapMapResp.setOccurrenceDate(k);
                snapMapResp.setSnapMapVOList(v);
                snapMapRespList.add(snapMapResp);
            });
            List<SnapMapResp> snapMapResps = snapMapRespList.stream().sorted(Comparator.comparing(SnapMapResp::getOccurrenceDate).reversed()).collect(Collectors.toList());
            return IPersonFilesResultInfo.success(snapMapResps, snapMapVOList.getPages(),
                    (int) snapMapVOList.getTotal(), "获取地图事件详情成功！");
        } catch (Exception e) {
            logger.error("获取事件地图详情异常：", e.getMessage());
        }
        return IPersonFilesResultInfo.error(null, 0, 0, "获取事件地图详情失败!");
    }

    /**
     * 删除抓拍事件中的照片
     * 事件流中将某个图片放入回收站
     * 统计的采集数减1
     *
     * @param faceId
     * @return BaseDataRespDTO
     */
    @ApiOperation(httpMethod = "DELETE",value = "事件流-删除抓拍")
    @DeleteMapping("/{faceId}/{personfileId}/{version}")
    public BaseDataRespDTO deleteEventSnapImg(@PathVariable("faceId") String faceId, @PathVariable("personfileId") String personfileId,
                                              @PathVariable(name = "version") String version) {
        try {
            subEventService.deleteEventSnapImg(faceId, personfileId);
        } catch (Exception e) {
            logger.error("删除抓拍事件中的照片异常");
            return new BaseDataRespDTO(IResultCode.ERROR, "删除抓拍事件中的照片失败", e.getMessage());
        }
        return new BaseDataRespDTO(null, IResultCode.SUCCESS, "删除抓拍事件中的照片成功");
    }
    
}
