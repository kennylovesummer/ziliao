package com.intellif.cloud.personfile.manage.schedule.camera;

import com.intellif.cloud.personfile.manage.services.general.IDevSynchronizeService;
import com.intellif.log.LoggerUtilI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class CameraSyncSchedule {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    @Autowired
    IDevSynchronizeService devSynchronizeService;
    
    /**
     * 同步设备列表
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void sysnchDevList() {
        try {
            logger.info("job开始同步设备列表开始...");
            devSynchronizeService.devSynchDeepEye();
            logger.info("job开始同步设备列表成功...");
        } catch (Exception e) {
            logger.error("job 同步设备列表异常" + e.getMessage());
        }
    }
}
