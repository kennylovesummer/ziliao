package com.intellif.cloud.personfile.manage.services.sub;

import com.github.pagehelper.Page;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.personfile.PersonfileMergeDTO;
import com.intellif.cloud.personfile.manage.model.dto.req.BaseDataRespDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapMapDTO;
import com.intellif.cloud.personfile.manage.model.dto.snap.SnapQueryDTO;
import com.intellif.cloud.personfile.manage.model.vo.activityRoutine.PersonfileActivityRoutinesVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.EventSnapDetailVO;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.entity.PersonfileBasics;
import com.intellif.cloud.personfile.manage.entity.PersonfileRubbish;
import com.intellif.cloud.personfile.manage.entity.PersonfileSnap;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author liuyu
 * @className PersonfileSnapService
 * @date 2019/3/19 13:57
 * @description
 */
public interface SubEventService {
    
    /**
     * 获取指定档案和时间被抓拍的日期和事件类型
     *
     * @param snapQueryDTO
     * @return
     */
    Page<EventSnapDetailVO> getPersonfileSnap(SnapQueryDTO snapQueryDTO);
    
    /**
     * 获取每天的事件
     *
     * @param personFilesId 档案ID
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param page 页码
     * @param perPage 页码大小
     * @return
     * @throws ParseException
     */
    Page<EventSnapDetailVO> getPersonfileSnapDetail(String personFilesId, String startDate,String endDate, int page, int perPage) throws ParseException;
    
    /**
     * 获取有捕获照片的设备(地图)
     *
     * @param snapMapDTO personFileId	String	档案ID（必填）
     *                   startTime	String	创建开始日期
     *                   endTime	    String	创建结束日期
     *                   eventType	String	事件类型(0-全部,1-抓拍，2-乘车，3-住宿)
     * @return BaseDataRespDTO
     */
    BaseDataRespDTO querySnapMapByPersonFilesId(SnapMapDTO snapMapDTO);
    
    /**
     * 根据档案id获取设备信息
     *
     * @param snapMapDTO personFileId	String	档案ID（必填）
     *                   startTime	String	创建开始日期
     *                   endTime	    String	创建结束日期
     *                   eventType	String	事件类型(0-全部,1-抓拍，2-乘车，3-住宿)
     * @return BaseDataRespDTO
     */
    Page<SnapMapVO> getSnapMapByPersonFilesId(SnapMapDTO snapMapDTO);
    
    /**
     * 获取事件详情(地图)
     *
     * @param snapQueryDTO 事件流详情(地图)
     * @return
     */
    Page<SnapMapVO> querySnapMapDetail(SnapQueryDTO snapQueryDTO);
    
    /**
     * 根据档案ID查找
     *
     * @return List
     */
    List<PersonfileRubbish> getByPersonfileId(String snapId, String personfileId,Integer page,Integer pageSize);
    
    /**
     * 抓拍删除
     */
    int deletePersonfileSnap(PersonfileSnap personfileSnap);
    
    
    /**
     * 根据抓拍id删除抓拍事件
     *
     * @param snapId
     * @param personfileId
     */
    void deleteEventSnapImg(String snapId,String personfileId) throws BusinessException;
    
    /**
     * 批量插入
     *
     * @param personfileSnaps
     * @return
     */
    int batchInsert(List<PersonfileSnap> personfileSnaps);
    
    
    Page<PersonfileActivityRoutinesVO> getSnapActivity(String personFilesId, String startTime, String endTime, Integer activityRoutineType, Integer page, Integer perpage);
    
    /**
     * 根据抓拍总数
     * @return
     */
    int getSnap(String startTime,String endTime);
    
    /**
     * 根据大图url查找抓拍
     *
     * @param imageUrl 大图url
     * @return id
     */
    String findByImageUrl(String imageUrl);
    
    /**
     * 根据时间查询事件数量
     *
     * @param dt   日期
     * @return 数量
     */
    Integer statisticSnapByDate(String dt);
    
    /**
     * 根据档案ID获取抓拍URL
     *
     * @param personFileId 档案ID
     * @return List
     */
    List<String> findSnapUrlsByPersonfileId(String personFileId);
    
    /**
     * 根据档案ID查找该档案第一张抓拍照片时间
     *
     * @param personFileId 档案ID
     * @return Date
     */
    Date findFirstSnapTimeByPersonFileId(String personFileId);
    
    /**
     * 获取最近抓拍时间和总抓拍数量
     *
     * @param personFileId 档案ID
     * @return PersonfileBasics
     */
    List<PersonfileBasics> findSnapTimeAndImageCount(String personFileId);
    
    /**
     * 根据档案ID获取统计信息
     *
     * @param personFileIds 档案IDs
     * @return PersonfileBasics
     */
    List<PersonfileBasics> findSnapTimeAndImageCountByPersonfileId(List<String> personFileIds);
    
    /**
     * 合并档案时事件处理
     *
     * @param params 合并信息
     */
    void updateSnapAid(List<PersonfileMergeDTO> params);
    
    /**
     * 事件同步
     *
     * @param personfileSnaps  事件
     */
    void eventSync(List<PersonfileSnap> personfileSnaps);
    
    /**
     * 批量同步事件
     *
     * @param params
     */
    void batchEventSync(List<Map<String,Object>> params);
    
    /**
     * 根据时间获取系统事件表
     *
     * @param startTime 开始时间(yyyy-MM-dd | yyyy-MM-dd HH:mm:ss)
     * @param endTime 结束时间(yyyy-MM-dd | yyyy-MM-dd HH:mm:ss)
     * @return 表名集合
     */
    List<String> getEventTables(String startTime,String endTime);
    
    List<String> getEventAllTables();
    
    List<SnapMapVO> getSnapMapByPersonFilesId(List<String> personfilesIdList);
}
