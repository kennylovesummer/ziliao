package com.intellif.cloud.personfile.manage.handler.analysis.createTask;

import com.intellif.cloud.personfile.manage.enums.DataStisticTypeEnum;

/**
 * 创建任务链
 *
 * @author liuzj
 * @date 2019-10-18
 */
public class AnalysisCreateHandler {
    
    private static final AbstractAnalysisCreateTaskHandler analysisTraceCreateHandler = new AnalysisTraceCreateHandler(DataStisticTypeEnum.TRACE.getName());
    
    private static final AbstractAnalysisCreateTaskHandler analysisPeerCreateHandler = new AnalysisPeerCreateHandler(DataStisticTypeEnum.PEER.getName());
    
    private static final AbstractAnalysisCreateTaskHandler analysisCrashCreateHandler = new AnalysisCrashCreateHandler(DataStisticTypeEnum.CRASH.getName());
    
    private static final AbstractAnalysisCreateTaskHandler analysisLingerCreateHandler = new AnalysisLingerCreateHandler(DataStisticTypeEnum.LINGER.getName());
    
    private static final AbstractAnalysisCreateTaskHandler analysisActivityCreateHandler = new AnalysisActivityCreateHandler(DataStisticTypeEnum.ACTIVITY.getName());
    
    private static final AbstractAnalysisCreateTaskHandler analysisNocturnalCreateHandler = new AnalysisNocturnalCreateHandler(DataStisticTypeEnum.NOCTURNAL.getName());
    
    static {
        analysisCrashCreateHandler.setNextHandler(analysisPeerCreateHandler);
        analysisTraceCreateHandler.setNextHandler(analysisCrashCreateHandler);
        analysisLingerCreateHandler.setNextHandler(analysisTraceCreateHandler);
        analysisActivityCreateHandler.setNextHandler(analysisLingerCreateHandler);
        analysisNocturnalCreateHandler.setNextHandler(analysisActivityCreateHandler);
    }
    
    public static AbstractAnalysisCreateTaskHandler getHandlerChain() {
        return analysisNocturnalCreateHandler;
    }
}
