package com.intellif.cloud.personfile.manage.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 碰撞分析地区表
 *
 * @author liuzj
 * @date 2019-06-26
 */
@Data
public class BigdataAnalysisCrashArea implements Serializable {
    private static final long serialVersionUID = -967778955801747696L;
    
    private Long id;
    
    private Long taskId;
    
    private String code;
    
    private String areaId;
    
    private String startTime;
    
    private String endTime;
    
    private String devs;
    
    private String address;
    
    List<String> devIds;
    
    private String firstDevId;
    
    private Date createTime;
    
    private String createBy;
    
    private Date modifyTime;
    
    private String modifyBy;
    
    private Integer isDeleted;
}
