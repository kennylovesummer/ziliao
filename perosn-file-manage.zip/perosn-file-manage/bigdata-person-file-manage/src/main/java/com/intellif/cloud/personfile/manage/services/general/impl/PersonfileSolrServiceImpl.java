package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.config.PersonPropertiest;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.BigdataCommon;
import com.intellif.cloud.personfile.manage.model.dto.cluster.PersonfileClusterFinishDTO;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.services.general.BigdataCommonService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileSolrService;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.util.NamedList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 特征值搜索
 *
 * @author liuzj
 * @date 2019-03-15
 * @see PersonfileSolrService
 */
@Service
public class PersonfileSolrServiceImpl implements PersonfileSolrService {
    
    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());
    
    private static final int[][] MAP = {{5022, 2048}, {5023, 2064}, {5024, 724}, {5029, 2064}, {5030, 2064}};
    
    @Autowired
    private PersonPropertiest personPropertiest;
    
    private volatile Integer mapIndex;
    
    @Autowired
    private BigdataCommonService bigdataCommonService;
    
    /**
     * 创建solr客户端
     *
     * @return HttpSolrClient
     */
    private static HttpSolrClient solrClient() {
        HttpSolrClient solrServer = new HttpSolrClient(PersonPropertiest.SOLRURL);
        solrServer.setSoTimeout(250000);
        solrServer.setConnectionTimeout(250000);
        solrServer.setDefaultMaxConnectionsPerHost(100);
        solrServer.setMaxTotalConnections(100);
        solrServer.setFollowRedirects(false);
        solrServer.setAllowCompression(true);
        return solrServer;
    }
    
    @Override
    public void findByFeature(ListFilterDTO listFilterDTO) throws Exception {
        
        if (Strings.isNotBlank(listFilterDTO.getFeature())) {
            SolrClient client = solrClient();
            int tmp = getMapindex();
            float simiRateTemp = personPropertiest.getSimilarRate();
            if (listFilterDTO.getFrom() == 1) {
                List<BigdataCommon> bigdataCommons = bigdataCommonService.findBigdataCommonByContentType(IPersonfilesManageConstant.IRedisCacheKey.PERSONFILES_SIMILAR_RATE);
                if (CollectionUtils.isNotEmpty(bigdataCommons)) {
                    simiRateTemp = Float.valueOf(bigdataCommons.get(0).getContent());
                }
            }
            if (listFilterDTO.getSimilarRate() != null) {
                simiRateTemp = listFilterDTO.getSimilarRate().floatValue();
            }
            final SolrQuery query = new SolrQuery();
            query.setQuery("*:*");
            query.setRequestHandler("/topsearch");
            query.set("fl", "archiveId,score");
            query.set("iff", "true");
            query.set("fq", "type:" + 5);
            query.set("sort", "score:desc");
            query.set("threshold", simiRateTemp + "");
            query.set("feature", MAP[tmp][0] + "@" + listFilterDTO.getFeature());
            query.setRows(personPropertiest.getSimilarPersonFileMaxNum());
            
            QueryResponse response = client.query(query);
            NamedList<Object> namedlist = response.getResponse();
            List<Map<String, Object>> documentList = (List<Map<String, Object>>) namedlist.get("docs");
            List<String> interArchiveIds = Lists.newArrayList();
            List<Map<String, Object>> similars = Lists.newLinkedList();
            if (CollectionUtils.isNotEmpty(documentList)) {
                ArrayList<String> archiveIds = new ArrayList<>();
                documentList.stream().filter((doc) -> doc.get("archiveId") != null)
                        .forEach((doc) -> {
                            Map<String, Object> similar = Maps.newHashMap();
                            archiveIds.add((String) doc.get("archiveId"));
                            similar.put("personfileId", doc.get("archiveId"));
                            similar.put("score", doc.get("score"));
                            similars.add(similar);
                        });
                interArchiveIds = archiveIds;
                if (CollectionUtils.isNotEmpty(listFilterDTO.getPersonFileIds())) {
                    interArchiveIds = listFilterDTO.getPersonFileIds().stream().filter(archiveIds::contains).collect(Collectors.toList());
                }
            } else {
                interArchiveIds.add("personfileId");
            }
            
            listFilterDTO.setPersonFileIds(interArchiveIds);
            listFilterDTO.setSimilars(similars);
            listFilterDTO.setPerpage(personPropertiest.getSimilarPersonFileMaxNum());
            
            if (client != null) {
                client.close();
            }
        }
    }
    
    @Override
    public void insert(List<PersonfileClusterFinishDTO> personfileClusterFinishDTOList) {
        SolrClient client = solrClient();
        List<SolrInputDocument> solrInputDocuments = new LinkedList<>();
        for (PersonfileClusterFinishDTO personfileClusterFinishDTO : personfileClusterFinishDTOList) {
            if (personfileClusterFinishDTO.getFeatureInfo() != null) {
                SolrInputDocument doc = new SolrInputDocument();
                doc.addField("id", Long.parseLong(personfileClusterFinishDTO.getPersonFilesId()));
                doc.addField("archiveId", personfileClusterFinishDTO.getPersonFilesId());
                doc.addField("time", personfileClusterFinishDTO.getPersonFileCreateTime());
                doc.addField("file", "");
                doc.addField("type", "5");
                int tmp = getMapindex();
                byte[] oriFeature = personfileClusterFinishDTO.getFeatureInfo();
                boolean isIgnore1 = ( !(5024 + "").equals(personfileClusterFinishDTO.getAlgoVersion())&& ( !(MAP[tmp][0] + "").equals(personfileClusterFinishDTO.getAlgoVersion()) || oriFeature.length != MAP[tmp][1]));
                if (isIgnore1) {
                    continue;
                }
    
                boolean isIgnore2 = (5024 + "").equals(personfileClusterFinishDTO.getAlgoVersion()) && (!(MAP[tmp][0] + "").equals(personfileClusterFinishDTO.getAlgoVersion()) || (oriFeature.length != MAP[tmp][1] || oriFeature.length != 528));
                if (isIgnore2) {
                    continue;
                }
                doc.addField("feature", Base64.getEncoder().encodeToString(oriFeature));
                doc.addField("version", personfileClusterFinishDTO.getAlgoVersion());
                doc.addField("camera", Long.parseLong(personfileClusterFinishDTO.getPersonFilesId()));
                solrInputDocuments.add(doc);
            }
        }
        
        if (CollectionUtils.isNotEmpty(solrInputDocuments)) {
            try {
                client.add(solrInputDocuments);
                client.commit(true, true, true);
//                refreshSolr();
                logger.info("档案刷入solr成功！-> " + solrInputDocuments.size());
            } catch (SolrServerException | IOException e) {
                logger.error("数据刷入solr失败：" + e.getMessage());
            } finally {
                try {
                    if (client != null) {
                        client.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
    
    /**
     * 删除档案
     *
     * @param personfileId 档案ID
     * @throws IOException
     * @throws SolrServerException
     */
    @Override
    public void deleteByPersonfileId(String personfileId) throws IOException, SolrServerException {
        SolrClient client = solrClient();
        client.deleteByQuery("archiveId:" + personfileId);
        if (client != null) {
            client.close();
        }
        refreshSolr();
    }
    
    /**
     * 刷新solr缓存
     *
     * @return boolean
     * @throws SolrServerException
     * @throws IOException
     */
    private boolean refreshSolr() throws SolrServerException, IOException {
        boolean success = false;
        SolrClient client = solrClient();
        SolrQuery query = new SolrQuery();
        query.setRequestHandler("/topsearch");
        //action=QUERY/WARM_UP/REFRESH_CACHE/FINISH
        query.set("action", "REFRESH_CACHE");
        QueryResponse rsp = client.query(query);
        if (rsp.getStatus() == 0) {
            success = true;
        } else {
        }
        if (client != null) {
            client.close();
        }
        return success;
    }
    
    /**
     * 获取对应版本在 MAP 中的位置
     *
     * @return Integer
     */
    private Integer getMapindex() {
        if (mapIndex != null) {
            return mapIndex;
        }
        Integer tmp = Integer.valueOf(personPropertiest.getVersion());
        int k;
        for (k = 0; k < MAP.length; k++) {
            if (tmp == MAP[k][0]) {
                break;
            }
        }
        if (k >= MAP.length) {
            throw new IllegalArgumentException("don,t supported version " + personPropertiest.getVersion());
        }
        mapIndex = k;
        return mapIndex;
    }
    
}
