package com.intellif.cloud.personfile.manage.services.sub;

import java.util.List;

/**
 * 分表CURD
 *
 * @author liuzj
 * @date 2019-08-22
 * @param <T>
 */
public interface SubService<T> {
    
//    /**
//     * 批量插入
//     *
//     * @param entities 数据集
//     */
//    void subBatchInsert(List<T> entities);
//
//    /**
//     * 查询
//     *
//     * @param params 参数集
//     * @return list
//     */
//    List<T> subSelectOne(Object params);
}
