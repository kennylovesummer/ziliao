package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.annotation.SubSelectMore;
import com.intellif.cloud.personfile.manage.entity.PersonfileLabel;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.vo.snap.SnapMapVO;
import com.intellif.cloud.personfile.manage.services.general.PersonfileLabelService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileMapService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.sub.SubArchiveService;
import com.intellif.cloud.personfile.manage.services.sub.SubEventService;
import com.intellif.cloud.personfile.manage.services.sub.impl.SubEventServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.cloud.personfile.manage.utils.ThreadLocalUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program person-file-manage
 * @Author liuYu
 * @create 2018-10-29 11:27
 * @Version 1.0
 * @desc
 */
@Service
public class PersonfileMapServiceImpl extends BaseServiceImpl implements PersonfileMapService {
    
    @Autowired
    private SubArchiveService subArchiveService;
    
    @Autowired
    private SubEventService subEventService;
    
    @Autowired
    private PersonfileLabelService personfileLabelService;
    
    @Override
    public List<SnapMapVO> get(List<String> lableIds) throws BusinessException {
        List<Integer> labelIdList;
        if (CollectionUtils.isEmpty(lableIds)) {
            List<PersonfileLabel> personfileLabeList = personfileLabelService.findAllPersonfileLabel();
            labelIdList = personfileLabeList.stream().map(PersonfileLabel::getId).collect(Collectors.toList());
        } else {
            labelIdList = lableIds.stream().map(Integer::valueOf).collect(Collectors.toList());
        }
        List<String> personfilesIdList = subArchiveService.findBaseInfoByLabels(labelIdList);
        if (CollectionUtils.isEmpty(personfilesIdList)) {
            return Lists.newArrayList();
        }
        return subEventService.getSnapMapByPersonFilesId(personfilesIdList);
    }
}
