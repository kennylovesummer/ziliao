package com.intellif.cloud.personfile.manage.kafka.consumer;

import com.bigdata.mq.kafka.consumer.AbstractSecurityKafkaConsumer;
import com.intellif.cloud.personfile.manage.config.ThreadPoolService;
import com.intellif.cloud.personfile.manage.kafka.MqMessageHandle;
import com.intellif.log.LoggerUtilI;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.Properties;

/**
 * 事件消费者类AbstractSecurityKafkaConsumer
 */
public class SecurityKafkaEventConsumer extends AbstractSecurityKafkaConsumer {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    private final MqMessageHandle mqMessageHandle;
    
    @Autowired
    public SecurityKafkaEventConsumer(final MqMessageHandle mqMessageHandle, Properties props, String... topic) {
        super(props, topic);
        this.mqMessageHandle = mqMessageHandle;
    }

    @Override
    public void receive(String s) {

    }

    @Override
    public void receive(Collection<String> list) {
        try {
            if (CollectionUtils.isNotEmpty(list)) {
                ThreadPoolService.threadPool.execute(new KafkaConsumerWork(list, mqMessageHandle,0));
            }
        } catch (Exception e){
            logger.error("事件kafka同步异常：" + e.getMessage());
            throw e;
        }
    }
}
