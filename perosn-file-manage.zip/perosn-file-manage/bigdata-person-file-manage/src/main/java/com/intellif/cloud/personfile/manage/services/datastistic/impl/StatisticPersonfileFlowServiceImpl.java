package com.intellif.cloud.personfile.manage.services.datastistic.impl;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileFlowService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName StatisticPersonfileFlowServiceImpl
 * @Author liuzhijian
 * @create 2018-10-31
 * @Version 1.0
 * @desc 人员流动统计实现类
 * @see StatisticPersonfileFlowService
 */
@Service
public class StatisticPersonfileFlowServiceImpl extends BaseServiceImpl implements StatisticPersonfileFlowService {

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = Exception.class)
    public int insert(StatisticPersonfileFlow statisticPersonfileFlow) {
        statisticPersonfileFlow.setCreateTime(new Date());
        statisticPersonfileFlow.setModifiedTime(new Date());
        return this.baseDao.insert(statisticPersonfileFlow);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = Exception.class)
    public int update(StatisticPersonfileFlow statisticPersonfileFlow) {
        return this.baseDao.update(statisticPersonfileFlow);
    }

    @Override
    public StatisticPersonfileFlow findByStatisticDate(String statisticDate) {
        QueryEvent<StatisticPersonfileFlow> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("statisticDate", statisticDate);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findByStatisticDate");
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object != null ? (StatisticPersonfileFlow) object : null;
    }

}
