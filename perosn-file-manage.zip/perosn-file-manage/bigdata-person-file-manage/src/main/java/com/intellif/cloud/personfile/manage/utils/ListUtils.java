package com.intellif.cloud.personfile.manage.utils;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * List工具类
 *
 * @author liuzj
 * @date 2019-07-01
 */
public class ListUtils {
    
    /**
     * 排序
     *
     * @param list 待排序集合
     * @param key  排序字段
     * @param sort 排序规则
     */
    public static void sort(List<Map<String,Object>> list,String key,String sort){
        Collections.sort(list, (o1, o2) -> {
            Long a = (Long)o1.get(key);
            Long b = (Long)o2.get(key);
            if (a == null || b == null) {
                return 0;
            }
            Long c = ("ASC".equalsIgnoreCase(sort)) ? (a - b) : (b - a);
            return c.intValue();
        });
    }
    
    public static List<Map<String,Object>> sort(List<Map<String,Object>> list) {
        return list.stream().sorted(Comparator.comparingDouble(ListUtils::comparingByKey))
                .collect(Collectors.toList());
    }
    
    private static Double comparingByKey(Map<String, Object> map){
        return (Double) map.get("score");
    }
}
