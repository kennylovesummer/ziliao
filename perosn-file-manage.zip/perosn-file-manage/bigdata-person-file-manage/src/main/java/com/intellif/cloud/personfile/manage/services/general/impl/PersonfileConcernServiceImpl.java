package com.intellif.cloud.personfile.manage.services.general.impl;

import com.google.common.collect.Maps;
import com.intellif.cloud.personfile.manage.contants.IPersonfilesManageConstant;
import com.intellif.cloud.personfile.manage.entity.PersonfileConcern;
import com.intellif.cloud.personfile.manage.exceptions.BusinessException;
import com.intellif.cloud.personfile.manage.model.dto.personfile.ListFilterDTO;
import com.intellif.cloud.personfile.manage.services.general.IPersonfileConcernService;
import com.intellif.cloud.personfile.manage.services.general.PersonfileConcernService;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PersonfileConcernServiceImpl extends BaseServiceImpl implements IPersonfileConcernService, PersonfileConcernService {

    @Override
    public List<PersonfileConcern> findByConcerner(String name) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("concerner", name);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findByConcerner");
        return (List) this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    /**
     * 统计查询
     * @return list
     */
    @Override
    public List<PersonfileConcern> findByConcerner(ListFilterDTO listFilterDTO) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = Maps.newHashMap();
        parameters.put("startTime", listFilterDTO.getStartTime());
        parameters.put("endTime", listFilterDTO.getEndTime());
        parameters.put("personName",listFilterDTO.getPersonName());
        parameters.put("labelIds",listFilterDTO.getLabelIds());
        parameters.put("personCid",listFilterDTO.getPersonCid());
        parameters.put("concerner", IPersonfilesManageConstant.DefaultUser.DEFAULT_USER_NAME);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findPersonConcernByConcerner");
        return (List) this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    @Override
    public int insertPersonfileConcern(PersonfileConcern personfileConcern) throws BusinessException, ParseException {
        personfileConcern.setCreateTime(new Date());
        personfileConcern.setModifiedTime(new Date());
        return this.baseDao.insert(personfileConcern);

    }

    @Override
    public int deleteByIdPersonfileConcern(String personFilesId) {
        PersonfileConcern personfileConcern = new PersonfileConcern();
        personfileConcern.setPersonFilesId(personFilesId);
        personfileConcern.setIsDeleted(1);
        return this.baseDao.updateStatement("updateByPersonfileId", personfileConcern);
    }

    @Override
    public PersonfileConcern findByPersonfileId(String personfileId) {
        QueryEvent<PersonfileConcern> queryEvent = new QueryEvent<>();
        Map<String, Object> parameters = new HashMap<>(1);
        parameters.put("personFilesId", personfileId);
        queryEvent.setParameter(parameters);
        queryEvent.setStatement("findByPersonfileId");
        return (PersonfileConcern) this.baseDao.findOneByCustom(queryEvent);
    }

    @Override
    public int updatePersonfileConcern(PersonfileConcern personfileConcern) {
        return this.baseDao.update(personfileConcern);
    }
}
