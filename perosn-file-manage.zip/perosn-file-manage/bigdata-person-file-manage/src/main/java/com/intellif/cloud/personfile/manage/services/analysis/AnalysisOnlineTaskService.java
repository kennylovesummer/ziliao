package com.intellif.cloud.personfile.manage.services.analysis;

import com.alibaba.fastjson.JSONObject;
import com.intellif.cloud.personfile.manage.model.dto.analysis.online.OnlineTaskDTO;

/**
 * 在线分析业务逻辑处理
 *
 * @author liuzj
 * @date 2019-09-12
 */
public interface AnalysisOnlineTaskService {
    
    /**
     * 参数解析
     *
     * @param params 参数
     * @return 基础数据平台参数集
     */
    OnlineTaskDTO paseParam(JSONObject params);
}
