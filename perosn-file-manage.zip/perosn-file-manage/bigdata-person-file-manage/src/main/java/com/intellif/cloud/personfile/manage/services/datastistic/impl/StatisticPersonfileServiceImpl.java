package com.intellif.cloud.personfile.manage.services.datastistic.services.impl;

import com.intellif.cloud.personfile.manage.entity.StatisticPersonfile;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileAge;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileFlow;
import com.intellif.cloud.personfile.manage.entity.StatisticPersonfileType;
import com.intellif.cloud.personfile.manage.model.vo.statistic.StatsticPersonfileTypeAndAgeVO;
import com.intellif.cloud.personfile.manage.services.base.BaseServiceImpl;
import com.intellif.cloud.personfile.manage.services.datastistic.StatisticPersonfileService;
import com.intellif.cloud.personfile.manage.utils.QueryEvent;
import com.intellif.log.LoggerUtilI;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 档案统计
 *
 * @author liuzhijian
 * @version 1.0
 * @date 2018年10月20日
 * @see StatisticPersonfileService
 * @since JDK1.8
 */
@Service
public class StatisticPersonfileServiceImpl extends BaseServiceImpl implements StatisticPersonfileService {

    private final LoggerUtilI logger = LoggerUtilI.getLogger(this.getClass().getName());

    @Override
    public List<StatisticPersonfile> findByBtwStatisticDate(String start, String end) {
        QueryEvent queryEvent = new QueryEvent();
        HashMap<String, Object> params = new HashMap<>(2);
        params.put("start", start);
        params.put("end", end);
        queryEvent.setParameter(params);
        queryEvent.setStatement("findByBtwStatisticDate");
        return (List<StatisticPersonfile>) this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    @Override
    public List<Map<String, Object>> findGroupByWeek(String start, String end) {
        QueryEvent queryEvent = new QueryEvent();
        HashMap<String, Object> params = new HashMap<>(2);
        params.put("start", start);
        params.put("end", end);
        queryEvent.setParameter(params);
        queryEvent.setStatement("findGroupByWeek");
        return (List<Map<String, Object>>) this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = Exception.class)
    public int insertStatisticPersonfile(StatisticPersonfile statisticPersonfile) {
        statisticPersonfile.setModifiedTime(new Date());
        statisticPersonfile.setCreateTime(new Date());
        return this.baseDao.insert(statisticPersonfile);
    }

    @Override
    public int updateStatisticPersonfile(StatisticPersonfile statisticPersonfile) {
        return this.baseDao.update(statisticPersonfile);
    }
    
    @Override
    public StatsticPersonfileTypeAndAgeVO getStatisticPersonfile() {
        StatsticPersonfileTypeAndAgeVO statsticPersonfileTypeAndAgeVO = new StatsticPersonfileTypeAndAgeVO();
        QueryEvent<StatisticPersonfileAge> event = new QueryEvent<>();
//        // 年龄分布
        event.setStatement("findStatisticPersonfileAge");
        List<StatisticPersonfileAge> statisticPersonfileAgeList =  this.baseDao.findAllIsPageByCustom(event);
        
        // 人员类型
        StatisticPersonfileType statisticPersonfileType = new StatisticPersonfileType();
        List<StatisticPersonfileType> statisticPersonfileTypeList;
        try {
            statisticPersonfileTypeList = this.baseDao.findAll(statisticPersonfileType);
        } catch (Exception e) {
            logger.error("查询人员类型异常:" + e.getMessage());
            statisticPersonfileTypeList = new ArrayList<>();
        }
        statsticPersonfileTypeAndAgeVO.setAgeList(statisticPersonfileAgeList.stream().sorted(Comparator.comparingInt(StatisticPersonfileAge::getPersonFileAgeId)).collect(Collectors.toList()));
        statsticPersonfileTypeAndAgeVO.setPersonfileTypeList(statisticPersonfileTypeList);
        return statsticPersonfileTypeAndAgeVO;
    }


    @Override
    public List<StatisticPersonfileFlow> getPersonfileFlow(LocalDate startDay, LocalDate endDay) {
        QueryEvent<StatisticPersonfileFlow> queryEvent = new QueryEvent<>();
        HashMap<String, Object> params = new HashMap<>(2);
        params.put("startDay", startDay);
        params.put("endDay", endDay);
        queryEvent.setParameter(params);
        queryEvent.setStatement("findPersonfileFlow");
        return this.baseDao.findAllIsPageByCustom(queryEvent);
    }

    @Override
    public StatisticPersonfile findTopOne(String statisticDate) {
        QueryEvent<StatisticPersonfileFlow> queryEvent = new QueryEvent<>();
        HashMap<String, Object> params = new HashMap<>(1);
        params.put("statisticDate", statisticDate);
        queryEvent.setStatement("findTopOne");
        queryEvent.setParameter(params);
        Object object = this.baseDao.findOneByCustom(queryEvent);
        return object != null ? (StatisticPersonfile) object : null;
    }
    
    @Override
    public void updateStatistic(Integer incTotal, Integer incRealNameTotal) {
        HashMap<String, Object> params = new HashMap<>(2);
        params.put("incTotal", incTotal);
        params.put("incRealNameTotal", incRealNameTotal);
        this.baseDao.updateStatement("updateStatistic",params);
    }
}
