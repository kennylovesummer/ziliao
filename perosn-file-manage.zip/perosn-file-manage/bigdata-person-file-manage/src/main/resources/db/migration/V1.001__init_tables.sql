-- 统计表 start

CREATE TABLE `t_bigdata_statistic_age_daily` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `person_file_age_id` int(11) NOT NULL DEFAULT '0' COMMENT '人员档案年龄（0-未知 1-婴儿 2-小孩 3-少年 4-青少年 5-青年 6-中年 7-壮年 8-中老年 9-老年）',
  `person_file_age_name` varchar(32) NOT NULL DEFAULT '儿童' COMMENT '人员档案年龄名称',
  `total` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '人员档案年龄段统计数量',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_age_id` (`person_file_age_id`) USING BTREE COMMENT '人员档案年龄统计唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='人员档案年龄统计表';

CREATE TABLE `t_bigdata_statistic_archive_daily` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `dt` date NOT NULL COMMENT '统计时间',
  `total` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '统计总数',
  `real_name_total` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '实名档案总数',
  `inc_num` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '人员档案今日新增数量',
  `real_name__inc_num` bigint(11) unsigned NOT NULL DEFAULT '0' COMMENT '新增实名总数',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_personfile_statistic_date` (`dt`) USING BTREE COMMENT '统计时间唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='人员档案统计表';

CREATE TABLE `t_bigdata_statistic_event_daily` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `dt` date NOT NULL COMMENT '统计时间',
  `inc_num` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '每天新增抓拍数量',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `dt` (`dt`) USING BTREE COMMENT '统计日期唯一'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案照片统计表';

CREATE TABLE `t_bigdata_statistic_flow_daily` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `dt` date NOT NULL COMMENT '统计时间',
  `flow_total` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '人员当天流动统计总数',
  `miss_total` int(11) unsigned DEFAULT '0' COMMENT '每日失踪人员统计',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_personfile_statistic_date` (`dt`) USING BTREE COMMENT '统计时间唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='人员档案统计表';

CREATE TABLE `t_bigdata_statistic_label_distribute` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `label_id` int(11) NOT NULL DEFAULT '0' COMMENT '人员档案类型ID',
  `label_name` varchar(32) NOT NULL DEFAULT '' COMMENT '人员档案类型名称',
  `total` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '人员档案数量',
  `is_deleted` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='人员档案类型统计表   ---暂时用不到，直接全量统计';

INSERT INTO `t_bigdata_statistic_age_daily` VALUES (1, now(), now(), 0, '未知', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (2, now(), now(), 1, '婴儿', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (3, now(), now(), 2, '小孩', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (4, now(), now(), 3, '少年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (5, now(), now(), 4, '青少年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (6, now(), now(), 5, '青年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (7, now(), now(), 6, '中年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (8, now(), now(), 7, '壮年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (9, now(), now(), 8, '中老年', 0);
INSERT INTO `t_bigdata_statistic_age_daily` VALUES (10, now(), now(), 9, '老年', 0);

-- 统计表 end

-- 一般业务表 start
CREATE TABLE `t_bigdata_account` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) NOT NULL COMMENT '用户名',
  `account` varchar(255) NOT NULL COMMENT '账号',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `login_time` datetime DEFAULT NULL COMMENT '上次登录时间',
  `is_deleted` int(2) NOT NULL DEFAULT '0' COMMENT '是否被删除（@1：已被删除；@0：未被删除）',
  `create_by` varchar(255) NOT NULL DEFAULT 'superuser' COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_by` varchar(255) NOT NULL DEFAULT 'superuser' COMMENT '更新人',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`) USING BTREE COMMENT '账号唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `t_bigdata_analysis_archive` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `aid` varchar(255) NOT NULL COMMENT '同行人档案ID',
  `cid` varchar(255) DEFAULT NULL COMMENT '同行人身份证号',
  `person_name` varchar(255) DEFAULT '' COMMENT '同行人名字',
  `curr_addr` varchar(255) DEFAULT NULL COMMENT '同行人地址',
  `face_url` varchar(255) DEFAULT '' COMMENT '同行人小图url',
  `event_times` int(20) DEFAULT '0' COMMENT '同行次数',
  `image_count` int(20) DEFAULT '0' COMMENT '同行人抓拍总数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `taskId` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='数据分析档案表';

CREATE TABLE `t_bigdata_analysis_crash` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `aid` varchar(255) NOT NULL COMMENT '档案ID',
  `camera_id` varchar(255) NOT NULL COMMENT '摄像头ID',
  `camera_name` varchar(255) DEFAULT NULL COMMENT '摄像头名称',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `date` bigint(20) DEFAULT NULL COMMENT '抓拍日',
  `image_count` int(11) DEFAULT '0' COMMENT '抓拍总数',
  `geo_string` varchar(255) DEFAULT NULL COMMENT '摄像头坐标',
  `area_code` varchar(255) NOT NULL DEFAULT '' COMMENT '地区ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `taskId` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='碰撞分析结果表';

CREATE TABLE `t_bigdata_analysis_crash_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `code` varchar(255) NOT NULL COMMENT '地区标识（A-A地区，B-B地区）',
  `first_dev_id` varchar(255) DEFAULT NULL COMMENT '第一个设备ID',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `devs` longtext COMMENT '摄像头ID集合（注：多个以英文逗号分隔）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  `area_id` varchar(500) DEFAULT NULL COMMENT '地区序号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `taskId` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='碰撞分析地区表';

CREATE TABLE `t_bigdata_analysis_event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `aid` varchar(255) NOT NULL COMMENT '档案ID',
  `source_aid` varchar(255) DEFAULT NULL COMMENT '被同行人档案ID',
  `camera_id` varchar(255) NOT NULL COMMENT '摄像头ID',
  `face_id` varchar(255) DEFAULT NULL COMMENT '小图ID',
  `face_url` varchar(255) DEFAULT '' COMMENT '小图url',
  `score` double(6,3) DEFAULT '0.000' COMMENT '相似度',
  `date` bigint(20) NOT NULL COMMENT '抓拍日',
  `time` bigint(20) NOT NULL COMMENT '抓拍时间',
  `area_code` varchar(255) DEFAULT NULL COMMENT '地区标识（A-A地区；B-B地区）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `image_id` varchar(500) DEFAULT NULL COMMENT '大图ID',
  `image_url` varchar(500) DEFAULT NULL COMMENT '大图URL',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `trace` (`task_id`,`camera_id`,`date`),
  KEY `crash` (`task_id`,`aid`,`camera_id`,`date`,`area_code`),
  KEY `peer` (`task_id`,`aid`,`camera_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='数据分析事件表';

CREATE TABLE `t_bigdata_analysis_export_task` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `task_id` bigint(11) DEFAULT NULL COMMENT '任务ID',
  `task_name` varchar(255) DEFAULT NULL COMMENT '任务名',
  `task_type` varchar(255) DEFAULT NULL COMMENT '任务类型：碰撞、同行、轨迹.......,取值范围【xxxx】',
  `file_name` varchar(512) DEFAULT NULL COMMENT '生成的文件名称，规范：分析任务类型ID+taskId+当前时间戳+随机数.zip',
  `file_path` varchar(255) DEFAULT NULL COMMENT '生成文件所在路径',
  `req_params` text COMMENT '请求参数(Json)：主要是基于分析任务结果过滤参数 ',
  `start_time` timestamp NULL DEFAULT NULL COMMENT '开始下载时间',
  `end_time` timestamp NULL DEFAULT NULL COMMENT '结束下载时间',
  `exec_id` varchar(255) DEFAULT NULL COMMENT '数据平台执行ID',
  `use_time` bigint(11) DEFAULT NULL COMMENT '下载用时',
  `status` int(9) DEFAULT '0' COMMENT '状态参数 0:等待下载 1：正在下载 2：下载完成  -1：下载失败',
  `download_msg` varchar(255) DEFAULT NULL COMMENT '如果下载失败，错误信息提示，',
  `retry_times` int(9) NOT NULL DEFAULT '0' COMMENT '重试次数',
  `create_by` varchar(255) DEFAULT NULL COMMENT '下载任务请求者',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下载任务创建时间',
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(255) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `t_bigdata_analysis_peer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `aid` varchar(255) NOT NULL,
  `camera_id` varchar(255) NOT NULL COMMENT '摄像头ID',
  `camera_name` varchar(255) DEFAULT NULL COMMENT '摄像头名称',
  `geo_string` varchar(255) DEFAULT NULL COMMENT '摄像头经纬度',
  `date` date DEFAULT NULL COMMENT '抓拍日',
  `face_id` varchar(255) DEFAULT NULL COMMENT '人脸ID',
  `face_url` varchar(255) DEFAULT NULL COMMENT '人脸地址',
  `image_count` bigint(20) DEFAULT '0' COMMENT '抓拍数',
  `score` double(6,3) DEFAULT NULL COMMENT '相似度',
  `time` bigint(20) DEFAULT NULL COMMENT '抓拍时间',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `time_span` int(11) DEFAULT NULL COMMENT '时间间隔',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `taskId` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='同行分析结果表';

CREATE TABLE `t_bigdata_analysis_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '任务名称',
  `areas` varchar(32) NOT NULL DEFAULT '' COMMENT '碰撞地区（注：此处为地区ID，多个以英文逗号分隔）',
  `aid` varchar(255) DEFAULT NULL COMMENT '档案ID',
  `cost_time` bigint(20) DEFAULT NULL COMMENT '耗时',
  `status` int(11) NOT NULL DEFAULT '2' COMMENT '任务状态（0：失败；1：成功；2：正在执行；3：正在同步结果）',
  `exec_id` varchar(255) DEFAULT NULL COMMENT 'azkaban任务ID',
  `result` varchar(1000) DEFAULT NULL COMMENT '执行结果（注：此处保存档案ID，多个以英文逗号分隔）',
  `params` longtext COMMENT '新建任务参数',
  `type` varchar(255) DEFAULT NULL COMMENT '任务类型（azkaban_collision-碰撞，azkaban_peer-同行，azkaban_track-轨迹，azkaban_multicollision-多区域碰撞）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `execId` (`exec_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='碰撞分析任务表';

CREATE TABLE `t_bigdata_analysis_trace` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `date` bigint(255) NOT NULL COMMENT '抓拍日',
  `camera_id` varchar(255) NOT NULL COMMENT '摄像头ID',
  `camera_name` varchar(255) DEFAULT NULL COMMENT '摄像头名字',
  `geo_string` varchar(255) DEFAULT NULL COMMENT '摄像头坐标',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `taskId` (`task_id`),
  KEY `taskIdAndDate` (`task_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='轨迹分析任务表';

CREATE TABLE `t_bigdata_archive` (
  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `cid` varchar(255) DEFAULT NULL COMMENT '身份证',
  `residence_addr` varchar(64) NOT NULL DEFAULT '-' COMMENT '档案户籍所在地',
  `phone_number` varchar(32) NOT NULL DEFAULT '' COMMENT '手机号码',
  `curr_addr` varchar(255) NOT NULL DEFAULT '-' COMMENT '居住地',
  `gender` int(3) NOT NULL DEFAULT '0' COMMENT '性别(1-男， 2-女, 0-未知)',
  `age` int(4) NOT NULL DEFAULT '0' COMMENT '年龄: 0 未知 （备注：只是作为一种参考值）',
  `phone_mac` varchar(64) NOT NULL DEFAULT '-' COMMENT '手机mac地址',
  `transportation_card` varchar(64) NOT NULL DEFAULT '-' COMMENT '交通卡',
  `transportation` varchar(64) NOT NULL DEFAULT '-' COMMENT '交通工具',
  `birthday` date DEFAULT NULL COMMENT '出生年月',
  `recent_snap_time` datetime DEFAULT NULL COMMENT '最近抓拍时间',
  `person_file_create_time` datetime DEFAULT NULL COMMENT '档案创建时间',
  `image_count` int(11) DEFAULT '0' COMMENT '抓拍照片数',
  `avatar_url` varchar(255) DEFAULT NULL COMMENT '头像地址',
  `algo_version` int(11) DEFAULT NULL COMMENT '算法版本',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  UNIQUE KEY `aid` (`aid`) USING BTREE COMMENT '档案ID唯一索引',
  KEY `modifyTime` (`modify_time`),
  KEY `imageCount` (`image_count`),
  KEY `personFileCreateTime` (`person_file_create_time`),
  KEY `cid` (`cid`),
  KEY `name` (`name`),
  KEY `isDeletedAndCid` (`is_deleted`,`cid`),
  KEY `recentSnapTime` (`recent_snap_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案中心人员基础信息表';

CREATE TABLE `t_bigdata_archive_label_record` (
  `aid` varchar(64) NOT NULL DEFAULT '',
  `label_id` bigint(11) NOT NULL DEFAULT '0',
  `label_name` varchar(32) DEFAULT NULL COMMENT '标签名称，数据冗余',
  PRIMARY KEY (`aid`,`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='人员标签关联表';

CREATE TABLE `t_bigdata_avatar_info` (
  `aid` varchar(255) NOT NULL COMMENT '档案ID',
  `feature_info` blob COMMENT '特征值',
  `big_image_url` varchar(255) DEFAULT NULL COMMENT '大图地址',
  `small_image_url` varchar(255) DEFAULT '0' COMMENT '小图地址',
  `target_rect` varchar(255) DEFAULT NULL COMMENT '人脸框',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  UNIQUE KEY `aid` (`aid`) USING BTREE COMMENT '人员档案id唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

CREATE TABLE `t_bigdata_camera_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dev_id` varchar(32) DEFAULT NULL COMMENT '摄像头id',
  `ip` varchar(255) DEFAULT NULL COMMENT '存放摄像头IP',
  `port` int(11) DEFAULT '0' COMMENT '存放摄像头端口',
  `area_id` bigint(20) DEFAULT NULL COMMENT '摄像所属区域ID',
  `geo_string` varchar(255) DEFAULT NULL COMMENT '经纬度',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '摄像头状态：1-有效 0-无效',
  `name` varchar(255) DEFAULT NULL COMMENT '摄像头名字',
  `device_type` varchar(255) DEFAULT NULL COMMENT '设备类型',
  `op_type` int(9) NOT NULL DEFAULT '3' COMMENT '操作类型:深目 1,深目3.0 2,基础服务 3,默认3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dev_id` (`dev_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案中心摄像头信息表';

CREATE TABLE `t_bigdata_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '具体内容',
  `content_type` varchar(255) NOT NULL DEFAULT '' COMMENT '标识',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='通用表';

CREATE TABLE `t_bigdata_concern` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',
  `concerner` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '关注人账号',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '创建人登录账号',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `modify_by` varchar(32) NOT NULL DEFAULT 'superuser' COMMENT '修改人账号',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案中心人员关注信息表';

CREATE TABLE `t_bigdata_event` (
  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',
  `thumbnail_id` varchar(255) NOT NULL COMMENT '小图id',
  `thumbnail_url` varchar(1000) NOT NULL COMMENT '小图地址',
  `image_id` varchar(255) DEFAULT NULL COMMENT '大图ID',
  `image_url` varchar(1000) DEFAULT NULL COMMENT '大图URL',
  `sys_code` varchar(255) DEFAULT NULL COMMENT '系统编码',
  `algo_version` int(11) NOT NULL COMMENT '算法版本',
  `gender_info` varchar(255) DEFAULT NULL COMMENT '性别信息',
  `age_info` varchar(255) DEFAULT NULL COMMENT '年龄信息',
  `hairstyle_info` varchar(255) DEFAULT NULL COMMENT '发型信息',
  `hat_info` varchar(255) DEFAULT NULL COMMENT '帽子信息',
  `glasses_info` varchar(255) DEFAULT NULL COMMENT '眼镜信息',
  `race_info` varchar(255) DEFAULT NULL COMMENT '族别信息',
  `mask_info` varchar(255) DEFAULT NULL COMMENT '口罩信息',
  `skin_info` varchar(255) DEFAULT NULL COMMENT '皮肤信息',
  `pose_info` varchar(255) DEFAULT NULL COMMENT '角度信息',
  `quality_info` decimal(4,3) DEFAULT NULL COMMENT '图片质量评分',
  `target_rect` varchar(255) DEFAULT NULL COMMENT '人脸区域',
  `target_rect_float` varchar(255) DEFAULT NULL COMMENT '检测区域的浮点',
  `land_mark_info` varchar(255) DEFAULT NULL COMMENT '一些脸部轮廓信息',
  `feature_quality` decimal(2,1) DEFAULT NULL COMMENT '图片质量信息',
  `source_id` varchar(255) DEFAULT NULL COMMENT '摄像头ID',
  `source_type` int(11) NOT NULL COMMENT '数据源类型',
  `site` varchar(255) DEFAULT NULL COMMENT '抓拍地点',
  `time` datetime NOT NULL COMMENT '抓拍时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `column1` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `column2` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `column3` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `dt` date DEFAULT NULL COMMENT '抓拍日期',
  UNIQUE KEY `thumbnailId` (`thumbnail_id`) USING BTREE,
  KEY `aid` (`aid`,`dt`),
  KEY `createTime` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='抓拍照片表';

CREATE TABLE `t_bigdata_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `label_name` varchar(32) NOT NULL DEFAULT '' COMMENT '标签名称',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='档案中心人员标签表';

CREATE TABLE `t_bigdata_operate_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `operate_user_name` varchar(255) NOT NULL DEFAULT '' COMMENT '操作者账号',
  `operate_user_id` bigint(11) DEFAULT NULL COMMENT '操作者ID',
  `operate_time` datetime NOT NULL COMMENT '操作时间',
  `operate_name` varchar(255) NOT NULL DEFAULT '' COMMENT '操作名称',
  `operate_user_ip` varchar(32) NOT NULL DEFAULT '' COMMENT '操作者IP',
  `remark` varchar(64) DEFAULT '' COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='操作记录表';

CREATE TABLE `t_bigdata_relationship` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `label` varchar(32) NOT NULL DEFAULT '' COMMENT '关系标签',
  `relationship_name` varchar(32) NOT NULL DEFAULT '' COMMENT '关系名称',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`,`label`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='关系表';

CREATE TABLE `t_bigdata_rubbish` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `aid` varchar(64) NOT NULL DEFAULT '' COMMENT '人员档案ID【编号】',
  `thumbnail_id` varchar(255) NOT NULL COMMENT '小图id',
  `thumbnail_url` varchar(1000) NOT NULL COMMENT '小图地址',
  `image_id` varchar(255) DEFAULT NULL COMMENT '大图id',
  `image_url` varchar(1000) DEFAULT NULL COMMENT '大图地址',
  `sys_code` varchar(255) DEFAULT NULL COMMENT '源数据系统编码',
  `algo_version` int(11) NOT NULL COMMENT '算法版本',
  `gender_info` varchar(255) DEFAULT NULL COMMENT '性别信息',
  `age_info` varchar(255) DEFAULT NULL COMMENT '年龄信息',
  `hairstyle_info` varchar(255) DEFAULT NULL COMMENT '发型信息',
  `hat_info` varchar(255) DEFAULT NULL COMMENT '帽子信息',
  `glasses_info` varchar(255) DEFAULT NULL COMMENT '眼镜信息',
  `race_info` varchar(255) DEFAULT NULL COMMENT '族别信息',
  `mask_info` varchar(255) DEFAULT NULL COMMENT '口罩信息',
  `skin_info` varchar(255) DEFAULT NULL COMMENT '皮肤信息',
  `pose_info` varchar(255) DEFAULT NULL COMMENT '角度信息',
  `quality_info` decimal(4,3) DEFAULT NULL COMMENT '图片质量评分',
  `target_rect` varchar(255) DEFAULT NULL COMMENT '人脸区域',
  `target_rect_float` varchar(255) DEFAULT NULL COMMENT '检测区域的浮点',
  `land_mark_info` varchar(255) DEFAULT NULL COMMENT '一些脸部轮廓信息',
  `feature_quality` decimal(2,1) DEFAULT NULL COMMENT '图片质量信息',
  `source_id` varchar(255) DEFAULT NULL COMMENT '摄像头ID',
  `source_type` int(11) NOT NULL COMMENT '数据源类型',
  `site` varchar(255) DEFAULT NULL COMMENT '抓拍地点',
  `time` datetime NOT NULL COMMENT '抓拍时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `column1` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `column2` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `column3` varchar(255) DEFAULT NULL COMMENT '扩展字段',
  `is_deleted` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除(0-未删除，1-已删除)',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`,`time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='抓拍照片表';

INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (1, 'FZ', '父子', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (2, 'XD', '兄弟', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (3, 'PY', '朋友', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (4, 'FQ', '夫妻', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (5, 'MN', '母女', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (6, 'MZ', '母子', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (7, 'JM', '姐妹', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (8, 'ZM', '姊妹', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (9, 'FN', '父女', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (10, 'QTQS', '其他亲戚', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (11, 'TS', '同事', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);
INSERT INTO `t_bigdata_relationship`(`id`, `label`, `relationship_name`, `create_time`, `modify_time`, `is_deleted`) VALUES (12, 'PEER', '同行', '2019-08-26 11:17:16', '2019-08-26 11:17:16', 0);

INSERT INTO `t_bigdata_common`(`id`, `content`, `content_type`, `remark`, `create_time`, `modify_time`, `is_deleted`) VALUES (1, '{\"frequency\":3,\"relationDepth\":1,\"timeInterval\":90,\"multipleDepth\":3,\"multipleFrequency\":1,\"multipleInterval\":90,\"similarScore\":0.50,\"topNum\":200,\"multipleSimilarScore\":0.50,\"multipleTopNum\":200}', 'RelationshipDefaultFilterVO', '关系图谱默认搜索条件', '2019-05-22 16:15:23', '2019-05-23 14:07:01', 0);

INSERT INTO `t_bigdata_account`(`id`, `name`, `account`, `password`, `login_time`, `is_deleted`, `create_by`, `create_time`, `modify_by`, `modify_time`) VALUES (1, 'superuser', 'superuser', 'introcks', '2019-09-26 14:15:23', 0, 'superuser', '2019-09-26 14:15:27', 'superuser', '2019-09-26 14:15:27');
-- 一般业务表 end