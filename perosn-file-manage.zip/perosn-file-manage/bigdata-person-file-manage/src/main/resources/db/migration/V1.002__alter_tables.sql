alter table t_bigdata_analysis_task change type type varchar(1000) DEFAULT NULL COMMENT '任务类型（0-碰撞，1-同行，2-轨迹）';

alter table t_bigdata_analysis_archive add column `lingerd_count` bigint(20) DEFAULT NULL COMMENT '徘徊次数';
alter table t_bigdata_analysis_archive add column `image_id` varchar(1000) DEFAULT NULL COMMENT '大图ID';
alter table t_bigdata_analysis_archive add column `image_url` varchar(1000) DEFAULT NULL COMMENT '大图URL';
alter table t_bigdata_analysis_archive add column `gender` varchar(255) DEFAULT NULL COMMENT '性别';
alter table t_bigdata_analysis_archive add column `sys_code` varchar(255) DEFAULT NULL COMMENT '业务编码';
alter table t_bigdata_analysis_archive add column `active_count` bigint(20) DEFAULT NULL COMMENT '活动规律出现次数';

alter table t_bigdata_analysis_event add column `target_rect` varchar(1000) DEFAULT NULL COMMENT '人脸框位置';
alter table t_bigdata_analysis_event add column `sys_code` varchar(255) DEFAULT NULL COMMENT '业务编码';
alter table t_bigdata_analysis_event add column `site` varchar(1000) DEFAULT NULL COMMENT '点位信息';

CREATE TABLE `t_bigdata_analysis_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` bigint(20) NOT NULL,
  `aid` varchar(255) DEFAULT NULL,
  `source_id` varchar(255) NOT NULL,
  `periods` varchar(5000) DEFAULT NULL,
  `image_count` bigint(20) DEFAULT NULL,
  `site` varchar(1000) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `create_by` varchar(255) NOT NULL DEFAULT 'superuser',
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modify_by` varchar(255) NOT NULL DEFAULT 'superuser',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;