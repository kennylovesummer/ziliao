DROP INDEX name on  t_bigdata_analysis_task;
alter table t_bigdata_analysis_task change type type varchar(255) DEFAULT NULL COMMENT '任务类型（0-碰撞，1-同行，2-轨迹）';
alter table t_bigdata_analysis_task add UNIQUE index name(name,type);