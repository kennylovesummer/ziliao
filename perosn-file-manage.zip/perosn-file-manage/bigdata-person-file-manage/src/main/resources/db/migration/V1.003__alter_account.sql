alter table t_bigdata_account add column`ip` varchar(255) DEFAULT NULL COMMENT '登录IP';
alter table t_bigdata_analysis_task change remark remark varchar(10000) DEFAULT NULL COMMENT '备注信息';

alter table t_bigdata_archive change algo_version algo_version VARCHAR(255) default null comment '算法版本';
alter table t_bigdata_event change algo_version algo_version VARCHAR(255) default null comment '算法版本';
alter table t_bigdata_event change source_type source_type VARCHAR(255) default null comment '数据源类型';
alter table t_bigdata_rubbish change algo_version algo_version VARCHAR(255) default null comment '算法版本';
alter table t_bigdata_rubbish change source_type source_type VARCHAR(255) default null comment '数据源类型';