#!/bin/bash

#nohup java -XX:+UseConcMarkSweepGC -Xmx2048m -Xms1024m  -XX:+PrintGCDateStamps -XX:+PrintGCDetails -Xloggc:./logs/java_gc.log -XX:-HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=./logs/ -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -jar api.jar --spring.profiles.active=default > nohup.out &
nohup java -XX:+UseConcMarkSweepGC -Xmx2048m -Xms1024m  -XX:+PrintGCDateStamps -XX:+PrintGCDetails -Xloggc:./logs/java_gc.log -Duser.timezone=Asia/Shanghai -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -jar etl-refresh-preprocess.jar > /dev/null 2>&1 &