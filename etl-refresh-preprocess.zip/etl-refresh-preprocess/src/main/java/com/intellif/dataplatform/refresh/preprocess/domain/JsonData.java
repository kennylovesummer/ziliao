package com.intellif.dataplatform.refresh.preprocess.domain;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @author w1992wishes 2018/11/10 9:47
 */
public class JsonData {

    // 质量分值
    private Float Quality;

    // pose json
    private String Pose;

    @JSONField(name = "Quality")
    public Float getQuality() {
        if (Quality == null) {
            Quality = 0F;
        }
        return Quality;
    }

    public void setQuality(Float quality) {
        Quality = quality;
    }

    @JSONField(name = "Pose")
    public String getPose() {
        return Pose;
    }

    public void setPose(String pose) {
        Pose = pose;
    }
}
