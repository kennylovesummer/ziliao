package com.intellif.dataplatform.refresh.preprocess.domain;

/**
 * @author w1992wishes 2019/3/4 15:22
 */
public class FaceAttributeInfo {

    private Object value;

    private int confidence;

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public int getConfidence() {
        return confidence;
    }

    public void setConfidence(int confidence) {
        this.confidence = confidence;
    }
}
