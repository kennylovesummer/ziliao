package com.intellif.dataplatform.refresh.preprocess.util;

import com.intellif.dataplatform.common.exception.DataplatformRuntimeException;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.Properties;

/**
 * 属性加载类
 *
 * @author w1992wishes 2018/11/8 14:29
 */
public class PropertiesUtils {

    private PropertiesUtils() {
    }

    private static final Logger LOG = LogManager.getLogger(PropertiesUtils.class);

    private static Properties props;

    static {
        loadProps();
    }

    private static synchronized void loadProps() {
        props = new Properties();
        try (
                // 要加载的属性文件
                InputStream in = new FileInputStream(new File("." + File.separator + "config" + File.separator + "config.properties"));
        ) {
            props.load(in);
        } catch (IOException e) {
            throw new DataplatformRuntimeException(e);
        }
    }

    /**
     * 获取值
     */
    public static String getStringValue(String key) {
        if (null == props) {
            loadProps();
        }
        return props.getProperty(key);
    }

    /**
     * 获取值
     */
    public static String getStringValue(String key, String defaultValue) {
        if (null == props) {
            loadProps();
        }
        String value =  props.getProperty(key);
        if (StringUtils.isEmpty(value)) {
            LOG.warn("****** the key {} is empty, use default steing value {}. ******" , key, defaultValue);
            return defaultValue;
        }
        return value;
    }

    /**
     * 获取值
     */
    public static Integer getIntValue(String key, Integer defaultValue) {
        Integer value;
        try {
            value = Integer.valueOf(getStringValue(key));
        } catch (Exception e) {
            LOG.error("****** get {} value failure, use default int value.", key, defaultValue, e);
            value = defaultValue;
        }
        return value;
    }

    /**
     * 获取值
     */
    public static Boolean getBooleanValue(String key, Boolean defaultValue) {
        Boolean value;
        try {
            value = Boolean.valueOf(getStringValue(key));
        } catch (Exception e) {
            LOG.error("****** get {} failure, use default boolean value {}", key, defaultValue, e);
            value = defaultValue;
        }
        return value;
    }

    /**
     * 获取值
     */
    public static Float getFloatValue(String key, Float defaultValue) {
        Float value;
        try {
            value = Float.valueOf(getStringValue(key));
        } catch (Exception e) {
            LOG.error("****** get {} failure, use default float value {}", key, defaultValue, e);
            value = defaultValue;
        }
        return value;
    }

    /**
     * 获取值
     */
    public static Double getDoubleValue(String key, Double defaultValue) {
        Double value;
        try {
            value = Double.valueOf(getStringValue(key));
        } catch (Exception e) {
            LOG.error("****** get {} failure, use default double value {}", key, defaultValue, e);
            value = defaultValue;
        }
        return value;
    }

}