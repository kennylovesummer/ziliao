package com.intellif.dataplatform.refresh.preprocess.task;

import com.intellif.dataplatform.refresh.preprocess.ifaas.E_FACE_ATTRIBUTE_LIST;
import com.intellif.dataplatform.refresh.preprocess.thrift.IFaaServiceThriftClient;
import com.intellif.dataplatform.refresh.preprocess.ifaas.T_MulAttrDetectRstRsp_v2;
import com.intellif.dataplatform.refresh.preprocess.ifaas.t_if_rect_t;
import org.apache.thrift.TException;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description :
 * @Author dyl
 * @Date 17:14 2018/12/26
 */
public class TestThrift {

    public static void main(String[] args) throws TException {

/*        String server_ip = "192.168.11.30";
        int server_port = 7788;*/

        IFaaServiceThriftClient iFaaServiceThriftClient = IFaaServiceThriftClient.getInstance();

        String pic_url = "http://192.168.11.100/eng1store1_4/FaceWareHouse/src_0_88203/20190929/20190929T113008_331293_421590_88203.jpg";

        t_if_rect_t t1 = new t_if_rect_t();
        t1.setTop(844);
        t1.setBottom(968);
        t1.setLeft(928);
        t1.setRight(1052);
        t_if_rect_t t2 = new t_if_rect_t();
        t2.setTop(782);
        t2.setBottom(1030);
        t2.setLeft(866);
        t2.setRight(1114);

        List<Integer> attrList = new ArrayList<>();
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue());
        attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
        //T_MulAttrDetectRstRsp_v2 t = iFaaServiceThriftClient.if_image_detect_extract_url_v3(pic_url,attrList,t1, t2, 1,-1);

        T_MulAttrDetectRstRsp_v2 t = iFaaServiceThriftClient.if_image_detect_extract_url_v2(pic_url,attrList,1,5029);
        System.out.println(t.toString());
    }
}
