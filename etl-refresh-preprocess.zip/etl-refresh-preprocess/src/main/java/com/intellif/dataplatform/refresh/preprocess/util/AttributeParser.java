package com.intellif.dataplatform.refresh.preprocess.util;

import com.alibaba.fastjson.JSON;
import com.intellif.dataplatform.refresh.preprocess.domain.FaceAttributeInfo;

/**
 * @author w1992wishes 2019/3/4 15:21
 */
public class AttributeParser {

    private AttributeParser(){}

    /**
     * age占用两个字节，分别表示年龄的区间和实际的年龄值，先左移8位（该8位用于表示年龄段），得到高八位，转换为十进制，用于表示真实年龄
     *
     */
    public static String parseAge(int age) {
        FaceAttributeInfo ageInfo = new FaceAttributeInfo();
        if (age > 255) {
            ageInfo.setValue(Integer.valueOf(Integer.toBinaryString(age >> 8), 2));
        }
        return JSON.toJSONString(ageInfo);
    }

    /**
     * gender字段为209，即11010001，bit位从左往右，依次从低往高。
     * bit 起始从0开始，bit7位表示新版本，bit4~bit6 位为101表示置信度数值，bit0~bit3 位为0001表示属性值1，即男性
     *
     */
    public static String parseGender(int gender) {
        FaceAttributeInfo genderInfo = new FaceAttributeInfo();

        int genderBits = gender & 0xFF;

        // 取后三位转为十进制标识实际性别值
        int intValue = Integer.valueOf(Integer.toBinaryString(genderBits & 0x07), 2);
        String stringValue = "unknown";
        if (intValue == 1) {
            stringValue = "male";
        } else if (intValue == 2) {
            stringValue = "female";
        }
        genderInfo.setValue(stringValue);

        // bit4~bit6 位表示置信度数值， 分 0-7 档
        int confidence = Integer.valueOf(Integer.toBinaryString((genderBits & 0x70) >> 4), 2);
        genderInfo.setConfidence(confidence);

        return JSON.toJSONString(genderInfo);
    }

    /**
     * byte3		byte2		byte1		byte0
     * 00000000   00000000   00000000    00000000
     *              长短发       帽子          眼镜
     */
    public static String parseGlasses(int accessories) {
        FaceAttributeInfo glassesInfo = new FaceAttributeInfo();

        // 取出表示 glasses 的 byte0
        int glasses = accessories & 0xFF;

        // 取后三位转为十进制标识实际值
        int intValue = Integer.valueOf(Integer.toBinaryString(glasses & 0x07), 2);
        String stringValue = "unknown";
        if (intValue == 1) {
            stringValue = "no";
        } else if (intValue == 2) {
            stringValue = "glasses";
        } else if (intValue == 3) {
            stringValue = "sunglasses";
        }
        glassesInfo.setValue(stringValue);

        // bit4~bit6 位表示置信度数值， 分 0-7 档
        int confidence = Integer.valueOf(Integer.toBinaryString((glasses & 0x70) >> 4), 2);
        glassesInfo.setConfidence(confidence);

        return JSON.toJSONString(glassesInfo);
    }

    /**
     * byte3		byte2		byte1		byte0
     * 00000000   00000000   00000000    00000000
     *              长短发       帽子          眼镜
     */
    public static String parseHat(int accessories) {
        FaceAttributeInfo hatInfo = new FaceAttributeInfo();

        // 取出表示 hat 的 byte1
        int hat = (accessories & 0xFF00) >> 8;

        // 取后三位转为十进制标识实际值
        int intValue = Integer.valueOf(Integer.toBinaryString(hat & 0x07), 2);
        String stringValue = "unknown";
        if (intValue == 1) {
            stringValue = "no";
        } else if (intValue == 2) {
            stringValue = "yes";
        }
        hatInfo.setValue(stringValue);

        // bit4~bit6 位表示置信度数值， 分 0-7 档
        int confidence = Integer.valueOf(Integer.toBinaryString((hat & 0x70) >> 4), 2);
        hatInfo.setConfidence(confidence);

        return JSON.toJSONString(hatInfo);
    }

    /**
     * byte3		byte2		byte1		byte0
     * 00000000   00000000   00000000    00000000
     *              长短发       帽子          眼镜
     */
    public static String parseHairStyle(int accessories) {
        FaceAttributeInfo hairStyleInfo = new FaceAttributeInfo();

        // 取出表示 HairStyle 的 byte2
        int hairStyle = (accessories & 0xFF0000) >> 16;

        // 取后三位转为十进制标识实际值
        int intValue = Integer.valueOf(Integer.toBinaryString(hairStyle & 0x07), 2);
        String stringValue = "unknown";
        if (intValue == 1) {
            stringValue = "short";
        } else if (intValue == 2) {
            stringValue = "long";
        }
        hairStyleInfo.setValue(stringValue);

        // bit4~bit6 位表示置信度数值， 分 0-7 档
        int confidence = Integer.valueOf(Integer.toBinaryString((hairStyle & 0x70) >> 4), 2);
        hairStyleInfo.setConfidence(confidence);

        return JSON.toJSONString(hairStyleInfo);
    }

    /**
     * byte3		byte2		byte1		byte0
     * 00000000   00000000   	00000000   	00000000
     *            	              口罩		  民族
     */
    public static String parseRace(int race) {
        FaceAttributeInfo raceInfo = new FaceAttributeInfo();

        int raceBits = race & 0xFF;

        // 取后三位转为十进制标识实际值
        int intValue = Integer.valueOf(Integer.toBinaryString(raceBits & 0x07), 2);
        String stringValue = "han";
        if (intValue == 1) {
            stringValue = "other";
        }
        raceInfo.setValue(stringValue);

        // bit4~bit6 位表示置信度数值， 分 0-7 档
        int confidence = Integer.valueOf(Integer.toBinaryString((raceBits & 0x70) >> 4), 2);
        raceInfo.setConfidence(confidence);

        return JSON.toJSONString(raceInfo);
    }
}
