package com.intellif.dataplatform.refresh.preprocess.action;

import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * @author w1992wishes 2019/4/30 10:53
 */
public abstract class Action<T> {

    protected Action<T> nextAction;

    protected Logger logger = LogManager.getLogger(getClass());

    protected AppConfig appConfig;

    public Action(AppConfig appConfig, Action<T> nextAction) {
        this.appConfig = appConfig;
        this.nextAction = nextAction;
    }

    public abstract void doAction(List<T> list);

}
