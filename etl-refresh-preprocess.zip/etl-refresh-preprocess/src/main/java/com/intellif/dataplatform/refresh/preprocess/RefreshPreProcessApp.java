package com.intellif.dataplatform.refresh.preprocess;

import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.task.RefreshPreProcessTask;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @author w1992wishes 2018/11/8 14:53
 */
public class RefreshPreProcessApp {

    private static final Logger LOG = LogManager.getLogger(RefreshPreProcessApp.class);

    public static void main(String[] args) throws InterruptedException {
        ScheduledExecutorService scheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        AppConfig appConfig = new AppConfig();
        Runnable refreshPreProcessTask = new RefreshPreProcessTask(appConfig);
        scheduledExecutor.scheduleWithFixedDelay(refreshPreProcessTask, 1, appConfig.getRefreshPeriod(), TimeUnit.SECONDS);

        LOG.info("****** refresh server started. ******");

        scheduledExecutor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
    }
}
