package com.intellif.dataplatform.refresh.preprocess.config;

import com.intellif.dataplatform.refresh.preprocess.util.PropertiesUtils;

/**
 * @author w1992wishes 2019/4/18 11:06
 */
public class AppConfig {

    private int exchangeCapacity = PropertiesUtils.getIntValue("exchange.capacity", 10000);

    private int readerTimeStep = PropertiesUtils.getIntValue("reader.time.step", 5);

    private int writerThreads = PropertiesUtils.getIntValue("writer.thread.num", 10);

    private String odlPendingTable = PropertiesUtils.getStringValue("odl.pending.table");
    private String dwdFaceTable = PropertiesUtils.getStringValue("dwd.face.table");

    private String refreshEngine = PropertiesUtils.getStringValue("refresh.engine");
    private int refreshExceptVersion = PropertiesUtils.getIntValue("refresh.feature.version", 5029);
    private int refreshThreadNum = PropertiesUtils.getIntValue("refresh.thread.num", 10);
    private Integer refreshSecondRange = PropertiesUtils.getIntValue("refresh.second.range", 300);
    private Integer refreshPeriod = PropertiesUtils.getIntValue("refresh.period", 120);

    private boolean kafkaEnable = PropertiesUtils.getBooleanValue("kafka.enable", false);
    private String kafkaServers = PropertiesUtils.getStringValue("kafka.bootstrap.servers");
    private String kafkaOutputTopic = PropertiesUtils.getStringValue("kafka.output.topic");

    private boolean refreshThriftV3 = PropertiesUtils.getBooleanValue("refresh.thrift.v3", true);
    private boolean refreshFeature = PropertiesUtils.getBooleanValue("refresh.feature.enable", true);
    private boolean refreshQuality = PropertiesUtils.getBooleanValue("refresh.quality.enable", true);
    private boolean refreshPose = PropertiesUtils.getBooleanValue("refresh.pose.enable", true);
    private boolean refreshAge = PropertiesUtils.getBooleanValue("refresh.age.enable", false);
    private boolean refreshGender = PropertiesUtils.getBooleanValue("refresh.gender.enable", false);
    private boolean refreshRace = PropertiesUtils.getBooleanValue("refresh.race.enable", false);
    private boolean refreshHairstyle = PropertiesUtils.getBooleanValue("refresh.hairstyle.enable", false);
    private boolean refreshHatInfo = PropertiesUtils.getBooleanValue("refresh.hatInfo.enable", false);
    private boolean refreshGlassesInfo = PropertiesUtils.getBooleanValue("refresh.glassesInfo.enable", false);
    private boolean refreshMaskInfo = PropertiesUtils.getBooleanValue("refresh.maskInfo.enable", false);
    private boolean refreshSkinInfo = PropertiesUtils.getBooleanValue("refresh.skinInfo.enable", false);
    private boolean refreshTargetRect = PropertiesUtils.getBooleanValue("refresh.targetRect.enable", false);
    private boolean refreshLandMarkInfo = PropertiesUtils.getBooleanValue("refresh.landMarkInfo.enable", false);

    private int writeThreadNums = PropertiesUtils.getIntValue("writer.thread.num", 10);
    private double writerErrorRatio = PropertiesUtils.getDoubleValue("writer.error.ratio", 0.01d);

    private String loadBalancer = PropertiesUtils.getStringValue("load.balancer", "weight");

    private int socketTimeout = PropertiesUtils.getIntValue("thrift.socket.timeout.ms", 60000);

    public int getRefreshExceptVersion() {
        return refreshExceptVersion;
    }

    public Integer getRefreshSecondRange() {
        return refreshSecondRange;
    }

    public Integer getRefreshPeriod() {
        return refreshPeriod;
    }

    public String getOdlPendingTable() {
        return odlPendingTable;
    }

    public String getDwdFaceTable() {
        return dwdFaceTable;
    }

    public boolean isKafkaEnable() {
        return kafkaEnable;
    }

    public String getKafkaServers() {
        return kafkaServers;
    }

    public String getKafkaOutputTopic() {
        return kafkaOutputTopic;
    }

    public int getWriteThreadNums() {
        return writeThreadNums;
    }

    public int getRefreshThreadNum() {
        return refreshThreadNum;
    }

    public boolean isRefreshQuality() {
        return refreshQuality;
    }

    public boolean isRefreshPose() {
        return refreshPose;
    }

    public boolean isRefreshAge() {
        return refreshAge;
    }

    public boolean isRefreshGender() {
        return refreshGender;
    }

    public boolean isRefreshRace() {
        return refreshRace;
    }

    public boolean isRefreshHairstyle() {
        return refreshHairstyle;
    }

    public boolean isRefreshHatInfo() {
        return refreshHatInfo;
    }

    public boolean isRefreshGlassesInfo() {
        return refreshGlassesInfo;
    }

    public boolean isRefreshMaskInfo() {
        return refreshMaskInfo;
    }

    public boolean isRefreshSkinInfo() {
        return refreshSkinInfo;
    }

    public boolean isRefreshTargetRect() {
        return refreshTargetRect;
    }

    public boolean isRefreshLandMarkInfo() {
        return refreshLandMarkInfo;
    }

    public boolean isRefreshFeature() {
        return refreshFeature;
    }

    public boolean isRefreshThriftV3() {
        return refreshThriftV3;
    }

    public int getExchangeCapacity() {
        return exchangeCapacity;
    }

    public int getReaderTimeStep() {
        return readerTimeStep;
    }

    public int getWriterThreads() {
        return writerThreads;
    }

    public String getRefreshEngine() {
        return refreshEngine;
    }

    public String getLoadBalancer() {
        return loadBalancer;
    }

    public int getSocketTimeout() {
        return socketTimeout;
    }

    public double getWriterErrorRatio() {
        return writerErrorRatio;
    }
}
