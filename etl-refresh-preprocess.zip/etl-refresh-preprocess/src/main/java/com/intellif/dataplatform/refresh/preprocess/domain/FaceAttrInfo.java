package com.intellif.dataplatform.refresh.preprocess.domain;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * @Description :
 * @Author dyl
 * @Date 15:18 2018/12/28
 */
public class FaceAttrInfo {

    // 属性列表
    private String attributes;

    // rect
    private String faceRect;

    // landmark
    private String landMark;

    @JSONField(name = "attributes")
    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    @JSONField(name = "face_rect")
    public String getFaceRect() {
        return faceRect;
    }

    public void setFaceRect(String faceRect) {
        this.faceRect = faceRect;
    }

    @JSONField(name = "landmark")
    public String getLandMark() {
        return landMark;
    }

    public void setLandMark(String landMark) {
        this.landMark = landMark;
    }
}
