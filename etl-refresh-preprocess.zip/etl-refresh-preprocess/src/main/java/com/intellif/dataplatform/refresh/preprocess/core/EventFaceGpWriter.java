package com.intellif.dataplatform.refresh.preprocess.core;

import com.alibaba.fastjson.JSON;
import com.intellif.dataplatform.common.domain.EventFace;
import com.intellif.dataplatform.common.sync.collector.MessageCollector;
import com.intellif.dataplatform.common.sync.transport.Exchange;
import com.intellif.dataplatform.common.sync.writer.AbstractEventFaceWriter;
import com.intellif.dataplatform.common.sync.writer.WriterConfig;
import com.intellif.dataplatform.common.util.DBUtils;
import com.intellif.dataplatform.refresh.preprocess.action.Action;
import com.intellif.dataplatform.refresh.preprocess.action.preprocess.EventFacePreProcessAction;
import com.intellif.dataplatform.refresh.preprocess.action.refresh.EventFaceRefreshAction;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.domain.FeatureSendStr;
import com.intellif.dataplatform.refresh.preprocess.util.DataSourceUtils;
import com.intellif.dataplatform.refresh.preprocess.util.KafkaSender;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;

/**
 * @author w1992wishes 2019/5/20 9:46
 */
public class EventFaceGpWriter extends AbstractEventFaceWriter {

    private AppConfig appConfig;
    private Action<EventFace> action;

    public EventFaceGpWriter(AppConfig appConfig, WriterConfig config, Exchange<EventFace> exchange, MessageCollector collector) {
        super(config, exchange, collector);
        this.appConfig = appConfig;
        Action<EventFace> preProcessAction = new EventFacePreProcessAction(appConfig, null);
        this.action = new EventFaceRefreshAction(appConfig, preProcessAction);
    }

    @Override
    protected Connection getSinkConnection() throws SQLException {
        return DataSourceUtils.getDwdConnection();
    }

    @Override
    protected void doTransfer(List<EventFace> list) {
        action.doAction(list);
    }

    @Override
    protected void doPostWrite(List<EventFace> subList) {
        if (appConfig.isKafkaEnable()) {
            subList.stream()
                    .filter(eventFace -> !Objects.isNull(eventFace) && !Objects.isNull(eventFace.getFeatureQuality()))
                    .filter(eventFace -> eventFace.getFeatureQuality().compareTo(-1.0f) >= 0 &&
                            eventFace.getFeatureQuality().compareTo(0.0f) != 0)
                    .forEach(eventFace -> KafkaSender.sendMessage(appConfig.getKafkaOutputTopic(), JSON.toJSONString(new FeatureSendStr<>("search", eventFace))));
            logger.info("=======> {} send {} kafka message.", Thread.currentThread().getName(), subList.size());
        }
    }

    @Override
    public void fillPreparedStatement(PreparedStatement ps, EventFace eventFace) throws SQLException {
        ps.setString(1, eventFace.getSysCode());
        ps.setString(2, eventFace.getThumbnailId());
        ps.setString(3, eventFace.getThumbnailUrl());
        ps.setString(4, eventFace.getImageId());
        ps.setString(5, eventFace.getImageUrl());
        ps.setBytes(6, eventFace.getFeatureInfo());
        ps.setString(7, eventFace.getAlgoVersion());
        ps.setString(8, eventFace.getGenderInfo());
        ps.setString(9, eventFace.getAgeInfo());
        ps.setString(10, eventFace.getHairstyleInfo());
        ps.setString(11, eventFace.getHatInfo());
        ps.setString(12, eventFace.getGlassesInfo());
        ps.setString(13, eventFace.getRaceInfo());
        ps.setString(14, eventFace.getMaskInfo());
        ps.setString(15, eventFace.getSkinInfo());
        ps.setString(16, eventFace.getPoseInfo());
        ps.setFloat(17, eventFace.getQualityInfo());
        ps.setString(18, eventFace.getTargetRect());
        ps.setString(19, eventFace.getTargetRectFloat());
        ps.setString(20, eventFace.getTargetThumbnailRect());
        ps.setString(21, eventFace.getLandMarkInfo());
        ps.setString(22, eventFace.getSourceId());
        ps.setString(23, eventFace.getSourceType());
        ps.setString(24, eventFace.getSite());
        ps.setTimestamp(25, eventFace.getTime());
        ps.setTimestamp(26, Timestamp.valueOf(LocalDateTime.now().withNano(0)));
        ps.setFloat(27, Objects.isNull(eventFace.getFeatureQuality()) ? 0.f : eventFace.getFeatureQuality());
        ps.setTimestamp(28, Timestamp.valueOf(LocalDateTime.now().withNano(0)));
        ps.setString(29, eventFace.getColumn1());
        ps.setString(30, eventFace.getColumn2());
        ps.setString(31, eventFace.getColumn3());
    }

    @Override
    public void makeAlert() {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DataSourceUtils.getAlertConnection();
            String sql = "insert into t_alert_info(alert_process, alert_time, alert_status, alert_detail) " +
                    "values(?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, "etl-refresh_preprocess");
            ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS)));
            ps.setString(3, "NEW");
            ps.setString(4, "write failure!");
            ps.execute();
        } catch (Exception e) {
            logger.warn("save alert fail. ", e);
        } finally {
            DBUtils.closeDBResources(null, ps, conn);
        }
    }

    @Override
    public String getWriteSql(String table) {
        return String.format("insert into %s (sys_code, thumbnail_id, thumbnail_url, image_id, image_url, " +
                        "feature_info, algo_version, gender_info, age_info, hairstyle_info, " +
                        "hat_info, glasses_info, race_info, mask_info, skin_info, " +
                        "pose_info, quality_info, target_rect, target_rect_float, target_thumbnail_rect, " +
                        "land_mark_info, source_id, source_type, site, time, " +
                        "create_time, feature_quality, save_time, column1, column2, " +
                        "column3) " +
                        "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
                        "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
                        "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
                        "?)",
                table);
    }
}
