package com.intellif.dataplatform.refresh.preprocess.util;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author w1992wishes 2019/4/13 14:53
 */
public class KafkaSender {

    private static final Logger LOG = LogManager.getLogger(KafkaSender.class);

    private KafkaSender() {
    }

    private static KafkaProducer<String, String> kafkaProducer;

    public static KafkaProducer<String, String> getInstance() {
        if (kafkaProducer != null) {
            return kafkaProducer;
        } else {
            try {
                Properties props = new Properties();
                InputStream is = new FileInputStream("." + File.separator + "config" + File.separator + "kafka.properties");
                props.setProperty("bootstrap.servers", PropertiesUtils.getStringValue("kafka.bootstrap.servers"));
                props.load(is);
                kafkaProducer = new KafkaProducer<>(props);
                return kafkaProducer;
            } catch (Exception e) {
                LOG.error("KafkaProducer initialization error. Please check the configuration file!", e);
                throw new ExceptionInInitializerError("****** KafkaProducer initialization error. Please check the configuration file!");
            }
        }
    }

    public static void sendMessage(String topic, String message) {
        getInstance().send(new ProducerRecord<>(topic, message));
    }
}
