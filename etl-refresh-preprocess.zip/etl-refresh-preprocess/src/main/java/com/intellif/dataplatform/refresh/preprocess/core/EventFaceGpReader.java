package com.intellif.dataplatform.refresh.preprocess.core;

import com.intellif.dataplatform.common.domain.EventFace;
import com.intellif.dataplatform.common.sync.collector.MessageCollector;
import com.intellif.dataplatform.common.sync.reader.AbstractEventFaceReader;
import com.intellif.dataplatform.common.sync.reader.ReaderConfig;
import com.intellif.dataplatform.common.sync.transport.Exchange;
import com.intellif.dataplatform.common.util.DBUtils;
import com.intellif.dataplatform.refresh.preprocess.util.DataSourceUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * @author w1992wishes 2019/5/20 9:33
 */
public class EventFaceGpReader extends AbstractEventFaceReader {
    public EventFaceGpReader(ReaderConfig config, Exchange<EventFace> exchange, MessageCollector collector) {
        super(config, exchange, collector);
    }

    @Override
    public void makeAlert() {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            String sql = "insert into t_alert_info(alert_process, alert_time, alert_status, alert_detail) " +
                    "values(?, ?, ?, ?)";
            conn = DataSourceUtils.getAlertConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, "etl-refresh_preprocess");
            ps.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS)));
            ps.setString(3, "NEW");
            ps.setString(4, "read failure!");
            ps.execute();
        } catch (Exception e) {
            LOG.warn("save alert fail. ", e);
        } finally {
            DBUtils.closeDBResources(null, ps, conn);
        }
    }

    @Override
    protected Connection getSourceConnection() throws SQLException {
        return DataSourceUtils.getOdlConnection();
    }
}
