package com.intellif.dataplatform.refresh.preprocess.domain;

/**
 * @Description :
 * @Author dyl
 * @Date 15:51 2018/12/28
 */
public class Pose {

    private Integer pitch;

    private Integer roll;

    private Integer yaw;


    public Pose(Integer pitch, Integer roll, Integer yaw) {
        this.pitch = pitch;
        this.roll = roll;
        this.yaw = yaw;
    }

    public Pose() {
    }

    public Integer getPitch() {
        return pitch;
    }

    public void setPitch(Integer pitch) {
        this.pitch = pitch;
    }

    public Integer getRoll() {
        return roll;
    }

    public void setRoll(Integer roll) {
        this.roll = roll;
    }

    public Integer getYaw() {
        return yaw;
    }

    public void setYaw(Integer yaw) {
        this.yaw = yaw;
    }
}
