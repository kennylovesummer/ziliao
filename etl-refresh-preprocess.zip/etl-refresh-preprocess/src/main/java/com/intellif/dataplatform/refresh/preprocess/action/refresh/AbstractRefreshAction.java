package com.intellif.dataplatform.refresh.preprocess.action.refresh;

import com.intellif.dataplatform.common.util.ListUtils;
import com.intellif.dataplatform.common.util.ThreadFactoryUtils;
import com.intellif.dataplatform.refresh.preprocess.action.Action;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author w1992wishes 2019/4/30 10:54
 */
public abstract class AbstractRefreshAction<T> extends Action<T> {

    private ExecutorService refreshThreadPool;

    AbstractRefreshAction(AppConfig appConfig, Action<T> nextAction){
        super(appConfig, nextAction);
        this.refreshThreadPool = Executors.newFixedThreadPool(appConfig.getRefreshThreadNum(),
                ThreadFactoryUtils.getNameThreadFactory("refresh_thread_"));
    }

    @Override
    public void doAction(List<T> list) {
        int segments = appConfig.getRefreshThreadNum();
        logger.info("======> there are {} threads totally to refresh data.", segments);

        CountDownLatch countDownLatch = new CountDownLatch(segments);
        ListUtils.averageAssign(list, segments).forEach(subList ->
                refreshThreadPool.execute(() -> {
                    try {
                        doRefreshAction(subList);
                    } finally {
                        countDownLatch.countDown();
                    }
                    nextAction.doAction(subList);
                }));
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        logger.info("****** all transfer thread finish. ******");
    }

    abstract void doRefreshAction(List<T> subList);

}
