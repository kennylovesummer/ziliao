package com.intellif.dataplatform.refresh.preprocess.domain;

/**
 * @Description :
 * @Author dyl
 * @Date 15:51 2018/12/28
 */
public class Headpose {

    private Integer pitch_angle;

    private Integer roll_angle;

    private Integer yaw_angle;

    public Integer getPitch_angle() {
        return pitch_angle;
    }

    public void setPitch_angle(Integer pitch_angle) {
        this.pitch_angle = pitch_angle;
    }

    public Integer getRoll_angle() {
        return roll_angle;
    }

    public void setRoll_angle(Integer roll_angle) {
        this.roll_angle = roll_angle;
    }

    public Integer getYaw_angle() {
        return yaw_angle;
    }

    public void setYaw_angle(Integer yaw_angle) {
        this.yaw_angle = yaw_angle;
    }
}
