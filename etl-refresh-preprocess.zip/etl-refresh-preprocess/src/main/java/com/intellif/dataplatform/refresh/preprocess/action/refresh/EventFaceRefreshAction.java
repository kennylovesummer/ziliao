package com.intellif.dataplatform.refresh.preprocess.action.refresh;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.intellif.dataplatform.common.domain.EventFace;
import com.intellif.dataplatform.common.domain.RectInfo;
import com.intellif.dataplatform.refresh.preprocess.action.Action;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.domain.Attributes;
import com.intellif.dataplatform.refresh.preprocess.domain.FaceAttrInfo;
import com.intellif.dataplatform.refresh.preprocess.domain.Headpose;
import com.intellif.dataplatform.refresh.preprocess.domain.Pose;
import com.intellif.dataplatform.refresh.preprocess.ifaas.*;
import com.intellif.dataplatform.refresh.preprocess.thrift.IFaaServiceThriftClient;
import com.intellif.dataplatform.refresh.preprocess.util.AttributeParser;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * @author w1992wishes 2019/4/30 10:59
 */
public class EventFaceRefreshAction extends AbstractRefreshAction<EventFace> {

    private static final String ATTRIBUTE_PREFIX = "1101";

    private static final String UNKNOW = "unknow";


    public EventFaceRefreshAction(AppConfig appConfig, Action<EventFace> nextAction) {
        super(appConfig, nextAction);
    }

    @Override
    void doRefreshAction(List<EventFace> eventFaces) {
        logger.info("****** {} starts.", Thread.currentThread().getName());
        // 统计出错的数量
        int warnCount = 0;

        for (EventFace eventFace : eventFaces) {
            boolean isRefreshFeature = false;
            int beFeaExtra = 0;
            //拼装需提取属性的attribute list
            List<Integer> attrList = new ArrayList<>();
            if (appConfig.isRefreshFeature() &&
                    (ArrayUtils.isEmpty(eventFace.getFeatureInfo())
                            || Integer.valueOf(eventFace.getAlgoVersion()) != appConfig.getRefreshExceptVersion())) {
                isRefreshFeature = true;
                beFeaExtra = 1;
                // 更改算法版本
                eventFace.setAlgoVersion(appConfig.getRefreshExceptVersion() + "");
                // 先清除特征信息
                eventFace.setFeatureInfo(null);
            }
            boolean isRefreshOtherAtt = isNeedRefresh(eventFace, attrList);
            if (isRefreshFeature || isRefreshOtherAtt) {
                String thumbnailUrl = eventFace.getThumbnailUrl();
                if (StringUtils.isNotEmpty(thumbnailUrl)) {
                    try {
                        T_MulAttrDetectRstRsp_v2 t = getAttrDetectRstRsp(eventFace, beFeaExtra, attrList);

                        //特征值提取错误
                        if (t != null && t.getMErrno() == 0) {
                            List<T_AttrDetectRstItem_v2> tAttrDetectRstItemV2s = t.getFaceAttrList();
                            if (!tAttrDetectRstItemV2s.isEmpty()) {
                                T_AttrDetectRstItem_v2 attrDetectRstItem = tAttrDetectRstItemV2s.size() > 1 ?
                                        matchBestAttrDetectRstItem(tAttrDetectRstItemV2s) : tAttrDetectRstItemV2s.get(0);
                                updateEventFace(eventFace, attrList, attrDetectRstItem);
                            }
                        } else {
                            logger.error("extract EventFace[thumbnail_id is {}, url is {}] attribute failure, error msg is {}",
                                    eventFace.getThumbnailId(), eventFace.getThumbnailUrl(), t != null ? t.ErrMsg : "t is null");
                            warnCount++;
                        }
                    } catch (Exception e) {
                        logger.error("****** extract attribute failure", e);
                        warnCount++;
                    }
                }
            }
        }
        logger.info("****** {} had refreshed {} data totally, failure {} totally",
                Thread.currentThread().getName(), eventFaces.size(), warnCount);
    }

    private T_AttrDetectRstItem_v2 matchBestAttrDetectRstItem(List<T_AttrDetectRstItem_v2> tAttrDetectRstItemV2s) {
        try {
            tAttrDetectRstItemV2s.sort((o1, o2) -> {
                if (StringUtils.isEmpty(o1.getFaceAttrInfo())) {
                    return -1;
                }
                if (StringUtils.isEmpty(o2.getFaceAttrInfo())) {
                    return 1;
                }

                FaceAttrInfo faceAttrInfo1 = JSON.parseObject(o1.getFaceAttrInfo(), FaceAttrInfo.class);
                FaceAttrInfo faceAttrInfo2 = JSON.parseObject(o2.getFaceAttrInfo(), FaceAttrInfo.class);
                List<t_if_rect_t> faceRect1 = JSON.parseArray(faceAttrInfo1.getFaceRect(), t_if_rect_t.class);
                List<t_if_rect_t> faceRect2 = JSON.parseArray(faceAttrInfo2.getFaceRect(), t_if_rect_t.class);
                if (faceRect1.isEmpty()) {
                    return -1;
                }
                if (faceRect2.isEmpty()) {
                    return 1;
                }

                t_if_rect_t rect1 = faceRect1.get(0);
                t_if_rect_t rect2 = faceRect2.get(0);
                int multiplies1 = Math.abs((rect1.top - rect1.bottom) * (rect1.right - rect1.left));
                int multiplies2 = Math.abs((rect2.top - rect2.bottom) * (rect2.right - rect2.left));

                return multiplies1 > multiplies2 ? 1 : -1;
            });
        } catch (Exception ignored) {
            // nothing
        }
        return tAttrDetectRstItemV2s.get(tAttrDetectRstItemV2s.size() - 1);
    }

    private T_MulAttrDetectRstRsp_v2 getAttrDetectRstRsp(EventFace eventFace, int beFeaExtra, List<Integer> attrList) {
        T_MulAttrDetectRstRsp_v2 t;
        IFaaServiceThriftClient thriftClient = IFaaServiceThriftClient.getInstance();
        if (appConfig.isRefreshThriftV3() && StringUtils.isNotEmpty(eventFace.getTargetRect()) &&
                StringUtils.isNotEmpty(eventFace.getTargetThumbnailRect())) {
            try {
                RectInfo targetRect = JSON.parseObject(eventFace.getTargetRect(), RectInfo.class);
                RectInfo targetThumbnailRect = JSON.parseObject(eventFace.getTargetThumbnailRect(), RectInfo.class);
                t_if_rect_t t1 = getThriftRect(targetRect);
                t_if_rect_t t2 = getThriftRect(targetThumbnailRect);
                t = thriftClient.if_image_detect_extract_url_v3(eventFace.getThumbnailUrl(), attrList, t1, t2,
                        beFeaExtra, appConfig.getRefreshExceptVersion());
            } catch (Exception e) {
                attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
                t = thriftClient.if_image_detect_extract_url_v2(eventFace.getThumbnailUrl(), attrList, beFeaExtra,
                        appConfig.getRefreshExceptVersion());
            }
        } else {
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_QUALITY.getValue());
            t = thriftClient.if_image_detect_extract_url_v2(eventFace.getThumbnailUrl(), attrList, beFeaExtra,
                    appConfig.getRefreshExceptVersion());
        }
        return t;
    }

    @NotNull
    private t_if_rect_t getThriftRect(RectInfo targetRect) {
        t_if_rect_t rect = new t_if_rect_t();
        rect.setTop(targetRect.getTop());
        rect.setBottom(targetRect.getBottom());
        rect.setLeft(targetRect.getLeft());
        rect.setRight(targetRect.getRight());
        return rect;
    }

    private void updateEventFace(EventFace eventFace, List<Integer> attrList, T_AttrDetectRstItem_v2
            attrDetectRstItem) {
        // 更新特征值信息
        if (ArrayUtils.isEmpty(eventFace.getFeatureInfo())) {
            eventFace.setFeatureInfo(attrDetectRstItem.getFeature());
        }

        String faceAttrInfoStr = attrDetectRstItem.getFaceAttrInfo();
        // 更新 FaceAttrInfo
        updateFaceAttrInfo(eventFace, attrList, faceAttrInfoStr);
    }

    private void updateFaceAttrInfo(EventFace eventFace, List<Integer> attrList, String faceAttrInfoStr) {

        if (StringUtils.isNotEmpty(faceAttrInfoStr)) {
            FaceAttrInfo faceAttrInfo = JSON.parseObject(faceAttrInfoStr, FaceAttrInfo.class);

            if (null != faceAttrInfo) {

                // 更新轮廓信息
                if (StringUtils.isEmpty(eventFace.getLandMarkInfo())) {
                    List<String> landMark = JSON.parseArray(faceAttrInfo.getLandMark(), String.class);
                    if (landMark != null && !landMark.isEmpty()) {
                        eventFace.setLandMarkInfo(landMark.get(0));
                    }
                }

                // 更新人脸框位置
                List<String> faceRect = JSON.parseArray(faceAttrInfo.getFaceRect(), String.class);
                if (faceRect != null && !faceRect.isEmpty() && StringUtils.isEmpty(eventFace.getTargetRect())) {
                    eventFace.setTargetRect(faceRect.get(0));
                }

                // 更新其他人脸属性
                List<Attributes> attributesList = JSONArray.parseArray(faceAttrInfo.getAttributes(), Attributes.class);

                if (null != attributesList && !attributesList.isEmpty()) {
                    Attributes attributes = attributesList.get(0);

                    //性别
                    if (attrList.contains(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue())) {
                        eventFace.setGenderInfo(AttributeParser.parseGender(getNewGender(attributes)));
                    }

                    //年龄
                    if (attrList.contains(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_AGE.getValue())) {
                        // 更新年龄信息
                        eventFace.setAgeInfo(AttributeParser.parseAge(getNewAge(attributes)));
                    }

                    //穿戴(长短发属性暂时没有提取)
                    if (attrList.contains(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_DRESS.getValue())) {
                        int newAccessories = getNewAccessories(attributes);
                        // 更新穿短发信息
                        eventFace.setHairstyleInfo(AttributeParser.parseHairStyle(newAccessories));
                        // 更新帽子信息
                        eventFace.setHatInfo(AttributeParser.parseHat(newAccessories));
                        // 更新眼镜信息
                        eventFace.setGlassesInfo(AttributeParser.parseGlasses(newAccessories));
                    }

                    //种族
                    if (attrList.contains(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue())) {
                        eventFace.setRaceInfo(AttributeParser.parseRace(getNewRace(attributes)));
                    }

                    //pose & quality
                    if (attrList.contains(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue())) {
                        // 更新质量
                        Float qualityInfo = Float.valueOf(attributes.getQuality());
                        eventFace.setQualityInfo(qualityInfo);

                        try {
                            List<Headpose> headposeList = JSONArray.parseArray(attributes.getHeadpose(), Headpose.class);
                            if (!headposeList.isEmpty()) {
                                Headpose hp = headposeList.get(0);
                                Pose p = new Pose(hp.getPitch_angle(), hp.getRoll_angle(), hp.getYaw_angle());
                                // 更新 pose
                                eventFace.setPoseInfo(JSON.toJSONString(p));
                            }
                        } catch (Exception e) {
                            logger.error("", e);
                        }

                    }
                }
            }
        }
    }

    /**
     * 是否需要重刷
     */
    private boolean isNeedRefresh(EventFace eventFace, List<Integer> attrList) {
        boolean flag = false;

        if (appConfig.isRefreshAge() && StringUtils.isEmpty(eventFace.getAgeInfo())) {
            flag = true;
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_AGE.getValue());
        }

        if (appConfig.isRefreshGender() && StringUtils.isEmpty(eventFace.getGenderInfo())) {
            flag = true;
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_GENDER.getValue());
        }

        if (appConfig.isRefreshRace() && StringUtils.isEmpty(eventFace.getRaceInfo())) {
            flag = true;
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_RACE.getValue());
        }

        if ((appConfig.isRefreshPose() && StringUtils.isEmpty(eventFace.getPoseInfo()))
                || (appConfig.isRefreshQuality() && (eventFace.getQualityInfo() == null || eventFace.getQualityInfo() <= 0))) {
            flag = true;
            // pose和quality 使用的一个模型
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_POSE.getValue());
        }

        if (appConfig.isRefreshGlassesInfo() && StringUtils.isEmpty(eventFace.getGlassesInfo())) {
            flag = true;
            attrList.add(E_FACE_ATTRIBUTE_LIST.FACE_ATTR_DRESS.getValue());
        }

        if (appConfig.isRefreshTargetRect() && StringUtils.isEmpty(eventFace.getTargetRect())) {
            flag = true;
        }

        if (appConfig.isRefreshLandMarkInfo() && StringUtils.isEmpty(eventFace.getLandMarkInfo())) {
            flag = true;
        }

        return flag;
    }

    private int getNewAge(Attributes attributes) {
        int age = attributes.getAge();
        //年龄段
        int ageBracket = 0;
        if (age > 0) {
            if (age <= 5) {
                ageBracket = 1;
            } else if (age <= 10) {
                ageBracket = 2;
            } else if (age <= 15) {
                ageBracket = 3;
            } else if (age <= 20) {
                ageBracket = 4;
            } else if (age <= 25) {
                ageBracket = 5;
            } else if (age <= 30) {
                ageBracket = 6;
            } else if (age <= 50) {
                ageBracket = 7;
            } else if (age <= 60) {
                ageBracket = 8;
            } else {
                ageBracket = 9;
            }
        }

        String ageBracketStr = String.format("%08d", Long.parseLong(Integer.toBinaryString(ageBracket)));
        String ageStr = String.format("%08d", Long.parseLong(Integer.toBinaryString(age)));
        BigInteger complexAge = new BigInteger(ageStr + ageBracketStr, 2);

        return complexAge.intValue();
    }

    private int getNewGender(Attributes attributes) {
        String gender = attributes.getGender().trim();
        int detectGender = 0;
        switch (gender) {
            case "male":
                detectGender = 1;
                break;
            case "female":
                detectGender = 2;
                break;
            case UNKNOW:
                break;
            default:
        }
        String genderStr = String.format("%04d", Long.parseLong(Integer.toBinaryString(detectGender)));
        BigInteger complexGender = new BigInteger(ATTRIBUTE_PREFIX + genderStr, 2);
        return complexGender.intValue();
    }

    private int getNewAccessories(Attributes attributes) {
        String glass = attributes.getGlass().trim();
        int detectGlass = 0;
        switch (glass) {
            case "none":
                detectGlass = 1;
                break;
            case "yes":
                detectGlass = 2;
                break;
            case "dark":
                detectGlass = 3;
                break;
            case UNKNOW:
                detectGlass = 0;
                break;
            default:
        }
        String glassStr = String.format("%04d", Long.parseLong(Integer.toBinaryString(detectGlass)));

        String hat = attributes.getHat().trim();
        int detectHat = 0;
        switch (hat) {
            case "none":
                detectHat = 1;
                break;
            case "yes":
                detectHat = 2;
                break;
            case UNKNOW:
                detectHat = 0;
                break;
            default:
        }
        String hatStr = String.format("%04d", Long.parseLong(Integer.toBinaryString(detectHat)));

        int detectHair = 0;
        String hairStr = String.format("%04d", Long.parseLong(Integer.toBinaryString(detectHair)));

        //穿戴（长短发+帽子+眼镜）
        BigInteger complexAccessories = new BigInteger(ATTRIBUTE_PREFIX + hairStr + ATTRIBUTE_PREFIX + hatStr + ATTRIBUTE_PREFIX + glassStr, 2);
        return complexAccessories.intValue();
    }

    private int getNewRace(Attributes attributes) {
        String race = attributes.getEthnicity().trim();
        int detectRace;
        switch (race) {
            case "asian":
                detectRace = 0;
                break;
            case "non-Asian":
                detectRace = 1;
                break;
            default:
                detectRace = 0;
                break;
        }
        String raceStr = String.format("%04d", Long.parseLong(Integer.toBinaryString(detectRace)));
        BigInteger complexRace = new BigInteger(ATTRIBUTE_PREFIX + raceStr, 2);
        return complexRace.intValue();
    }
}
