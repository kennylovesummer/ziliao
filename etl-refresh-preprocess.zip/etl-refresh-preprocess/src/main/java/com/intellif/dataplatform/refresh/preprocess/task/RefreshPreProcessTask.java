package com.intellif.dataplatform.refresh.preprocess.task;

import com.intellif.dataplatform.common.domain.EventFace;
import com.intellif.dataplatform.common.sync.collector.MessageCollector;
import com.intellif.dataplatform.common.sync.reader.Reader;
import com.intellif.dataplatform.common.sync.reader.ReaderConfig;
import com.intellif.dataplatform.common.sync.transport.Exchange;
import com.intellif.dataplatform.common.sync.transport.ExchangeConfig;
import com.intellif.dataplatform.common.sync.transport.RecordExchange;
import com.intellif.dataplatform.common.sync.writer.Writer;
import com.intellif.dataplatform.common.sync.writer.WriterConfig;
import com.intellif.dataplatform.common.util.ThreadFactoryUtils;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.core.EventFaceGpReader;
import com.intellif.dataplatform.refresh.preprocess.core.EventFaceGpWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 重刷抽象类
 *
 * @author w1992wishes 2018/12/12 14:35
 */
public class RefreshPreProcessTask implements Runnable {

    private static final Logger LOG = LogManager.getLogger(RefreshPreProcessTask.class);

    private ExecutorService taskThreadPool;

    private Reader reader;
    private Writer writer;
    private Exchange<EventFace> exchange;
    private MessageCollector collector;

    public RefreshPreProcessTask(AppConfig appConfig) {
        ExchangeConfig exchangeConfig = initExchangeConfig(appConfig);
        ReaderConfig readerConfig = initReaderConfig(appConfig);
        WriterConfig writerConfig = initWriterConfig(appConfig);
        this.exchange = new RecordExchange<>(exchangeConfig);
        this.collector = new MessageCollector("mapdb/time.db");
        this.reader = new EventFaceGpReader(readerConfig, exchange, collector);
        this.writer = new EventFaceGpWriter(appConfig, writerConfig, exchange, collector);
        taskThreadPool = Executors.newFixedThreadPool(2, ThreadFactoryUtils.getNameThreadFactory("RefreshPreProcessTask-Thread-"));
    }

    private ExchangeConfig initExchangeConfig(AppConfig appConfig) {
        ExchangeConfig config = new ExchangeConfig();
        config.setCapacity(appConfig.getExchangeCapacity());
        return config;
    }

    private WriterConfig initWriterConfig(AppConfig appConfig) {
        WriterConfig config = new WriterConfig();
        config.setSinkTable(appConfig.getDwdFaceTable());
        config.setWriteThreadNum(appConfig.getWriterThreads());
        config.setErrorRatio(appConfig.getWriterErrorRatio());
        return config;
    }

    private ReaderConfig initReaderConfig(AppConfig appConfig) {
        ReaderConfig config = new ReaderConfig();
        config.setSourceTable(appConfig.getOdlPendingTable());
        config.setReaderSecondRange(appConfig.getRefreshSecondRange());
        config.setReaderTimeStep(appConfig.getReaderTimeStep());
        return config;
    }

    @Override
    public final void run() {
        long start = System.currentTimeMillis();
        Future<Boolean> readerFinished = taskThreadPool.submit(reader);
        Future<Boolean> writerFinished = taskThreadPool.submit(writer);
        try {
            if (readerFinished.get() && writerFinished.get()) {
                long end = System.currentTimeMillis();
                LOG.info("****** finish one round {}ms, totally {} data. read speed {}ms, " +
                                "action speed {}ms, write speed {}ms, transfer speed {}ms.******",
                        (end - start), collector.getReadeDataNum(), collector.getReadTime(),
                        collector.getActionTime(), collector.getWriteTime(), collector.getTransferTime());
            } else {
                writerFinished.cancel(true);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            LOG.error("", e);
        } finally {
            collector.reset();
            exchange.clear();
        }
    }

}
