package com.intellif.dataplatform.refresh.preprocess.action.preprocess;

import com.intellif.dataplatform.refresh.preprocess.action.Action;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;

import java.util.List;

/**
 * @author w1992wishes 2019/4/30 11:21
 */
public abstract class AbstractPreProcessAction<T> extends Action<T> {

    AbstractPreProcessAction(AppConfig appConfig, Action<T> nextAction) {
        super(appConfig, nextAction);
    }

    @Override
    public void doAction(List<T> list) {

        doPreProcessAction(list);

        if (nextAction != null) {
            nextAction.doAction(list);
        }
    }

    abstract void doPreProcessAction(List<T> list);
}
