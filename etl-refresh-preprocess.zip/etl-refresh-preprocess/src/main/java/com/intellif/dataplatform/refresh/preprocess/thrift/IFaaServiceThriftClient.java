package com.intellif.dataplatform.refresh.preprocess.thrift;

import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.ifaas.IFaaService;
import com.intellif.dataplatform.refresh.preprocess.ifaas.T_MulAttrDetectRstRsp_v2;
import com.intellif.dataplatform.refresh.preprocess.ifaas.t_if_rect_t;
import com.intellif.dataplatform.refresh.preprocess.thrift.failover.FailoverChecker;
import com.intellif.dataplatform.refresh.preprocess.thrift.loadbalance.LoadBalancer;
import com.intellif.dataplatform.refresh.preprocess.thrift.loadbalance.RandomLoad;
import com.intellif.dataplatform.refresh.preprocess.thrift.loadbalance.WeightLoad;
import com.intellif.dataplatform.refresh.preprocess.thrift.pool.DefaultThriftConnectionPool;
import com.intellif.dataplatform.refresh.preprocess.thrift.pool.ThriftConnectionFactory;
import com.intellif.dataplatform.refresh.preprocess.thrift.pool.ThriftConnectionPool;
import com.intellif.dataplatform.refresh.preprocess.thrift.pool.ThriftServer;
import org.apache.commons.pool2.impl.GenericKeyedObjectPoolConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TTransport;

import java.util.List;

/**
 * @author Administrator
 */
public class IFaaServiceThriftClient implements IFaceSdkTarget {

    private static final Logger LOG = LogManager.getLogger(IFaaServiceThriftClient.class);

    private AppConfig appConfig = new AppConfig();

    private ThriftConnectionPool thriftConnectionPool;

    private List<ThriftServer> servers;

    private LoadBalancer loadBalancer;

    private FailoverChecker failoverChecker;

    private IFaaServiceThriftClient() {
        this.servers = ThriftServer.parse(appConfig.getRefreshEngine());
        initPool();
        this.loadBalancer = getLoadBalancer();
    }

    private void initPool() {
        GenericKeyedObjectPoolConfig config = new GenericKeyedObjectPoolConfig();
        // 最大空闲连接数
        config.setMinIdlePerKey(20);
        // 最大连接数
        config.setMaxTotal(appConfig.getRefreshThreadNum());
        // 从连接池获取连接的时候需要测试
        config.setTestOnBorrow(true);
        // 创建连接的时候需要测试
        config.setTestOnCreate(true);
        // 归还连接的时候需要测试
        config.setTestOnReturn(true);
        // 连接空闲的时候需要测试
        config.setTestWhileIdle(true);
        // 连接的空闲的最长时间，需要testWhileIdle为true，默认5分钟
        config.setMinEvictableIdleTimeMillis(1000 * 60 * 5);
        // 失效检测时间，需要testWhileIdle为true，默认5分钟
        config.setTimeBetweenEvictionRunsMillis(1000 * 60 * 5);
        // 每次检查连接的数量，需要testWhileIdle为true
        config.setNumTestsPerEvictionRun(3);
        // 设置为true时，池中无可用连接，borrow时进行阻塞；为false时，当池中无可用连接，抛出NoSuchElementException异常
        // config.setBlockWhenExhausted(true);

        this.failoverChecker = new FailoverChecker(TTransport::isOpen);
        this.thriftConnectionPool = new DefaultThriftConnectionPool(new ThriftConnectionFactory(appConfig.getSocketTimeout(), failoverChecker), config);
        failoverChecker.setServerList(servers);
        failoverChecker.setConnectionPool(thriftConnectionPool);
        failoverChecker.startChecking();
    }

    private LoadBalancer getLoadBalancer() {
        switch (appConfig.getLoadBalancer()) {
            case LoadBalancer.LoadBalance.RANDOM:
                return new RandomLoad();
            case LoadBalancer.LoadBalance.WEIGHT:
                return new WeightLoad();
            default:
                return new RandomLoad();
        }
    }

    private static class InstanceHolder{
        private static IFaaServiceThriftClient instance = new IFaaServiceThriftClient();
    }

    public static IFaaServiceThriftClient getInstance() {
        return InstanceHolder.instance;
    }

    @Override
    public T_MulAttrDetectRstRsp_v2 if_image_detect_extract_url_v2(String inputImg, List<Integer> AttrEnList, int beFeaExtra, int algType) {
        T_MulAttrDetectRstRsp_v2 result = null;
        TTransport tTransport = null;
        ThriftServer server = loadBalancer.getServerInstance(failoverChecker.getAvailableServers());
        try {
            tTransport = thriftConnectionPool.getConnection(server);
            TProtocol protocol = new TBinaryProtocol(tTransport);
            IFaaService.Iface client = ReconnectingThriftClient.wrap(new IFaaService.Client(protocol), IFaaService.Iface.class);
            result = client.if_image_detect_extract_url_v2(inputImg, AttrEnList, beFeaExtra, algType);
        } catch (Exception e) {
            LOG.error("image detect feature error:", e);
        } finally {
            thriftConnectionPool.returnConnection(server, tTransport);
        }
        return result;
    }

    @Override
    public T_MulAttrDetectRstRsp_v2 if_image_detect_extract_url_v3(String inputImg, List<Integer> AttrEnList, t_if_rect_t rFaceRect,
                                                                   t_if_rect_t rFaceImageRect, int beFeaExtra, int algType) {
        T_MulAttrDetectRstRsp_v2 result = null;
        TTransport tTransport = null;
        ThriftServer server = loadBalancer.getServerInstance(failoverChecker.getAvailableServers());
        try {
            tTransport = thriftConnectionPool.getConnection(server);
            TProtocol protocol = new TBinaryProtocol(tTransport);
            IFaaService.Iface client = ReconnectingThriftClient.wrap(new IFaaService.Client(protocol), IFaaService.Iface.class);
            result = client.if_image_detect_extract_url_v3(inputImg, AttrEnList, rFaceRect, rFaceImageRect, beFeaExtra, algType);
        } catch (Exception e) {
            LOG.error("image detect feature error:", e);
        } finally {
            thriftConnectionPool.returnConnection(server, tTransport);
        }
        return result;
    }
}