package com.intellif.dataplatform.refresh.preprocess.domain;

public class FeatureSendStr<T> {

    private String operate = "search";

    private T data;

    public FeatureSendStr(T data) {
        this.data = data;
    }

    public FeatureSendStr(String operate, T data) {
        this.data = data;
        this.operate = operate;
    }

    public String getOperate() {
        return operate;
    }

    public void setOperate(String operate) {
        this.operate = operate;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
