package com.intellif.dataplatform.refresh.preprocess.util;

import com.alibaba.fastjson.JSON;
import com.intellif.dataplatform.common.domain.FeatureQualityConfig;
import com.intellif.dataplatform.common.domain.PoseInfo;
import com.intellif.dataplatform.common.util.ArithUtils;
import com.intellif.dataplatform.common.util.PoseInfoUtils;
import com.intellif.dataplatform.refresh.preprocess.config.PreProcessConfig;
import com.intellif.dataplatform.util.FeatureQualityUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author w1992wishes 2019/4/18 10:41
 */
public class PreProcessUtils {

    // 字段缺失或者字段格式不对归为该类
    private static final float USELESS_QUALITY = -3.0f;
    // 计算出的不可归档不可聚档归为该类
    private static final float UNCLASS_QUALITY = -2.0f;
    // 计算出的可归档不可聚档归为该类
    private static final float CLASS_QUALITY = -1.0f;

    private static final Logger LOG = LogManager.getLogger(PreProcessUtils.class);

    /**
     * 计算特征值质量
     *
     * @param config      配置属性
     * @param featureInfo 特征值信息
     * @param poseInfo    角度信息
     * @param qualityInfo 质量信息
     */
    public static float calculateFeatureQuality(PreProcessConfig config, FeatureQualityConfig featureQualityConfig, byte[] featureInfo, String poseInfo, Float qualityInfo) {

        PoseInfo poseInfoModel;
        float featureQuality;
        if (StringUtils.isNotEmpty(poseInfo) && ArrayUtils.isNotEmpty(featureInfo)) {
            try {
                poseInfoModel = JSON.parseObject(poseInfo, PoseInfo.class);
                featureQuality = calculateFeatureQuality(config, featureQualityConfig, poseInfoModel, qualityInfo);
            } catch (Exception e) {
                featureQuality = USELESS_QUALITY;
                LOG.error("****** json parse to XPose failure, json is {}", poseInfo);
            }
        } else {
            featureQuality = USELESS_QUALITY;
        }
        return ArithUtils.round(featureQuality, 4);
    }


    private static float calculateClusterFeatureQuality(Float quality, PoseInfo poseInfo, FeatureQualityConfig config) {
        return FeatureQualityUtils.getFeatureQuality(quality, poseInfo, config);
    }

    private static boolean clusterPoseFilter(PoseInfo poseInfo, PreProcessConfig config) {
        return PoseInfoUtils.inAngle(poseInfo, config.getClusterPitchThreshold(), config.getClusterRollThreshold(), config.getClusterYawThreshold());
    }

    private static boolean classPoseFilter(PoseInfo poseInfo, PreProcessConfig config) {
        return PoseInfoUtils.inAngle(poseInfo, config.getClassPitchThreshold(), config.getClassRollThreshold(), config.getClassYawThreshold());
    }

    private static boolean clusterQualityFilter(float quality, float clusterQualityThreshold) {
        return quality >= clusterQualityThreshold;
    }

    private static boolean classQualityFilter(float quality, float classQualityThreshold) {
        return quality >= classQualityThreshold;
    }

    /**
     * 计算特征值质量
     *
     * @param config   阈值
     * @param poseInfo 角度
     * @param quality  质量分值
     * @return 特征质量
     */
    private static float calculateFeatureQuality(PreProcessConfig config, FeatureQualityConfig featureQualityConfig, PoseInfo poseInfo, Float quality) {
        float featureQuality;
        if (clusterQualityFilter(quality, config.getClusterQualityThreshold()) && clusterPoseFilter(poseInfo, config)) {
            featureQuality = calculateClusterFeatureQuality(quality, poseInfo, featureQualityConfig);
        } else if (classQualityFilter(quality, config.getClassQualityThreshold()) && classPoseFilter(poseInfo, config)) {
            featureQuality = CLASS_QUALITY;
        } else {
            featureQuality = UNCLASS_QUALITY;
        }
        return featureQuality;
    }
}
