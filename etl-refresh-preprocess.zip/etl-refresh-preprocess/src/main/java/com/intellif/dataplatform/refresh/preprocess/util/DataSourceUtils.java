package com.intellif.dataplatform.refresh.preprocess.util;

import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.sql.DataSource;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 连接工具类
 *
 * @author w1992wishes 2018/11/8 14:29
 */
public class DataSourceUtils {

    private static final Logger LOG = LogManager.getLogger(DataSourceUtils.class);

    private DataSourceUtils() {
    }

    private static String odlDriver = PropertiesUtils.getStringValue("odl.driver");
    private static String odlUrl = PropertiesUtils.getStringValue("odl.url");
    private static String odlUser = PropertiesUtils.getStringValue("odl.user");
    private static String odlPasswd = PropertiesUtils.getStringValue("odl.passwd");

    private static String dwdDriver = PropertiesUtils.getStringValue("dwd.driver");
    private static String dwdUrl = PropertiesUtils.getStringValue("dwd.url");
    private static String dwdUser = PropertiesUtils.getStringValue("dwd.user");
    private static String dwdPasswd = PropertiesUtils.getStringValue("dwd.passwd");

    private static String alertDriver = PropertiesUtils.getStringValue("alert.driver");
    private static String alertUrl = PropertiesUtils.getStringValue("alert.url");
    private static String alertUser = PropertiesUtils.getStringValue("alert.user");
    private static String alertPasswd = PropertiesUtils.getStringValue("alert.passwd");

    private static DataSource ALERT_DBCP;

    private static DataSource getDataSource(String fileName, String url, String user, String passwd, String driver) {
        Properties pro = new Properties();
        try (InputStream is = new FileInputStream("." + File.separator + "config" + File.separator + fileName)) {
            pro.load(is);
            pro.setProperty("username", user);
            pro.setProperty("password", passwd);
            pro.setProperty("driverClassName", driver);
            pro.setProperty("url", url);
            return BasicDataSourceFactory.createDataSource(pro);
        } catch (Exception e) {
            LOG.error("Connection initialization error!", e);
            throw new ExceptionInInitializerError("****** Connection initialization error!");
        }
    }

    private static class Holder {
        private static final DataSource ODL_DBCP = getDataSource("odl_dbcp.properties", odlUrl, odlUser, odlPasswd, odlDriver);
        private static final DataSource DWD_DBCP = getDataSource("dwd_dbcp.properties", dwdUrl, dwdUser, dwdPasswd, dwdDriver);
    }

    public static Connection getOdlConnection() throws SQLException {
        return Holder.ODL_DBCP.getConnection();
    }

    public static Connection getDwdConnection() throws SQLException {
        return Holder.DWD_DBCP.getConnection();
    }

    public static Connection getAlertConnection() throws SQLException {
        if (ALERT_DBCP == null) {
            synchronized (DataSourceUtils.class) {
                if (ALERT_DBCP == null) {
                    ALERT_DBCP = getDataSource("alert_dbcp.properties", alertUrl, alertUser, alertPasswd, alertDriver);
                }
            }
        }
        return ALERT_DBCP.getConnection();
    }

}
