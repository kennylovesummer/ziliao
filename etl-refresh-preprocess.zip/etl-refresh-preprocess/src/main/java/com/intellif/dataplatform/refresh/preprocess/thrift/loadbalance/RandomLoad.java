package com.intellif.dataplatform.refresh.preprocess.thrift.loadbalance;

import com.intellif.dataplatform.common.exception.DataplatformRuntimeException;
import com.intellif.dataplatform.refresh.preprocess.thrift.pool.ThriftServer;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author w1992wishes 2019/6/19 16:30
 */
public class RandomLoad implements LoadBalancer {

    private int randomNextInt() {
        return ThreadLocalRandom.current().nextInt();
    }

    @Override
    public ThriftServer getServerInstance(List<ThriftServer> servers) {
        if (servers.isEmpty()) {
            throw new DataplatformRuntimeException("****** No server available. ******");
        }
        return servers.get(randomNextInt() % servers.size());
    }
}
