package com.intellif.dataplatform.refresh.preprocess.action.preprocess;

import com.intellif.dataplatform.common.domain.EventFace;
import com.intellif.dataplatform.common.domain.FeatureQualityConfig;
import com.intellif.dataplatform.refresh.preprocess.action.Action;
import com.intellif.dataplatform.refresh.preprocess.config.AppConfig;
import com.intellif.dataplatform.refresh.preprocess.config.PreProcessConfig;
import com.intellif.dataplatform.refresh.preprocess.util.PreProcessUtils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author w1992wishes 2019/4/30 11:28
 */
public class EventFacePreProcessAction extends AbstractPreProcessAction<EventFace> {

    private PreProcessConfig preProcessConfig;
    private FeatureQualityConfig featureQualityConfig;

    public EventFacePreProcessAction(AppConfig appConfig, Action<EventFace> nextAction) {
        super(appConfig, nextAction);
        this.preProcessConfig = new PreProcessConfig();
        this.featureQualityConfig = new FeatureQualityConfig();
        this.featureQualityConfig.setQ_base(this.preProcessConfig.getqBase());
        this.featureQualityConfig.setQ_good(this.preProcessConfig.getqGood());
        this.featureQualityConfig.setQ_high(this.preProcessConfig.getqHigh());
    }

    @Override
    void doPreProcessAction(List<EventFace> eventFaces) {

        eventFaces.forEach(eventFace -> {
            eventFace.setFeatureQuality(
                    PreProcessUtils.calculateFeatureQuality(
                            this.preProcessConfig, this.featureQualityConfig, eventFace.getFeatureInfo(), eventFace.getPoseInfo(), eventFace.getQualityInfo()));
            eventFace.setSaveTime(Timestamp.valueOf(LocalDateTime.now().withNano(0)));
        });
    }


}
