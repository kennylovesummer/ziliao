package com.intellif.dataplatform.refresh.preprocess.config;

import com.intellif.dataplatform.refresh.preprocess.util.PropertiesUtils;

/**
 * @author w1992wishes 2019/4/18 11:07
 */
public class PreProcessConfig {

    /**
     * 聚档阈值
     */
    private float clusterQualityThreshold = PropertiesUtils.getFloatValue("preProcess.clusterQualityThreshold", 0.79f);

    private float clusterPitchThreshold = PropertiesUtils.getFloatValue("preProcess.clusterPitchThreshold", 14f);

    private float clusterRollThreshold = PropertiesUtils.getFloatValue("preProcess.clusterRollThreshold", 14f);

    private float clusterYawThreshold = PropertiesUtils.getFloatValue("preProcess.clusterYawThreshold", 14f);

    /**
     * 归档阈值
     */
    private float classQualityThreshold = PropertiesUtils.getFloatValue("preProcess.classQualityThreshold", 0.3f);

    private float classPitchThreshold = PropertiesUtils.getFloatValue("preProcess.classPitchThreshold", 59f);

    private float classRollThreshold = PropertiesUtils.getFloatValue("preProcess.classRollThreshold", 49f);

    private float classYawThreshold = PropertiesUtils.getFloatValue("preProcess.classYawThreshold", 43f);

    private float qBase = PropertiesUtils.getFloatValue("preProcess.quality.base", 05.f);

    private float qGood = PropertiesUtils.getFloatValue("preProcess.quality.good", 07.f);

    private float qHigh = PropertiesUtils.getFloatValue("preProcess.quality.high", 0.85f);

    public float getClusterQualityThreshold() {
        return clusterQualityThreshold;
    }

    public float getClusterPitchThreshold() {
        return clusterPitchThreshold;
    }

    public float getClusterRollThreshold() {
        return clusterRollThreshold;
    }

    public float getClusterYawThreshold() {
        return clusterYawThreshold;
    }

    public float getClassQualityThreshold() {
        return classQualityThreshold;
    }

    public float getClassPitchThreshold() {
        return classPitchThreshold;
    }

    public float getClassRollThreshold() {
        return classRollThreshold;
    }

    public float getClassYawThreshold() {
        return classYawThreshold;
    }

    public float getqBase() {
        return qBase;
    }

    public float getqGood() {
        return qGood;
    }

    public float getqHigh() {
        return qHigh;
    }
}
