#!/bin/bash

if [ -n "${SERVICE_NAME}" ]; then
    echo -e "\033[32m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: AppId - ${SERVICE_NAME} \033[0m"

    # logs
    if [ ! -d "/opt/logs" ]; then
        mkdir -p /opt/logs
    else
        rm -rf /opt/${SERVICE_NAME}/logs
    fi
    ln -s /opt/logs /opt/${SERVICE_NAME}/logs

    # mapdb
    if [ ! -d "/opt/mapdb" ]; then
        mkdir -p /opt/mapdb
    else
        rm -rf /opt/${SERVICE_NAME}/mapdb
    fi
    ln -s /opt/mapdb /opt/${SERVICE_NAME}/mapdb

    # config
    if [ ! -d "/opt/conf" ]; then
        mkdir -p /opt/conf
    fi

    # config.properties set
    if [ ! -f "/opt/conf/config.properties" ]; then
        mv /opt/${SERVICE_NAME}/config/config.properties /opt/conf
        if [ -n "$GREENPLUM_IP" ]; then
            sed -i "s#greenplum://127.0.0.1:5432#greenplum://${GREENPLUM_IP}#g" /opt/conf/config.properties
        fi
        if [ -n "KAFKA_ADDRESS"  ]; then
            sed -i "s#^kafka.bootstrap.servers.*#kafka.bootstrap.servers=${KAFKA_ADDRESS}#g" /opt/conf/config.properties
        fi
        if [ -n "${LOCAL_IP}"  ]; then
            sed -i "s#alert.url=jdbc:mysql://127.0.0.1#alert.url=jdbc:mysql://${LOCAL_IP}#g" /opt/conf/config.properties
        fi
    else
        rm -rf /opt/${SERVICE_NAME}/config/config.properties
    fi
    ln -s /opt/conf/config.properties /opt/${SERVICE_NAME}/config/config.properties

    # 映射其它配置文件
    if [ ! -f "/opt/conf/dwd_dbcp.properties" ]; then
        mv /opt/${SERVICE_NAME}/config/dwd_dbcp.properties /opt/conf
    else
        rm -rf /opt/${SERVICE_NAME}/config/dwd_dbcp.properties
    fi
    ln -s /opt/conf/dwd_dbcp.properties /opt/${SERVICE_NAME}/config/dwd_dbcp.properties

    if [ ! -f "/opt/conf/kafka.properties" ]; then
        mv /opt/${SERVICE_NAME}/config/kafka.properties /opt/conf
    else
        rm -rf /opt/${SERVICE_NAME}/config/kafka.properties
    fi
    ln -s /opt/conf/kafka.properties /opt/${SERVICE_NAME}/config/kafka.properties

    if [ ! -f "/opt/conf/odl_dbcp.properties" ]; then
        mv /opt/${SERVICE_NAME}/config/odl_dbcp.properties /opt/conf
    else
        rm -rf /opt/${SERVICE_NAME}/config/odl_dbcp.properties
    fi
    ln -s /opt/conf/odl_dbcp.properties /opt/${SERVICE_NAME}/config/odl_dbcp.properties
    
     if [ ! -f "/opt/conf/alert_dbcp.properties" ]; then
        mv /opt/${SERVICE_NAME}/config/alert_dbcp.properties /opt/conf
    else
        rm -rf /opt/${SERVICE_NAME}/config/alert_dbcp.properties
    fi
    ln -s /opt/conf/alert_dbcp.properties /opt/${SERVICE_NAME}/config/alert_dbcp.properties

    # build & version info
    count=`ls /opt/conf/*.data|wc -l`
    if [ ${count} -ne 0 ]; then rm -rf /opt/conf/*.data; fi
    cp /opt/${SERVICE_NAME}/*.data /opt/conf

    #bash setting_limits.sh
    cd /opt
    if grep -q "soft nofile 65536" /etc/security/limits.conf ; then
        echo -e "\032[31m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: Already initialized!!!"
    else
        ./setting_limits.sh
    fi

    # start app
    cd /opt/${SERVICE_NAME}
    if [ -n "${TYPE}" ]; then
        if [ -z "${APOLLO_ADMIN}" ]; then echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: Missing params APOLLO_ADMIN!!!";exit 1; fi
        until curl --silent --fail ${APOLLO_ADMIN}; do echo -e "\033[33m[`date +"%Y-%m-%d %H:%M:%S"`] WARNING: Waiting apollo admin start up!!!"; sleep 3; done
        if [ -n "${DELAY}" ]; then
            echo -e "\032[31m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: ${SERVICE_NAME} delay ${DELAY}s startup!!!"
            sleep ${DELAY}
        fi
        ./start.sh
    else
        ./start.sh
    fi
    if [ $? -ne 0 ]; then
        echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: ${SERVICE_NAME} start fail!!!"
        tail -n 1000 /opt/${SERVICE_NAME}/logs/*.log
        exit 1
    else
        echo -e "\033[32m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: Begin start ${SERVICE_NAME} ..." >> /opt/logs/info.log
        tail -fn 1000 /opt/logs/*.log
    fi
else
    echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: please set SERVICE_NAME!!!"
    exit 1
fi
