#!/bin/bash

if [ -n "$SERVICE_NAME" ]; then
    echo -e "\033[32m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: AppId - ${SERVICE_NAME} \033[0m"
    DB_NAME=${SERVICE_NAME//-/_}

    # logs
    if [ ! -d "/opt/logs" ]; then
        mkdir -p /opt/logs
    else
        rm -rf /opt/${SERVICE_NAME}/logs
    fi
    ln -s /opt/logs /opt/${SERVICE_NAME}/logs

    # config
    if [ ! -d "/opt/conf" ]; then
        mkdir -p /opt/conf
    fi
    # apollo ip set
    if [ ! -f "/opt/conf/apollo-env.properties" ]; then
        mv /opt/${SERVICE_NAME}/conf/apollo-env.properties /opt/conf
        if [ -n "$APOLLO_IP" ]; then
            sed -i "s#^dev.meta=.*#dev.meta=${APOLLO_IP}#g" /opt/conf/apollo-env.properties
            sed -i "s#^fat.meta=.*#fat.meta=${APOLLO_IP}#g" /opt/conf/apollo-env.properties
            sed -i "s#^uat.meta=.*#uat.meta=${APOLLO_IP}#g" /opt/conf/apollo-env.properties
            sed -i "s#^pro.meta=.*#pro.meta=${APOLLO_IP}#g" /opt/conf/apollo-env.properties
            sed -i "s#^appId=.*#appId=node#g" /opt/conf/apollo-env.properties
        fi
    else
        rm -rf /opt/${SERVICE_NAME}/conf/apollo-env.properties
    fi
    ln -s /opt/conf/apollo-env.properties /opt/${SERVICE_NAME}/conf/apollo-env.properties
    # apollo env name
    if [ ! -f "/opt/conf/server.properties" ]; then
        mv /opt/settings/server.properties /opt/conf
        if [ -n "$ENV" ]; then
            sed -i "s#^env=.*#env=${ENV}#g" /opt/conf/server.properties
        fi
    else
        rm -rf /opt/settings/server.properties
    fi
    ln -s /opt/conf/server.properties /opt/settings/server.properties

    # pqxxconn_base set IP
    if [ ! -f "/opt/conf/pqxxconn_base.conf" ]; then
        mv /opt/${SERVICE_NAME}/conf/pqxxconn_base.conf /opt/conf
        if [ -n ${LOCAL_IP} ]; then
            echo "will sed /opt/conf/pqxxconn_base.conf ip is ${LOCAL_IP}"
            sed -i "s#^localHostIP=.*#localHostIP=${LOCAL_IP}#g" /opt/conf/pqxxconn_base.conf
            sed -i "s#^hostaddr=.*#hostaddr=${LOCAL_IP}#g" /opt/conf/pqxxconn_base.conf
        fi
        
        # k8s部署上云，使用服务名,并等待pg启动完成
        if [[ -n ${K8S_SERVICE_NAME} ]]; then
            sed -i "s#^localHostIP=.*#localHostIP=${K8S_SERVICE_NAME}#g" /opt/conf/pqxxconn_base.conf
            echo "wait for pg ready 30 seconds"
            sleep 30
            i=1
            curl 127.0.0.1:5432 >/dev/null 2>&1
            pgResult=$?
            echo "curl 127.0.0.1:5432 result code is ${pgResult}"
            while [ ${pgResult} -ne 52 ]
                do
              echo "pg not ready,wait another 10 seconds, total 120 seconds"
              sleep 10
              let i++
              if [[ $i -eq 12 ]];then
                  echo "error: cannot connect to pgsql"
              break
              fi
              curl 127.0.0.1:5432 >/dev/null 2>&1
              pgResult=$?
            done
        fi


    else
        rm -rf /opt/${SERVICE_NAME}/conf/pqxxconn_base.conf
    fi
    ln -s /opt/conf/pqxxconn_base.conf /opt/${SERVICE_NAME}/conf/pqxxconn_base.conf

    # build & version info
    count=`ls /opt/conf/*.data|wc -l`
    if [ ${count} -ne 0 ]; then rm -rf /opt/conf/*.data; fi
    cp /opt/${SERVICE_NAME}/*.data /opt/conf

    # gpu_config.conf set IP
    if [ ! -f "/opt/conf/gpu_config.conf" ]; then
        mv /opt/${SERVICE_NAME}/conf/gpu_config.conf /opt/conf
    else
        rm -rf /opt/${SERVICE_NAME}/conf/gpu_config.conf
    fi
    ln -s /opt/conf/gpu_config.conf /opt/${SERVICE_NAME}/conf/gpu_config.conf

    # build & version info
    count=`ls /opt/conf/*.data|wc -l`
    if [ ${count} -ne 0 ]; then rm -rf /opt/conf/*.data; fi
    cp /opt/${SERVICE_NAME}/*.data /opt/conf

    # add /etc/ld.so.conf 
    cat /opt/${SERVICE_NAME}/linkRoute.txt >> /etc/ld.so.conf
    # Remove duplicate rows
    sed -r ':1;N;s/^(\S+)((\n.*)*)\n\1$/\1\2/M;$!b1' /etc/ld.so.conf
    ldconfig

    # start app
    cd /opt/${SERVICE_NAME}

   export apollo_appId='node'
    # apollo_appId='node'
    
    # Apollo的环境变量值是大写的,而在配置文件中的却是小写，修改Apollo配置前需要转换成大写的
    # ENV=${ENV^^}
    
    # Apollo配置修改需要的环境变量，容器运行时通过环境变量参数传递过来，值的形式如下：
    # export APOLLO_PORTAL="192.168.13.84:7903"
    # export ENV=pro
    # DEPLOY_NUM="5"
    # SERVICE_NAME="ifaas-isearchcloud-node-gpu"
    # ACTION=install


    for((i=1;i<=${DEPLOY_NUM};i++)); 
    do  
    NODES_TEST_2="${NODES_TEST_2},{\\\"GroupTopic${i}\\\": [\\\"${SERVICE_NAME}-${i}:group${i}\\\"]}"; 
    done
    NODES_TEST_2="[${NODES_TEST_2:1}]"
    NODES_TEST_3=$NODES_TEST_2;
    echo ${NODES_TEST_3}


    if [[ "${ACTION}" == "install" ]] && [[ -z "$(./apollo.sh "check" "application" "deployed" 2> /dev/null)" ]];then
      # 以下步骤只执行一次，重启不执行
      ./apollo.sh "update" "application" "deployed" "1" "是否首次修改的标志"
      ./apollo.sh "update" "intellif.search3.0-common" "nodes" "$NODES_TEST_3" "集群配置"
    elif [[ "${ACTION}" == "up" ]];then
      # 扩容时会执行，重启也会执行
      ./apollo.sh "update" "intellif.search3.0-common" "nodes" "$NODES_TEST_3" "集群配置"
    fi



    # # 修改引擎授权服务器地址示例,ACTION为upgrade时代表进行通过CMP进行升级，不修改Apollo配置，其它情况执行修改：
    # if [[ ${ACTION} != "upgrade" ]];then
    #     ./apollo.sh update "intellif.search3.0-common" "nodes" "$NODES_TEST_3" "集群配置"
    # fi

    
    if [ -n "${TYPE}" ]; then
        if [ -z "${APOLLO_ADMIN}" ]; then echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: Missing params APOLLO_ADMIN!!!";exit 1; fi
        until curl --silent --fail ${APOLLO_ADMIN}; do echo -e "\033[33m[`date +"%Y-%m-%d %H:%M:%S"`] WARNING: Waiting apollo admin start up!!!"; sleep 3; done
        if [ -n "${DELAY}" ]; then
            echo -e "\032[31m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: ${SERVICE_NAME} delay ${DELAY}s startup!!!"
            sleep ${DELAY}
        fi
        ./start.sh
    else
        ./start.sh
    fi

    if [ $? -ne 0 ]; then
        echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: ${SERVICE_NAME} start fail!!!"
        tail -n 1000 /opt/${SERVICE_NAME}/logs/*.log
        exit 1
    else
        echo -e "\033[32m[`date +"%Y-%m-%d %H:%M:%S"`] INFO: Begin start ${SERVICE_NAME} ..." >> /opt/logs/info.log
        tail -fn 1000 /opt/logs/*.log
    fi
else
    echo -e "\033[31m[`date +"%Y-%m-%d %H:%M:%S"`] ERROR: please set SERVICE_NAME!!!"
    exit 1
fi
